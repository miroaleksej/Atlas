# PRIMARY SOURCES — QPDTR/ΦQG CURRENT-STATE v2.5.0

Публикации задают математическое происхождение методов. Они не заменяют implementation tests, numerical equality, convergence certificates и claim gates.

## Tensor networks, stabilizer и CAMPS

- Aaronson, S.; Gottesman, D. *Improved Simulation of Stabilizer Circuits*. Physical Review A 70, 052328 (2004). DOI `10.1103/PhysRevA.70.052328`.
- *Automatic structural optimization of tree tensor networks*. Physical Review Research 5, 013031 (2023). DOI `10.1103/PhysRevResearch.5.013031`.
- *Classical simulability of circuits with Clifford-augmented matrix product states*. Physical Review Research 8, 023116 (2026). DOI `10.1103/ybnf-rjw8`.
- *Stabilizer Tensor Networks with Magic State Injection*. Physical Review Letters 134, 190602 (2025). DOI `10.1103/PhysRevLett.134.190602`.

## Decision diagrams и code-compiled circuits

- Cheng, B.; Wang, Z.; Deng, R.; Chen, J.; Ji, Z. *Breaking the Treewidth Barrier in Quantum Circuit Simulation with Decision Diagrams*. arXiv `2510.06775` (2025). Работа связывает размер FeynmanDD с linear rank-width и показывает классы, где этот параметр существенно меньше treewidth.
- Deger, A.; Koutsioumpas, S.; Webster, M.; Sayginel, H.; Roffe, J.; Browne, D. E. *Efficiently simulable quantum circuits with large entanglement, magic, and non-Gaussianity via code-compiled tensor networks*. arXiv `2607.08396` (2026). Работа использует CSS-code automorphisms, transversal diagonal gates и classical permutation tracking; bond dimension ограничивается стоимостью encoder.

Текущий QPDTR owner не копирует полную авторскую компиляцию. Он независимо реализует bounded phase-polynomial DD и executor уже проверенного diagonal/permutation certificate; CSS discovery, automorphism proof и arbitrary gate lowering остаются открытыми.

## Конструктивно положительная открытая tensor-train динамика

- Werner, A. H. et al. *Positive Tensor Network Approach for Simulating Open Quantum Many-Body Systems*. Physical Review Letters 116, 237201 (2016). arXiv `1412.5746`; DOI `10.1103/PhysRevLett.116.237201`.
- *Efficient simulation of open quantum systems using locally purified tensor networks*. arXiv `2409.08127` (2024).
- *Completely Positive Trace-Preserving Tensor-Train Time Integrators for Lindblad Dynamics*. arXiv `2605.01494` (2026).

Активный owner использует локально очищенное представление, exact local Kraus channels и nearest-neighbour unitary gates. SVD уменьшает bond и local-Kraus ranks, сохраняя факторизованную положительность; нелинейное state-dependent сжатие не объявляется линейным CPTP-каналом на произвольном входе.

## Basis-adaptive sparse simulation

- *Basis-Adaptive Sparse-State Simulation of Quantum Circuits*. arXiv `2605.27285` (2026).

Активный owner независимо реализует bounded top-k pure-state route: one-qubit RDM eigenbases рассматриваются как кандидаты, а participation-ratio gate отклоняет ухудшающие повороты. Generic mixed-state и product-basis-delocalized режимы не заявляются.

## Квазисвободные фермионные открытые системы

- Prosen, T. *Third quantization: a general method to solve master equations for quadratic open Fermi systems*. New Journal of Physics 10, 043026 (2008). DOI `10.1088/1367-2630/10/4/043026`.
- Barthel, T.; Zhang, Y. *Solving quasi-free and quadratic Lindblad master equations for open fermionic and bosonic systems*. Journal of Statistical Mechanics: Theory and Experiment 2022, 113101 (2022). arXiv `2112.08344`; DOI `10.1088/1742-5468/ac8e5c`.

Текущий exact owner ограничен number-conserving quadratic Hamiltonian и linear gain/loss Lindblad operators. Pairing/Bogoliubov, interactions и nonlinear jumps не включены в активный claim.

## Interacting impurity solver

- *Tree tensor network impurity solver based on Cayley-tree mapping*. Physical Review B 113, 195144 (2026). DOI `10.1103/ycty-d5f9`.
- Bauernfeind, D.; Aichhorn, M. *Time Dependent Variational Principle for Tree Tensor Networks*. SciPost Physics 8, 024 (2020). DOI `10.21468/SciPostPhys.8.2.024`.

Текущий owner использует Cayley bath mapping, interacting spinful SIAM, imaginary-time tensor-network preparation и symmetric real-time product formula. Star, chain и exact diagonalization являются bounded validation references, а не параллельными active owners.

## Open-system memory, learning и error certification

- Pollock, F. A. et al. *Non-Markovian quantum processes: Complete framework and efficient characterization*. Physical Review A 97, 012127 (2018). DOI `10.1103/PhysRevA.97.012127`.
- Strathearn, A. et al. *Efficient non-Markovian quantum dynamics using time-evolving matrix product operators*. Nature Communications 9, 3322 (2018). DOI `10.1038/s41467-018-05617-3`.
- Jørgensen, M. R.; Pollock, F. A. *Exploiting the Causal Tensor Network Structure of Quantum Processes to Efficiently Simulate Non-Markovian Path Integrals*. Physical Review Letters 123, 240602 (2019). DOI `10.1103/PhysRevLett.123.240602`.
- White, G. A. L. et al. *Demonstration of non-Markovian process characterisation and control on a quantum processor*. Nature Communications 11, 6301 (2020). DOI `10.1038/s41467-020-20113-3`.
- Guo, Y. et al. *Experimental Demonstration of Instrument-Specific Quantum Memory Effects and Non-Markovian Process Recovery for Common-Cause Processes*. Physical Review Letters 126, 230401 (2021). DOI `10.1103/PhysRevLett.126.230401`.
- Cygorek, M. et al. *Simulation of open quantum systems by automated compression of arbitrary environments*. Nature Physics 18, 662–668 (2022).
- White, G. A. L. et al. *Non-Markovian Quantum Process Tomography*. PRX Quantum 3, 020344 (2022).
- IBM Quantum Documentation, *View backend details / backend properties*. Backend properties contain time-dependent T1, T2, operation error and duration data.
- Qiskit IBM Runtime repository, `qiskit_ibm_runtime/fake_provider/backends/manila/props_manila.json`. Public snapshot used by the active calibration owner: backend `ibmq_manila`, timestamp `2024-05-27T15:27:23-03:00`.

The public backend-properties snapshot is real-device-derived calibration evidence for a Markov baseline. It is not multitime process tomography and cannot identify non-Markovian memory.

- *Applicability of transfer tensor method for open quantum system dynamics*. Journal of Chemical Physics 149 (2018). DOI `10.1063/1.5009086`.
- *Discrete memory kernel for multitime correlations in non-Markovian quantum processes*. Physical Review A 102, 052206 (2020). DOI `10.1103/PhysRevA.102.052206`.
- *General Framework for Error Interference in Quantum Simulation*. Physical Review Letters 136, 200601 (2026). DOI `10.1103/g2n5-qdxh`.

## Schwarzschild radial modes и детекторный отклик

- Tjoa, E.; Mann, R. B. *Unruh-DeWitt detector in dimensionally-reduced static spherically symmetric spacetimes*. Journal of High Energy Physics 03, 014 (2022). arXiv `2202.04084`.
- SciPy `solve_ivp`, `expm` и `expm_multiply` используются как численные primitives; физическая квалификация задаётся owner-тестами, flux balance и nested refinement.

## Аппаратное ускорение

NVIDIA cuQuantum/cuTensorNet и cuDensityMat документируют single-/multi-GPU и multi-node routes. В текущем дистрибутиве они остаются `BLOCKED_BACKEND_UNAVAILABLE`, пока не исполнены на реальном соответствующем оборудовании.
