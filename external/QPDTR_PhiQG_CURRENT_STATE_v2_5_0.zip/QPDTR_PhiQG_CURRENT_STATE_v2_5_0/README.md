# Quantum Physical Digital Twin Runtime — ΦQG CURRENT-STATE v2.5.0

QPDTR/ΦQG — fail-closed исследовательский runtime квантовой динамики. Единственная authoritative orchestration: `qpdtr.owner.QuantumGravityDynamicsOwner.execute`. CLI и scripts только вызывают owners и сохраняют сертификаты.

## PHI-Q1000-ARFE

Единый observable-first owner:

`qpdtr.domains.quantum_gravity.structural_router.plan_resource_factorized_emulation`

Он выполняет последовательность:

1. типизация требуемого результата (`observable`, `reduced_state`, `sample`, `full_state`);
2. точное построение обратного причинного конуса;
3. оценка ресурсов участка: graph width, state/operator bond, magic, Pauli support, temporal memory;
4. выбор одного authoritative patch-owner;
5. формирование типизированного boundary contract;
6. принятие результата только внутри общего error ledger.

Активные базовые слои:

- `QCM-CAUSAL-CONE`: точное исключение кубитов и операций вне причинного конуса наблюдаемого;
- `QCM-PAULI-OBS`: Heisenberg-распространение разреженного Pauli-наблюдаемого с L1-границей отброшенных коэффициентов;
- `QCM-GTN-BP`: точная belief-propagation свёртка тензорной сети на дереве; loopy-граф блокируется без cluster/reference certificate;
- `QCM-PHI-Q1000-ARFE`: единый owner маршрутизации и boundary/error contracts.

Контрольная 1000-кубитная схема сокращается до точного причинного конуса из 16 кубитов. Разреженное Pauli-наблюдаемое распространяется без state vector. Деревянная graph-TN на 1000 узлах свёрнута с reference gap порядка машинной точности.

## Остальной портфель

Runtime сохраняет exact state/density controls, matrix-free Krylov, MPS/TEBD, persistent adaptive TTN, general contraction tree, trajectories, пространственно-временной process tensor, Clifford tableau, CAMPS, Cayley-TTN, fermionic Gaussian, phase-polynomial DD, code-compiled MPS и bounded Schwarzschild/EPRL controls.

## Граница

Не заявляются произвольный точный full-state на 1000 кубитах, произвольная глубокая universal circuit, точное полное распределение исходов, MAST owner, graph influence-functional BP, real non-Markov hardware twin, real CUDA multi-GPU/MPI, завершённая Φ-RQG или новый физический закон. Неподдерживаемая структура возвращает `BLOCKED`.

Активная математика: `MATHEMATICAL_BOOK.md`; границы: `CLAIM_BOUNDARY.md`; evidence: `reports/current/EXECUTION_BUNDLE.json`.
