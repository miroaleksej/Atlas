#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import sys


_ROOT = Path(__file__).resolve().parents[1]
_SRC = _ROOT / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from qpdtr.cli import main  # noqa: E402  (source-tree bootstrap must precede import)


if __name__ == "__main__":
    raise SystemExit(main())
