# МАТЕМАТИЧЕСКАЯ КНИГА
## Quantum Physical Digital Twin Runtime — ΦQG CURRENT-STATE v2.5.0

## 1. Authoritative execution owner

Единственная активная оркестрация:

\[
\mathcal E_{\Phi QG}=\operatorname{QuantumGravityDynamicsOwner.execute}.
\]

Специализированные owners владеют своими алгоритмами; CLI и scripts алгоритмов не содержат. Дистрибутив содержит только текущую активную математику, текущие tests и текущие evidence. История изменений не входит в current-state tree и относится к внешней системе контроля версий.

## 2. PHI-Q1000: адаптивный ресурсно-факторизованный owner

Запрос обязан определить объект вычисления

\[
Y\in\{\text{observable},\text{reduced state},\text{sample},\text{full state}\}.
\]

Число кубитов само по себе не задаёт вычислительную сложность. Для пространственно-временного участка \(P\) owner строит ресурсный паспорт

\[
\mathbf r(P)=
\left(
 w_P,\chi_P,\chi_P^{\rm op},\mathcal M_P,K_P,
 D_P^{\rm time},\ell_P^{\rm mem},c_P^{\rm cut}
\right).
\]

Здесь \(w_P\) — ширина графовой свёртки, \(\chi_P\) — state bond, \(\chi_P^{\rm op}\) — operator bond, \(\mathcal M_P\) — magic resource, \(K_P\) — Pauli support, \(D_P^{\rm time}\) и \(\ell_P^{\rm mem}\) — ранг и длина памяти, \(c_P^{\rm cut}\) — стоимость границы.

### 2.1 Точный причинный конус

Для наблюдаемого \(O\) обратный проход по квантовым и классическим зависимостям строит \(\operatorname{LC}(O)\). Тогда

\[
\langle O\rangle
=
\operatorname{Tr}\!\left[
 O\,\mathcal C_{\operatorname{LC}(O)}
 (\rho_{0,\operatorname{LC}(O)})
\right].
\]

Операции вне конуса исключаются точно. Mid-circuit measurement и feedforward входят через классические зависимости. Контрольная 1000-кубитная схема имеет точный 16-кубитный cone certificate.

### 2.2 Разреженное Pauli-наблюдаемое

В Heisenberg representation

\[
O_{j-1}=U_j^\dagger O_jU_j,
\qquad
O_j=\sum_P c_P^{(j)}P.
\]

После локального сопряжения одинаковые Pauli words объединяются. Если сохраняется top-\(K\) набор,

\[
\widehat O_K=\sum_{P\in\operatorname{TopK}}c_PP,
\qquad
\epsilon_{\rm Pauli}^{(1)}=\sum_{P\notin\operatorname{TopK}}|c_P|.
\]

Поскольку \(\|P\|_\infty=1\), для любой density matrix

\[
\left|\operatorname{Tr}[\rho(O-\widehat O_K)]\right|
\leq \epsilon_{\rm Pauli}^{(1)}.
\]

Этот owner вычисляет только заявленное наблюдаемое и не утверждает наличие полного wavefunction или общего sampler.

### 2.3 Graph-TN belief propagation

Для дерева сообщение от \(u\) к \(v\) есть точная частичная свёртка поддерева:

\[
m_{u\to v}
=
\operatorname{Contract}_{u\setminus v}
\left[A_u,\{m_{w\to u}:w\in\partial u\setminus v\}\right].
\]

После двух проходов конечная свёртка совпадает с прямым reference. Для 1000-узлового дерева контрольный gap равен \(3.33\times10^{-15}\). На графе с циклами BP является только диагностическим приближением и блокируется, пока residual не дополнен cluster expansion или независимой reference-границей.

### 2.4 Patch-owner и boundary contract

Owner выбирается единственным законом

\[
m_P^\star
=
\arg\min_{m\in\mathfrak M}\widehat C_m(P)
\quad\text{при}\quad
\widehat\epsilon_m(P)\leq\epsilon_P.
\]

Участок возвращает типизированную границу

\[
\mathcal B_P
=
\operatorname{Tr}_{P^\circ}
\left[
\mathcal T_P\circ\mathcal A_P(\rho_{\partial P})
\right],
\]

которая может быть tensor message, Pauli map, stabilizer frame или CPTP/process-tensor channel. Автоматическое преобразование произвольных состояний между представлениями не заявляется.

### 2.5 Общий бюджет

\[
|\widehat{\langle O\rangle}-\langle O\rangle|
\leq
\epsilon_{\rm cone}+\epsilon_{\rm cut}+\epsilon_{\rm sample}
+\sum_P
(\epsilon_P^{\rm TN}+\epsilon_P^{\rm BP}+\epsilon_P^{\rm magic}
+\epsilon_P^{\rm Pauli}+\epsilon_P^{\rm memory}).
\]

Неконтролируемый рост bond, magic, Pauli support, temporal rank или cut count возвращает `BLOCKED`. Generic full-state для 1000 кубитов, MAST и influence-functional graph-BP не являются активными альтернативными путями.

## 3. Persistent adaptive TTN

Состояние хранится бинарным деревом тензоров. Для каждого внутреннего разреза SVD

\[
M=U\Sigma V^\dagger
\]

выбирает минимальный ранг \(\chi\leq\chi_{\max}\), удовлетворяющий

\[
\epsilon_{\rm disc}=\sum_{i>\chi}\sigma_i^2,
\qquad
\sum_{\rm updates}\epsilon_{\rm disc}
\leq \epsilon_{\rm budget}.
\]

Одноузловой гейт изменяет leaf tensor. Для произвольной пары листьев \(a,b\) путь раскрывается локальными ассоциативными поворотами

\[
((X,Y),Z)\longleftrightarrow(X,(Y,Z)),
\]

каждый из которых реализуется локальной contraction/SVD-факторизацией. После превращения \(a,b\) в sibling leaves двухузловой гейт применяется к joint tensor, затем выполняется локальная SVD и дерево остаётся persistent. Масштабируемый owner не строит вектор размера \(2^n\).

Квалифицированы:

\[
|\mathrm{GHZ}_{50}\rangle=
\frac{|0\rangle^{\otimes 50}+|1\rangle^{\otimes 50}}{\sqrt2},
\]

с used bond 2, discarded weight 0 и statevector-free global-correlation certificates; а также noncommuting pair-forest Hamiltonian dynamics

\[
H=0.11\sum_{i=0}^{49}Z_i+0.30\sum_{k=0}^{24}X_{2k}X_{2k+1}.
\]

Граф второго контроля имеет treewidth 1. Результаты не переносятся на arbitrary high-treewidth или volume-law workloads.

## 4. Matrix-free и MPS/contraction routes

Для линейного генератора \(A\) вычисляется действие

\[
|\psi(t)\rangle=e^{tA}|\psi(0)\rangle
\]

через `LinearOperator`/Krylov action без обязательного построения плотной \(e^{tA}\). Малые случаи сравниваются с independent dense reference. MPS/TEBD допускается при контролируемом росте bond dimension; general-graph contraction tree хранит порядок свёртки, peak-memory certificate и exact slicing без усечения выходных индексов.

## 5. Markovian open dynamics and trajectories

\[
\dot\rho=-\frac{i}{\hbar}[H,\rho]
+\sum_k\gamma_k\mathcal D[L_k]\rho.
\]

Trajectory runtime хранит отдельно sampling error

\[
\epsilon_{\rm sample}=O(N_{\rm traj}^{-1/2})
\]

и representation/truncation error. На малых регистрах ensemble density сравнивается с exact GKSL evolution.

## 6. Пространственно-временной process-tensor tensor-network owner

Активный memory-owner моделирует не только последовательность состояний, а многовременной управляемый процесс

\[
\rho_k=\Upsilon_{k:0}[\mathcal A_{k-1},\ldots,\mathcal A_0],
\]

где \(\mathcal A_j\) может быть unitary, dissipative CP map, projective outcome, nonselective measurement или trace-and-prepare reset.

### 6.1 Временной causal-memory контроль

Для qubit-системы \(S\) и сохраняющей память qubit-среды \(E\)

\[
\rho_{SE}^{(j+1)}
=U_{SE}(\mathcal A_j\otimes\mathcal I_E)[\rho_{SE}^{(j)}]U_{SE}^\dagger,
\qquad
\rho_S^{(k)}=\operatorname{Tr}_E\rho_{SE}^{(k)}.
\]

Трёхинтервенционный exact tensor имеет

\[
16^3\cdot4=16384
\]

комплексных коэффициента и TT-ranks

\[
(1,4,16,4,1).
\]

Он сверяется с прямой system-environment dilation. Causal-break witness обязан быть ненулевым при сохраняющейся среде и нулевым в контроле, где среда сбрасывается после каждого шага.

### 6.2 Пространственная факторизация

Для двух системных кубитов и одной общей memory-qubit строится двухвременной process tensor

\[
\Upsilon_{A_0A_1;o},
\qquad
\dim A_j=d_S^4=256,
\qquad
\dim o=d_S^2=16,
\]

с числом коэффициентов

\[
256^2\cdot16=1\,048\,576.
\]

Каждый полный superoperator leg факторизуется по пространственным узлам:

\[
A_j\longleftrightarrow(a_{j,1},a_{j,2}),
\qquad
\dim a_{j,q}=16,
\]

а output leg:

\[
o\longleftrightarrow(o_1,o_2),
\qquad
\dim o_q=4.
\]

Получается единый шестиногий пространственно-временной тензор

\[
\widetilde\Upsilon_{a_{0,1},a_{0,2},a_{1,1},a_{1,2},o_1,o_2},
\]

который сжимается как TT/MPS, то есть chain-TTN:

\[
\widetilde\Upsilon
\approx
G^{[0]}G^{[1]}G^{[2]}G^{[3]}G^{[4]}G^{[5]}.
\]

Действующий owner сравнивает time-major и space-major порядки и выбирает меньший максимальный bond. Для bounded-контроля выбран

\[
\texttt{TIME\_MAJOR\_SITE\_FACTORED\_TT\_MPS}
\]

с рангами

\[
(1,4,16,64,16,4,1).
\]

Сжатый tensor повторно применяется к независимым двухкубитным intervention sequences, включая entangling CNOT и локальное dephasing, и сравнивается с прямой восьмимерной joint dilation.

### 6.3 Единый пространственно-временной бюджет ошибки

В одну Frobenius-совместимую группу входят:

\[
\epsilon_{\rm temporal\ compression},\quad
\epsilon_{\rm temporal\ prediction},\quad
\epsilon_{\rm spacetime\ compression},\quad
\epsilon_{\rm spacetime\ prediction}.
\]

Для RSS-правила

\[
\epsilon_{\rm joint}
=
\sqrt{\sum_i\epsilon_i^2}
\le
\sqrt{\sum_i\beta_i^2}
=\beta_{\rm joint}.
\]

Проверяется как каждая компонента, так и совместная group bound. Превышение любой границы блокирует owner.

### 6.4 Real-device-derived calibration baseline

Публичный calibration snapshot `ibmq_manila` от 27 мая 2024 года задаёт для кубитов 0–1:

- \(T_1,T_2\);
- single- и two-qubit gate duration/error;
- readout assignment error;
- статическую \(ZZ\)-связь.

Для длительности \(t_g\) строятся

\[
\gamma_1=1-e^{-t_g/T_1},
\qquad
\frac1{T_\phi}=\max\left(0,\frac1{T_2}-\frac1{2T_1}\right),
\qquad
\lambda_\phi=e^{-t_g/T_\phi},
\]

amplitude/phase Kraus channels, coherent \(ZZ\)-эволюция и two-qubit depolarizing correction, согласованная с опубликованной gate error. Полный канал проверяется условиями

\[
\sum_rK_r^\dagger K_r=I,
\qquad
J(\mathcal E)\succeq0.
\]

Он образует Markov process-tensor baseline с temporal bond dimension \(1\).

Backend properties не содержат multitime intervention/outcome counts и covariance. Поэтому

\[
\texttt{NON\_MARKOVIAN\_IDENTIFICATION}
=
\texttt{BLOCKED\_MULTITIME\_CALIBRATION\_DATA\_REQUIRED}.
\]

Память реального устройства не выводится из \(T_1/T_2\) и не подменяется синтетической.

Legacy-функции `qualify_transfer_tensor_memory` и `qualify_temporal_kernel_compression` являются тонкими совместимыми представлениями этого owner и не содержат самостоятельного алгоритма.

Граница: квалифицирован bounded two-system-qubit/two-time space-time TT/MPS process tensor. Не квалифицированы arbitrary many-qubit PT-TTN, continuum influence-functional bath, scalable real-QPU tomography и unbounded bond growth.

## 7. Blind Hamiltonian/Lindbladian generator learning

Для одно-кубитного Bloch vector используется affine generator

\[
\dot r=Ar+b.
\]

Сначала по trajectory pairs оценивается discrete map

\[
r_{k+1}=Mr_k+c.
\]

Затем строится augmented matrix

\[
\widetilde M=
\begin{pmatrix}
M & c\\
0 & 1
\end{pmatrix},
\qquad
\widetilde L=\frac{1}{\Delta t}\log\widetilde M,
\]

из которой извлекаются \(A\) и \(b\). Covariance линейной регрессии

\[
\operatorname{Cov}(\operatorname{vec}\widehat B)
=\Sigma_y\otimes(X^\top X)^{-1}
\]

распространяется на held-out observables посредством повторного propagation sampled affine maps. Gate требует:

- stable design condition number;
- bounded generator gap на synthetic truth control;
- blind held-out trajectory agreement;
- заданную confidence coverage;
- явное различение statistical uncertainty и model misspecification.

Текущий PASS относится только к synthetic single-qubit affine-Bloch control. Он не является ansatz-free many-qubit Lindbladian learning и не использует physical experimental data.

## 8. Certified error interference

Для ошибок \(e_k\) в одной нормированной линейной области определяется

\[
\nu_k=\|e_k\|,
\qquad
G_{ij}=\frac{\langle e_i,e_j\rangle}{\nu_i\nu_j}.
\]

Если \(G\succeq0\) и его происхождение сертифицировано explicit error vectors либо independent upper-bound contract, то

\[
\left\|\sum_k e_k\right\|^2
=\nu^\top G\nu.
\]

Fail-closed правила:

- при отсутствии cross-error geometry используется
  \[
  \left\|\sum_k e_k\right\|\leq\sum_k\|e_k\|;
  \]
- uncertified correlation matrix является только diagnostic;
- non-PSD или ненормированный Gram contract блокируется;
- ошибки в разных метриках не объединяются.

Текущий exact-vector control дал triangle bound \(5.9143\times10^{-2}\) и certified aggregate \(2.44949\times10^{-3}\), совпадающий с непосредственной нормой суммы.

## 9. Unified spatial-temporal quantum error budget

Компонента имеет тип

\[
E_i=(\text{owner},\text{metric},b_i,\beta_i,\text{group},\text{rule}).
\]

Только метрически совместимые компоненты допускают `SUM`, `RSS`, `MAX` или `SEPARATE`. Для каждой группы одновременно вычисляются observed bound и allocated group budget тем же правилом:

\[
b_G=\operatorname{Combine}_G(\{b_i\}),
\qquad
\beta_G=\operatorname{Combine}_G(\{\beta_i\}).
\]

Fail-closed условия:

\[
b_i\le\beta_i\quad\forall i,
\qquad
b_G\le\beta_G\quad\forall G.
\]

В одном ledger находятся TTN truncation, Trotter refinement, temporal process-tensor compression, site-factorized space-time compression, multitime prediction, calibration CPTP, trajectory sampling, state-reference и slicing controls. Разные нормы не превращаются в один бессодержательный процент точности.

## 10. Backend qualification

CPU проверяется реальным sparse-vs-dense вычислением. CUDA допускается только при реальном CuPy/CUDA device, MPI — только при `COMM_WORLD.size>1`. Отсутствие backend даёт `BLOCKED_BACKEND_UNAVAILABLE`, а не fallback-PASS.

## 11. Exact stabilizer tableau owner

Для `n` кубитов поддерживается канонический набор destabilizer/stabilizer строк. Pauli-строка кодируется как

\[
P(p,x,z)=i^p X^x Z^z,
\qquad p\in\mathbb Z_4,
\qquad x,z\in\mathbb F_2^n.
\]

Clifford-гейт действует симплектическим преобразованием над `GF(2)` и сохраняет форму

\[
\omega((x,z),(x',z'))=x\cdot z'+z\cdot x'\pmod 2.
\]

Таблица содержит `2n` канонических строк. H, S, S†, Pauli, CNOT, CZ и SWAP обновляют только бинарные строки и фазы. Измерение `Z_a` выполняет точный row-reduction/collapse при случайном исходе и каноническое разложение при детерминированном исходе. Память имеет порядок `O(n^2)`, а не `O(2^n)`.

Квалифицирован 1000-кубитный statevector-free Clifford-контроль со status `PASS_CLIFFORD_1000_TABLEAU_EXACT`. Сертификат не охватывает non-Clifford resource.

## 12. Exact bounded magic decomposition

Активный bounded owner использует

\[
T=\begin{pmatrix}1&0\\0&e^{i\pi/4}\end{pmatrix}
 =\alpha I+\beta Z,
\quad
\alpha=\frac{1+e^{i\pi/4}}2,
\quad
\beta=\frac{1-e^{i\pi/4}}2.
\]

После `m` T-гейтов

\[
|\psi_m\rangle=\sum_{s\in\{0,1\}^m}c_sP_s|\phi_C\rangle,
\qquad N_{\rm branches}\le 2^m.
\]

Квалифицировано `n=10`, `m=5`, `N=32` с independent statevector equality. Это точный bounded reference; экспоненциальная граница по T-count является частью контракта.

## 13. Clifford-augmented MPS owner

Физическое состояние представляется единственным активным CAMPS-контрактом

\[
|\psi\rangle=C|\phi\rangle,
\qquad |\phi\rangle\in\mathrm{MPS}.
\]

`CliffordFrame` не хранит прежнюю схему или журнал гейтов. Он хранит только текущие симплектические образы

\[
C^\dagger X_q C,
\qquad
C^\dagger Z_q C,
\]

и проверяет сохранение канонических коммутационных отношений. Clifford-гейт `G` заменяет frame как `C←GC`; residual MPS при этом не меняется.

Для T-гейта

\[
T_q=e^{i\pi/8}\exp\!\left(-\frac{i\pi}{8}Z_q\right),
\]

поэтому

\[
T_qC
 =C\,e^{i\pi/8}
  \exp\!\left(-\frac{i\pi}{8}P_q\right),
\qquad
P_q=C^\dagger Z_qC.
\]

Поскольку `P_q^2=I`,

\[
\exp(-i\theta P_q)=\cos\theta\,I-i\sin\theta\,P_q.
\]

При support `P_q≤2` rotation применяется локально к MPS. При большем support строится точная линейная комбинация

\[
|\phi'\rangle
 =\cos\theta|\phi\rangle-i\sin\theta P_q|\phi\rangle,
\]

после чего единственный MPS-owner выполняет SVD-компрессию с cumulative discarded-weight budget. Нулевой бюджет выбирает численный ранг, а не сохраняет нулевые сингулярные направления.

### 13.1 Bounded exact certificate

Для 12 кубитов, 8 T-гейтов и 31 Clifford-гейта:

\[
\epsilon_{\rm phase}=3.83175877025482\times10^{-16},
\qquad
\epsilon_{\rm disc}=0,
\]

frame canonical-pair gap равен нулю; residual maximum bond равен 1, ordinary MPS maximum bond равен 2. Status: `PASS_BOUNDED_EXACT_CAMPS_STATEVECTOR_EQUALITY`.

### 13.2 Structured 200-qubit holdout

Три независимых seed квалифицируют одну и ту же заранее объявленную one-dimensional brickwork family:

\[
n=200,\quad d=4,\quad N_T=32,\quad N_C=1398.
\]

Для каждого holdout:

\[
\chi_{\rm CAMPS}^{\max}=2,
\qquad
\chi_{\rm MPS}^{\max}=4,
\qquad
\epsilon_{\rm disc}^{\rm CAMPS}=0,
\]

maximum twisted-Pauli support равен 2, statevector не создаётся. Status: `PASS_STRUCTURED_200_CAMPS_HOLDOUT_STATEVECTOR_FREE`.

Этот сертификат доказывает исполнение указанного семейства и преимущество residual bond внутри него. Он не доказывает polynomial complexity для arbitrary magic placement, двумерных схем, volume-law residual states или универсальной 200-кубитной Clifford+T динамики.

## 14. Interacting spinful SIAM Cayley-TTN

### 14.1 Активная модель

\[
H_{\mathrm{SIAM}}=\epsilon_d\sum_{\sigma\in\{\uparrow,\downarrow\}}n_{d\sigma}
+U n_{d\uparrow}n_{d\downarrow}
+\sum_{ij\sigma}h_{ij}c_{i\sigma}^{\dagger}c_{j\sigma}
+\sum_{i\sigma}\left(V_i d_\sigma^\dagger c_{i\sigma}+\overline V_i c_{i\sigma}^\dagger d_\sigma\right),
\qquad h=h^\dagger,
\qquad U>0.
\]

Квадратичная bath-часть преобразуется единственным recursive Cayley owner. Корневое направление

\[
|t_0\rangle=\frac{|V^*\rangle}{\|V\|_2}
\]

соединяет impurity только с root tree-site. Рекурсивное ортогональное разложение даёт

\[
U_C^\dagger U_C=I,
\qquad H_{tree}=U_C^\dagger hU_C.
\]

Star и независимый Lanczos-chain не являются параллельными runtime owners; они используются только для точной bounded-проверки.

### 14.2 Инварианты bath mapping

\[
\Delta_{star}(z)=V^\dagger(zI-h)^{-1}V
=\|V\|_2^2[(zI-H_{tree})^{-1}]_{00}=\Delta_{tree}(z).
\]

Для 31-mode mapping:

\[
\epsilon_{recon}=1.172900631337402\times10^{-13},\quad
\epsilon_{\Delta,tree}=4.684364995852737\times10^{-15},\quad
\epsilon_{\Delta,chain}=8.053942809845217\times10^{-12}.
\]

### 14.3 Точная interacting star/chain/tree эквивалентность

Для трёх bath modes на spin, восьми spin-orbitals, сектора \(N_\uparrow=N_\downarrow=2\) и \(U=1.6\) строятся независимые many-body Hamiltonians в star, chain и tree bases. Проверяются спектр, ground energy, impurity occupations и double occupation:

\[
\epsilon_{spec}^{star/tree}=1.2434497875801753\times10^{-14},\qquad
\epsilon_{E_0}^{star/tree}=2.6645352591003757\times10^{-15}.
\]

Status: `PASS_EXACT_INTERACTING_SIAM_STAR_CHAIN_TREE_EQUIVALENCE`.

### 14.4 Imaginary-time ground state и bond convergence

Нормированная imaginary-time эволюция использует symmetric product formula и локальные Cayley-TTN операции:

\[
|\psi(\beta+\delta\beta)\rangle
\propto e^{-\delta\beta H/2}_{\rm onsite}
 e^{-\delta\beta H}_{\rm hop/int}
 e^{-\delta\beta H/2}_{\rm onsite}|\psi(\beta)\rangle.
\]

Начальное состояние строится продолжением из невзаимодействующего reference ground state. При \(\beta=5.4\), \(\delta\beta=0.15\), \(\chi_{max}=16\):

\[
|E_{TTN}-E_{ED}|=8.331500660263558\times10^{-5},\qquad
F=0.9999032054858223.
\]

Независимая exact-state factorization даёт монотонную последовательность

\[
\chi=(2,4,8),\quad
\delta E=(8.431776988266746\times10^{-1},8.102832133256577\times10^{-3},3.316749221937698\times10^{-7}).
\]

### 14.5 Real-time TEBD/product formula

Текущий active integrator — symmetric second-order product formula, а не параллельный TDVP path:

\[
U_2(\delta t)=e^{-i\delta t H_A/2}e^{-i\delta t H_B}e^{-i\delta t H_A/2},
\qquad U(t)=U_2(\delta t)^{t/\delta t}.
\]

При \(t=0.24\):

\[
\epsilon_{state}(0.08)=2.09000752347109\times10^{-4},\quad
\epsilon_{state}(0.04)=5.220766201254169\times10^{-5},
\]

\[
F_{0.04}=0.9999999972743601,
\qquad \epsilon_{n_d}^{max}=6.64619049017823\times10^{-7}.
\]

### 14.6 Interacting Green function и sum rules

\[
G^R_\sigma(t)=-i\theta(t)\langle\{d_\sigma(t),d_\sigma^\dagger(0)\}\rangle.
\]

Lehmann reference проверяет tree/star/chain equality и моменты:

\[
\mu_0=\int A_\sigma(\omega)d\omega=1,
\qquad
\mu_1=\epsilon_d+U\langle n_{d\bar\sigma}\rangle.
\]

Получено

\[
\epsilon_{\mu_0}=8.881784197001252\times10^{-16},\qquad
\epsilon_{\mu_1}=7.771561172376096\times10^{-16}.
\]

### 14.7 Structured 26-qubit holdout

Двенадцать bath modes на spin, из которых три образуют impurity-coupled active tree component. Взаимодействующая эволюция исполняется без глобального statevector:

\[
\epsilon_N=8.881784197001252\times10^{-16},\quad
\epsilon_{norm}=0,\quad
n_{spectator}^{max}=0.
\]

Status: `PASS_STRUCTURED_26_QUBIT_INTERACTING_CAYLEY_TTN_HOLDOUT`.

### 14.8 Исправленный TTN topology invariant

Для graph-aware дерева порядок `topology.leaves` обязан совпадать с порядком физических tensor axes. При factorization tensor сначала переставляется в этот порядок; parent leaves формируются конкатенацией фактических child orders, а не сортировкой меток. Текущий тест требует для произвольного комплексного состояния

\[
\|\,|\psi_{after}\rangle-e^{i\phi}|\psi_{before}\rangle\|_2<10^{-12}
\]

после path exposure, tree rotations и identity two-site gate.

### 14.9 Bath discretization и граница

Gauss–Legendre orders 15 и 63 дают fine continuum hybridization gap

\[
\epsilon_{\Delta,63}=2.180423264219744\times10^{-6}.
\]

Квалифицированы exact-control система с тремя bath modes на spin и structured 26-qubit holdout с тремя активными modes на spin. Не квалифицированы произвольные continuum baths, generic 26-qubit interactions, long-time/volume-law growth, finite temperature, multiorbital SIAM, DMFT self-consistency и linear-prediction extrapolation.

## 15. Pointwise multidimensional claim contract

Исполнимость задаётся точкой

\[
W=(n,N_T,\mathcal M,G,w_{tree},\dot S,\chi,N_b,U,N_{active},\delta t,\beta,\varepsilon,\text{backend},\ldots).
\]

PASS распространяется только на measured coordinates, включая interacting SIAM exact control \((n=8,N_b=3/\sigma,U=1.6)\) и structured holdout \((n=26,N_b=12/\sigma,N_{active}=3/\sigma,U=1.4)\). Соседняя точка с неизвестным bath class, большим active component, другим temperature/orbital regime или неконтролируемым bond growth остаётся `OPEN`.

## 16. Конструктивно положительный tensor-train owner открытой динамики

Для одномерной цепочки активное состояние хранится не как векторизованная плотностная матрица, а как локально очищенный тензорный поезд. На узле \(i\) используется тензор

\[
A_i\in\mathbb C^{D_{i-1}\times 2\times K_i\times D_i},
\]

где \(D_i\) — межузловая связь, а \(K_i\) — локальная очищающая связь. Глобальный фактор \(X\) задаётся

\[
X_{s_1\ldots s_N,k_1\ldots k_N}
=
\sum_{\alpha_1\ldots\alpha_{N-1}}
A_1^{s_1k_1}{}_{1\alpha_1}\cdots
A_N^{s_Nk_N}{}_{\alpha_{N-1}1},
\]

а физическое состояние определяется формулой

\[
\boxed{\rho=\operatorname{Tr}_{K}|X\rangle\langle X|}.
\]

Поэтому для любого набора конечных тензоров

\[
\rho\succeq0.
\]

Локальный GKSL-генератор

\[
\mathcal L_i(\rho)=
-i[h_i,\rho]
+\sum_a\left(
L_{ia}\rho L_{ia}^{\dagger}
-\frac12\{L_{ia}^{\dagger}L_{ia},\rho\}
\right)
\]

экспоненцируется на одном узле. Из Choi-матрицы канала извлекаются Kraus operators \(K_{ia}\), удовлетворяющие

\[
\sum_a K_{ia}^{\dagger}K_{ia}=I.
\]

Они действуют только на физический индекс и расширяют локальный очищающий индекс:

\[
B_i^{t,(k,a)}=\sum_s (K_{ia})_{ts}A_i^{s,k}.
\]

Nearest-neighbour Hamiltonian gates

\[
U_{i,i+1}(\Delta t)=e^{-i\Delta t h_{i,i+1}}
\]

действуют на два физических индекса и после SVD изменяют только связь \(D_i\). Один симметричный шаг имеет вид

\[
\prod_i\mathcal E_i(\Delta t/2)
\prod_{i\in\mathrm{even}}\mathcal U_i(\Delta t/2)
\prod_{i\in\mathrm{odd}}\mathcal U_i(\Delta t)
\prod_{i\in\mathrm{even}}\mathcal U_i(\Delta t/2)
\prod_i\mathcal E_i(\Delta t/2).
\]

Без усечения это композиция CPTP-каналов. Уменьшение межузловой и локальной Kraus-размерности выполняется SVD с отдельными реестрами

\[
\varepsilon_{D}=\sum_{s}\sum_{r>D_{\max}}\sigma_{s,r}^{2},
\qquad
\varepsilon_{K}=\sum_{s}\sum_{r>K_{\max}}\kappa_{s,r}^{2}.
\]

После усечения представление по-прежнему имеет форму \(XX^{\dagger}\), поэтому положительность сохраняется конструктивно; след явно нормируется. Поскольку выбор ранга зависит от текущего состояния, сжатый шаг не объявляется линейным CPTP-супероператором на произвольном входе.

Квалифицированный класс: конечные one-dimensional nearest-neighbour qubit GKSL-модели с локальными jump-операторами. Не квалифицированы двумерные и дальнодействующие генераторы, нелокальные jumps и режимы неконтролируемого роста \(D_i,K_i\).

## 17. Basis-adaptive sparse-state owner

Для чистого состояния используется изменяемый локальный product basis

\[
|\psi\rangle=
\left(\bigotimes_{j=1}^{N}U_j\right)
\sum_{x\in S}c_x|x\rangle,
\qquad |S|\le k.
\]

Физический gate \(G_Q\), действующий на подмножестве \(Q\), переводится в рабочий базис:

\[
\widetilde G_Q=
\left(\bigotimes_{j\in Q}U_j^{\dagger}\right)
G_Q
\left(\bigotimes_{j\in Q}U_j\right).
\]

В фиксированном базисе оптимальная \(k\)-разреженная аппроксимация по норме получается сохранением \(k\) амплитуд с наибольшими \(|c_x|^2\). Перед усечением owner вычисляет одночастичные reduced density matrices

\[
\rho_j=\operatorname{Tr}_{\bar j}|\psi\rangle\langle\psi|
\]

и рассматривает их собственные базисы как кандидаты \(U_j\). Поворот принимается только при уменьшении participation ratio

\[
\operatorname{PR}(c)=rac{1}{\sum_x |c_x|^4}
\]

с заданным допуском. Это do-no-harm gate: неудачный локальный базис отклоняется.

На каждом усечении регистрируется сохранённая масса

\[
r_s=\frac{\sum_{x\in S_k}|c_x|^2}{\sum_x|c_x|^2},
\qquad
R_{\mathrm{cum}}=\prod_s r_s.
\]

\(R_{\mathrm{cum}}\) является диагностикой потерь, но не объявляется строгой нижней границей полной мног шаговой fidelity после последующей интерференции.

Owner квалифицирован только для pure-state one/two-qubit circuits с конечным support budget и доказанным sparse admission. Mixed states, generic volume-law states и состояния, не концентрируемые ни в одном локальном product basis, остаются вне активного класса.

## 18. Квазисвободный фермионный Gaussian owner

Активный класс задаётся number-conserving quadratic Hamiltonian

\[
H=\sum_{ij}h_{ij}c_i^\dagger c_j,
\qquad h=h^\dagger,
\]

и линейными loss/gain jump-операторами, собранными в положительные one-particle matrices \(\Gamma_-\succeq0\), \(\Gamma_+\succeq0\). Для соглашения

\[
C_{ij}=\langle c_j^\dagger c_i\rangle
\]

динамика замыкается:

\[
\dot C=AC+CA^\dagger+\Gamma_+,
\qquad
A=-ih-\frac12(\Gamma_-+\Gamma_+).
\]

Точное конечновременное решение:

\[
C(t)=e^{At}(C_0-C_\infty)e^{A^\dagger t}+C_\infty,
\]

где стационарная матрица решает Lyapunov equation

\[
AC_\infty+C_\infty A^\dagger+\Gamma_+=0.
\]

Физичность fermionic correlation matrix требует

\[
0\preceq C(t)\preceq I.
\]

Для Gaussian state четырёхточечный контроль задаётся Wick identity:

\[
\langle c_i^\dagger c_j^\dagger c_lc_k\rangle
=C_{ki}C_{lj}-C_{li}C_{kj}.
\]

Owner сверяется с независимой dense Jordan-Wigner Lindblad evolution на четырёх модах и выполняет statevector-free контроль на 128 модах. Pairing/Bogoliubov terms, interacting Hamiltonians, quadratic/nonlinear jumps и non-Gaussian states не входят в активный claim.

## 19. Phase-polynomial decision-diagram owner

После отдельного семантического понижения допустимая схема представляется multilinear polynomial

\[
f(x_1,\ldots,x_n)=\sum_{S\subseteq\{1,\ldots,n\}}c_S\prod_{j\in S}x_j\pmod 8,
\qquad x_j\in\{0,1\}.
\]

Текущий owner вычисляет нормированную phase amplitude

\[
A(f)=2^{-n}\sum_{x\in\{0,1\}^n}\omega_8^{f(x)},
\qquad \omega_8=e^{i\pi/4},
\]

посредством reduced ordered multi-terminal decision diagram. Терминальные вершины соответствуют остаткам `0,...,7`; внутренний узел фиксирует одну Boolean variable и два cofactors. Изоморфные остаточные подполиномы разделяют один узел, а узел с одинаковыми low/high branches удаляется. Рекурсия имеет fail-closed ограничение `node_budget`; переполнение не заменяется приближением.

Для interaction graph \(G_f\) определяется cut-rank над \(\mathbb F_2\):

\[
\rho_G(X)=\operatorname{rank}_{\mathbb F_2} A_G[X,V\setminus X].
\]

Для фиксированного порядка \(\pi\) текущий диагностический показатель

\[
\operatorname{lrw}_\pi(G)=\max_k\rho_G(\{\pi_1,\ldots,\pi_k\})
\]

сравнивается с treewidth. Он не выдаётся за точный linear rank-width без оптимизации по всем порядкам.

Bounded reference:

- `n=16`: полное суммирование по \(2^{16}\) assignments, gap \(2.2542859121191408\times10^{-14}\);
- `n=64`: complete interaction graph, treewidth upper bound `63`, fixed-order cut-rank `1`, `492` DD nodes, statevector не создавался.

Claim ограничен уже проверенным `Z_8` phase-polynomial lowering. Generic quantum circuit, произвольный gate set и guarantee малой DD отсутствуют.

## 20. Code-compiled tensor-network executor

Допустимый вход содержит проверенный compilation certificate и физическое расписание

\[
|\psi_s\rangle=P_sD_sP_{s-1}D_{s-1}\cdots P_1D_1E|\psi_0\rangle,
\]

где \(E|\psi_0\rangle\) уже имеет MPS-представление, каждый

\[
D_s=\bigotimes_{j=1}^{n}\operatorname{diag}(1,e^{i\pi k_{sj}/4})
\]

является произведением одноузловых диагональных гейтов, а \(P_s\) — перестановкой проводов. Одноузловые диагональные gates не меняют Schmidt ranks. Перестановка не реализуется SWAP network: owner обновляет bijection `logical_to_site`.

Поэтому после encoder

\[
\chi_{\max}(s)=\chi_{\rm enc}
\]

для всего допустимого расписания. Это равенство относится только к физическим слоям объявленного класса, а не к произвольной logical circuit.

Bounded reference:

- 10 кубит, 96 слоёв: dense equality gap \(3.5215689824136954\times10^{-15}\);
- 256 кубит, 512 слоёв: `peak_bond=encoder_bond=2`, 342 permutation layers, global statevector не создавался.

Owner не ищет CSS code, не проверяет automorphism group и не компилирует logical gate. Эти доказательства должны быть частью входного immutable certificate.

## 21. Многопризнаковый certificate-driven router

Выбор representation основан не на одном treewidth, а на наборе конструктивных сертификатов и ресурсных оценок:

\[
\Pi=(
\widehat{\rm tw},
\widehat{\rm lrw},
\widehat{\rm PR}_{Z},
k,
\text{phase lowering},
\text{code schedule},
\text{Clifford},
\text{Gaussian},
\text{GKSL locality},
\text{memory},
\text{low-treewidth prior}
).
\]

Активный приоритет:

\[
\text{verified code schedule}
\succ
\text{verified phase-DD width separation}
\succ
\text{Clifford}
\succ
\text{Gaussian}
\succ
\text{locally purified GKSL}
\succ
\text{admitted BASS crossover}
\succ
\text{space-time process tensor TT/MPS}
\succ
\text{adaptive TTN}
\succ
\text{general TN}.
\]

BASS допускается только если объявлены pure-state sparse certificate, finite support budget \(k\) и оценка

\[
\widehat{\rm PR}_{Z}>k,
\]

то есть фиксированный вычислительный базис требует нетривиального усечения. Одномерная локальная GKSL-модель направляется только в конструктивно положительный tensor-train owner.

Знак \(\succ\) задаёт порядок admission, а не универсальное сравнение wall-clock времени. Router не конвертирует уже сформированные состояния и не доказывает глобальную оптимальность. Для non-Markovian workloads он требует temporal bond estimate; для пространственно запутанного multiqubit process дополнительно требует joint space-time bond estimate. Наличие real calibration snapshot не считается доказательством памяти без multitime calibration records.

## 22. Остальная активная математика

В одной current-state системе действуют persistent adaptive TTN, graph-ordered MPS/TEBD, bounded contraction tree, one-dimensional locally purified GKSL tensor train, quasi-free fermionic covariance dynamics, site-factorized spatial-temporal process tensors, real-device-derived Markov calibration baseline, synthetic affine generator learning, exact/Krylov references, trajectories/GKSL и enforced metric-typed unified error budget. CAMPS и SIAM используют существующих tensor-network owners и не создают алгоритмов в CLI или compiler.

## 23. Current-state граница

Квалифицировано:

- exact statevector-free 1000-qubit Clifford tableau;
- exact bounded 10-qubit/5-T stabilizer-branch decomposition;
- exact bounded 12-qubit/8-T CAMPS equality;
- structured statevector-free 200-qubit CAMPS holdouts;
- bounded interacting spinful SIAM Cayley-TTN exact control;
- structured statevector-free 26-qubit interacting SIAM holdout;
- structured statevector-free 50-qubit persistent TTN;
- bounded one-dimensional locally purified GKSL tensor train;
- bounded basis-adaptive sparse pure-state simulation;
- exact quasi-free number-conserving fermionic Gaussian dynamics;
- bounded exact phase-polynomial DD after verified lowering;
- bounded exact diagonal/permutation code-compiled MPS execution;
- deterministic structural owner routing;
- bounded intervention-complete temporal memory;
- bounded two-qubit/two-time site-factorized process-tensor TT/MPS;
- unified spatial-temporal error budget;
- CPTP Markov digital-twin baseline from the public IBM Manila calibration snapshot;
- generator learning and typed error controls.

Открыто:

- generic long-time/volume-law interacting SIAM scaling;
- finite-temperature, multiorbital и DMFT impurity workflows;
- 2D/long-range/nonlocal-jump locally purified GKSL tensor train;
- fermionic pairing, interactions и non-Gaussian jumps;
- arbitrary magic и двумерный/volume-law CAMPS;
- generic circuit-to-phase-polynomial lowering и unbounded DD size;
- automatic CSS code/automorphism discovery и state conversion между representations;
- MERA;
- continuum-bath and many-qubit process-tensor MPO with unbounded intervention depth;
- real CUDA multi-GPU/MPI qualification;
- Lorentzian EPRL continuum theory и экспериментально подтверждённый новый закон.

## 24. Неограниченный портфель вычислительных маршрутов

Φ-Compiler выбирает композиции вычислительных методов без встроенного потолка порядка. QPDTR не копирует алгоритмы компилятора, а связывает каждый `QCM-*` с единственным runtime owner. Для маршрута

\[
\mathcal R=(m_1,\ldots,m_k)
\]

строится сертификат

\[
\mathcal B(\mathcal R)=\{(m_j,O_j,E_j,S_j)\}_{j=1}^{k},
\]

где \(O_j\) — authoritative owner, \(E_j\) — фактическое evidence, \(S_j\) — статус исполнения. Неизвестный метод остаётся `PARTIAL_MISSING_OWNERS`; CUDA/MPI остаются `BLOCKED_EXTERNAL_BACKEND`, если не исполнялись на настоящем устройстве. CPTP tensor-train, BASS, fermionic-Gaussian, phase-DD, code-compiled-TN и structural-router routes имеют собственные bounded owners; MERA, automatic representation conversion и внешний multi-GPU backend остаются открытыми.

## 25. General-graph fallback после отклонения MPS/TTN

Для графа взаимодействий \(K_8\) используется

\[
H=\sum_{i=0}^{7} h_i Z_i+\sum_{0\le i<j\le7}J_{ij}X_iX_j.
\]

Граф имеет treewidth upper bound 7. Искусственно малый statevector workspace запрещает прямой маршрут; высокий treewidth исключает MPS/TTN. Выбранный owner — `GENERAL_GRAPH_CONTRACTION_TREE_STATEVECTOR`. Получено

\[
\epsilon_{\rm Krylov}=9.729661964372252\times10^{-9},
\]

\[
\epsilon_{\rm Trotter}=1.325089555598142\times10^{-10},
\qquad
\epsilon_{\rm norm}=9.769962616701378\times10^{-15}.
\]

Это доказывает корректность bounded fallback и маршрутизации, но не масштабируемость произвольной high-treewidth/volume-law динамики.

## 26. Четырёхмерный Schwarzschild radial-mode owner

Внешняя область задаётся

\[
ds^2=-f(r)dt^2+f(r)^{-1}dr^2+r^2d\Omega_2^2,
\qquad f(r)=1-\frac{2M}{r}.
\]

Радиальная функция безмассового скалярного поля удовлетворяет

\[
\frac{d^2u_{\omega\ell}}{dr_*^2}
+\left[\omega^2-V_\ell(r)\right]u_{\omega\ell}=0,
\]

\[
V_\ell(r)=f(r)\left[\frac{\ell(\ell+1)}{r^2}+\frac{2M}{r^3}\right].
\]

Из асимптотик вычисляются transmission и reflection coefficients с flux control

\[
\Gamma_\ell(\omega)+R_\ell(\omega)=1+\epsilon_{\rm flux}.
\]

Активный алгоритм не фиксирует \(\ell_{\max}=3\). Он последовательно увеличивает angular cutoff и останавливается только когда одновременно выполнены

\[
\|C_L-C_{L-1}\|_\infty\le\varepsilon_C,
\qquad
\|P_L-P_{L-1}\|_\infty\le\varepsilon_P.
\]

В текущем контроле выбран

\[
L=6,
\qquad N_\omega=65,
\qquad N_{\rm radial}=455.
\]

Получены

\[
\epsilon_{\rm flux}=6.443998890048874\times10^{-9},
\]

\[
\|C_6-C_5\|_\infty=1.99312879238156\times10^{-3},
\]

\[
\|P_6-P_5\|_\infty=6.414361602091745\times10^{-5}.
\]

Raw spectral gap \(5.69880512282519\times10^{-2}\) сохраняется в отчёте, но не выдаётся за сходимость физической наблюдаемой.

## 27. Вложенная частотная сходимость редуцированной динамики

Из greybody-weighted mode sum строится

\[
J_L(\omega)=\frac{e^{-(\omega/\omega_c)^2}}{4\pi}
\sum_{\ell=0}^{L}(2\ell+1)\Gamma_\ell(\omega).
\]

Для вложенных сеток 17, 33 и 65 узлов вычисляются

\[
C_N(t)=\sum_{k=1}^{N}w_kJ_L(\omega_k)e^{-i\omega_k t}
\]

и одноэкситационная псевдомодовая дилатация. Текущий refinement:

\[
\|C_{33}-C_{65}\|_\infty
=1.8580500402195213\times10^{-3},
\]

\[
\|P_{33}-P_{65}\|_\infty
=2.6707641429868367\times10^{-5}.
\]

Это finite-time numerical convergence для объявленного detector/population класса. Не доказаны continuum/many-qubit process tensor, полный Wightman reconstruction и совместное снятие \(L,N,r_{\max},\eta\).

## 28. Полная архитектура квантового эмулятора

Активный runtime является адаптивным портфелем:

1. bounded exact density/Choi;
2. matrix-free Krylov;
3. graph-ordered MPS/TEBD;
4. persistent adaptive TTN;
5. general contraction tree;
6. trajectories/GKSL;
7. locally purified GKSL tensor train;
8. basis-adaptive sparse pure-state owner;
9. quasi-free fermionic Gaussian covariance;
10. intervention-complete process-tensor tensor train;
11. Clifford tableau;
12. CAMPS;
13. Cayley-TTN impurity solver;
14. phase-polynomial multi-terminal decision diagram;
15. code-compiled diagonal/permutation MPS executor;
16. multi-indicator certificate-driven structural router;
17. adaptive 4D Schwarzschild radial environment;
18. backend qualification with real CPU and fail-closed CUDA/MPI.

Выбор определяется geometry, treewidth, linear-rank width, participation ratio, entanglement/operator-entanglement growth, openness, memory, fermionic structure, magic, observable scope, target error и memory budget. Каждый путь возвращает typed error components. Эмулятор не превращает generic exponential or volume-law complexity в полиномиальную.
