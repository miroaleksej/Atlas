from __future__ import annotations

from pathlib import Path
import sys

import numpy
from setuptools import Extension, setup

ROOT = Path(__file__).parent
if sys.platform.startswith("linux"):
    compile_args = ["-O3", "-std=c++17", "-fopenmp"]
    link_args = ["-fopenmp"]
elif sys.platform == "darwin":
    # Apple Clang does not ship OpenMP by default.  The same exact native kernel is built
    # single-threaded unless the user selects a compiler toolchain with OpenMP support.
    compile_args = ["-O3", "-std=c++17"]
    link_args = []
elif sys.platform == "win32":
    compile_args = ["/O2", "/std:c++17", "/openmp"]
    link_args = []
else:
    compile_args = ["-O3", "-std=c++17"]
    link_args = []

extension = Extension(
    "qpdtr._native",
    sources=["src/qpdtr/_native.cpp"],
    include_dirs=[numpy.get_include()],
    language="c++",
    extra_compile_args=compile_args,
    extra_link_args=link_args,
)

setup(ext_modules=[extension])
