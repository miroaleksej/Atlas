# CLAIM BOUNDARY — QPDTR/ΦQG CURRENT-STATE v2.5.0

## Подтверждено внутри текущего дистрибутива

- `plan_resource_factorized_emulation` является единственным active PHI-Q1000 routing owner;
- exact backward causal cone учитывает квантовые операции, измерения и feedforward;
- контрольная 1000-кубитная схема точно сокращена до 16 активных кубитов;
- sparse Pauli observable распространяется без глобального state vector;
- top-K усечение получает L1-границу ошибки expectation value;
- graph-TN belief propagation является точным на деревьях и проверено на 1000-узловом дереве;
- loopy BP блокируется без независимой cluster/reference границы;
- все patch-ошибки входят в единый fail-closed ledger;
- Clifford-1000 остаётся точным специализированным классом;
- authoritative control gates: 53/53 PASS.

## Не подтверждено

- универсальная эффективная симуляция произвольной 1000-кубитной схемы;
- хранение произвольного полного состояния или точного полного распределения `2^1000` исходов;
- global optimality разбиения и выбора patch-owner;
- автоматическое преобразование произвольных состояний между разными representations;
- active MAST/delayed-projection owner;
- active influence-functional graph-BP для многокубитной аппаратной памяти;
- произвольный loopy GTN без cluster certificate;
- live/non-Markov digital twin реального QPU без multitime counts и covariance;
- real CUDA multi-GPU/MPI, завершённая Φ-RQG или новый физический закон.

Отдельные causal-cone, tensor-network BP, Pauli propagation и hybrid stabilizer/TN методы имеют prior art. Возможная новизна полной Φ-Q1000 интеграции не доказана этим релизом.
