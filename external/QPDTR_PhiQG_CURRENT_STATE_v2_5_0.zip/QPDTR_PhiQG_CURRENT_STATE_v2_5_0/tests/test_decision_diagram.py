import numpy as np
import pytest

from qpdtr.domains.quantum_gravity.decision_diagram import (
    PhasePolynomialDecisionDiagram,
    complete_graph_phase_polynomial,
    qualify_phase_polynomial_decision_diagram,
)


def test_bounded_phase_decision_diagram_exact_and_width_selective():
    certificate = qualify_phase_polynomial_decision_diagram()
    assert certificate.passed
    assert certificate.exact_reference_gap < 1e-11
    assert certificate.large_treewidth_upper_bound >= 60
    assert certificate.large_linear_cut_rank <= 2
    assert certificate.large_node_count < 25_000
    assert certificate.statevector_materialized_large is False


def test_decision_diagram_fails_closed_on_node_budget():
    polynomial = complete_graph_phase_polynomial(20)
    with pytest.raises(RuntimeError, match="DECISION_DIAGRAM_NODE_BUDGET_EXCEEDED"):
        PhasePolynomialDecisionDiagram(polynomial, node_budget=9)
