import numpy as np

from qpdtr.domains.quantum_gravity.matter import (
    simplicial_qubit_hamiltonian,
    simplicial_qubit_matter_control,
)
from qpdtr.domains.quantum_gravity.quantum import FiniteQuantumDynamics, _unvec, _vec


def test_closed_and_open_quantum_certificates():
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    psi = np.array([1, 0], dtype=complex)
    closed = FiniteQuantumDynamics(0.7 * sx + 0.2 * sz).certify(psi, 0.8)
    opened = FiniteQuantumDynamics(0.7 * sx + 0.2 * sz, [np.sqrt(0.1) * sz]).certify(psi, 0.8)
    assert closed.closed_passed
    assert opened.open_passed
    assert opened.purity_final < opened.purity_initial
    assert opened.choi_reshuffle_gap < 1e-12


def test_liouvillian_linear_operator_matches_dense_action():
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    dynamics = FiniteQuantumDynamics(0.4 * sx + 0.1 * sz, [np.sqrt(0.03) * sz])
    density = np.array([[0.7, 0.2j], [-0.2j, 0.3]], dtype=complex)
    dense = dynamics.liouvillian() @ _vec(density)
    matrix_free = dynamics.liouvillian_operator() @ _vec(density)
    assert np.linalg.norm(dense - matrix_free) < 1e-12
    assert np.linalg.norm(_unvec(matrix_free, 2) - dynamics._liouvillian_action(density)) < 1e-12


def test_choi_reshuffle_exactly_matches_basis_construction():
    sx = np.array([[0, 1], [1, 0]], dtype=complex)
    sz = np.array([[1, 0], [0, -1]], dtype=complex)
    dynamics = FiniteQuantumDynamics(0.4 * sx + 0.1 * sz, [np.sqrt(0.03) * sz])
    channel = dynamics.channel_superoperator(0.3)
    reshuffled = dynamics.choi_from_superoperator(channel, 2)
    legacy = np.zeros((4, 4), dtype=complex)
    for i in range(2):
        for j in range(2):
            basis = np.zeros((2, 2), dtype=complex)
            basis[i, j] = 1.0
            legacy[i * 2 : (i + 1) * 2, j * 2 : (j + 1) * 2] = _unvec(
                channel @ _vec(basis), 2
            )
    legacy = 0.5 * (legacy + legacy.conj().T)
    assert np.linalg.norm(reshuffled - legacy) < 1e-13


def test_six_qubit_mps_matches_independent_krylov_reference():
    hamiltonian, _, _ = simplicial_qubit_hamiltonian(6, mass=0.35, hopping=0.12, interaction=0.025)
    from qpdtr.domains.quantum_gravity.quantum import AdaptiveExecutionPolicy, AdaptiveQuantumDynamics

    policy = AdaptiveExecutionPolicy(
        statevector_memory_limit_bytes=1024 * 1024,
        mps_max_bond=64,
        mps_discarded_weight_budget=1e-26,
        trotter_steps=4,
        trajectory_count=4,
        force_mps=True,
    )
    certificate = AdaptiveQuantumDynamics(hamiltonian, policy).execute_closed(0.04)
    assert certificate.passed
    assert certificate.exact_reference_gap is not None
    assert certificate.exact_reference_gap < 1e-7
    assert certificate.entangled_site_count == 6


def test_fifty_local_qubit_simplicial_control():
    certificate = simplicial_qubit_matter_control()
    assert certificate.passed
    assert certificate.qubit_count == 50
    assert certificate.simplex_count == 47
    assert certificate.interaction_edge_count == 144
    assert certificate.interaction_graph_bandwidth == 3
    assert certificate.encoding == "LOCAL_TWO_LEVEL_DEGREE_OF_FREEDOM_PER_SIMPLICIAL_VERTEX"
    assert certificate.scalable_closed_dynamics.interaction_term_count == 482
    assert certificate.scalable_closed_dynamics.compiled_local_generator_count == 194
    assert certificate.scalable_closed_dynamics.representation == "ADAPTIVE_GRAPH_ORDERED_MPS_TEBD"
    assert certificate.scalable_closed_dynamics.statevector_bytes_estimate == 16 * 2**50
    assert certificate.scalable_closed_dynamics.statevector_workspace_bytes_estimate == 6 * 16 * 2**50
    assert certificate.scalable_closed_dynamics.dense_choi_bytes_estimate == 16 * 2**200
    assert certificate.scalable_closed_dynamics.minimum_interaction_degree > 0
    assert certificate.scalable_closed_dynamics.noncommuting_term_pairs > 0
    assert certificate.scalable_closed_dynamics.entangled_site_count > 0
    assert certificate.scalable_open_dynamics.passed
    assert len(certificate.scalable_open_dynamics.mean_excitation_probability) == 50
    assert len(certificate.scalable_open_dynamics.mean_x_expectation) == 50
    assert certificate.processor_emulator.passed
    assert certificate.processor_emulator.backend_resolved in {"NATIVE_CPP_OPENMP", "CUQUANTUM_CUTENSORNET", "TORCH_CPU", "TORCH_CUDA", "TORCH_MPS"}
    assert certificate.processor_emulator.lorentzian_memory is not None
    assert certificate.processor_emulator.lorentzian_memory.passed
    assert certificate.processor_emulator.toric_code is not None
    assert certificate.processor_emulator.toric_code.passed


def test_statevector_route_uses_workspace_not_single_vector_only():
    from qpdtr.domains.quantum_gravity.quantum import AdaptiveExecutionPolicy, AdaptiveQuantumDynamics

    hamiltonian, _, _ = simplicial_qubit_hamiltonian(20, mass=0.35, hopping=0.12, interaction=0.025)
    assert hamiltonian.statevector_bytes == 16 * 2**20
    policy = AdaptiveExecutionPolicy(
        statevector_memory_limit_bytes=32 * 1024 * 1024,
        statevector_workspace_factor=6,
        mps_max_bond=8,
        trotter_steps=1,
        trajectory_count=2,
    )
    dynamics = AdaptiveQuantumDynamics(hamiltonian, policy)
    assert hamiltonian.statevector_bytes < policy.statevector_memory_limit_bytes
    assert hamiltonian.statevector_bytes * policy.statevector_workspace_factor > policy.statevector_memory_limit_bytes
    assert dynamics.selected_representation() == "ADAPTIVE_GRAPH_ORDERED_MPS_TEBD"


def test_mps_error_budget_fails_closed_with_reason():
    from qpdtr.domains.quantum_gravity.quantum import AdaptiveExecutionPolicy, AdaptiveQuantumDynamics

    hamiltonian, _, _ = simplicial_qubit_hamiltonian(8, mass=0.35, hopping=0.4, interaction=0.2)
    policy = AdaptiveExecutionPolicy(
        statevector_memory_limit_bytes=1024,
        statevector_workspace_factor=6,
        mps_max_bond=2,
        mps_discarded_weight_budget=1e-28,
        trotter_steps=1,
        trajectory_count=2,
        force_mps=True,
    )
    certificate = AdaptiveQuantumDynamics(hamiltonian, policy).execute_closed(0.8)
    assert not certificate.passed
    assert certificate.blocked_reason is not None
    assert certificate.blocked_reason.startswith("BLOCKED_RESOURCE_INFEASIBLE:")


def test_general_graph_contraction_tree_matches_krylov_and_uses_exact_slicing():
    from qpdtr.domains.quantum_gravity.matter import general_graph_contraction_control

    certificate = general_graph_contraction_control()
    assert certificate.passed
    assert certificate.qubit_count == 14
    assert certificate.representation == "GENERAL_GRAPH_CONTRACTION_TREE_STATEVECTOR"
    assert certificate.interaction_graph_bandwidth == 12
    assert certificate.interaction_treewidth_upper_bound == 4
    assert certificate.contraction_backend == "NUMPY_CPU"
    assert certificate.contraction_optimizer == "greedy"
    assert certificate.contraction_slice_count == 4
    assert certificate.contraction_sliced_index_count == 2
    assert certificate.contraction_unsliced_peak_elements > certificate.contraction_peak_elements
    assert certificate.contraction_peak_elements <= 131_072
    assert certificate.contraction_parallel_mode == "THREAD_POOL_2"
    assert certificate.exact_reference_gap is not None
    assert certificate.exact_reference_gap < 1e-7
    assert certificate.contraction_norm_crosscheck_gap is not None
    assert certificate.contraction_norm_crosscheck_gap < 1e-10


def test_general_graph_contraction_slice_budget_fails_closed():
    from qpdtr.domains.quantum_gravity.matter import _GENERAL_GRAPH_CONTROL_EDGES
    from qpdtr.domains.quantum_gravity.quantum import (
        AdaptiveExecutionPolicy,
        AdaptiveQuantumDynamics,
        LocalPauliHamiltonian,
        LocalPauliTerm,
    )

    terms = [
        LocalPauliTerm((site,), ("Z",), -0.175, f"z_{site}") for site in range(14)
    ]
    for left, right in _GENERAL_GRAPH_CONTROL_EDGES:
        terms.extend(
            (
                LocalPauliTerm((left, right), ("X", "X"), 0.06, f"xx_{left}_{right}"),
                LocalPauliTerm((left, right), ("Y", "Y"), 0.06, f"yy_{left}_{right}"),
                LocalPauliTerm((left, right), ("Z", "Z"), 0.025, f"zz_{left}_{right}"),
            )
        )
    policy = AdaptiveExecutionPolicy(
        statevector_memory_limit_bytes=1024,
        mps_max_interaction_span=4,
        trotter_steps=1,
        trajectory_count=2,
        contraction_memory_limit_elements=131_072,
        contraction_max_slices=1,
        contraction_parallel_workers=1,
        contraction_statevector_max_qubits=18,
        contraction_backend="numpy",
        force_contraction_tree=True,
    )
    certificate = AdaptiveQuantumDynamics(LocalPauliHamiltonian(14, terms), policy).execute_closed(0.01)
    assert not certificate.passed
    assert certificate.blocked_reason == (
        "BLOCKED_RESOURCE_INFEASIBLE:CONTRACTION_SLICE_BUDGET_EXCEEDED"
    )


def test_forced_unavailable_cupy_backend_fails_closed(monkeypatch):
    import sys

    from qpdtr.domains.quantum_gravity.quantum import (
        AdaptiveExecutionPolicy,
        AdaptiveQuantumDynamics,
        LocalPauliHamiltonian,
        LocalPauliTerm,
    )

    monkeypatch.setitem(sys.modules, "cupy", None)
    terms = [
        LocalPauliTerm((site,), ("Z",), -0.1, f"z_{site}") for site in range(6)
    ]
    terms.extend(
        (
            LocalPauliTerm((0, 5), ("X", "X"), 0.05, "xx_0_5"),
            LocalPauliTerm((0, 5), ("Y", "Y"), 0.05, "yy_0_5"),
            LocalPauliTerm((0, 5), ("Z", "Z"), 0.02, "zz_0_5"),
        )
    )
    policy = AdaptiveExecutionPolicy(
        statevector_memory_limit_bytes=1024,
        mps_max_interaction_span=1,
        trotter_steps=1,
        trajectory_count=2,
        contraction_memory_limit_elements=16_384,
        contraction_max_slices=8,
        contraction_statevector_max_qubits=8,
        contraction_backend="cupy",
        force_contraction_tree=True,
    )
    certificate = AdaptiveQuantumDynamics(LocalPauliHamiltonian(6, terms), policy).execute_closed(0.01)
    assert not certificate.passed
    assert certificate.blocked_reason == (
        "BLOCKED_BACKEND_UNAVAILABLE:CUPY_CUDA_DEVICE_NOT_AVAILABLE"
    )


def test_general_graph_scalar_observable_route_is_complete_and_normalized():
    from qpdtr.domains.quantum_gravity.quantum import (
        AdaptiveExecutionPolicy,
        AdaptiveQuantumDynamics,
        LocalPauliHamiltonian,
        LocalPauliTerm,
    )

    terms = [
        LocalPauliTerm((site,), ("Z",), -0.1, f"z_{site}") for site in range(6)
    ]
    for left, right in ((0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (0, 5)):
        terms.extend(
            (
                LocalPauliTerm((left, right), ("X", "X"), 0.08, f"xx_{left}_{right}"),
                LocalPauliTerm((left, right), ("Y", "Y"), 0.08, f"yy_{left}_{right}"),
                LocalPauliTerm((left, right), ("Z", "Z"), 0.03, f"zz_{left}_{right}"),
            )
        )
    policy = AdaptiveExecutionPolicy(
        statevector_memory_limit_bytes=1024,
        mps_max_interaction_span=1,
        trotter_steps=1,
        trajectory_count=2,
        contraction_memory_limit_elements=16_384,
        contraction_max_slices=8,
        contraction_parallel_workers=2,
        contraction_statevector_max_qubits=2,
        contraction_observable_max_count=64,
        contraction_backend="numpy",
        force_contraction_tree=True,
    )
    certificate = AdaptiveQuantumDynamics(
        LocalPauliHamiltonian(6, terms), policy
    ).execute_closed(0.02)
    assert certificate.passed
    assert certificate.representation == "GENERAL_GRAPH_CONTRACTION_TREE_OBSERVABLES"
    assert certificate.exact_reference_gap is None
    assert certificate.contraction_norm_crosscheck_gap is not None
    assert certificate.contraction_norm_crosscheck_gap < 1e-10
    assert certificate.entangled_site_count == 6


def test_forced_mpi_without_multi_process_runtime_fails_closed(monkeypatch):
    import sys

    from qpdtr.domains.quantum_gravity.quantum import (
        AdaptiveExecutionPolicy,
        AdaptiveQuantumDynamics,
        LocalPauliHamiltonian,
        LocalPauliTerm,
    )

    monkeypatch.setitem(sys.modules, "mpi4py", None)
    terms = [
        LocalPauliTerm((site,), ("Z",), -0.1, f"z_{site}") for site in range(4)
    ]
    for left, right in ((0, 1), (1, 2), (2, 3), (0, 3)):
        terms.extend(
            (
                LocalPauliTerm((left, right), ("X", "X"), 0.05, f"xx_{left}_{right}"),
                LocalPauliTerm((left, right), ("Y", "Y"), 0.05, f"yy_{left}_{right}"),
                LocalPauliTerm((left, right), ("Z", "Z"), 0.02, f"zz_{left}_{right}"),
            )
        )
    policy = AdaptiveExecutionPolicy(
        statevector_memory_limit_bytes=1024,
        mps_max_interaction_span=1,
        trotter_steps=1,
        trajectory_count=2,
        contraction_memory_limit_elements=4096,
        contraction_max_slices=8,
        contraction_statevector_max_qubits=8,
        contraction_backend="numpy",
        contraction_enable_mpi=True,
        force_contraction_tree=True,
    )
    certificate = AdaptiveQuantumDynamics(
        LocalPauliHamiltonian(4, terms), policy
    ).execute_closed(0.01)
    assert not certificate.passed
    assert certificate.blocked_reason == (
        "BLOCKED_BACKEND_UNAVAILABLE:MPI4PY_OR_MPI_RUNTIME_NOT_AVAILABLE"
    )


def _processor_owner():
    from qpdtr.domains.quantum_gravity.quantum import (
        AdaptiveExecutionPolicy,
        AdaptiveQuantumDynamics,
        LocalPauliHamiltonian,
        LocalPauliTerm,
    )

    hamiltonian = LocalPauliHamiltonian(
        3,
        (
            LocalPauliTerm((0,), ("Z",), 0.1, "z0"),
            LocalPauliTerm((1,), ("Z",), 0.1, "z1"),
            LocalPauliTerm((2,), ("Z",), 0.1, "z2"),
            LocalPauliTerm((0, 1), ("X", "X"), 0.05, "xx01"),
        ),
    )
    return AdaptiveQuantumDynamics(
        hamiltonian,
        AdaptiveExecutionPolicy(trotter_steps=1, trajectory_count=2, random_seed=20260728),
    )


def test_processor_emulator_circuit_noise_memory_and_toric_code():
    certificate = simplicial_qubit_matter_control().processor_emulator
    assert certificate.passed
    assert certificate.backend_resolved in {"NATIVE_CPP_OPENMP", "CUQUANTUM_CUTENSORNET", "TORCH_CPU", "TORCH_CUDA", "TORCH_MPS"}
    assert certificate.accelerator_numpy_state_gap < 1e-11
    assert certificate.arbitrary_control_target_gap < 1e-11
    assert certificate.maximum_kraus_completeness_gap < 1e-11
    assert certificate.trajectory_density_gap < 0.04
    assert certificate.lorentzian_memory is not None
    assert certificate.lorentzian_memory.passed
    assert certificate.lorentzian_memory.blp_backflow > 0.0
    assert certificate.toric_code is not None
    assert certificate.toric_code.passed
    assert certificate.toric_code.noncontractible_x_loop_detected
    assert certificate.toric_code.noncontractible_z_loop_detected


def test_processor_noise_rejects_unphysical_t2():
    import pytest

    from qpdtr.domains.quantum_gravity.quantum import ProcessorNoiseSpec

    with pytest.raises(ValueError, match="T2 <= 2\\*T1"):
        ProcessorNoiseSpec(t1=10.0, t2=21.0).validate()


def test_processor_openqasm3_dynamic_pulse_and_arbitrary_control_target():
    from qpdtr.domains.quantum_gravity.accelerators import execute_numpy
    from qpdtr.domains.quantum_gravity.control import OpenQASM3Parser

    program = OpenQASM3Parser.parse(
        """
        OPENQASM 3.0;
        qubit[3] q;
        x q[2];
        cx q[2],q[0];
        rz(pi/3) q[1];
        """
    )
    numpy_state = execute_numpy(program)
    assert abs(numpy_state[5]) > 1.0 - 1e-12
    assert abs(np.vdot(numpy_state, numpy_state).real - 1.0) < 1e-12
    certificate = simplicial_qubit_matter_control().processor_emulator
    assert certificate.openqasm_version == "3.0"
    assert certificate.dynamic_measurement_count >= 2
    assert certificate.dynamic_loop_iterations >= 1
    assert certificate.dynamic_branch_count >= 1
    assert certificate.dynamic_feedforward_gap < 1e-11
    assert certificate.pulse_control is not None and certificate.pulse_control.passed
    assert certificate.adaptive_jump_control is not None and certificate.adaptive_jump_control.passed
    assert certificate.circuit_level_qec is not None and certificate.circuit_level_qec.passed


def test_forced_unavailable_torch_cuda_fails_closed(monkeypatch):
    import torch

    monkeypatch.setattr(torch.cuda, "is_available", lambda: False)
    certificate = _processor_owner().execute_processor_emulator(
        requested_backend="cuda",
        processor_qubits=4,
        trajectory_count=256,
        readout_shots=512,
        toric_lattice_size=3,
        toric_trials=8,
    )
    assert not certificate.passed
    assert certificate.blocked_reason == (
        "BLOCKED_BACKEND_UNAVAILABLE:TORCH_CUDA_DEVICE_NOT_AVAILABLE"
    )


def test_retyped_driven_open_quantum_cell_controls_are_physical_and_fail_closed_ready():
    from qpdtr.domains.quantum_gravity.quantum import retyped_open_systems_control

    certificate = retyped_open_systems_control()
    assert certificate.passed
    assert len(certificate.cell_records) == 12
    assert all(record.original_family == "quantum_closed" for record in certificate.cell_records)
    assert all(record.corrected_family == "quantum_open" for record in certificate.cell_records)
    assert certificate.master_equation_contract == (
        "LINEAR_GKSL_WITH_OPTIONAL_NONLINEAR_HAMILTONIAN"
    )
    assert certificate.mollow_triplet_detected
    assert len(certificate.mollow_peak_frequencies) == 3
    assert certificate.no_signalling_extension_gap < 1e-12
    assert len(certificate.kerr_semiclassical_positive_roots) == 3
    assert certificate.kerr_stationary_state_kernel_dimension == 1
    assert certificate.spatial_kernel_min_eigenvalue >= 0.0
    assert certificate.spatial_dfs_suppression_ratio < 0.05
    assert certificate.topological_flux_periodicity_gap < 1e-12
    assert certificate.eft_generator_trace_gap < 1e-11
    assert 0.0 < certificate.eft_hierarchy_ratio < 1.0
    assert certificate.rg_critical_slowing_ratio > 9.0
