from __future__ import annotations

from qpdtr.domains.quantum_gravity.law_validation import PhysicalLawQualificationOwner


def test_full_table_registry_is_bound_to_the_proof_ladder() -> None:
    certificate = PhysicalLawQualificationOwner().execute()
    assert certificate.registry.passed
    assert certificate.registry.row_count == 9383
    assert certificate.registry.unique_cell_ids == 9383
    assert certificate.registry.unique_cell_execution_digests == 9383
    assert certificate.registry.proof_counts == {
        "P1 OPEN": 1,
        "P2 CONDITIONAL": 9255,
        "P3 OWNER-BOUND": 86,
        "P4 EVIDENCE-BOUND": 41,
    }
    assert certificate.registry.owner_selection_counts == {
        "REFERENCE_OPERATOR_OWNER": 7871,
        "CONTROLLED_NEAR_OWNER": 1354,
        "EXISTING_OWNER_SET": 127,
        "P0_REPLACEMENT_OWNER": 31,
    }
    assert certificate.registry.open_cell_ids == ("CELL-F9FC30783A1D",)
    assert certificate.registry.uncovered_qualification_owners == ()
    assert certificate.registry.p4_without_independent_evidence == ()


def test_table_mapped_quantum_law_algorithms_pass() -> None:
    certificate = PhysicalLawQualificationOwner().execute().quantum_laws
    assert certificate.passed
    assert certificate.mapped_cell_ids["strong_subadditivity"] == "CELL-0585EC0E6A9E"
    assert certificate.mapped_cell_ids["gksl"] == "CELL-5D36F0C92AC9"
    assert certificate.mapped_cell_ids["diffusive_sme"] == "CELL-DEFCD1976DF9"
    assert certificate.strong_subadditivity_min_gap_bits >= -1e-11
    assert certificate.holevo_bound_gap_bits >= 0.0
    assert certificate.qfi >= certificate.classical_fisher_information - 1e-12
    assert certificate.data_processing_gap >= 0.0
    assert certificate.locc_monotonicity_gap >= 0.0
    assert abs(abs(certificate.chern_number) - 1.0) < 1e-10
    assert certificate.diffusive_sme_ensemble_gap < 0.035


def test_nonlinear_pure_state_ansatz_is_rejected_operationally() -> None:
    certificate = PhysicalLawQualificationOwner().execute().quantum_laws
    assert certificate.nonlinear_ensemble_dependence_trace_distance > 0.1
    assert certificate.physical_claim_status == "IMPLEMENTATION_VALIDATED_PHYSICAL_PROOF_WITHHELD"


def test_law_qualification_is_deterministic() -> None:
    first = PhysicalLawQualificationOwner(random_seed=20260729).execute().to_dict()
    second = PhysicalLawQualificationOwner(random_seed=20260729).execute().to_dict()
    assert first == second
