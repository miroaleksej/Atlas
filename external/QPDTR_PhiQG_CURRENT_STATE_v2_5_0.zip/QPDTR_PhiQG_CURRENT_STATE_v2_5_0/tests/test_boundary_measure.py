from qpdtr.domains.quantum_gravity.boundary import isotropic_livine_speziale_boundary_family
from qpdtr.domains.quantum_gravity.measure import RegularizedMeasureSpec, regularized_measure_certificate


def test_coherent_boundary_family_normalization_and_closure():
    certificate = isotropic_livine_speziale_boundary_family()
    assert certificate.passed
    assert len(certificate.face_order) == 10
    assert len(certificate.configurations) > 2
    assert max(certificate.closure_residuals) < 1e-12
    assert certificate.shape_matching_status.startswith("OPEN")


def test_regularized_measure_is_finite_and_tail_bounded():
    certificate = regularized_measure_certificate(RegularizedMeasureSpec())
    assert certificate.passed
    assert certificate.cutoff_tail_fraction < 0.01
    assert certificate.specification.derivation_status == "OPEN_NOT_UNIQUE"
