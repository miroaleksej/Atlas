from qpdtr.domains.quantum_gravity.lorentzian import causal_lorentzian_bisimplex
from qpdtr.domains.quantum_gravity.relational import finite_relational_observable_control


def test_metric_lorentzian_causality_certificate():
    certificate = causal_lorentzian_bisimplex()
    assert certificate.passed
    assert certificate.edge_classes == {"timelike": 8, "spacelike": 6, "null": 0}
    assert certificate.simplex_gram_signatures == ((1, 3, 0), (1, 3, 0))
    assert certificate.shared_slice_normal_time_signs[0] == -certificate.shared_slice_normal_time_signs[1]


def test_relational_povm_is_normalized_and_relabel_covariant():
    certificate = finite_relational_observable_control()
    assert certificate.passed
    assert certificate.relabel_covariance_gap < 1e-12
    assert certificate.sharp_limit_distance < 1e-12
