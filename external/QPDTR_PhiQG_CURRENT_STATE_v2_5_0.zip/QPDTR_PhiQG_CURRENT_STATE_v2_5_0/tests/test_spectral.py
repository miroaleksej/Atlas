import numpy as np
from qpdtr.domains.quantum_gravity.spectral import estimate_spectral_dimension, periodic_grid_graph, plateau_estimate


def test_spectral_ground_truth():
    sigmas = np.logspace(-2,2,81)
    one = estimate_spectral_dimension(periodic_grid_graph((96,)), sigmas)
    two = estimate_spectral_dimension(periodic_grid_graph((24,24)), sigmas)
    assert max(one.backend_disagreement, two.backend_disagreement) < 1e-10
    assert abs(plateau_estimate(one,0.2,8.0)-1) < 0.12
    assert abs(plateau_estimate(two,0.2,8.0)-2) < 0.24
