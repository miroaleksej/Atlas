from __future__ import annotations

import numpy as np

from qpdtr.domains.quantum_gravity.accelerators import (
    NativeStatevectorKernel,
    apply_numpy_gate,
    gate_matrix,
    qualify_accelerators,
)
from qpdtr.domains.quantum_gravity.control import (
    OpenQASM3Executor,
    OpenQASM3Parser,
    QuantumInstruction,
    TransmonPulseEngine,
)
from qpdtr.domains.quantum_gravity.eprl_adapter import AdmittedVertexAmplitudeCache
from qpdtr.domains.quantum_gravity.open_system import certify_adaptive_quantum_jumps
from qpdtr.domains.quantum_gravity.qec import certify_circuit_level_qec


def test_openqasm3_dynamic_feedback_loop_and_timing():
    program = OpenQASM3Parser.parse(
        """OPENQASM 3.0;
qubit[2] q;
bit[2] c;
x q[1];
while (c[1] == 0) { c[1] = measure q[1]; }
reset q[1];
for int i in [0:1] { x q[i]; }
c[0] = measure q[0];
if (c[0] == 1) { x q[1]; } else { z q[1]; }
delay[10ns] q[0], q[1];
"""
    )
    result = OpenQASM3Executor(NativeStatevectorKernel(2), random_seed=7).execute(program)
    expected = np.zeros(4, dtype=complex)
    expected[2] = 1.0
    assert np.linalg.norm(result.statevector - expected) < 1e-12
    assert result.measurement_count == 3
    assert result.loop_iterations == 3
    assert result.branch_count == 1
    assert max(result.qubit_clock_ns) == 70.0


def test_openpulse_qutrit_drag_and_cross_resonance_control():
    program = OpenQASM3Parser.parse(
        """OPENQASM 3.0;
defcalgrammar "openpulse";
qubit[2] q;
cal {
  extern port d0;
  extern port d1;
  frame f0 = newframe(d0, 5.0e9, 0.0);
  frame f1 = newframe(d1, 5.1e9, 0.0);
  waveform x_drag = drag(0.1469837, 40ns, 8.87155645ns, 1.63577546);
  waveform cr_square = constant(0.012, 65.44984694978736ns);
}
defcal x $0 { play(f0, x_drag); }
defcal cr $0, $1 { play(f1, cr_square); }
x q[0];
cr q[0], q[1];
"""
    )
    assert program.pulse_program is not None
    certificate = TransmonPulseEngine().certify(program.pulse_program)
    assert certificate.passed
    assert certificate.single_transmon_leakage < 5e-3
    assert certificate.cross_resonance_process_fidelity > 0.99


def test_native_cpp_kernel_matches_independent_numpy_on_arbitrary_axes():
    instructions = (
        QuantumInstruction("h", (3,)),
        QuantumInstruction("rx", (1,), 0.37),
        QuantumInstruction("cx", (3, 0)),
        QuantumInstruction("swap", (1, 2)),
    )
    native = NativeStatevectorKernel(4)
    reference = np.zeros(16, dtype=complex)
    reference[0] = 1.0
    for instruction in instructions:
        native.apply_instruction(instruction)
        reference = apply_numpy_gate(reference, gate_matrix(instruction), instruction.qubits)
    assert np.linalg.norm(native.to_numpy() - reference) < 1e-12
    assert qualify_accelerators(8).passed


def test_adaptive_quantum_jump_and_pseudomode_controls():
    certificate = certify_adaptive_quantum_jumps(trajectory_count=256, seed=20260729)
    assert certificate.passed
    assert certificate.exact_trace_distance < 0.045
    assert certificate.pseudomode_survival_gap < 2e-6


def test_repeated_syndrome_toric_and_color_qec_control():
    certificate = certify_circuit_level_qec(lattice_size=3, syndrome_rounds=5, trials=128)
    assert certificate.passed
    assert certificate.all_single_data_faults_corrected
    assert certificate.all_single_measurement_faults_corrected
    assert certificate.maximum_residual_syndrome_count == 0
    assert certificate.color_code_single_pauli_faults_corrected


def test_eprl_cache_rejects_non_admitted_evidence(tmp_path):
    from qpdtr.domains.quantum_gravity.eprl_adapter import EPRLProbeResult

    cache = AdmittedVertexAmplitudeCache(tmp_path)
    probe = EPRLProbeResult(
        status="BLOCKED_EXTERNAL_BACKEND",
        backend="sl2cfoam-next",
        request={},
        request_digest="0" * 64,
        reason="absent",
        contract_checks={},
    )
    import pytest

    with pytest.raises(ValueError, match="fully admitted"):
        cache.admit(probe)
