from qpdtr.domains.quantum_gravity.frg import beta_newton_r2, beta_newton_r5, positive_fixed_point
from qpdtr.domains.quantum_gravity.regge import (
    boundary_of_five_simplex,
    regge_equation_certificate,
    scaling_certificate,
)


def test_frg_fixed_points():
    r2 = positive_fixed_point(beta_newton_r2, "R2", "5.17")
    r5 = positive_fixed_point(beta_newton_r5, "R5", "6.14")
    assert abs(r2.fixed_point - 2.0074490937292486) < 1e-12
    assert abs(r2.critical_exponent - 2.2960242865) < 1e-8
    assert abs(r5.fixed_point - 1.999602543523522) < 1e-12
    assert abs(r5.critical_exponent - 2.3112297636) < 1e-8
    assert abs(r2.critical_exponent - r5.critical_exponent) < 0.05


def test_regge_scaling_and_equations():
    geometry = boundary_of_five_simplex(1.0)
    assert geometry.four_simplex_count == 6 and geometry.triangle_count == 20
    scaling = scaling_certificate(1, 2)
    assert abs(scaling.action_ratio - 4) < 1e-12
    assert abs(scaling.curvature_ratio - 0.25) < 1e-12
    assert scaling.invariant_r_sqrt_v_gap < 1e-12
    equations = regge_equation_certificate()
    assert equations.passed
    assert equations.perturbed_gradient_norm > 1e-3
