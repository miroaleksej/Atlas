from qpdtr.domains.quantum_gravity.ponzano_regge import cross_backend_certificate, equilateral_asymptotic, orthogonality_certificate, recoupling_amplitude_matrix
from qpdtr.domains.quantum_gravity.tensor_rg import svd_coarse_grain


def test_exact_ponzano_controls():
    orth = orthogonality_certificate(4)
    assert orth.exact_pass and orth.max_absolute_residual == 0
    cross = cross_backend_certificate([(2,2,0,2,2,0),(2,2,2,2,2,2),(4,4,4,4,4,4),(6,4,2,4,6,4)])
    assert cross.max_absolute_disagreement < 1e-30


def test_large_spin_asymptotic():
    assert equilateral_asymptotic(50).relative_error < 0.025


def test_tensor_certificate():
    matrix,_ = recoupling_amplitude_matrix(6,0.06)
    _,cert = svd_coarse_grain(matrix,3)
    assert cert.retained_bond_dimension == 3 and cert.certified_bound_gap < 1e-12


def test_nd_tensor_certificate_uses_same_owner_algorithm():
    import numpy as np
    from qpdtr.domains.quantum_gravity.tensor_rg import svd_coarse_grain_tensor

    tensor = np.arange(2 * 3 * 4 * 2 * 2, dtype=float).reshape((2, 3, 4, 2, 2))
    approximation, cert = svd_coarse_grain_tensor(tensor, 3, left_axes=(0, 1))
    assert approximation.shape == tensor.shape
    assert cert.original_shape == tensor.shape
    assert cert.left_axes == (0, 1)
    assert cert.right_axes == (2, 3, 4)
    assert cert.retained_bond_dimension == 3
    assert cert.certified_bound_gap < 1e-12
