from __future__ import annotations

import numpy as np
import pytest

from qpdtr.domains.quantum_gravity.fermionic_gaussian import (
    FermionicGaussianLindbladOwner,
    qualify_fermionic_gaussian_runtime,
)


def test_fermionic_gaussian_owner_exact_and_scalable_controls() -> None:
    certificate = qualify_fermionic_gaussian_runtime(scalable_mode_count=64)
    assert certificate.passed
    assert certificate.exact_one_body_gap < 5e-10
    assert certificate.exact_four_point_wick_gap < 5e-10
    assert certificate.scalable_physicality_gap < 2e-8


def test_fermionic_gaussian_owner_fails_closed_outside_physical_covariance() -> None:
    owner = FermionicGaussianLindbladOwner(
        np.diag([0.1, 0.2]),
        np.diag([0.1, 0.1]),
        np.diag([0.02, 0.02]),
    )
    with pytest.raises(ValueError):
        owner.evolve(np.diag([1.2, 0.0]), 0.1)
