import numpy as np

from qpdtr.domains.quantum_gravity.refinement import canonical_refinement_suite, sphere_boundary_complex
from qpdtr.domains.quantum_gravity.simplicial import (
    SimplicialComplex,
    gf2_nullspace,
    gf2_rank,
    gf2_solve,
)


def test_gf2_kernel():
    matrix = np.array([[1, 1, 0], [0, 1, 1]], dtype=np.uint8)
    kernel = gf2_nullspace(matrix)
    assert kernel.shape == (3, 1)
    assert not ((matrix @ kernel) & 1).any()
    assert gf2_rank(matrix) == 2


def _reference_gf2_rank(matrix: np.ndarray) -> int:
    a = np.asarray(matrix, dtype=np.uint8).copy() & 1
    rows, cols = a.shape
    rank = 0
    for col in range(cols):
        pivot = next((row for row in range(rank, rows) if a[row, col]), None)
        if pivot is None:
            continue
        if pivot != rank:
            a[[rank, pivot]] = a[[pivot, rank]]
        for row in range(rank + 1, rows):
            if a[row, col]:
                a[row] ^= a[rank]
        rank += 1
        if rank == rows:
            break
    return rank


def test_vectorized_gf2_owner_matches_independent_reference():
    rng = np.random.default_rng(20260729)
    for rows in range(1, 9):
        for cols in range(1, 9):
            for _ in range(4):
                matrix = rng.integers(0, 2, size=(rows, cols), dtype=np.uint8)
                rank = gf2_rank(matrix)
                assert rank == _reference_gf2_rank(matrix)
                kernel = gf2_nullspace(matrix)
                assert kernel.shape == (cols, cols - rank)
                assert not ((matrix @ kernel) & 1).any()
                if cols:
                    witness = rng.integers(0, 2, size=cols, dtype=np.uint8)
                    rhs = (matrix @ witness) & 1
                    solution = gf2_solve(matrix, rhs)
                    assert np.array_equal((matrix @ solution) & 1, rhs)


def test_nontrivial_homology_through_h4():
    assert SimplicialComplex([(0, 1), (1, 2), (0, 2)]).betti_numbers() == (1, 1)
    for dimension in range(1, 5):
        expected = (1,) + (0,) * (dimension - 1) + (1,)
        assert sphere_boundary_complex(dimension).betti_numbers() == expected


def test_barycentric_refinement_suite():
    suite = canonical_refinement_suite()
    assert all(item["passed"] for item in suite.values())
    assert suite["S4_exact_topology"]["betti"] == (1, 0, 0, 0, 1)
