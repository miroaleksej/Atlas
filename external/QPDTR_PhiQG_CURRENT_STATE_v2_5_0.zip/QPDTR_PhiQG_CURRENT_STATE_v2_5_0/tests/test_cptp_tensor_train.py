from __future__ import annotations

import numpy as np
import pytest

from qpdtr.domains.quantum_gravity.cptp_tensor_train import (
    CPTPTensorTrainLindbladOwner,
    qualify_cptp_tensor_train_runtime,
)


def test_cptp_tensor_train_exact_refinement_and_scalable_control() -> None:
    certificate = qualify_cptp_tensor_train_runtime(scalable_qubit_count=12)
    assert certificate.passed
    assert certificate.exact_frobenius_gap < 2.5e-3
    assert certificate.minimum_density_eigenvalue > -2e-12
    assert certificate.scalable_trace_gap < 2e-10
    assert not certificate.statevector_materialized_scalable


def test_cptp_tensor_train_rejects_missing_bond() -> None:
    zero = np.zeros((2, 2), dtype=complex)
    ground = np.diag([1.0, 0.0]).astype(complex)
    with pytest.raises(ValueError):
        CPTPTensorTrainLindbladOwner([zero, zero], [], [(), ()], [ground, ground])
