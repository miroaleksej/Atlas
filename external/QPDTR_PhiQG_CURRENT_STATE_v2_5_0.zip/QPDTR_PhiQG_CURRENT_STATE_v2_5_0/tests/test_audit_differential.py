from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import sys

from qpdtr.audit import split_semantic_payload
from qpdtr.domains.quantum_gravity.differential import run_differential_benchmarks


def _digest(payload: dict) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def test_performance_telemetry_is_removed_recursively_from_semantic_digest():
    first = {
        "physical": {"elapsed_time": 0.04, "answer": [1.0, 2.0]},
        "control": {
            "contraction_planning_seconds": 0.1,
            "native_max_threads": 5,
            "nested": {"contraction_seconds": 0.2, "residual": 1e-12},
        },
    }
    second = {
        "physical": {"elapsed_time": 0.04, "answer": [1.0, 2.0]},
        "control": {
            "contraction_planning_seconds": 9.1,
            "native_max_threads": 1,
            "nested": {"contraction_seconds": 8.2, "residual": 1e-12},
        },
    }
    split_first = split_semantic_payload(first)
    split_second = split_semantic_payload(second)
    assert split_first.semantic_payload == split_second.semantic_payload
    assert _digest(split_first.semantic_payload) == _digest(split_second.semantic_payload)
    assert split_first.performance_metrics != split_second.performance_metrics
    assert split_first.semantic_payload["physical"]["elapsed_time"] == 0.04


def test_source_tree_launcher_resolves_src_without_pythonpath():
    root = Path(__file__).resolve().parents[1]
    environment = {"PATH": str(Path(sys.executable).parent) + ":/usr/bin:/bin"}
    process = subprocess.run(
        [sys.executable, "scripts/run_execution_bundle.py", "--help"],
        cwd=root,
        env=environment,
        capture_output=True,
        text=True,
        timeout=30,
        check=False,
    )
    assert process.returncode == 0, process.stderr
    assert "--report-dir" in process.stdout


def test_external_differential_suite_never_substitutes_missing_tools():
    certificate = run_differential_benchmarks(eprl_statuses=("BLOCKED_EXTERNAL_BACKEND", "BLOCKED_EXTERNAL_BACKEND"))
    payload = certificate.to_dict()
    assert {case["tool"] for case in payload["cases"]} == {
        "Qiskit Aer",
        "QuTiP",
        "ITensorMPS.jl",
        "Stim + PyMatching",
        "sl2cfoam-next",
    }
    for case in payload["cases"]:
        assert case["status"] == "PASS" or case["status"].startswith(("BLOCKED", "FAIL"))
        if case["status"] == "PASS":
            assert case["value"] is not None
            assert case["tolerance"] is not None
            assert case["value"] <= case["tolerance"]
