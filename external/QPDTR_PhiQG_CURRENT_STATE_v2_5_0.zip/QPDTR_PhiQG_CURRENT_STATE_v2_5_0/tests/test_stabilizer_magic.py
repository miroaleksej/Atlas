import numpy as np

from qpdtr.domains.quantum_gravity.stabilizer import (
    BoundedMagicInjectionRuntime,
    StabilizerTableau,
    qualify_bounded_magic_injection,
    qualify_large_clifford_stabilizer,
    qualify_stabilizer_magic_runtime,
)


def test_tableau_bell_correlations_and_measurement_collapse():
    state = StabilizerTableau.zero_state(2)
    state.h(0)
    state.cnot(0, 1)
    assert state.expectation_pauli("XX") == 1
    assert state.expectation_pauli("ZZ") == 1
    assert state.expectation_pauli("ZI") == 0
    first = state.measure_z(0, forced_outcome=1)
    second = state.measure_z(1)
    assert first.outcome == 1 and not first.deterministic
    assert second.outcome == 1 and second.deterministic


def test_tableau_phase_gates_and_pauli_expectations():
    state = StabilizerTableau.zero_state(1)
    state.h(0)
    assert state.expectation_pauli("X") == 1
    state.s(0)
    assert state.expectation_pauli("Y") == 1
    state.sdg(0)
    assert state.expectation_pauli("X") == 1
    state.z_gate(0)
    assert state.expectation_pauli("X") == -1


def test_magic_branch_runtime_matches_direct_reference():
    runtime = BoundedMagicInjectionRuntime(
        3,
        maximum_t_gates=2,
        maximum_branches=4,
        materialization_qubit_limit=3,
    )
    runtime.apply_clifford("H", 0)
    runtime.apply_clifford("CNOT", 0, 1)
    runtime.apply_t(0)
    runtime.apply_clifford("S", 2)
    runtime.apply_t(1)
    runtime.apply_clifford("CZ", 1, 2)
    branch = runtime.materialize_branch_sum()
    direct = runtime.materialize_direct_reference()
    overlap = np.vdot(direct, branch)
    if abs(overlap):
        branch *= np.exp(-1j * np.angle(overlap))
    assert np.linalg.norm(direct - branch) < 1e-12
    assert len(runtime.branches) == 4


def test_bounded_magic_qualification_passes():
    certificate = qualify_bounded_magic_injection(qubit_count=8, t_gate_count=4)
    assert certificate.passed
    assert certificate.branch_count == 16
    assert certificate.phase_aligned_state_gap < 1e-12


def test_large_clifford_qualification_is_statevector_free():
    certificate = qualify_large_clifford_stabilizer(qubit_count=256)
    assert certificate.passed
    assert certificate.global_x_expectation == 1
    assert certificate.statevector_materialized is False


def test_combined_stabilizer_magic_runtime_certificate():
    certificate = qualify_stabilizer_magic_runtime(
        clifford_qubit_count=128,
        magic_qubit_count=8,
        magic_t_gate_count=4,
    )
    assert certificate.passed
    payload = certificate.to_dict()
    assert payload["sha256"]
