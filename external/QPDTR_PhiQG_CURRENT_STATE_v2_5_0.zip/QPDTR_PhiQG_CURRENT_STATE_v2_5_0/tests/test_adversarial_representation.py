from qpdtr.domains.quantum_gravity.adversarial_representation import (
    qualify_representation_adversarial_benchmark,
)


def test_adversarial_representation_portfolio() -> None:
    certificate = qualify_representation_adversarial_benchmark()
    assert certificate["status"] == "PASS_BOUNDED_ADVERSARIAL_REPRESENTATION_BENCHMARK"
    assert certificate["routing_cases"]["positive_open_chain"]["actual_patch_owner"] == "QCM-CPTP-TT-LINDBLAD"
    assert certificate["routing_cases"]["basis_sparse_crossover"]["actual_patch_owner"] == "QCM-BASS"
    assert certificate["routing_cases"]["observable_pauli"]["active_owner"] == "QCM-PHI-Q1000-ARFE"
    assert certificate["routing_cases"]["tree_graph"]["actual_patch_owner"] == "QCM-GTN-BP"
