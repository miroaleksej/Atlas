from __future__ import annotations
import numpy as np
import networkx as nx
from qpdtr.domains.quantum_gravity.adaptive_ttn import PersistentAdaptiveTTN, qualify_persistent_adaptive_ttn
from qpdtr.domains.quantum_gravity.backend_qualification import qualify_real_backends
from qpdtr.domains.quantum_gravity.error_budget import QuantumErrorAllocation, build_unified_quantum_error_budget
from qpdtr.domains.quantum_gravity.tempo import (
    qualify_process_tensor_digital_twin,
    qualify_process_tensor_memory,
    qualify_temporal_kernel_compression,
)

def test_persistent_adaptive_ttn_reference():
    cert=qualify_persistent_adaptive_ttn()
    assert cert.status=='PASS_BOUNDED_PERSISTENT_ADAPTIVE_TTN'
    assert cert.reconstruction_error is not None and cert.reconstruction_error < 1e-10
    assert cert.topology_rebuild_count > 0
    assert cert.used_maximum_bond >= 2

def test_ttn_state_is_persistent_and_normalized():
    s=PersistentAdaptiveTTN.product_state([0,0,0,0],max_bond=8,discarded_weight_budget=1e-10,maximum_refactor_qubits=8)
    h=np.array([[1,1],[1,-1]],complex)/np.sqrt(2)
    s.apply_one_site_gate(0,h)
    v=s.to_statevector()
    assert abs(np.vdot(v,v).real-1)<1e-12
    cert=s.certificate()
    assert cert.gate_count==1



def test_intervention_complete_process_tensor_memory():
    cert = qualify_process_tensor_memory()
    assert cert.status == "PASS_BOUNDED_SPATIAL_TEMPORAL_PROCESS_TENSOR_TTN"
    assert cert.process_tensor_bond_dimension <= 16
    assert cert.spatial_qubit_count == 2
    assert cert.spatial_temporal_bond_dimension <= 64
    assert cert.spatial_temporal_compression_relative_frobenius_error < 1e-10
    assert cert.spatial_temporal_prediction_gap < 1e-10
    assert cert.unified_error_budget_status == "PASS_UNIFIED_SPATIAL_TEMPORAL_ERROR_BUDGET"
    assert cert.digital_twin_status.startswith("PASS_REAL_CALIBRATION_SNAPSHOT")
    assert cert.digital_twin_non_markovian_status == "BLOCKED_MULTITIME_CALIBRATION_DATA_REQUIRED"
    assert cert.compression_relative_frobenius_error < 1e-10
    assert cert.maximum_intervention_prediction_gap < 1e-10
    assert cert.conditional_probability_gap < 1e-10
    assert cert.conditional_state_trace_distance < 1e-10
    assert cert.causal_break_memory_witness > 1e-3
    assert cert.markov_reset_memory_witness < 1e-10



def test_real_calibration_snapshot_builds_only_markov_digital_twin():
    cert = qualify_process_tensor_digital_twin()
    assert cert.status == "PASS_REAL_CALIBRATION_SNAPSHOT_MARKOV_PROCESS_TENSOR_BASELINE"
    assert cert.backend_name == "ibmq_manila"
    assert cert.calibration_timestamp.startswith("2024-05-27")
    assert cert.markov_process_tensor_bond_dimension == 1
    assert cert.one_step_choi_minimum_eigenvalue >= -1e-10
    assert cert.trace_preservation_gap < 1e-10
    assert cert.non_markovian_identifiability_status == "BLOCKED_MULTITIME_CALIBRATION_DATA_REQUIRED"


def test_temporal_kernel_compression_control():
    cert=qualify_temporal_kernel_compression(linewidth=.4,coupling_rate=2.0)
    assert cert.status.startswith('PASS')
    assert cert.relative_reconstruction_error < 1e-8

def test_unified_quantum_error_budget():
    budget=build_unified_quantum_error_budget((
      QuantumErrorAllocation('a','ttn','norm',1e-7,1e-6,'RSS','state','PASS'),
      QuantumErrorAllocation('b','tempo','norm',2e-7,1e-6,'RSS','state','PASS'),
      QuantumErrorAllocation('c','slice','abs',0.0,1e-12,'MAX','slice','PASS'),
    ))
    assert budget.status == 'PASS_UNIFIED_SPATIAL_TEMPORAL_ERROR_BUDGET'
    assert not budget.exceeded_components
    assert not budget.exceeded_groups
    assert budget.compatible_group_bounds
    assert budget.compatible_group_budgets

def test_backend_qualification_is_fail_closed():
    q=qualify_real_backends()
    assert q.cpu.executed and q.cpu.status=='PASS'
    assert q.cuda.status in {'PASS','BLOCKED_BACKEND_UNAVAILABLE'}
    assert q.mpi.status in {'PASS','BLOCKED_BACKEND_UNAVAILABLE'}

from scipy.linalg import expm
from qpdtr.domains.quantum_gravity.adaptive_ttn import qualify_scalable_adaptive_ttn
from qpdtr.domains.quantum_gravity.quantum import (
    AdaptiveExecutionPolicy,
    AdaptiveQuantumDynamics,
    LocalPauliHamiltonian,
    LocalPauliTerm,
    QuantumWorkloadProfile,
)


def test_ttn_arbitrary_pair_path_update_matches_dense_reference():
    rng=np.random.default_rng(11)
    n=8
    state=PersistentAdaptiveTTN.product_state([0]*n,max_bond=64,discarded_weight_budget=1e-12,maximum_refactor_qubits=10)
    reference=np.zeros(2**n,complex); reference[0]=1
    for step in range(16):
        if step%4==0:
            site=int(rng.integers(n))
            h=rng.normal(size=(2,2))+1j*rng.normal(size=(2,2)); h=(h+h.conj().T)/2
            gate=expm(-0.07j*h)
            state.apply_one_site_gate(site,gate)
            tensor=reference.reshape((2,)*n)
            moved=np.moveaxis(tensor,site,0)
            moved=(gate@moved.reshape(2,-1)).reshape(moved.shape)
            reference=np.moveaxis(moved,0,site).reshape(-1)
        else:
            first,second=(int(v) for v in rng.choice(n,2,replace=False))
            h=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4)); h=(h+h.conj().T)/2
            gate=expm(-0.03j*h)
            state.apply_two_site_gate(first,second,gate)
            tensor=reference.reshape((2,)*n)
            moved=np.moveaxis(tensor,(first,second),(0,1))
            moved=(gate@moved.reshape(4,-1)).reshape(moved.shape)
            reference=np.moveaxis(moved,(0,1),(first,second)).reshape(-1)
    actual=state.to_statevector(maximum_qubits=10)
    phase=np.vdot(reference,actual)
    actual*=np.exp(-1j*np.angle(phase))
    assert np.linalg.norm(reference-actual)<1e-10
    assert state.local_path_update_count>0
    assert state.tree_rotation_count>0



def test_graph_aware_tree_rotations_preserve_arbitrary_state_under_identity_gate():
    rng = np.random.default_rng(20260801)
    qubits = 6
    vector = rng.normal(size=2**qubits) + 1.0j * rng.normal(size=2**qubits)
    vector /= np.linalg.norm(vector)
    graph = nx.Graph()
    graph.add_nodes_from(range(qubits))
    graph.add_edges_from(((0, 4), (4, 2), (2, 5), (5, 1), (1, 3)))
    state = PersistentAdaptiveTTN(
        vector,
        qubit_count=qubits,
        max_bond=64,
        discarded_weight_budget=0.0,
        interaction_graph=graph,
        maximum_refactor_qubits=10,
    )
    before = state.to_statevector(maximum_qubits=10)
    state.apply_two_site_gate(0, 3, np.eye(4, dtype=complex))
    after = state.to_statevector(maximum_qubits=10)
    phase = np.vdot(before, after)
    after *= np.exp(-1.0j * np.angle(phase))
    assert np.linalg.norm(before - after) < 1e-12
    assert state.tree_rotation_count > 0

def test_structured_50_qubit_ttn_is_statevector_free_and_globally_entangled():
    cert=qualify_scalable_adaptive_ttn(50)
    assert cert.passed
    assert cert.entangled_site_count==50
    assert cert.statevector_materialized is False
    assert cert.maximum_zz_correlation_gap<1e-12
    assert cert.global_x_string_gap<1e-12


def test_multidimensional_workload_selects_ttn_and_executes_bounded_reference():
    terms=[]
    for site in range(8):
        terms.append(LocalPauliTerm((site,),('Z',),0.07,f'z{site}'))
    for site in range(7):
        terms.append(LocalPauliTerm((site,site+1),('X','X'),0.2,f'xx{site}'))
    hamiltonian=LocalPauliHamiltonian(8,terms)
    profile=QuantumWorkloadProfile(
        qubit_count=8,
        circuit_geometry='tree_like',
        tensor_network_geometry='adaptive_tree',
        entanglement_growth_rate='moderate',
        estimated_treewidth=1,
        axis_registry_digest='test-axis-digest',
    )
    policy=AdaptiveExecutionPolicy(
        statevector_memory_limit_bytes=1024,
        ttn_max_bond=64,
        ttn_discarded_weight_budget=1e-28,
        ttn_treewidth_upper_bound=4,
        trotter_steps=4,
    )
    runtime=AdaptiveQuantumDynamics(hamiltonian,policy,profile)
    decision=runtime.method_decision()
    assert decision.representation=='PERSISTENT_ADAPTIVE_TTN_PATH_UPDATE'
    cert=runtime.execute_closed(0.1)
    assert cert.representation=='PERSISTENT_ADAPTIVE_TTN_PATH_UPDATE'
    assert cert.exact_reference_gap is not None and cert.exact_reference_gap<1e-7
    assert cert.passed


def test_structured_50_qubit_ttn_hamiltonian_dynamics_is_statevector_free():
    from qpdtr.domains.quantum_gravity.quantum import (
        qualify_structured_50_qubit_ttn_hamiltonian_dynamics,
    )

    certificate = qualify_structured_50_qubit_ttn_hamiltonian_dynamics()
    assert certificate.passed
    assert certificate.qubit_count == 50
    assert certificate.representation == "PERSISTENT_ADAPTIVE_TTN_PATH_UPDATE"
    assert certificate.ttn_statevector_materialized is False
    assert certificate.interaction_treewidth_upper_bound == 1
    assert certificate.interaction_term_count == 75
    assert certificate.noncommuting_term_pairs == 50
    assert certificate.entangled_site_count == 50
    assert certificate.max_bond_used >= 2
    assert certificate.trotter_step_doubling_gap < 5e-2
