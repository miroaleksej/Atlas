import pytest

from qpdtr.model import PhiQGModelSpec


def test_canonical_current_identity_and_active_owners():
    spec = PhiQGModelSpec()
    spec.validate()
    assert (spec.domain, spec.model, spec.status, spec.spacetime_dimension) == (
        "quantum_gravity",
        "PhiQG",
        "NEW_CANDIDATE",
        4,
    )
    assert spec.signature == "lorentzian_target"
    assert spec.gauge_group == "SL(2,C)"
    assert spec.boundary_state_scope == "normalized_isotropic_Livine_Speziale_scale_mode"
    assert spec.measure_status == "REGULARIZED_EPRL_CANDIDATE_MEASURE"
    assert spec.quantum_qubit_count == 50
    assert spec.quantum_statevector_workspace_factor == 6
    assert spec.quantum_mps_max_bond >= 2
    assert spec.quantum_trajectory_count >= 2
    assert {observable.scope for observable in spec.observables} == {"CONTROL", "TARGET"}


def test_invalid_identity_rejected():
    with pytest.raises(ValueError):
        PhiQGModelSpec(domain="quantum").validate()
    with pytest.raises(ValueError):
        PhiQGModelSpec(spacetime_dimension=3).validate()
    with pytest.raises(ValueError):
        PhiQGModelSpec(signature="euclidean").validate()
    with pytest.raises(ValueError):
        PhiQGModelSpec(gauge_group="SU(2)").validate()
    with pytest.raises(ValueError):
        PhiQGModelSpec(boundary_state_scope="unsupported_boundary_scope").validate()
    with pytest.raises(ValueError):
        PhiQGModelSpec(quantum_qubit_count=49).validate()
    with pytest.raises(ValueError):
        PhiQGModelSpec(quantum_statevector_workspace_factor=1).validate()
