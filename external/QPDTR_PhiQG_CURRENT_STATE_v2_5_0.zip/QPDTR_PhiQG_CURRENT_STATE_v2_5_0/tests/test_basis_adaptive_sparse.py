from __future__ import annotations

import pytest

from qpdtr.domains.quantum_gravity.basis_adaptive_sparse import (
    BasisAdaptiveSparseStateOwner,
    qualify_basis_adaptive_sparse_runtime,
)


def test_basis_adaptive_sparse_improves_bounded_control() -> None:
    certificate = qualify_basis_adaptive_sparse_runtime()
    assert certificate.passed
    assert certificate.adaptive_basis_fidelity > certificate.fixed_basis_fidelity
    assert certificate.fidelity_gain > 1.5
    assert not certificate.statevector_materialized_scalable


def test_basis_adaptive_sparse_rejects_zero_budget() -> None:
    with pytest.raises(ValueError):
        BasisAdaptiveSparseStateOwner(4, sparse_budget=0)
