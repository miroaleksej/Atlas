from __future__ import annotations

from qpdtr.domains.quantum_gravity.portfolio import qualify_method_route
from qpdtr.domains.quantum_gravity.quantum import qualify_high_treewidth_contraction_fallback
from qpdtr.domains.quantum_gravity.schwarzschild_4d import (
    qualify_schwarzschild_4d_radial_modes,
    scalar_greybody_mode,
)


def test_high_treewidth_contraction_fallback_is_executed() -> None:
    certificate = qualify_high_treewidth_contraction_fallback()
    assert certificate.passed
    assert certificate.representation == "GENERAL_GRAPH_CONTRACTION_TREE_STATEVECTOR"
    assert certificate.interaction_treewidth_upper_bound == 7
    assert certificate.minimum_interaction_degree == 7
    assert certificate.exact_reference_gap is not None
    assert certificate.exact_reference_gap < 1e-7


def test_compiler_route_binding_is_fail_closed_for_external_accelerator() -> None:
    methods = (
        "QCM-ADAPTIVE-TTN",
        "QCM-CONTRACTION-OPT",
        "QCM-GENERAL-TN",
        "QCM-MULTIGPU",
        "QCM-TEMPO",
        "QCM-TRAJECTORIES",
    )
    evidence = {method: True for method in methods if method != "QCM-MULTIGPU"}
    evidence["QCM-MULTIGPU"] = "BLOCKED_EXTERNAL_BACKEND"
    certificate = qualify_method_route("QROUTE-TEST", methods, evidence)
    assert certificate.status == "PASS_WITH_EXTERNAL_ACCELERATOR_BLOCKED"
    assert not certificate.route_executable_on_current_cpu
    assert certificate.route_executable_with_blocked_accelerators_removed
    assert certificate.blocked_external_method_count == 1
    assert certificate.missing_method_count == 0


def test_schwarzschild_scalar_flux_control() -> None:
    mode = scalar_greybody_mode(1, 0.30, radius_max=100.0)
    assert 0.0 <= mode.transmission <= 1.0
    assert 0.0 <= mode.reflection <= 1.0
    assert mode.flux_gap < 1e-7


def test_bounded_schwarzschild_4d_qualification() -> None:
    certificate = qualify_schwarzschild_4d_radial_modes()
    assert certificate.passed
    assert certificate.angular_cutoff == 6
    assert certificate.adaptive_angular_converged
    assert certificate.radial_mode_count == 455
    assert certificate.maximum_flux_gap < 5e-8
    assert certificate.angular_cutoff_correlation_gap < 3e-3
    assert certificate.angular_cutoff_population_gap < 2e-4
    assert certificate.reduced_population_rank_gap_33_65 < 5e-4
    assert certificate.reduced_population_rank_gap_33_65 < certificate.reduced_population_rank_gap_17_33
