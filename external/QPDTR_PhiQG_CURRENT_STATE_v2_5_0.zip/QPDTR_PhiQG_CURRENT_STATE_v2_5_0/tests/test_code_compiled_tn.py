import pytest

from qpdtr.domains.quantum_gravity.code_compiled_tn import (
    CodeCompilationCertificate,
    PermutationTrackedMPS,
    ghz_encoder_mps,
    qualify_code_compiled_tensor_network,
)


def test_code_compiled_tensor_network_matches_dense_and_preserves_bond():
    certificate = qualify_code_compiled_tensor_network()
    assert certificate.passed
    assert certificate.exact_reference_gap < 1e-11
    assert certificate.large_qubit_count == 256
    assert certificate.large_peak_bond == certificate.encoder_peak_bond == 2
    assert certificate.statevector_materialized_large is False


def test_code_compiled_runtime_rejects_unverified_compilation():
    certificate = CodeCompilationCertificate.issue(
        compiler_id="unverified",
        code_family="none",
        encoder_digest="0" * 64,
        logical_gate_library=(),
        verified=False,
    )
    with pytest.raises(ValueError, match="verified compilation certificate"):
        PermutationTrackedMPS(ghz_encoder_mps(4), certificate)
