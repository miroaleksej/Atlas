from __future__ import annotations

import numpy as np

from qpdtr.domains.quantum_gravity.error_budget import (
    build_interference_aware_error_bound,
    qualify_error_interference_control,
)
from qpdtr.domains.quantum_gravity.generator_learning import (
    qualify_bounded_generator_learning,
)
from qpdtr.domains.quantum_gravity.tempo import qualify_process_tensor_memory


def test_process_tensor_memory_is_intervention_complete_and_causal():
    certificate = qualify_process_tensor_memory()
    assert certificate.passed
    assert certificate.status == "PASS_BOUNDED_SPATIAL_TEMPORAL_PROCESS_TENSOR_TTN"
    assert certificate.process_tensor_bond_dimension == 16
    assert certificate.spatial_temporal_bond_dimension == 64
    assert certificate.maximum_intervention_prediction_gap < 1e-12
    assert certificate.spatial_temporal_prediction_gap < 1e-12
    assert certificate.unified_error_budget_status.startswith("PASS")
    assert certificate.conditional_probability_gap < 1e-12
    assert certificate.causal_break_memory_witness > 1e-3
    assert certificate.markov_reset_memory_witness < 1e-12


def test_generator_learning_blind_holdout_and_uncertainty():
    certificate = qualify_bounded_generator_learning()
    assert certificate.passed
    assert certificate.generator_matrix_gap < 0.01
    assert certificate.generator_drift_gap < 0.005
    assert certificate.holdout_maximum_gap < 0.01
    assert certificate.confidence_coverage_rate >= 0.9


def test_error_interference_is_certified_only_from_valid_geometry():
    certificate = qualify_error_interference_control()
    assert certificate.status == 'PASS_CERTIFIED_INTERFERENCE_BOUND'
    assert certificate.interference_bound is not None
    assert certificate.interference_bound < certificate.triangle_bound
    assert abs(certificate.interference_bound - certificate.actual_aggregate_norm) < 1e-12

    diagnostic = build_interference_aware_error_bound(
        ('a', 'b'),
        (0.1, 0.1),
        normalized_gram=np.asarray([[1.0, -0.5], [-0.5, 1.0]]),
        certified_gram_upper_bound=False,
    )
    assert diagnostic.status == 'PASS_DIAGNOSTIC_INTERFERENCE_TRIANGLE_REMAINS_AUTHORITATIVE'


def test_invalid_interference_gram_is_blocked():
    certificate = build_interference_aware_error_bound(
        ('a', 'b'),
        (0.1, 0.1),
        normalized_gram=np.asarray([[1.0, -2.0], [-2.0, 1.0]]),
        certified_gram_upper_bound=True,
    )
    assert certificate.status == 'BLOCKED_INVALID_GRAM_CERTIFICATE'
