import numpy as np

from qpdtr.domains.quantum_gravity.structural_router import (
    CircuitInstruction,
    GraphTensorNode,
    SparsePauliObservable,
    StructuralProfile,
    compute_backward_causal_cone,
    contract_graph_tensor_network_bp,
    propagate_pauli_observable,
    qualify_phi_q1000_arfe,
    select_structural_owner,
)


def test_phi_q1000_arfe_qualification() -> None:
    qualification = qualify_phi_q1000_arfe()
    assert qualification.status == "PASS_PHI_Q1000_ADAPTIVE_RESOURCE_FACTORIZED_EMULATOR"
    assert qualification.causal_cone.qubit_count == 1000
    assert len(qualification.causal_cone.causal_qubits) == 16
    assert qualification.pauli_observable.status == "PASS_PAULI_OBSERVABLE_PROPAGATION"
    assert qualification.graph_tensor_bp.node_count == 1000
    assert qualification.graph_tensor_bp.status == "PASS_GRAPH_TENSOR_BP"
    assert qualification.unified_error_budget["status"] == "PASS_UNIFIED_SPATIAL_TEMPORAL_ERROR_BUDGET"


def test_exact_backward_causal_cone_tracks_feedforward() -> None:
    circuit = (
        CircuitInstruction("H", (0,)),
        CircuitInstruction("MEASURE", (0,), classical_writes=(2,)),
        CircuitInstruction("X", (7,), classical_reads=(2,)),
        CircuitInstruction("H", (9,)),
    )
    cone = compute_backward_causal_cone(10, circuit, observable_support=(7,))
    assert cone.included_instruction_indices == (0, 1, 2)
    assert cone.causal_qubits == (0, 7)
    assert cone.causal_classical_bits == (2,)
    assert cone.excluded_instruction_count == 1


def test_pauli_observable_propagation_is_statevector_free_and_bounded() -> None:
    circuit = (
        CircuitInstruction("H", (0,)),
        CircuitInstruction("CNOT", (0, 1)),
        CircuitInstruction("RZ", (1,), parameters=(0.37,)),
    )
    observable = SparsePauliObservable.from_terms(1000, {((1, "X"),): 1.0})
    certificate = propagate_pauli_observable(
        observable,
        circuit,
        max_terms=16,
        allocated_error_budget=1e-12,
    )
    assert certificate.status == "PASS_PAULI_OBSERVABLE_PROPAGATION"
    assert certificate.qubit_count == 1000
    assert certificate.output_term_count == 2
    assert certificate.dropped_l1_error_bound <= 1e-12


def test_graph_tensor_bp_is_exact_on_tree_and_blocks_uncontrolled_loop() -> None:
    tree = (
        GraphTensorNode(0, (1,), np.array([0.6, 0.4])),
        GraphTensorNode(1, (0, 2), np.array([[0.9, 0.1], [0.2, 0.8]])),
        GraphTensorNode(2, (1,), np.ones(2)),
    )
    exact = contract_graph_tensor_network_bp(tree, independent_reference=1.0)
    assert exact.status == "PASS_GRAPH_TENSOR_BP"
    assert exact.exact_tree_contraction
    assert exact.reference_gap is not None and exact.reference_gap <= 1e-12

    loop = (
        GraphTensorNode(0, (1, 2), np.eye(2)),
        GraphTensorNode(1, (0, 2), np.eye(2)),
        GraphTensorNode(2, (0, 1), np.eye(2)),
    )
    blocked = contract_graph_tensor_network_bp(loop)
    assert blocked.status == "BLOCKED_LOOPY_GRAPH_BP_REQUIRES_CLUSTER_OR_REFERENCE_CERTIFICATE"


def test_legacy_selector_delegates_to_single_arfe_owner() -> None:
    decision = select_structural_owner(
        StructuralProfile(
            qubit_count=1000,
            simulation_object="observable",
            causal_cone_qubit_count=32,
            pauli_observable_admissible=True,
            estimated_pauli_term_count=512,
            pauli_term_budget=1024,
        )
    )
    assert decision.selected_method_id == "QCM-PHI-Q1000-ARFE"
    assert decision.primary_patch_owner_id == "QCM-PAULI-OBS"
    assert decision.patch_owner_ids == ("QCM-CAUSAL-CONE", "QCM-PAULI-OBS")
    assert decision.passed


def test_generic_full_state_1000_is_fail_closed() -> None:
    decision = select_structural_owner(StructuralProfile(qubit_count=1000, simulation_object="full_state"))
    assert decision.status == "BLOCKED_NO_CERTIFIED_RESOURCE_FACTORIZED_ROUTE"
    assert decision.primary_patch_owner_id is None
    assert any("exponentially blocked" in reason for reason in decision.rejected_shortcuts)
