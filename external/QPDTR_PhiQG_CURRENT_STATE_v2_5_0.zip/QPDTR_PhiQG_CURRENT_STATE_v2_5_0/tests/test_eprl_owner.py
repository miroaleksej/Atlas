import hashlib
import json
import sys
from dataclasses import asdict
from pathlib import Path

import numpy as np

from qpdtr.domains.quantum_gravity.eprl_adapter import (
    BackendInvocation,
    SL2CfoamAdapter,
    SL2CfoamRuntime,
    assess_shell_sequence,
    source_tree_digest,
)
from qpdtr.model import EPRLShellPolicy
from qpdtr.owner import QuantumGravityDynamicsOwner, _digest as _owner_digest, _target_tensor_coarse_graining


def _digest(payload) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _runtime(tmp_path: Path) -> SL2CfoamRuntime:
    root = tmp_path / "sl2cfoam-next"
    (root / "julia").mkdir(parents=True)
    (root / "lib").mkdir()
    module = root / "julia" / "SL2Cfoam.jl"
    module.write_text(
        "module SL2Cfoam\n"
        "cinit()=nothing\ncclear()=nothing\nvertex_compute()=nothing\n"
        "coherentstate_compute()=nothing\ncontract()=nothing\nintertwiner_range()=nothing\nend\n",
        encoding="utf-8",
    )
    library = root / "lib" / "libsl2cfoam.so"
    library.write_bytes(b"contract-test-library")
    tables = tmp_path / "tables"
    tables.mkdir()
    table3 = tables / "test.3j"
    table6 = tables / "test.6j"
    table3.write_bytes(b"3j-table")
    table6.write_bytes(b"6j-table")
    build = {"command": "make BLAS=system ADD_CFLAGS=-O3", "compiler": "gcc-test", "flags": ["-O3"]}
    dependencies = {"wigxjpf": "1.13", "fastwigxj": "1.4.1", "blas": "system-test"}
    build_digest = _digest({"build": build, "dependencies": dependencies})
    table_artifacts = [
        {"relative_path": table3.name, "sha256": _sha(table3)},
        {"relative_path": table6.name, "sha256": _sha(table6)},
    ]
    identity = {
        "backend": "sl2cfoam-next",
        "upstream_repository": "https://github.com/qg-cpt-marseille/sl2cfoam-next",
        "commit_sha": "a" * 40,
        "source_tree_sha256": source_tree_digest(root),
        "library_sha256": _sha(library),
        "julia_module_sha256": _sha(module),
        "fastwigxj_tables": table_artifacts,
        "y_map": "gamma_j_plus_one",
        "build_identity_sha256": build_digest,
    }
    provenance = {
        "schema": "qpdtr-sl2cfoam-backend-provenance-current",
        **identity,
        "library_relative_path": "lib/libsl2cfoam.so",
        "julia_module_relative_path": "julia/SL2Cfoam.jl",
        "build": build,
        "dependencies": dependencies,
        "backend_identity_sha256": _digest(identity),
    }
    provenance_path = tmp_path / "backend_provenance.json"
    provenance_path.write_text(json.dumps(provenance, indent=2, sort_keys=True), encoding="utf-8")
    runtime, reason = SL2CfoamRuntime.from_paths(
        root=root,
        tables=tables,
        julia=Path(sys.executable),
        provenance_path=provenance_path,
    )
    assert runtime is not None, reason
    return runtime


class ContractRunner:
    def __init__(self, *, converged: bool = True):
        self.converged = converged

    def execute(self, invocation: BackendInvocation):
        request = invocation.request
        policy = request["shell_policy"]
        minimum = int(policy["minimum_shell"])
        maximum = int(policy["maximum_shell"])
        if self.converged:
            shells = list(range(minimum, minimum + int(policy["minimum_samples"])))
            values = [1.0 + 1.0e-12 * index for index in range(len(shells))]
        else:
            shells = list(range(minimum, maximum + 1))
            values = [1.0 + 0.1 * index for index in range(len(shells))]
        sequence = [
            {"shell": shell, "contracted_amplitude": {"real": value, "imag": 0.0}}
            for shell, value in zip(shells, values)
        ]
        certificate = assess_shell_sequence(sequence, policy)
        artifacts = []
        amplitudes = []
        final_pair = shells[-2:]
        role = (
            "single_vertex_tensor"
            if request["task"] == "single_vertex_coherent_family"
            else "delta3_constituent_vertex_tensor"
        )
        for index, configuration in enumerate(request["amplitude_configurations"]):
            configuration_id = configuration["configuration_id"]
            for shell_index, shell in enumerate(final_pair):
                base = np.arange(32, dtype="<f8") + index + 1
                perturbation = (shell_index * 1.0e-12) if self.converged else (shell_index * 0.1)
                tensor = (base + perturbation).reshape((2, 2, 2, 2, 2), order="F")
                relative = f"tensors/{request['task']}_{configuration_id}_shell_{shell}.f64"
                path = invocation.workdir / relative
                path.parent.mkdir(parents=True, exist_ok=True)
                tensor.ravel(order="F").tofile(path)
                artifacts.append(
                    {
                        "relative_path": relative,
                        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                        "shape": [2, 2, 2, 2, 2],
                        "dtype": "float64_le",
                        "storage": "raw_column_major",
                        "element_count": 32,
                        "role": role,
                        "configuration_id": configuration_id,
                        "shell": shell,
                    }
                )
            amplitudes.append(
                {
                    "configuration_id": configuration_id,
                    "amplitude": {"real": float(index + 1), "imag": -0.25 * index},
                }
            )
        shell_report = {
            "policy_digest": request["shell_policy_digest"],
            "sequence": sequence,
            "increments": certificate["increments"],
            "executed_shells": certificate["executed_shells"],
            "successive_shell_estimator": certificate["successive_shell_estimator"],
            "relative_successive_shell_estimator": certificate["relative_successive_shell_estimator"],
            "stable_steps_observed": certificate["stable_steps_observed"],
            "converged": certificate["converged"],
            "termination_reason": certificate["termination_reason"],
            "interpretation": certificate["interpretation"],
        }
        runtime = invocation.runtime
        return {
            "backend": "sl2cfoam-next",
            "backend_identity_digest": runtime.backend_identity_digest,
            "commit_sha": runtime.commit_sha,
            "source_digest": runtime.source_digest,
            "library_digest": runtime.library_digest,
            "julia_module_digest": runtime.julia_module_digest,
            "build_identity_digest": runtime.build_identity_digest,
            "table_artifacts": list(runtime.table_artifacts),
            "y_map": runtime.y_map,
            "request_digest": invocation.request_digest,
            "precision": "contract-test-float64",
            "boundary_family_digest": request["boundary_family"]["family_digest"],
            "complex_contract_digest": request["complex_contract_digest"],
            "configuration_amplitudes": amplitudes,
            "contracted_amplitude": sequence[-1]["contracted_amplitude"],
            "shell_convergence": shell_report,
            "tensor_artifacts": artifacts,
        }


def _request():
    family = {"family": "contract_test", "family_digest": "b" * 64}
    contract = {"id": "single_4simplex_vertex"}
    policy = asdict(EPRLShellPolicy(maximum_shell=5, minimum_samples=4, stable_steps=3))
    return {
        "task": "single_vertex_coherent_family",
        "model": "Lorentzian_EPRL",
        "boundary_family": family,
        "amplitude_configurations": [
            {
                "configuration_id": "c0",
                "twice_spins": [2] * 10,
                "coefficient": {"real": 1.0, "imag": 0.0},
            }
        ],
        "complex_contract": contract,
        "complex_contract_digest": _digest(contract),
        "shell_policy": policy,
        "shell_policy_digest": _digest(policy),
        "y_map": "gamma_j_plus_one",
    }


def _clear_backend_env(monkeypatch):
    for name in (
        "QPDTR_SL2CFOAM_ROOT",
        "QPDTR_SL2CFOAM_PROVENANCE",
        "QPDTR_SL2CFOAM_TABLES",
        "QPDTR_JULIA",
    ):
        monkeypatch.delenv(name, raising=False)


def test_adapter_fails_closed_without_immutable_runtime(tmp_path, monkeypatch):
    _clear_backend_env(monkeypatch)
    result = SL2CfoamAdapter().probe(_request(), tmp_path)
    assert result.status == "BLOCKED_EXTERNAL_BACKEND"
    assert result.output is None
    assert (tmp_path / "eprl_request.json").is_file()


def test_adapter_requires_exact_provenance_adaptive_shell_and_tensor_contract(tmp_path):
    runtime = _runtime(tmp_path)
    result = SL2CfoamAdapter(runtime=runtime, runner=ContractRunner()).probe(
        _request(), tmp_path / "work"
    )
    assert result.status == "PASS"
    assert all(result.contract_checks.values())
    assert result.shell_certificate["converged"]
    assert len(result.tensor_artifacts) == 1
    assert len(result.tensor_shell_certificates) == 1
    assert result.tensor_shell_certificates[0]["passed"]


def test_runtime_rejects_mutated_compiled_library(tmp_path):
    runtime = _runtime(tmp_path)
    runtime.library_path.write_bytes(b"mutated")
    discovered, reason = SL2CfoamRuntime.from_paths(
        root=runtime.root,
        tables=runtime.tables,
        julia=runtime.julia,
        provenance_path=runtime.provenance_path,
    )
    assert discovered is None
    assert "library digest mismatch" in reason.lower()


def test_valid_backend_but_unstable_shells_are_partial_and_not_admitted(tmp_path):
    runtime = _runtime(tmp_path)
    result = SL2CfoamAdapter(runtime=runtime, runner=ContractRunner(converged=False)).probe(
        _request(), tmp_path / "unstable"
    )
    assert result.status == "PARTIAL_SHELL_NOT_CONVERGED"
    assert all(result.contract_checks.values())
    assert not result.shell_certificate["converged"]


def test_owner_current_bundle_replay_is_blocked_without_backend(tmp_path, monkeypatch):
    _clear_backend_env(monkeypatch)
    first = QuantumGravityDynamicsOwner().execute(tmp_path / "current")
    assert first["verdict"] == "QUANTUM_EMULATOR_CONTROL_PASS_TARGET_EPRL_BLOCKED"
    assert first["evidence_grade"] == "EVIDENCE_TABLE_BOUND_ATLAS_BOUNDED_OPENQASM3_PULSE_QEC_50_QUBIT_QG_CONTROL_VALIDATION"
    assert first["control_summary"] == {"passed": 53, "total": 53, "failed": []}
    assert set(first["target_summary"]["blocked"]) == {
        "lorentzian_eprl_single_vertex_coherent_family",
        "lorentzian_eprl_delta3_three_vertex",
        "eprl_target_tensor_coarse_graining",
    }
    semantic_payload = {
        key: value for key, value in first.items()
        if key not in {"execution_digest", "performance_telemetry"}
    }
    assert first["performance_telemetry"]["excluded_from_execution_digest"] is True
    assert first["execution_digest"] == _owner_digest(semantic_payload)


def test_owner_feeds_only_shell_stable_admitted_tensors_to_existing_svd_owner(tmp_path, monkeypatch):
    runtime = _runtime(tmp_path)
    adapter = SL2CfoamAdapter(runtime=runtime, runner=ContractRunner())
    monkeypatch.setattr("qpdtr.owner.SL2CfoamAdapter", lambda: adapter)
    result = QuantumGravityDynamicsOwner().execute(tmp_path / "executed")
    assert result["target_evidence"]["single_vertex_target_tensor_coarse_graining"]["status"] == "PASS"
    assert result["target_evidence"]["delta3_target_tensor_coarse_graining"]["status"] == "PASS"
    assert result["target_requirements"]["eprl_target_tensor_coarse_graining"]["status"] == "PASS"
    assert result["target_requirements"]["multi_complex_renormalization"]["status"] == "PARTIAL"
    assert not result["target_summary"]["blocked"]



def test_unstable_probe_is_not_admitted_to_svd_owner(tmp_path):
    runtime = _runtime(tmp_path)
    probe = SL2CfoamAdapter(runtime=runtime, runner=ContractRunner(converged=False)).probe(
        _request(), tmp_path / "unstable_svd"
    )
    result = _target_tensor_coarse_graining(probe, tmp_path / "target", max_bond=2)
    assert result["status"] == "PARTIAL_SHELL_NOT_CONVERGED"
    assert result["certificates"] == []
