from qpdtr.domains.quantum_gravity.camps import (
    CliffordAugmentedMPS,
    CliffordFrame,
    PauliWord,
    qualify_bounded_camps_exact,
    qualify_structured_200_camps_holdout,
)


def test_clifford_frame_preserves_canonical_symplectic_form():
    frame = CliffordFrame(8)
    for qubit in range(8):
        frame.apply("H", qubit)
        frame.apply("S", qubit)
    for left in range(7):
        frame.apply("CNOT", left, left + 1)
    assert frame.canonical_pair_gap() == 0
    twisted = frame.twisted_z(7)
    assert twisted.is_hermitian
    assert twisted.support_size >= 1


def test_camps_local_and_twisted_t_gates_preserve_norm():
    runtime = CliffordAugmentedMPS(6, max_bond=32, discarded_weight_budget=1e-12)
    runtime.apply_clifford("H", 0)
    runtime.apply_clifford("CNOT", 0, 1)
    runtime.apply_t(1)
    runtime.apply_clifford("CNOT", 1, 2)
    runtime.apply_t(2)
    assert runtime.frame.canonical_pair_gap() == 0
    assert runtime.residual_norm_gap() < 1e-12
    assert runtime.maximum_twisted_pauli_support >= 2


def test_bounded_camps_matches_independent_statevector():
    certificate = qualify_bounded_camps_exact()
    assert certificate.passed
    assert certificate.phase_aligned_state_gap < 1e-12
    assert certificate.frame_canonical_pair_gap == 0
    assert certificate.residual_maximum_bond < certificate.standard_mps_maximum_bond


def test_structured_200_camps_holdout_is_statevector_free_and_pointwise():
    certificate = qualify_structured_200_camps_holdout(seeds=(271828,))[0]
    assert certificate.passed
    assert certificate.qubit_count == 200
    assert certificate.t_gate_count == 32
    assert certificate.frame_canonical_pair_gap == 0
    assert certificate.statevector_materialized is False
    assert certificate.residual_maximum_bond < certificate.standard_mps_maximum_bond
