from __future__ import annotations

import numpy as np

from qpdtr.domains.quantum_gravity.cayley_impurity import CayleyBathMapping, qualify_cayley_impurity_runtime


def test_exact_finite_cayley_mapping_for_complex_hybridizations() -> None:
    energies = np.linspace(-1.5, 1.5, 15)
    phases = np.exp(1.0j * np.linspace(0.0, 0.7, 15))
    couplings = phases * np.linspace(0.05, 0.2, 15)
    owner = CayleyBathMapping(np.diag(energies), couplings)
    certificate = owner.certificate()
    assert certificate.passed
    assert certificate.node_count == 15
    assert certificate.edge_count == 14
    assert certificate.maximum_degree <= 3
    assert certificate.tree_nonedge_residual < 2e-10
    assert certificate.star_tree_hybridization_gap < 2e-10
    assert certificate.star_chain_hybridization_gap < 2e-10


def test_current_interacting_siam_cayley_ttn_qualification() -> None:
    result = qualify_cayley_impurity_runtime()
    assert result.passed
    assert result.mapping.passed
    assert result.representation_equivalence.passed
    assert result.ground_state.passed
    assert result.real_time_tebd.passed
    assert result.green_function.passed
    assert result.scalable_holdout.passed
    assert result.bath_discretization.passed
    assert result.ground_state.interaction_u > 0.0
    assert result.ground_state.energy_gap < 1e-4
    assert result.ground_state.ground_state_fidelity > 0.9998
    assert result.ground_state.bond_energy_gap_sequence[-1] < 1e-6
    assert result.real_time_tebd.fine_state_gap < 2e-4
    assert result.green_function.spectral_zeroth_moment_gap < 2e-10
    assert result.green_function.spectral_first_moment_gap < 2e-10
    assert result.scalable_holdout.spin_orbital_count == 26
    assert result.scalable_holdout.statevector_materialized is False
    assert result.scalable_holdout.maximum_spectator_occupation < 1e-10
    assert result.unqualified_regions
