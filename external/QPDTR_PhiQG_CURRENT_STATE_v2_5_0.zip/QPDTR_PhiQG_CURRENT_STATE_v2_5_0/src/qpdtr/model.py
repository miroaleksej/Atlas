from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal

import numpy as np

ClaimStatus = Literal["NEW_CANDIDATE", "DERIVED", "REFERENCE", "BLOCKED"]
EvidenceScope = Literal["CONTROL", "TARGET"]


@dataclass(frozen=True, slots=True)
class ObservableSpec:
    name: str
    units: str
    estimator: str
    acceptance: str
    scope: EvidenceScope


@dataclass(frozen=True, slots=True)
class NumericalThresholds:
    heat_kernel_backend_gap: float = 1e-10
    tensor_identity_gap: float = 1e-12
    fixed_point_residual: float = 1e-10
    selected_frg_order_spread: float = 0.05
    regge_scaling_gap: float = 1e-12
    regge_equation_residual: float = 2e-6
    lorentzian_metric_gap: float = 1e-10
    boundary_normalization_gap: float = 1e-12
    boundary_closure_gap: float = 1e-12
    measure_tail_fraction: float = 0.05
    quantum_channel_gap: float = 1e-10
    relational_covariance_gap: float = 1e-12


@dataclass(frozen=True, slots=True)
class EPRLShellPolicy:
    """Single active shell-truncation policy for all Lorentzian EPRL targets.

    A successive-shell difference is an estimator, not a rigorous remainder bound.  Target
    admission therefore requires a stable consecutive window, retains the estimator under its
    correct name, and never labels it a proof of convergence of the infinite shelled sum.
    """

    minimum_shell: int = 0
    maximum_shell: int = 12
    minimum_samples: int = 4
    stable_steps: int = 3
    absolute_tolerance: float = 1e-10
    relative_tolerance: float = 1e-6
    tensor_absolute_tolerance: float = 1e-10
    tensor_relative_tolerance: float = 1e-6
    relative_floor: float = 1e-30

    def shell_grid(self) -> tuple[int, ...]:
        return tuple(range(self.minimum_shell, self.maximum_shell + 1))

    def validate(self) -> None:
        if self.minimum_shell < 0 or self.maximum_shell <= self.minimum_shell:
            raise ValueError("EPRL shell policy requires 0 <= minimum < maximum")
        count = self.maximum_shell - self.minimum_shell + 1
        if self.minimum_samples < 3 or self.minimum_samples > count:
            raise ValueError("EPRL minimum_samples is outside the shell grid")
        if self.stable_steps < 2 or self.stable_steps >= self.minimum_samples:
            raise ValueError("EPRL stable_steps must be at least two and below minimum_samples")
        if (
            self.absolute_tolerance <= 0.0
            or self.relative_tolerance <= 0.0
            or self.tensor_absolute_tolerance <= 0.0
            or self.tensor_relative_tolerance <= 0.0
        ):
            raise ValueError("EPRL shell and tensor tolerances must be positive")
        if self.relative_floor <= 0.0:
            raise ValueError("EPRL relative floor must be positive")


@dataclass(frozen=True, slots=True)
class PhiQGModelSpec:
    """Canonical current-state contract for the sole PhiQG execution owner."""

    domain: str = "quantum_gravity"
    model: str = "PhiQG"
    status: ClaimStatus = "NEW_CANDIDATE"
    spacetime_dimension: int = 4
    signature: str = "lorentzian_target"
    gauge_group: str = "SL(2,C)"
    vertex_model: str = "Lorentzian_EPRL"

    boundary_state_scope: str = "normalized_isotropic_Livine_Speziale_scale_mode"
    boundary_center_twice_spin: int = 4
    boundary_width_twice_spin: float = 1.25
    boundary_extrinsic_phase: float = 0.18

    measure_status: str = "REGULARIZED_EPRL_CANDIDATE_MEASURE"
    measure_derivation_status: str = "OPEN_NOT_UNIQUE"
    measure_face_dimension_power: float = 1.0
    measure_edge_intertwiner_power: float = 0.0
    measure_heat_kernel_epsilon: float = 0.08
    measure_twice_spin_cutoff: int = 16

    quantum_qubit_count: int = 50
    quantum_exact_choi_max_qubits: int = 6
    quantum_statevector_memory_limit_bytes: int = 512 * 1024 * 1024
    quantum_statevector_workspace_factor: int = 6
    quantum_mps_max_bond: int = 64
    quantum_mps_discarded_weight_budget: float = 1e-7
    quantum_mps_max_interaction_span: int = 4
    quantum_trotter_steps: int = 1
    quantum_trajectory_count: int = 8
    quantum_random_seed: int = 20260727
    quantum_contraction_optimizer: str = "greedy"
    quantum_contraction_memory_limit_elements: int = 131_072
    quantum_contraction_max_slices: int = 64
    quantum_contraction_parallel_workers: int = 2
    quantum_contraction_statevector_max_qubits: int = 18
    quantum_contraction_observable_max_count: int = 1024
    quantum_contraction_backend: str = "numpy"
    quantum_contraction_enable_mpi: bool = False

    quantum_stabilizer_clifford_qubit_count: int = 1000
    quantum_magic_materialization_qubit_limit: int = 10
    quantum_magic_t_gate_limit: int = 5
    quantum_magic_branch_limit: int = 32
    quantum_magic_reference_tolerance: float = 1e-12

    quantum_processor_qubit_count: int = 8
    quantum_processor_backend: str = "auto"
    quantum_processor_trajectory_count: int = 2048
    quantum_processor_readout_shots: int = 8192
    quantum_processor_t1: float = 60.0
    quantum_processor_t2: float = 45.0
    quantum_processor_one_qubit_gate_time: float = 0.04
    quantum_processor_two_qubit_gate_time: float = 0.16
    quantum_processor_readout_0_to_1: float = 0.015
    quantum_processor_readout_1_to_0: float = 0.025
    quantum_toric_lattice_size: int = 5
    quantum_toric_trials: int = 256
    quantum_toric_error_probability: float = 0.02
    quantum_lorentzian_linewidth: float = 0.4
    quantum_lorentzian_coupling_rate: float = 2.0

    immirzi: float = 0.1
    eprl_shell_policy: EPRLShellPolicy = field(default_factory=EPRLShellPolicy)
    eprl_y_map: str = "gamma_j_plus_one"
    eprl_backend_accuracy: str = "VeryHighAccuracy"
    eprl_backend_max_MB_mem_per_thread: int = 4096
    eprl_target_max_bond: int = 8
    delta3_boundary_twice_spin: int = 4
    delta3_internal_twice_spins: tuple[int, ...] = (0, 2, 4, 6, 8)

    causal_vertex_status: str = "OPEN_TOLLER_CAUSAL_VERTEX_NOT_EXECUTABLE"
    matter_derivation_status: str = "OPEN_STANDARD_MODEL_NOT_DERIVED"
    relational_qg_status: str = "PARTIAL_FINITE_POVM_CONTROL_ONLY"
    physical_inner_product_status: str = "OPEN_NOT_PROVEN"
    continuum_status: str = "OPEN_DISTRIBUTIONAL_OR_REFINEMENT_LIMIT_NOT_CONSTRUCTED"

    spectral_sigmas: tuple[float, ...] = tuple(float(x) for x in np.logspace(-2, 2, 81))
    thresholds: NumericalThresholds = field(default_factory=NumericalThresholds)
    observables: tuple[ObservableSpec, ...] = (
        ObservableSpec(
            "adaptive_quantum_dynamics",
            "dimensionless",
            "v3.0 physical-law registry qualification plus bounded exact Choi, matrix-free Krylov, graph-ordered MPS/TEBD, general-graph contraction trees, processor circuits, CPTP T1/T2 noise, POVM/readout, Lorentzian-memory channels, toric-code recovery, driven-open GKSL/Kerr/spatial/topological/EFT/RG controls, and trajectories",
            "registry/proof-ladder integrity, theorem-owner coverage, strong-subadditivity/Holevo/QFI/speed-limit/LOCC/Chern/SME certificates, exact-reference agreement and fail-closed resource routing",
            "CONTROL",
        ),
        ObservableSpec(
            "lorentzian_metric_causality",
            "length-squared and four-volume",
            "Minkowski Gram matrices and facet normals",
            "non-degenerate Lorentzian signature and compatible time orientation",
            "CONTROL",
        ),
        ObservableSpec(
            "coherent_boundary_family",
            "complex amplitude coefficients",
            "normalized isotropic Livine-Speziale scale family",
            "normalization and closure certificates",
            "CONTROL",
        ),
        ObservableSpec(
            "regularized_microscopic_measure",
            "dimensionless weight",
            "face-dimension power times heat-kernel regulator",
            "finite normalization and cutoff-tail estimate",
            "CONTROL",
        ),
        ObservableSpec(
            "spectral_dimension_estimator",
            "dimensionless",
            "heat-kernel trace",
            "cross-backend agreement and 1D/2D ground-truth recovery",
            "CONTROL",
        ),
        ObservableSpec(
            "betti_numbers_refinement_and_induced_map",
            "integer",
            "GF(2) simplicial homology and last-vertex refinement map",
            "exact topology/refinement certificate through H4",
            "CONTROL",
        ),
        ObservableSpec(
            "ponzano_regge_6j",
            "dimensionless",
            "symbolic Wigner and independent Racah sum",
            "exact finite identities",
            "CONTROL",
        ),
        ObservableSpec(
            "regge_equations_and_scaling",
            "dimensionless residuals",
            "general edge-length Regge action",
            "stationary equilateral cosmological solution and perturbation response",
            "CONTROL",
        ),
        ObservableSpec(
            "relational_povm_observable",
            "observable-dependent",
            "matter-reference Gaussian POVM",
            "normalization and relabel covariance",
            "CONTROL",
        ),
        ObservableSpec(
            "frg_selected_order_fixed_points",
            "dimensionless",
            "roots of cited beta polynomials",
            "residual and selected-order comparison",
            "CONTROL",
        ),
        ObservableSpec(
            "lorentzian_eprl_single_vertex_tensor_and_coherent_amplitude",
            "real rank-5 tensor and complex amplitude",
            "immutable-provenance official sl2cfoam-next Julia backend",
            "commit/source/binary/module/table/Y-map/request binding and adaptive shell certificate",
            "TARGET",
        ),
        ObservableSpec(
            "lorentzian_eprl_delta3_three_vertex_amplitude",
            "complex amplitude",
            "published Delta3 cyclic contraction of three partial-coherent EPRL vertices",
            "one-internal-face graph binding and adaptive shell certificate",
            "TARGET",
        ),
        ObservableSpec(
            "lorentzian_eprl_tensor_shell_stability",
            "relative Frobenius difference",
            "last-two-shell rank-5 artifact comparison",
            "configuration-complete tensor shell certificate",
            "TARGET",
        ),
        ObservableSpec(
            "lorentzian_eprl_target_tensor_coarse_graining",
            "relative Frobenius error",
            "sole N-dimensional SVD owner applied only after target shell admission",
            "provenance and discarded-singular-value certificate",
            "TARGET",
        ),
    )
    metadata: dict[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        if self.domain != "quantum_gravity":
            raise ValueError("PhiQG executes only in the quantum_gravity domain")
        if self.model != "PhiQG" or self.status != "NEW_CANDIDATE":
            raise ValueError("The active model identity is PhiQG / NEW_CANDIDATE")
        if self.spacetime_dimension != 4:
            raise ValueError("The target model is four-dimensional; lower dimensions are controls only")
        if self.signature != "lorentzian_target":
            raise ValueError("The target signature must remain Lorentzian")
        if self.gauge_group != "SL(2,C)" or self.vertex_model != "Lorentzian_EPRL":
            raise ValueError("The configured target is the Lorentzian EPRL model")
        if self.quantum_qubit_count < 50:
            raise ValueError("The active scalable control requires at least 50 local qubits")
        if self.quantum_exact_choi_max_qubits < 1:
            raise ValueError("Exact Choi reference limit must be positive")
        if (
            self.quantum_statevector_memory_limit_bytes < 1024
            or self.quantum_statevector_workspace_factor < 2
        ):
            raise ValueError("State-vector memory/workspace contract is inadmissible")
        if (
            self.quantum_mps_max_bond < 2
            or self.quantum_mps_discarded_weight_budget <= 0.0
            or self.quantum_mps_max_interaction_span < 1
        ):
            raise ValueError("MPS bond, truncation and interaction-span policy is inadmissible")
        if self.quantum_trotter_steps < 1 or self.quantum_trajectory_count < 2:
            raise ValueError("Quantum evolution and trajectory policy is inadmissible")
        if self.quantum_contraction_optimizer not in {
            "greedy",
            "auto",
            "auto-hq",
            "random-greedy",
            "random-greedy-128",
        }:
            raise ValueError("Contraction-tree optimizer is inadmissible")
        if (
            self.quantum_contraction_memory_limit_elements < 1024
            or self.quantum_contraction_max_slices < 1
            or self.quantum_contraction_parallel_workers < 1
            or self.quantum_contraction_statevector_max_qubits < 2
            or self.quantum_contraction_observable_max_count < 4
        ):
            raise ValueError("Contraction-tree resource policy is inadmissible")
        if self.quantum_contraction_backend not in {"auto", "numpy", "cupy"}:
            raise ValueError("Contraction-tree backend is inadmissible")
        if (
            self.quantum_stabilizer_clifford_qubit_count < 1
            or self.quantum_magic_materialization_qubit_limit < 1
            or self.quantum_magic_t_gate_limit < 0
            or self.quantum_magic_branch_limit < 1
            or self.quantum_magic_branch_limit < (1 << self.quantum_magic_t_gate_limit)
            or self.quantum_magic_reference_tolerance <= 0.0
        ):
            raise ValueError("Stabilizer/magic resource policy is inadmissible")
        if self.quantum_processor_qubit_count < 3:
            raise ValueError("Processor-circuit control requires at least three qubits")
        if self.quantum_processor_backend not in {"auto", "cpu", "cuda", "mps"}:
            raise ValueError("Processor accelerator backend is inadmissible")
        if (
            self.quantum_processor_trajectory_count < 256
            or self.quantum_processor_readout_shots < 512
        ):
            raise ValueError("Processor sampling contracts are inadmissible")
        if (
            self.quantum_processor_t1 <= 0.0
            or self.quantum_processor_t2 <= 0.0
            or self.quantum_processor_t2 > 2.0 * self.quantum_processor_t1 + 1e-12
            or self.quantum_processor_one_qubit_gate_time <= 0.0
            or self.quantum_processor_two_qubit_gate_time <= 0.0
        ):
            raise ValueError("Processor T1/T2 and gate-time contract is inadmissible")
        if not (
            0.0 <= self.quantum_processor_readout_0_to_1 <= 1.0
            and 0.0 <= self.quantum_processor_readout_1_to_0 <= 1.0
        ):
            raise ValueError("Processor readout assignment is inadmissible")
        if (
            self.quantum_toric_lattice_size < 3
            or self.quantum_toric_trials < 1
            or not 0.0 <= self.quantum_toric_error_probability <= 1.0
        ):
            raise ValueError("Toric-code control contract is inadmissible")
        if self.quantum_lorentzian_linewidth <= 0.0 or self.quantum_lorentzian_coupling_rate <= 0.0:
            raise ValueError("Lorentzian reservoir parameters must be positive")
        if self.boundary_state_scope != "normalized_isotropic_Livine_Speziale_scale_mode":
            raise ValueError("The current owner requires the normalized coherent boundary family")
        if self.boundary_center_twice_spin < 1 or self.boundary_width_twice_spin <= 0.0:
            raise ValueError("Boundary-state parameters are inadmissible")
        if self.measure_status != "REGULARIZED_EPRL_CANDIDATE_MEASURE":
            raise ValueError("The current finite target sum uses the regularized candidate measure")
        if self.measure_heat_kernel_epsilon <= 0.0 or self.measure_twice_spin_cutoff < 2:
            raise ValueError("Measure regulator and cutoff are inadmissible")
        self.eprl_shell_policy.validate()
        if self.eprl_y_map not in {"gamma_j_plus_one", "gamma_j"}:
            raise ValueError("Unsupported EPRL Y-map build convention")
        if self.eprl_backend_accuracy not in {"NormalAccuracy", "HighAccuracy", "VeryHighAccuracy"}:
            raise ValueError("Unsupported sl2cfoam-next accuracy configuration")
        if self.eprl_backend_max_MB_mem_per_thread <= 0 or self.eprl_target_max_bond <= 0:
            raise ValueError("EPRL memory and tensor bond parameters must be positive")
        if self.delta3_boundary_twice_spin <= 0 or self.delta3_boundary_twice_spin % 2:
            raise ValueError("Delta3 target currently requires an integer boundary spin")
        if not self.delta3_internal_twice_spins or any(
            value < 0 or value % 2 for value in self.delta3_internal_twice_spins
        ):
            raise ValueError("Delta3 internal spins must be non-negative integer-spin labels")
        if not (0.0 < self.immirzi < 10.0):
            raise ValueError("Immirzi parameter is outside the configured research range")
        if len(self.spectral_sigmas) < 5 or any(s <= 0 for s in self.spectral_sigmas):
            raise ValueError("Spectral-dimension grid must contain positive diffusion times")
        for name, value in asdict(self.thresholds).items():
            if value <= 0:
                raise ValueError(f"Numerical threshold {name} must be positive")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
