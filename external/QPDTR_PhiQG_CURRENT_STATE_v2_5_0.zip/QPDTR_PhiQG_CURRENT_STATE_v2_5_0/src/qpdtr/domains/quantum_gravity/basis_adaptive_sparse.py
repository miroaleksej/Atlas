from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from typing import Any, Iterable, Mapping, Sequence

import numpy as np


def _digest(payload: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=float).encode("utf-8")
    ).hexdigest()


def _as_gate(gate: np.ndarray, qubit_count: int) -> np.ndarray:
    matrix = np.asarray(gate, dtype=np.complex128)
    expected = 1 << int(qubit_count)
    if matrix.shape != (expected, expected):
        raise ValueError(f"Gate must have shape {(expected, expected)}")
    return matrix


def _top_k(amplitudes: Mapping[int, complex], budget: int) -> tuple[dict[int, complex], float, float]:
    if budget < 1:
        raise ValueError("Sparse budget must be positive")
    cleaned = {int(index): complex(value) for index, value in amplitudes.items() if abs(value) > 1e-16}
    total = float(sum(abs(value) ** 2 for value in cleaned.values()))
    if not np.isfinite(total) or total <= 0.0:
        raise RuntimeError("Sparse state lost all probability mass")
    if len(cleaned) > budget:
        selected = sorted(cleaned.items(), key=lambda item: abs(item[1]) ** 2, reverse=True)[:budget]
        retained = dict(selected)
    else:
        retained = cleaned
    retained_mass = float(sum(abs(value) ** 2 for value in retained.values()))
    scale = np.sqrt(retained_mass)
    normalized = {index: value / scale for index, value in retained.items()}
    return normalized, retained_mass / total, total


def _participation_ratio(amplitudes: Mapping[int, complex]) -> float:
    probabilities = np.asarray([abs(value) ** 2 for value in amplitudes.values()], dtype=float)
    total = float(np.sum(probabilities))
    if total <= 0.0:
        return float("inf")
    probabilities /= total
    denominator = float(np.sum(probabilities**2))
    return float(1.0 / denominator) if denominator > 0.0 else float("inf")


@dataclass(frozen=True, slots=True)
class BasisAdaptiveSparseCertificate:
    schema: str
    status: str
    exact_reference_qubit_count: int
    sparse_budget: int
    fixed_basis_fidelity: float
    adaptive_basis_fidelity: float
    fidelity_gain: float
    exact_norm_gap: float
    adaptive_norm_gap: float
    fixed_cumulative_retention: float
    adaptive_cumulative_retention: float
    accepted_basis_rotations: int
    rejected_basis_rotations: int
    maximum_support: int
    scalable_qubit_count: int
    scalable_depth: int
    scalable_support: int
    scalable_norm_gap: float
    scalable_cumulative_retention: float
    statevector_materialized_scalable: bool
    claim_boundary: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_BOUNDED_BASIS_ADAPTIVE_SPARSE_OWNER"

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["passed"] = self.passed
        return payload


class BasisAdaptiveSparseStateOwner:
    """Top-k sparse pure-state owner with adaptive local product bases.

    The physical state is represented as ``(tensor_j U_j) |psi_work>``.  Sparse
    amplitudes are stored in the working product basis.  Physical gates are
    conjugated into that basis.  When truncation is required, single-qubit RDM
    eigenbases are tested with a participation-ratio do-no-harm guard.  The owner
    never claims exactness after a non-zero truncation and records the cumulative
    retained probability separately from the normalized state.
    """

    def __init__(
        self,
        qubit_count: int,
        *,
        sparse_budget: int,
        initial_bits: Sequence[int] | None = None,
        adaptive_basis: bool = True,
        adaptation_sweeps: int = 1,
        participation_tolerance: float = 1e-12,
        expanded_support_factor: int = 4,
    ) -> None:
        n = int(qubit_count)
        if n < 1:
            raise ValueError("At least one qubit is required")
        bits = tuple(0 for _ in range(n)) if initial_bits is None else tuple(int(v) for v in initial_bits)
        if len(bits) != n or any(v not in {0, 1} for v in bits):
            raise ValueError("Initial bits must be a valid product state")
        self.qubit_count = n
        self.sparse_budget = int(sparse_budget)
        if self.sparse_budget < 1:
            raise ValueError("Sparse budget must be positive")
        self.adaptive_basis = bool(adaptive_basis)
        self.adaptation_sweeps = max(1, int(adaptation_sweeps))
        self.participation_tolerance = float(participation_tolerance)
        self.expanded_support_limit = max(self.sparse_budget, int(expanded_support_factor) * self.sparse_budget)
        index = 0
        for q, bit in enumerate(bits):
            index |= int(bit) << q
        self.amplitudes: dict[int, complex] = {index: 1.0 + 0.0j}
        self.local_bases = [np.eye(2, dtype=np.complex128) for _ in range(n)]
        self.cumulative_retained_probability = 1.0
        self.truncation_count = 0
        self.accepted_basis_rotations = 0
        self.rejected_basis_rotations = 0
        self.maximum_support = 1

    def copy(self) -> "BasisAdaptiveSparseStateOwner":
        duplicate = object.__new__(BasisAdaptiveSparseStateOwner)
        duplicate.qubit_count = self.qubit_count
        duplicate.sparse_budget = self.sparse_budget
        duplicate.adaptive_basis = self.adaptive_basis
        duplicate.adaptation_sweeps = self.adaptation_sweeps
        duplicate.participation_tolerance = self.participation_tolerance
        duplicate.expanded_support_limit = self.expanded_support_limit
        duplicate.amplitudes = dict(self.amplitudes)
        duplicate.local_bases = [basis.copy() for basis in self.local_bases]
        duplicate.cumulative_retained_probability = self.cumulative_retained_probability
        duplicate.truncation_count = self.truncation_count
        duplicate.accepted_basis_rotations = self.accepted_basis_rotations
        duplicate.rejected_basis_rotations = self.rejected_basis_rotations
        duplicate.maximum_support = self.maximum_support
        return duplicate

    @property
    def support_size(self) -> int:
        return len(self.amplitudes)

    def norm_gap(self) -> float:
        return abs(float(sum(abs(value) ** 2 for value in self.amplitudes.values())) - 1.0)

    def participation_ratio(self) -> float:
        return _participation_ratio(self.amplitudes)

    def one_qubit_rdm(self, qubit: int) -> np.ndarray:
        q = int(qubit)
        if q < 0 or q >= self.qubit_count:
            raise ValueError("Qubit index lies outside the register")
        rho = np.zeros((2, 2), dtype=np.complex128)
        mask = 1 << q
        for index, amplitude in self.amplitudes.items():
            bit = 1 if index & mask else 0
            rho[bit, bit] += abs(amplitude) ** 2
            if bit == 0:
                partner = index | mask
                partner_amplitude = self.amplitudes.get(partner)
                if partner_amplitude is not None:
                    rho[0, 1] += amplitude * np.conj(partner_amplitude)
        rho[1, 0] = np.conj(rho[0, 1])
        trace = complex(np.trace(rho))
        if abs(trace) <= 0.0:
            raise RuntimeError("One-qubit RDM has zero trace")
        return 0.5 * (rho / trace + (rho / trace).conj().T)

    def _apply_working_gate(self, sites: Sequence[int], gate: np.ndarray) -> None:
        ordered_sites = tuple(int(site) for site in sites)
        if len(ordered_sites) not in {1, 2} or len(set(ordered_sites)) != len(ordered_sites):
            raise ValueError("Only one- and two-qubit gates are supported")
        if any(site < 0 or site >= self.qubit_count for site in ordered_sites):
            raise ValueError("Gate site lies outside the register")
        matrix = _as_gate(gate, len(ordered_sites))
        output: dict[int, complex] = {}
        for index, amplitude in self.amplitudes.items():
            local_input = 0
            base_index = index
            for site in ordered_sites:
                local_input = (local_input << 1) | ((index >> site) & 1)
                base_index &= ~(1 << site)
            column = matrix[:, local_input]
            for local_output, coefficient in enumerate(column):
                if abs(coefficient) <= 1e-16:
                    continue
                target = base_index
                for position, site in enumerate(reversed(ordered_sites)):
                    if (local_output >> position) & 1:
                        target |= 1 << site
                output[target] = output.get(target, 0.0 + 0.0j) + coefficient * amplitude
        self.amplitudes = {index: value for index, value in output.items() if abs(value) > 1e-16}
        self.maximum_support = max(self.maximum_support, len(self.amplitudes))

    def _working_gate(self, sites: Sequence[int], physical_gate: np.ndarray) -> np.ndarray:
        ordered_sites = tuple(int(site) for site in sites)
        matrix = _as_gate(physical_gate, len(ordered_sites))
        basis = self.local_bases[ordered_sites[0]]
        for site in ordered_sites[1:]:
            basis = np.kron(basis, self.local_bases[site])
        return basis.conj().T @ matrix @ basis

    def _truncate(self) -> float:
        before = len(self.amplitudes)
        normalized, retained_fraction, _ = _top_k(self.amplitudes, self.sparse_budget)
        self.amplitudes = normalized
        if before > self.sparse_budget or retained_fraction < 1.0 - 1e-15:
            self.truncation_count += 1
            self.cumulative_retained_probability *= retained_fraction
        self.maximum_support = max(self.maximum_support, before)
        return retained_fraction

    def _tentative_basis_update(self, qubit: int, rotation: np.ndarray, baseline_pr: float) -> bool:
        candidate = self.copy()
        candidate._apply_working_gate((qubit,), rotation.conj().T)
        candidate._truncate()
        candidate_pr = candidate.participation_ratio()
        if candidate_pr < baseline_pr - self.participation_tolerance:
            self.amplitudes = candidate.amplitudes
            self.local_bases[qubit] = self.local_bases[qubit] @ rotation
            self.cumulative_retained_probability = candidate.cumulative_retained_probability
            self.truncation_count = candidate.truncation_count
            self.maximum_support = max(self.maximum_support, candidate.maximum_support)
            self.accepted_basis_rotations += 1
            return True
        self.rejected_basis_rotations += 1
        return False

    def adapt_product_basis(self) -> int:
        if not self.adaptive_basis:
            return 0
        accepted_total = 0
        for _ in range(self.adaptation_sweeps):
            rdms = tuple(self.one_qubit_rdm(qubit) for qubit in range(self.qubit_count))
            accepted_this_sweep = 0
            for qubit, rho in enumerate(rdms):
                eigenvalues, eigenvectors = np.linalg.eigh(rho)
                order = np.argsort(eigenvalues)[::-1]
                rotation = eigenvectors[:, order]
                baseline_pr = self.participation_ratio()
                if self._tentative_basis_update(qubit, rotation, baseline_pr):
                    accepted_this_sweep += 1
            accepted_total += accepted_this_sweep
            if accepted_this_sweep == 0:
                break
        return accepted_total

    def apply_physical_gate(self, sites: Sequence[int], gate: np.ndarray) -> None:
        working_gate = self._working_gate(sites, gate)
        self._apply_working_gate(sites, working_gate)
        if len(self.amplitudes) > self.sparse_budget:
            if self.adaptive_basis:
                self.adapt_product_basis()
            if len(self.amplitudes) > self.sparse_budget:
                self._truncate()
        if len(self.amplitudes) > self.expanded_support_limit:
            raise RuntimeError("BLOCKED_SPARSE_SUPPORT_EXPLOSION")

    def physical_statevector(self, *, maximum_qubits: int = 20) -> np.ndarray:
        if self.qubit_count > int(maximum_qubits):
            raise RuntimeError("BLOCKED_DENSE_MATERIALIZATION")
        vector = np.zeros(1 << self.qubit_count, dtype=np.complex128)
        for index, amplitude in self.amplitudes.items():
            vector[index] = amplitude
        tensor = vector.reshape((2,) * self.qubit_count)
        for site, basis in enumerate(self.local_bases):
            tensor = np.moveaxis(tensor, site, 0)
            tensor = np.tensordot(basis, tensor, axes=([1], [0]))
            tensor = np.moveaxis(tensor, 0, site)
        return tensor.reshape(-1)


def _dense_apply(state: np.ndarray, gate: np.ndarray, sites: Sequence[int], qubit_count: int) -> np.ndarray:
    ordered_sites = tuple(int(site) for site in sites)
    tensor = np.asarray(state, dtype=np.complex128).reshape((2,) * qubit_count)
    moved = np.moveaxis(tensor, ordered_sites, tuple(range(len(ordered_sites))))
    flat = moved.reshape(1 << len(ordered_sites), -1)
    transformed = _as_gate(gate, len(ordered_sites)) @ flat
    moved = transformed.reshape(moved.shape)
    return np.moveaxis(moved, tuple(range(len(ordered_sites))), ordered_sites).reshape(-1)


def _ry(theta: float) -> np.ndarray:
    c = np.cos(theta / 2.0)
    s = np.sin(theta / 2.0)
    return np.array([[c, -s], [s, c]], dtype=np.complex128)


def _rz(theta: float) -> np.ndarray:
    return np.diag([np.exp(-0.5j * theta), np.exp(0.5j * theta)]).astype(np.complex128)


_CZ = np.diag([1.0, 1.0, 1.0, -1.0]).astype(np.complex128)
_CNOT = np.array(
    [[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, 0.0], [0.0, 0.0, 0.0, 1.0], [0.0, 0.0, 1.0, 0.0]],
    dtype=np.complex128,
)


def _benchmark_circuit(qubit_count: int, depth: int) -> tuple[tuple[tuple[int, ...], np.ndarray], ...]:
    n = int(qubit_count)
    gates: list[tuple[tuple[int, ...], np.ndarray]] = []
    for layer in range(int(depth)):
        for q in range(n):
            angle = 0.37 + 0.11 * ((q + 2 * layer) % 5)
            gates.append(((q,), _ry(angle)))
            gates.append(((q,), _rz(0.19 * ((q + layer) % 7 - 3))))
        offset = layer % 2
        for q in range(offset, n - 1, 2):
            gates.append(((q, q + 1), _CZ if layer % 3 else _CNOT))
    return tuple(gates)


def _fidelity(reference: np.ndarray, approximate: np.ndarray) -> float:
    return float(abs(np.vdot(reference, approximate)) ** 2)


def qualify_basis_adaptive_sparse_runtime() -> BasisAdaptiveSparseCertificate:
    small_n = 12
    budget = 64
    circuit = _benchmark_circuit(small_n, 2)
    exact = np.zeros(1 << small_n, dtype=np.complex128)
    exact[0] = 1.0
    fixed = BasisAdaptiveSparseStateOwner(small_n, sparse_budget=budget, adaptive_basis=False)
    adaptive = BasisAdaptiveSparseStateOwner(
        small_n,
        sparse_budget=budget,
        adaptive_basis=True,
        adaptation_sweeps=2,
    )
    for sites, gate in circuit:
        exact = _dense_apply(exact, gate, sites, small_n)
        fixed.apply_physical_gate(sites, gate)
        adaptive.apply_physical_gate(sites, gate)
    fixed_vector = fixed.physical_statevector(maximum_qubits=small_n)
    adaptive_vector = adaptive.physical_statevector(maximum_qubits=small_n)
    fixed_fidelity = _fidelity(exact, fixed_vector)
    adaptive_fidelity = _fidelity(exact, adaptive_vector)

    scalable_n = 24
    scalable_depth = 2
    scalable = BasisAdaptiveSparseStateOwner(
        scalable_n,
        sparse_budget=128,
        adaptive_basis=True,
        adaptation_sweeps=1,
    )
    for sites, gate in _benchmark_circuit(scalable_n, scalable_depth):
        scalable.apply_physical_gate(sites, gate)

    exact_norm_gap = abs(float(np.vdot(exact, exact).real) - 1.0)
    adaptive_norm_gap = adaptive.norm_gap()
    fidelity_gain = adaptive_fidelity / max(fixed_fidelity, np.finfo(float).tiny)
    checks = {
        "exact_norm": exact_norm_gap < 1e-12,
        "adaptive_norm": adaptive_norm_gap < 1e-11,
        "fidelity_improvement": adaptive_fidelity > fixed_fidelity + 5e-3,
        "relative_improvement": fidelity_gain > 1.5,
        "basis_updates_used": adaptive.accepted_basis_rotations > 0,
        "scalable_norm": scalable.norm_gap() < 1e-10,
        "scalable_budget": scalable.support_size <= scalable.sparse_budget,
        "scalable_retention": scalable.cumulative_retained_probability > 0.0,
    }
    status = "PASS_BOUNDED_BASIS_ADAPTIVE_SPARSE_OWNER" if all(checks.values()) else "FAIL_BOUNDED_BASIS_ADAPTIVE_SPARSE_OWNER"
    semantic: dict[str, Any] = {
        "schema": "qpdtr-basis-adaptive-sparse-state/v1",
        "status": status,
        "exact_reference_qubit_count": small_n,
        "sparse_budget": budget,
        "fixed_basis_fidelity": fixed_fidelity,
        "adaptive_basis_fidelity": adaptive_fidelity,
        "fidelity_gain": fidelity_gain,
        "exact_norm_gap": exact_norm_gap,
        "adaptive_norm_gap": adaptive_norm_gap,
        "fixed_cumulative_retention": fixed.cumulative_retained_probability,
        "adaptive_cumulative_retention": adaptive.cumulative_retained_probability,
        "accepted_basis_rotations": adaptive.accepted_basis_rotations,
        "rejected_basis_rotations": adaptive.rejected_basis_rotations,
        "maximum_support": adaptive.maximum_support,
        "scalable_qubit_count": scalable_n,
        "scalable_depth": scalable_depth,
        "scalable_support": scalable.support_size,
        "scalable_norm_gap": scalable.norm_gap(),
        "scalable_cumulative_retention": scalable.cumulative_retained_probability,
        "statevector_materialized_scalable": False,
        "claim_boundary": (
            "The owner is an approximate pure-state circuit simulator with a fixed top-k support budget. "
            "It adapts only a product of single-qubit bases using one-qubit RDM eigenvectors and a participation-ratio do-no-harm guard. "
            "The cumulative retained probability is a truncation diagnostic, not a rigorous multi-step fidelity bound. "
            "Generic volume-law states, mixed-state dynamics and circuits whose amplitudes remain delocalized in every product basis are outside the active claim."
        ),
    }
    return BasisAdaptiveSparseCertificate(**semantic, digest=_digest(semantic))
