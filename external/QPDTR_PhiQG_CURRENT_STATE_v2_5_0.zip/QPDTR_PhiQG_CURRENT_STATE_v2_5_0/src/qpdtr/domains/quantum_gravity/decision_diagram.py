from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from typing import Any, Iterable, Mapping, Sequence

import networkx as nx
import numpy as np


@dataclass(frozen=True, slots=True)
class PhaseTerm:
    coefficient: int
    variables: tuple[int, ...]

    def __post_init__(self) -> None:
        variables = tuple(sorted({int(v) for v in self.variables}))
        if any(v < 0 for v in variables):
            raise ValueError("phase-polynomial variable indices must be nonnegative")
        object.__setattr__(self, "variables", variables)
        object.__setattr__(self, "coefficient", int(self.coefficient))


class PhasePolynomial:
    """Integer-valued multilinear phase polynomial over Boolean variables.

    The active bounded decision-diagram owner evaluates sums
        2^{-n} sum_x exp(i*pi*f(x)/4)
    for f:{0,1}^n -> Z_8.  It is not a general circuit simulator; a caller must
    provide a verified path-sum lowering into this representation.
    """

    def __init__(self, variable_count: int, terms: Iterable[PhaseTerm], *, modulus: int = 8) -> None:
        n = int(variable_count)
        m = int(modulus)
        if n < 0 or m < 2:
            raise ValueError("invalid phase-polynomial dimensions")
        combined: dict[tuple[int, ...], int] = {}
        for term in terms:
            if any(v >= n for v in term.variables):
                raise ValueError("phase term references an undeclared variable")
            key = tuple(term.variables)
            combined[key] = (combined.get(key, 0) + int(term.coefficient)) % m
        self.variable_count = n
        self.modulus = m
        self.terms = tuple(
            PhaseTerm(coefficient=value, variables=key)
            for key, value in sorted(combined.items(), key=lambda item: (len(item[0]), item[0]))
            if value % m
        )

    @property
    def signature(self) -> tuple[tuple[int, tuple[int, ...]], ...]:
        return tuple((term.coefficient % self.modulus, term.variables) for term in self.terms)

    def substitute(self, variable: int, bit: int) -> "PhasePolynomial":
        q = int(variable)
        b = int(bit)
        if b not in {0, 1}:
            raise ValueError("Boolean substitution requires bit 0 or 1")
        reduced: list[PhaseTerm] = []
        for term in self.terms:
            if q not in term.variables:
                reduced.append(term)
            elif b == 1:
                reduced.append(PhaseTerm(term.coefficient, tuple(v for v in term.variables if v != q)))
        return PhasePolynomial(self.variable_count, reduced, modulus=self.modulus)

    def evaluate(self, bits: Sequence[int]) -> int:
        if len(bits) != self.variable_count:
            raise ValueError("assignment length differs from variable_count")
        total = 0
        for term in self.terms:
            product = 1
            for variable in term.variables:
                product *= int(bits[variable])
            total += term.coefficient * product
        return total % self.modulus

    def interaction_graph(self) -> nx.Graph:
        graph = nx.Graph()
        graph.add_nodes_from(range(self.variable_count))
        for term in self.terms:
            variables = term.variables
            for left in range(len(variables)):
                for right in range(left + 1, len(variables)):
                    graph.add_edge(variables[left], variables[right])
        return graph


@dataclass(frozen=True, slots=True)
class DDNode:
    level: int
    low: int
    high: int


@dataclass(frozen=True, slots=True)
class DecisionDiagramCertificate:
    schema: str
    status: str
    exact_reference_gap: float
    small_variable_count: int
    small_node_count: int
    large_variable_count: int
    large_node_count: int
    large_treewidth_upper_bound: int
    large_linear_cut_rank: int
    large_amplitude_real: float
    large_amplitude_imag: float
    node_budget: int
    statevector_materialized_large: bool
    claim_boundary: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_BOUNDED_PHASE_DD_OWNER"

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["passed"] = self.passed
        return payload


class PhasePolynomialDecisionDiagram:
    """Reduced ordered multi-terminal DD for Z_m-valued phase polynomials."""

    def __init__(
        self,
        polynomial: PhasePolynomial,
        *,
        variable_order: Sequence[int] | None = None,
        node_budget: int = 250_000,
    ) -> None:
        self.polynomial = polynomial
        self.order = tuple(range(polynomial.variable_count)) if variable_order is None else tuple(int(v) for v in variable_order)
        if sorted(self.order) != list(range(polynomial.variable_count)):
            raise ValueError("variable_order must be a permutation of all variables")
        self.node_budget = int(node_budget)
        if self.node_budget < polynomial.modulus:
            raise ValueError("node budget is too small even for terminals")
        self.terminals = tuple(range(polynomial.modulus))
        self.nodes: dict[int, DDNode] = {}
        self._unique: dict[tuple[int, int, int], int] = {}
        self._memo: dict[tuple[int, tuple[tuple[int, tuple[int, ...]], ...]], int] = {}
        self._next_id = polynomial.modulus
        self.root = self._build(polynomial, 0)

    @property
    def node_count(self) -> int:
        return len(self.terminals) + len(self.nodes)

    def _constant_value(self, polynomial: PhasePolynomial) -> int:
        value = 0
        for term in polynomial.terms:
            if term.variables:
                raise ValueError("nonconstant residual at terminal level")
            value = (value + term.coefficient) % polynomial.modulus
        return value

    def _build(self, polynomial: PhasePolynomial, level: int) -> int:
        key = (int(level), polynomial.signature)
        cached = self._memo.get(key)
        if cached is not None:
            return cached
        if level == len(self.order):
            terminal = self._constant_value(polynomial)
            self._memo[key] = terminal
            return terminal
        variable = self.order[level]
        low_poly = polynomial.substitute(variable, 0)
        high_poly = polynomial.substitute(variable, 1)
        low = self._build(low_poly, level + 1)
        high = self._build(high_poly, level + 1)
        if low == high:
            self._memo[key] = low
            return low
        unique_key = (level, low, high)
        node_id = self._unique.get(unique_key)
        if node_id is None:
            if self._next_id >= self.node_budget:
                raise RuntimeError(
                    f"DECISION_DIAGRAM_NODE_BUDGET_EXCEEDED:budget={self.node_budget}"
                )
            node_id = self._next_id
            self._next_id += 1
            self._unique[unique_key] = node_id
            self.nodes[node_id] = DDNode(level=level, low=low, high=high)
        self._memo[key] = node_id
        return node_id

    def terminal_counts(self) -> tuple[int, ...]:
        n = len(self.order)
        memo: dict[tuple[int, int], tuple[int, ...]] = {}

        def visit(node_id: int, current_level: int) -> tuple[int, ...]:
            key = (node_id, current_level)
            cached = memo.get(key)
            if cached is not None:
                return cached
            if node_id < self.polynomial.modulus:
                counts = [0] * self.polynomial.modulus
                counts[node_id] = 1 << (n - current_level)
                result = tuple(counts)
                memo[key] = result
                return result
            node = self.nodes[node_id]
            skipped_factor = 1 << max(0, node.level - current_level)
            low = visit(node.low, node.level + 1)
            high = visit(node.high, node.level + 1)
            result = tuple(skipped_factor * (a + b) for a, b in zip(low, high, strict=True))
            memo[key] = result
            return result

        return visit(self.root, 0)

    def normalized_phase_sum(self) -> complex:
        counts = self.terminal_counts()
        roots = np.exp(2.0j * np.pi * np.arange(self.polynomial.modulus) / self.polynomial.modulus)
        return complex(np.dot(np.asarray(counts, dtype=np.float64), roots) / (2.0 ** self.polynomial.variable_count))


def _gf2_rank(matrix: np.ndarray) -> int:
    a = np.asarray(matrix, dtype=np.uint8).copy() & np.uint8(1)
    rows, cols = a.shape
    rank = 0
    for col in range(cols):
        pivots = np.flatnonzero(a[rank:, col])
        if pivots.size == 0:
            continue
        pivot = rank + int(pivots[0])
        if pivot != rank:
            a[[rank, pivot]] = a[[pivot, rank]]
        for row in range(rows):
            if row != rank and a[row, col]:
                a[row] ^= a[rank]
        rank += 1
        if rank == rows:
            break
    return rank


def linear_cut_rank(graph: nx.Graph, order: Sequence[int]) -> int:
    nodes = tuple(order)
    index = {node: i for i, node in enumerate(nodes)}
    adjacency = np.zeros((len(nodes), len(nodes)), dtype=np.uint8)
    for left, right in graph.edges():
        i, j = index[left], index[right]
        adjacency[i, j] = 1
        adjacency[j, i] = 1
    maximum = 0
    for cut in range(1, len(nodes)):
        maximum = max(maximum, _gf2_rank(adjacency[:cut, cut:]))
    return int(maximum)


def complete_graph_phase_polynomial(variable_count: int) -> PhasePolynomial:
    n = int(variable_count)
    terms = [PhaseTerm(1, (q,)) for q in range(n)]
    terms.extend(PhaseTerm(4, (left, right)) for left in range(n) for right in range(left + 1, n))
    return PhasePolynomial(n, terms, modulus=8)


def _brute_phase_sum(polynomial: PhasePolynomial) -> complex:
    n = polynomial.variable_count
    total = 0.0 + 0.0j
    for value in range(1 << n):
        bits = tuple((value >> q) & 1 for q in range(n))
        phase = polynomial.evaluate(bits)
        total += np.exp(2.0j * np.pi * phase / polynomial.modulus)
    return complex(total / (2.0 ** n))


def _digest(payload: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ).hexdigest()


def qualify_phase_polynomial_decision_diagram() -> DecisionDiagramCertificate:
    small = complete_graph_phase_polynomial(16)
    small_dd = PhasePolynomialDecisionDiagram(small, node_budget=50_000)
    exact_gap = abs(small_dd.normalized_phase_sum() - _brute_phase_sum(small))

    large = complete_graph_phase_polynomial(64)
    order = tuple(range(64))
    large_dd = PhasePolynomialDecisionDiagram(large, variable_order=order, node_budget=250_000)
    graph = large.interaction_graph()
    width, _ = nx.approximation.treewidth_min_fill_in(graph)
    cut_rank = linear_cut_rank(graph, order)
    amplitude = large_dd.normalized_phase_sum()
    passed = bool(
        exact_gap < 1e-11
        and int(width) >= 60
        and cut_rank <= 2
        and large_dd.node_count < 25_000
        and sum(large_dd.terminal_counts()) == 1 << 64
        and np.isfinite(amplitude.real)
        and np.isfinite(amplitude.imag)
    )
    semantic = {
        "schema": "qpdtr-phase-polynomial-decision-diagram/v1",
        "status": "PASS_BOUNDED_PHASE_DD_OWNER" if passed else "FAIL_BOUNDED_PHASE_DD_OWNER",
        "exact_reference_gap": float(exact_gap),
        "small_variable_count": 16,
        "small_node_count": small_dd.node_count,
        "large_variable_count": 64,
        "large_node_count": large_dd.node_count,
        "large_treewidth_upper_bound": int(width),
        "large_linear_cut_rank": cut_rank,
        "large_amplitude_real": float(amplitude.real),
        "large_amplitude_imag": float(amplitude.imag),
        "node_budget": large_dd.node_budget,
        "statevector_materialized_large": False,
        "claim_boundary": (
            "Exact only after a verified lowering to a Z_8 multilinear phase polynomial. "
            "The bounded owner does not implement arbitrary-gate synthesis and does not claim "
            "that low linear cut-rank holds for generic circuits."
        ),
    }
    return DecisionDiagramCertificate(**semantic, digest=_digest(semantic))
