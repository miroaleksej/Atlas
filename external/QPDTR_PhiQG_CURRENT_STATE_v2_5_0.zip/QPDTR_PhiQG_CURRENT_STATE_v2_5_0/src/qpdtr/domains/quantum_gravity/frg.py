from __future__ import annotations

from dataclasses import asdict, dataclass
from math import pi
from typing import Callable

import numpy as np
from scipy.optimize import brentq


@dataclass(frozen=True, slots=True)
class FixedPointCertificate:
    truncation: str
    fixed_point: float
    beta_residual: float
    critical_exponent: float
    source_equation: str
    claim: str

    def to_dict(self) -> dict:
        return asdict(self)


def beta_newton_r2(g: float) -> float:
    return 2.0 * g - 8.0 * g**2 / (3.0 * pi) - 29.0 * g**3 / (40.0 * pi**2)


def beta_newton_r5(g: float) -> float:
    return (
        2.0 * g
        - 8.0 * g**2 / (3.0 * pi)
        - 29.0 * g**3 / (40.0 * pi**2)
        - 2459.0 * g**4 / (68040.0 * pi**3)
        + 5441.0 * g**5 / (3265920.0 * pi**4)
        + 39059.0 * g**6 / (53887680.0 * pi**5)
    )


def _derivative(function: Callable[[float], float], x: float) -> float:
    h = max(1e-7, abs(x) * 1e-6)
    return (function(x + h) - function(x - h)) / (2.0 * h)


def positive_fixed_point(function: Callable[[float], float], name: str, equation: str) -> FixedPointCertificate:
    grid = np.geomspace(1e-8, 100.0, 2000)
    root = None
    previous_x, previous_y = grid[0], function(float(grid[0]))
    for x in grid[1:]:
        y = function(float(x))
        if previous_y * y < 0:
            root = brentq(function, float(previous_x), float(x), xtol=1e-14, rtol=1e-14)
            break
        previous_x, previous_y = x, y
    if root is None:
        raise RuntimeError("No positive non-Gaussian fixed point found")
    return FixedPointCertificate(name, float(root), abs(float(function(root))), float(-_derivative(function, root)), equation, "finite_truncation_evidence_not_full_UV_proof")
