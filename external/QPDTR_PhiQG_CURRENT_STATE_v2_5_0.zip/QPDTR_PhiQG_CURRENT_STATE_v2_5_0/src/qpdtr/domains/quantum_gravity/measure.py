from __future__ import annotations

from dataclasses import asdict, dataclass
from math import exp, log

import numpy as np


@dataclass(frozen=True, slots=True)
class RegularizedMeasureSpec:
    face_dimension_power: float = 1.0
    edge_intertwiner_power: float = 0.0
    heat_kernel_epsilon: float = 0.08
    twice_spin_cutoff: int = 16
    automorphism_divisor: bool = True
    status: str = "REGULARIZED_EPRL_CANDIDATE_MEASURE"
    derivation_status: str = "OPEN_NOT_UNIQUE"

    def validate(self) -> None:
        if self.heat_kernel_epsilon <= 0.0:
            raise ValueError("Heat-kernel regulator must be positive")
        if self.twice_spin_cutoff < 2:
            raise ValueError("Twice-spin cutoff is too small")
        if not np.isfinite(self.face_dimension_power) or not np.isfinite(self.edge_intertwiner_power):
            raise ValueError("Measure powers must be finite")

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class MeasureCertificate:
    specification: RegularizedMeasureSpec
    partition_sum: float
    normalized_weights: tuple[float, ...]
    twice_spins: tuple[int, ...]
    mean_spin: float
    spin_variance: float
    cutoff_tail_estimate: float
    cutoff_tail_fraction: float
    scheme_partition_spread: float

    @property
    def passed(self) -> bool:
        return (
            np.isfinite(self.partition_sum)
            and self.partition_sum > 0.0
            and abs(sum(self.normalized_weights) - 1.0) < 1e-12
            and self.cutoff_tail_fraction < 0.05
        )

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["passed"] = self.passed
        return payload


def face_weight(twice_spin: int, spec: RegularizedMeasureSpec) -> float:
    if twice_spin < 0:
        return 0.0
    j = 0.5 * twice_spin
    casimir = j * (j + 1.0)
    return float((twice_spin + 1.0) ** spec.face_dimension_power * exp(-spec.heat_kernel_epsilon * casimir))


def _tail_sum(spec: RegularizedMeasureSpec, start: int, max_terms: int = 200000) -> float:
    total = 0.0
    last = float("inf")
    for q in range(start, start + max_terms):
        term = face_weight(q, spec)
        total += term
        if term < 1e-16 and term <= last:
            break
        last = term
    return float(total)


def regularized_measure_certificate(spec: RegularizedMeasureSpec) -> MeasureCertificate:
    spec.validate()
    twice_spins = tuple(range(spec.twice_spin_cutoff + 1))
    weights = np.array([face_weight(q, spec) for q in twice_spins], dtype=float)
    partition = float(weights.sum())
    normalized = weights / partition
    spins = 0.5 * np.asarray(twice_spins, dtype=float)
    mean = float(np.dot(normalized, spins))
    variance = float(np.dot(normalized, (spins - mean) ** 2))
    tail = _tail_sum(spec, spec.twice_spin_cutoff + 1)
    fraction = tail / (partition + tail)

    variants = []
    for power_shift in (-0.25, 0.0, 0.25):
        for epsilon_scale in (0.8, 1.0, 1.2):
            variant = RegularizedMeasureSpec(
                face_dimension_power=spec.face_dimension_power + power_shift,
                edge_intertwiner_power=spec.edge_intertwiner_power,
                heat_kernel_epsilon=spec.heat_kernel_epsilon * epsilon_scale,
                twice_spin_cutoff=spec.twice_spin_cutoff,
                automorphism_divisor=spec.automorphism_divisor,
            )
            values = np.array([face_weight(q, variant) for q in twice_spins], dtype=float)
            variants.append(log(float(values.sum())))
    spread = float(max(variants) - min(variants))

    return MeasureCertificate(
        specification=spec,
        partition_sum=partition,
        normalized_weights=tuple(float(value) for value in normalized),
        twice_spins=twice_spins,
        mean_spin=mean,
        spin_variance=variance,
        cutoff_tail_estimate=tail,
        cutoff_tail_fraction=float(fraction),
        scheme_partition_spread=spread,
    )
