from __future__ import annotations

from dataclasses import asdict, dataclass
from functools import lru_cache
from itertools import permutations

from .simplicial import SimplicialComplex, simplicial_map_certificate


@dataclass(frozen=True, slots=True)
class RefinementCertificate:
    dimension: int
    source_maximal_count: int
    refined_maximal_count: int
    source_betti: tuple[int, ...]
    refined_betti: tuple[int, ...]
    source_euler: int
    refined_euler: int
    chain_map_valid: bool
    induced_homology_ranks: tuple[int, ...]
    classifications: tuple[str, ...]

    @property
    def passed(self) -> bool:
        return (
            self.source_betti == self.refined_betti
            and self.source_euler == self.refined_euler
            and self.chain_map_valid
            and tuple(self.induced_homology_ranks) == tuple(self.source_betti)
        )

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["passed"] = self.passed
        return payload


def sphere_boundary_complex(dimension: int) -> SimplicialComplex:
    if dimension < 1:
        raise ValueError("Sphere dimension must be at least one")
    vertices = tuple(range(dimension + 2))
    maximal = [tuple(vertex for vertex in vertices if vertex != omitted) for omitted in vertices]
    return SimplicialComplex(maximal)


def barycentric_subdivision(source: SimplicialComplex) -> tuple[SimplicialComplex, dict[int, int]]:
    simplex_to_vertex: dict[tuple[int, ...], int] = {}
    for level in source.simplices:
        for simplex in level:
            simplex_to_vertex[simplex] = len(simplex_to_vertex)
    refined_maximal: set[tuple[int, ...]] = set()
    for maximal in source.maximal_simplices:
        for order in permutations(maximal):
            chain = []
            current: list[int] = []
            for vertex in order:
                current.append(vertex)
                chain.append(simplex_to_vertex[tuple(sorted(current))])
            refined_maximal.add(tuple(chain))
    refined = SimplicialComplex(refined_maximal)
    last_vertex_map = {
        barycenter: max(simplex)
        for simplex, barycenter in simplex_to_vertex.items()
    }
    return refined, last_vertex_map


def refinement_certificate(source: SimplicialComplex) -> RefinementCertificate:
    refined, last_vertex_map = barycentric_subdivision(source)
    transfer = simplicial_map_certificate(refined, source, last_vertex_map)
    return RefinementCertificate(
        dimension=source.dimension,
        source_maximal_count=len(source.maximal_simplices),
        refined_maximal_count=len(refined.maximal_simplices),
        source_betti=source.betti_numbers(),
        refined_betti=refined.betti_numbers(),
        source_euler=source.euler_characteristic(),
        refined_euler=refined.euler_characteristic(),
        chain_map_valid=transfer.chain_map_valid,
        induced_homology_ranks=transfer.induced_homology_ranks,
        classifications=transfer.classification,
    )


@lru_cache(maxsize=4)
def canonical_refinement_suite(max_refined_dimension: int = 3) -> dict[str, dict]:
    results: dict[str, dict] = {}
    for dimension in range(1, max_refined_dimension + 1):
        certificate = refinement_certificate(sphere_boundary_complex(dimension))
        results[f"S{dimension}"] = certificate.to_dict()
    s4 = sphere_boundary_complex(4)
    identity = simplicial_map_certificate(s4, s4, {vertex: vertex for vertex in s4.vertices})
    point = SimplicialComplex([(0,)])
    collapse = simplicial_map_certificate(s4, point, {vertex: 0 for vertex in s4.vertices})
    results["S4_exact_topology"] = {
        "betti": s4.betti_numbers(),
        "euler": s4.euler_characteristic(),
        "identity_map": asdict(identity),
        "collapse_map": asdict(collapse) | {
            "higher_dimensional_classification": ("not_applicable", "erased", "erased", "erased", "erased_or_collapsed"),
        },
        "passed": (
            s4.betti_numbers() == (1, 0, 0, 0, 1)
            and identity.chain_map_valid
            and identity.induced_homology_ranks == (1, 0, 0, 0, 1)
            and collapse.chain_map_valid
            and point.dimension == 0
        ),
    }
    return results
