from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Iterable

import networkx as nx
import numpy as np
from scipy.linalg import expm


@dataclass(frozen=True, slots=True)
class SpectralDimensionResult:
    sigmas: tuple[float, ...]
    return_probabilities: tuple[float, ...]
    spectral_dimensions: tuple[float, ...]
    laplacian: str
    backend_disagreement: float

    def to_dict(self) -> dict:
        return asdict(self)


def periodic_grid_graph(shape: tuple[int, ...]) -> nx.Graph:
    if not shape or any(n < 3 for n in shape):
        raise ValueError("Each periodic dimension must have at least three sites")
    graph = nx.Graph()
    for index in np.ndindex(*shape):
        graph.add_node(index)
        for axis, size in enumerate(shape):
            nxt = list(index)
            nxt[axis] = (nxt[axis] + 1) % size
            graph.add_edge(index, tuple(nxt))
    return graph


def estimate_spectral_dimension(graph: nx.Graph, sigmas: Iterable[float], *, normalized: bool = False) -> SpectralDimensionResult:
    sigma = np.asarray(tuple(float(s) for s in sigmas), dtype=float)
    if np.any(sigma <= 0) or sigma.size < 5:
        raise ValueError("Positive diffusion times are required")
    nodes = list(graph.nodes)
    adjacency = nx.to_numpy_array(graph, nodelist=nodes, dtype=float)
    degree_values = adjacency.sum(axis=1)
    degree = np.diag(degree_values)
    if normalized:
        invsqrt = np.zeros_like(degree_values)
        mask = degree_values > 0
        invsqrt[mask] = 1.0 / np.sqrt(degree_values[mask])
        lap = np.eye(len(nodes)) - np.diag(invsqrt) @ adjacency @ np.diag(invsqrt)
        label = "symmetric_normalized"
    else:
        lap = degree - adjacency
        label = "combinatorial"
    eigenvalues = np.linalg.eigvalsh(lap)
    p_eig = np.array([np.exp(-s * eigenvalues).mean() for s in sigma])
    indices = np.unique(np.linspace(0, sigma.size - 1, min(9, sigma.size), dtype=int))
    p_expm = np.array([np.trace(expm(-sigma[i] * lap)).real / len(nodes) for i in indices])
    disagreement = float(np.max(np.abs(p_expm - p_eig[indices])))
    ds = -2.0 * np.gradient(np.log(np.maximum(p_eig, np.finfo(float).tiny)), np.log(sigma), edge_order=2)
    return SpectralDimensionResult(tuple(map(float, sigma)), tuple(map(float, p_eig)), tuple(map(float, ds)), label, disagreement)


def plateau_estimate(result: SpectralDimensionResult, lower: float, upper: float) -> float:
    sigma = np.asarray(result.sigmas)
    ds = np.asarray(result.spectral_dimensions)
    mask = (sigma >= lower) & (sigma <= upper)
    if not mask.any():
        raise ValueError("Plateau interval does not intersect the diffusion grid")
    return float(np.median(ds[mask]))
