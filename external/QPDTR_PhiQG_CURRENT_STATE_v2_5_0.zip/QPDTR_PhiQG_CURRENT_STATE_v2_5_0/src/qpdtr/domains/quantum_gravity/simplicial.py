from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from typing import Iterable, Mapping

import numpy as np

Simplex = tuple[int, ...]


def _norm_simplex(simplex: Iterable[int]) -> Simplex:
    result = tuple(sorted(set(int(v) for v in simplex)))
    if not result:
        raise ValueError("Empty simplex is not supported")
    return result


def _gf2_matrix(matrix: np.ndarray) -> np.ndarray:
    value = np.asarray(matrix, dtype=np.uint8)
    if value.ndim != 2:
        raise ValueError("GF(2) linear algebra requires a rank-2 matrix")
    return np.ascontiguousarray(value & 1)


def _gf2_rref(matrix: np.ndarray) -> tuple[np.ndarray, tuple[int, ...]]:
    """Return the reduced row-echelon form over GF(2).

    Elimination is vectorized across all affected rows.  The previous implementation
    performed one Python-level XOR per row and became the dominant cost for refined
    simplicial complexes.  This function is the single active elimination owner used by
    rank, nullspace and solve.
    """

    a = _gf2_matrix(matrix).copy()
    rows, cols = a.shape
    pivot_row = 0
    pivots: list[int] = []
    for col in range(cols):
        candidates = np.flatnonzero(a[pivot_row:, col])
        if candidates.size == 0:
            continue
        pivot = pivot_row + int(candidates[0])
        if pivot != pivot_row:
            a[[pivot_row, pivot]] = a[[pivot, pivot_row]]
        affected = np.flatnonzero(a[:, col])
        affected = affected[affected != pivot_row]
        if affected.size:
            a[affected] ^= a[pivot_row]
        pivots.append(col)
        pivot_row += 1
        if pivot_row == rows:
            break
    return a, tuple(pivots)


def gf2_rank(matrix: np.ndarray) -> int:
    """Exact matrix rank over GF(2)."""

    _, pivots = _gf2_rref(matrix)
    return len(pivots)


def gf2_nullspace(matrix: np.ndarray) -> np.ndarray:
    """Return a column basis for the exact GF(2) nullspace."""

    rref, pivot_cols = _gf2_rref(matrix)
    cols = rref.shape[1]
    pivot_set = set(pivot_cols)
    free_cols = tuple(col for col in range(cols) if col not in pivot_set)
    if not free_cols:
        return np.zeros((cols, 0), dtype=np.uint8)
    basis = np.zeros((cols, len(free_cols)), dtype=np.uint8)
    basis[np.asarray(free_cols), np.arange(len(free_cols))] = 1
    free_index = np.asarray(free_cols, dtype=int)
    for row, pivot_col in enumerate(pivot_cols):
        basis[pivot_col] = rref[row, free_index]
    return basis


def gf2_solve(matrix: np.ndarray, vector: np.ndarray) -> np.ndarray:
    """Return one exact GF(2) solution with free variables set to zero."""

    a = _gf2_matrix(matrix)
    b = np.asarray(vector, dtype=np.uint8).reshape(-1, 1) & 1
    if b.shape[0] != a.shape[0]:
        raise ValueError("GF(2) right-hand side has incompatible dimension")
    augmented, pivots = _gf2_rref(np.concatenate([a, b], axis=1))
    cols = a.shape[1]
    if cols in pivots:
        raise ValueError("GF(2) system is inconsistent")
    for row in range(len(pivots), augmented.shape[0]):
        if not augmented[row, :cols].any() and augmented[row, cols]:
            raise ValueError("GF(2) system is inconsistent")
    x = np.zeros(cols, dtype=np.uint8)
    for row, pivot in enumerate(pivots):
        if pivot >= cols:
            raise ValueError("GF(2) system is inconsistent")
        x[pivot] = augmented[row, cols]
    return x


def _vector_bits(vector: np.ndarray) -> int:
    value = np.asarray(vector, dtype=np.uint8).reshape(-1) & 1
    packed = np.packbits(value, bitorder="little")
    return int.from_bytes(packed.tobytes(), byteorder="little", signed=False)


class _IncrementalGF2Basis:
    """Exact rank-revealing basis for repeated column insertions.

    Python integers provide packed bit vectors and make the boundary/cycle quotient step
    effectively linear in the number of inserted vectors rather than repeatedly invoking
    full dense elimination for every candidate.
    """

    def __init__(self) -> None:
        self._pivots: dict[int, int] = {}

    def add(self, vector: np.ndarray) -> bool:
        value = _vector_bits(vector)
        while value:
            pivot = value.bit_length() - 1
            existing = self._pivots.get(pivot)
            if existing is None:
                self._pivots[pivot] = value
                return True
            value ^= existing
        return False


class SimplicialComplex:
    def __init__(self, maximal_simplices: Iterable[Iterable[int]]):
        maximal = {_norm_simplex(s) for s in maximal_simplices}
        if not maximal:
            raise ValueError("At least one maximal simplex is required")
        self.maximal_simplices = tuple(sorted(maximal, key=lambda s: (len(s), s)))
        max_dim = max(len(s) - 1 for s in self.maximal_simplices)
        by_dim: list[set[Simplex]] = [set() for _ in range(max_dim + 1)]
        for simplex in self.maximal_simplices:
            for size in range(1, len(simplex) + 1):
                by_dim[size - 1].update(combinations(simplex, size))
        self.simplices = tuple(tuple(sorted(level)) for level in by_dim)
        self._index = tuple({s: i for i, s in enumerate(level)} for level in self.simplices)
        self._boundary_cache: dict[int, np.ndarray] = {}
        self._boundary_rank_cache: dict[int, int] = {}
        self._betti_cache: tuple[int, ...] | None = None
        self._homology_cache: dict[int, tuple[np.ndarray, np.ndarray]] = {}

    @property
    def dimension(self) -> int:
        return len(self.simplices) - 1

    @property
    def vertices(self) -> tuple[int, ...]:
        return tuple(s[0] for s in self.simplices[0])

    def boundary_matrix(self, k: int) -> np.ndarray:
        cached = self._boundary_cache.get(k)
        if cached is not None:
            return cached
        if k <= 0 or k > self.dimension:
            rows = len(self.simplices[k - 1]) if 0 < k <= self.dimension + 1 else 0
            cols = len(self.simplices[k]) if 0 <= k <= self.dimension else 0
            matrix = np.zeros((rows, cols), dtype=np.uint8)
        else:
            matrix = np.zeros(
                (len(self.simplices[k - 1]), len(self.simplices[k])), dtype=np.uint8
            )
            row_index = self._index[k - 1]
            for j, simplex in enumerate(self.simplices[k]):
                for face in combinations(simplex, k):
                    matrix[row_index[face], j] ^= 1
        matrix.setflags(write=False)
        self._boundary_cache[k] = matrix
        return matrix

    def _boundary_rank(self, k: int) -> int:
        cached = self._boundary_rank_cache.get(k)
        if cached is None:
            cached = gf2_rank(self.boundary_matrix(k))
            self._boundary_rank_cache[k] = cached
        return cached

    def betti_numbers(self) -> tuple[int, ...]:
        if self._betti_cache is None:
            values: list[int] = []
            for k in range(self.dimension + 1):
                n_k = len(self.simplices[k])
                rank_bk = self._boundary_rank(k) if k > 0 else 0
                rank_next = self._boundary_rank(k + 1) if k < self.dimension else 0
                values.append(n_k - rank_bk - rank_next)
            self._betti_cache = tuple(values)
        return self._betti_cache

    def euler_characteristic(self) -> int:
        return sum(((-1) ** k) * len(level) for k, level in enumerate(self.simplices))

    def homology_basis(self, k: int) -> tuple[np.ndarray, np.ndarray]:
        if k < 0 or k > self.dimension:
            raise ValueError("Homology dimension is outside the simplicial complex")
        cached = self._homology_cache.get(k)
        if cached is not None:
            return cached
        n_k = len(self.simplices[k])
        boundaries = (
            self.boundary_matrix(k + 1)
            if k < self.dimension
            else np.zeros((n_k, 0), dtype=np.uint8)
        )
        cycles = (
            gf2_nullspace(self.boundary_matrix(k))
            if k > 0
            else np.eye(n_k, dtype=np.uint8)
        )
        span = _IncrementalGF2Basis()
        selected_boundaries: list[np.ndarray] = []
        for col in boundaries.T:
            if span.add(col):
                selected_boundaries.append(np.asarray(col, dtype=np.uint8).copy())
        homology: list[np.ndarray] = []
        for col in cycles.T:
            if span.add(col):
                homology.append(np.asarray(col, dtype=np.uint8).copy())
        b = (
            np.column_stack(selected_boundaries)
            if selected_boundaries
            else np.zeros((n_k, 0), dtype=np.uint8)
        )
        h = (
            np.column_stack(homology)
            if homology
            else np.zeros((n_k, 0), dtype=np.uint8)
        )
        b.setflags(write=False)
        h.setflags(write=False)
        self._homology_cache[k] = (b, h)
        return b, h


@dataclass(frozen=True, slots=True)
class TopologyTransferCertificate:
    chain_map_valid: bool
    chain_map_failures: tuple[int, ...]
    source_betti: tuple[int, ...]
    target_betti: tuple[int, ...]
    induced_homology_ranks: tuple[int, ...]
    classification: tuple[str, ...]


def simplicial_map_certificate(
    source: SimplicialComplex,
    target: SimplicialComplex,
    vertex_map: Mapping[int, int],
) -> TopologyTransferCertificate:
    max_dim = min(source.dimension, target.dimension)
    f_mats: list[np.ndarray] = []
    for k in range(max_dim + 1):
        f = np.zeros((len(target.simplices[k]), len(source.simplices[k])), dtype=np.uint8)
        target_index = target._index[k]
        for j, simplex in enumerate(source.simplices[k]):
            mapped = tuple(sorted(vertex_map[v] for v in simplex))
            if len(set(mapped)) != len(mapped):
                continue
            if mapped in target_index:
                f[target_index[mapped], j] = 1
        f_mats.append(f)
    failures: list[int] = []
    for k in range(1, max_dim + 1):
        lhs = (target.boundary_matrix(k) @ f_mats[k]) & 1
        rhs = (f_mats[k - 1] @ source.boundary_matrix(k)) & 1
        if not np.array_equal(lhs, rhs):
            failures.append(k)
    source_betti = source.betti_numbers()
    target_betti = target.betti_numbers()
    ranks: list[int] = []
    labels: list[str] = []
    for k in range(max_dim + 1):
        _, h_src = source.homology_basis(k)
        b_tgt, h_tgt = target.homology_basis(k)
        if h_src.shape[1] == 0 or h_tgt.shape[1] == 0:
            rank = 0
        else:
            combined = np.column_stack([b_tgt, h_tgt])
            coords: list[np.ndarray] = []
            for v in ((f_mats[k] @ h_src) & 1).T:
                solution = gf2_solve(combined, v)
                coords.append(solution[b_tgt.shape[1] :])
            coord_matrix = (
                np.column_stack(coords)
                if coords
                else np.zeros((h_tgt.shape[1], 0), dtype=np.uint8)
            )
            rank = gf2_rank(coord_matrix)
        ranks.append(rank)
        bs, bt = source_betti[k], target_betti[k]
        if bs == bt == rank:
            labels.append("preserved")
        elif rank < bs and bt <= bs:
            labels.append("erased_or_collapsed")
        elif bt > bs:
            labels.append("emergent_in_target")
        else:
            labels.append("changed")
    return TopologyTransferCertificate(
        not failures,
        tuple(failures),
        source_betti,
        target_betti,
        tuple(ranks),
        tuple(labels),
    )
