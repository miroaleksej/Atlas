from __future__ import annotations

from dataclasses import asdict, dataclass, field
import hashlib
import json
from math import isfinite
from typing import Any, Iterable, Mapping, Sequence

import numpy as np

from .error_budget import QuantumErrorAllocation, build_unified_quantum_error_budget


# ---------------------------------------------------------------------------
# Typed execution objects
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class CircuitInstruction:
    """One typed circuit operation used by the authoritative ARFE owner.

    ``classical_reads`` and ``classical_writes`` are included so a backward
    causal cone remains correct for mid-circuit measurement and feed-forward.
    Matrix-free propagation currently admits the named one- and two-qubit
    gates registered in ``_gate_matrix``; unsupported gates fail closed.
    """

    name: str
    qubits: tuple[int, ...]
    parameters: tuple[float, ...] = ()
    classical_reads: tuple[int, ...] = ()
    classical_writes: tuple[int, ...] = ()

    def __post_init__(self) -> None:
        if not self.qubits:
            raise ValueError("circuit instruction requires at least one qubit")
        if len(set(self.qubits)) != len(self.qubits):
            raise ValueError("instruction qubits must be unique")
        if any(q < 0 for q in self.qubits):
            raise ValueError("qubit indices must be non-negative")
        if any(bit < 0 for bit in self.classical_reads + self.classical_writes):
            raise ValueError("classical indices must be non-negative")


@dataclass(frozen=True, slots=True)
class CausalConeCertificate:
    schema: str
    qubit_count: int
    observable_support: tuple[int, ...]
    included_instruction_indices: tuple[int, ...]
    causal_qubits: tuple[int, ...]
    causal_classical_bits: tuple[int, ...]
    excluded_instruction_count: int
    exact_reduction: bool
    status: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_EXACT_BACKWARD_CAUSAL_CONE"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"passed": self.passed}


PauliKey = tuple[tuple[int, str], ...]


@dataclass(frozen=True, slots=True)
class SparsePauliObservable:
    qubit_count: int
    terms: tuple[tuple[PauliKey, complex], ...]

    @staticmethod
    def from_terms(
        qubit_count: int,
        terms: Mapping[PauliKey | Sequence[tuple[int, str]], complex],
        *,
        coefficient_tolerance: float = 0.0,
    ) -> "SparsePauliObservable":
        if qubit_count <= 0:
            raise ValueError("qubit_count must be positive")
        merged: dict[PauliKey, complex] = {}
        for raw_key, raw_coefficient in terms.items():
            key = _canonical_pauli_key(raw_key, qubit_count)
            coefficient = complex(raw_coefficient)
            if not (isfinite(coefficient.real) and isfinite(coefficient.imag)):
                raise ValueError("Pauli coefficients must be finite")
            merged[key] = merged.get(key, 0.0 + 0.0j) + coefficient
        canonical = tuple(
            sorted(
                (
                    (key, value)
                    for key, value in merged.items()
                    if abs(value) > coefficient_tolerance
                ),
                key=lambda item: item[0],
            )
        )
        return SparsePauliObservable(qubit_count=qubit_count, terms=canonical)

    def to_mapping(self) -> dict[PauliKey, complex]:
        return {key: coefficient for key, coefficient in self.terms}

    @property
    def support(self) -> tuple[int, ...]:
        return tuple(sorted({q for key, _ in self.terms for q, _ in key}))


@dataclass(frozen=True, slots=True)
class PauliPropagationCertificate:
    schema: str
    qubit_count: int
    input_term_count: int
    output_term_count: int
    processed_instruction_count: int
    maximum_intermediate_term_count: int
    retained_term_budget: int
    dropped_l1_error_bound: float
    allocated_error_budget: float
    output_terms: tuple[tuple[PauliKey, tuple[float, float]], ...]
    status: str
    claim_scope: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_PAULI_OBSERVABLE_PROPAGATION"

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["passed"] = self.passed
        return payload


@dataclass(frozen=True, slots=True)
class GraphTensorNode:
    node_id: int
    neighbors: tuple[int, ...]
    tensor: np.ndarray = field(repr=False, compare=False)


@dataclass(frozen=True, slots=True)
class GraphBPContractionCertificate:
    schema: str
    node_count: int
    edge_count: int
    is_tree: bool
    exact_tree_contraction: bool
    iteration_count: int
    message_residual: float
    contraction_value: tuple[float, float] | None
    independent_reference_value: tuple[float, float] | None
    reference_gap: float | None
    allocated_error_budget: float
    status: str
    claim_scope: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_GRAPH_TENSOR_BP"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"passed": self.passed}


@dataclass(frozen=True, slots=True)
class BoundaryContract:
    schema: str
    boundary_id: str
    authoritative_owner: str
    representation: str
    support: tuple[int, ...]
    input_signature: tuple[str, ...]
    output_signature: tuple[str, ...]
    error_metric: str
    error_bound: float
    status: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_TYPED_BOUNDARY_CONTRACT"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"passed": self.passed}


@dataclass(frozen=True, slots=True)
class StructuralProfile:
    """Resource profile consumed by the single PHI-Q1000-ARFE owner.

    The legacy fields remain as input compatibility only.  They no longer own a
    separate routing algorithm; ``select_structural_owner`` delegates directly
    to ``AdaptiveResourceFactorizedEmulator.plan``.
    """

    qubit_count: int = 0
    simulation_object: str = "full_state"
    observable_support_size: int | None = None
    causal_cone_qubit_count: int | None = None
    verified_phase_polynomial_lowering: bool = False
    estimated_treewidth: int | None = None
    estimated_linear_rank_width: int | None = None
    verified_code_compiled_schedule: bool = False
    clifford_only: bool = False
    gaussian_fermionic: bool = False
    one_dimensional_local_lindblad: bool = False
    basis_adaptive_sparse_admissible: bool = False
    estimated_computational_basis_participation_ratio: float | None = None
    sparse_budget: int | None = None
    non_markovian_memory: bool = False
    multitime_interventions: bool = False
    conditional_measurements: bool = False
    causal_breaks: bool = False
    estimated_process_tensor_bond_dimension: int | None = None
    spatially_entangled_multiqubit_process: bool = False
    estimated_spacetime_bond_dimension: int | None = None
    real_calibration_snapshot: bool = False
    multitime_calibration_record_count: int | None = None
    expected_low_treewidth: bool = False
    graph_bp_admissible: bool = False
    graph_is_tree: bool | None = None
    estimated_graph_bp_residual: float | None = None
    pauli_observable_admissible: bool = False
    estimated_pauli_term_count: int | None = None
    pauli_term_budget: int | None = None
    magic_injection_admissible: bool = False
    estimated_magic_bond_dimension: int | None = None
    magic_bond_budget: int | None = None
    requested_total_error_budget: float = 1e-8


@dataclass(frozen=True, slots=True)
class StructuralRouteDecision:
    schema: str
    selected_method_id: str
    primary_patch_owner_id: str | None
    patch_owner_ids: tuple[str, ...]
    status: str
    reasons: tuple[str, ...]
    rejected_shortcuts: tuple[str, ...]
    profile: dict[str, Any]
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_RESOURCE_FACTORIZED_ROUTE_SELECTED"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"passed": self.passed}


@dataclass(frozen=True, slots=True)
class ARFEQualificationCertificate:
    schema: str
    owner_id: str
    causal_cone: CausalConeCertificate
    pauli_observable: PauliPropagationCertificate
    graph_tensor_bp: GraphBPContractionCertificate
    boundary_contracts: tuple[BoundaryContract, ...]
    unified_error_budget: dict[str, Any]
    route_cases: dict[str, dict[str, Any]]
    status: str
    claim_scope: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_PHI_Q1000_ADAPTIVE_RESOURCE_FACTORIZED_EMULATOR"

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": self.schema,
            "owner_id": self.owner_id,
            "causal_cone": self.causal_cone.to_dict(),
            "pauli_observable": self.pauli_observable.to_dict(),
            "graph_tensor_bp": self.graph_tensor_bp.to_dict(),
            "boundary_contracts": [contract.to_dict() for contract in self.boundary_contracts],
            "unified_error_budget": self.unified_error_budget,
            "route_cases": self.route_cases,
            "status": self.status,
            "claim_scope": self.claim_scope,
            "digest": self.digest,
            "passed": self.passed,
        }


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _json_default(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, complex):
        return [float(value.real), float(value.imag)]
    raise TypeError(f"unsupported JSON value {type(value).__name__}")


def _digest(payload: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(
            payload,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            default=_json_default,
        ).encode("utf-8")
    ).hexdigest()


def _canonical_pauli_key(
    raw_key: PauliKey | Sequence[tuple[int, str]],
    qubit_count: int,
) -> PauliKey:
    seen: set[int] = set()
    canonical: list[tuple[int, str]] = []
    for raw_q, raw_label in raw_key:
        q = int(raw_q)
        label = str(raw_label).upper()
        if not (0 <= q < qubit_count):
            raise ValueError(f"Pauli qubit {q} outside register")
        if q in seen:
            raise ValueError("Pauli key contains a duplicate qubit")
        if label not in {"I", "X", "Y", "Z"}:
            raise ValueError(f"unsupported Pauli label {label}")
        seen.add(q)
        if label != "I":
            canonical.append((q, label))
    return tuple(sorted(canonical))


# ---------------------------------------------------------------------------
# Layer 1: exact backward causal cone
# ---------------------------------------------------------------------------


def compute_backward_causal_cone(
    qubit_count: int,
    instructions: Sequence[CircuitInstruction],
    observable_support: Iterable[int],
    *,
    target_classical_bits: Iterable[int] = (),
) -> CausalConeCertificate:
    if qubit_count <= 0:
        raise ValueError("qubit_count must be positive")
    active_qubits = {int(q) for q in observable_support}
    active_classical = {int(bit) for bit in target_classical_bits}
    if not active_qubits and not active_classical:
        raise ValueError("causal cone requires quantum or classical target support")
    if any(q < 0 or q >= qubit_count for q in active_qubits):
        raise ValueError("observable support outside register")

    included: list[int] = []
    for index in range(len(instructions) - 1, -1, -1):
        instruction = instructions[index]
        if any(q >= qubit_count for q in instruction.qubits):
            raise ValueError("instruction qubit outside register")
        touches_quantum = bool(active_qubits.intersection(instruction.qubits))
        writes_relevant_classical = bool(active_classical.intersection(instruction.classical_writes))
        if not (touches_quantum or writes_relevant_classical):
            continue
        included.append(index)
        active_qubits.update(instruction.qubits)
        active_classical.update(instruction.classical_reads)

    included_indices = tuple(sorted(included))
    semantic = {
        "schema": "qpdtr-exact-backward-causal-cone/v1",
        "qubit_count": int(qubit_count),
        "observable_support": tuple(sorted(int(q) for q in observable_support)),
        "included_instruction_indices": included_indices,
        "causal_qubits": tuple(sorted(active_qubits)),
        "causal_classical_bits": tuple(sorted(active_classical)),
        "excluded_instruction_count": len(instructions) - len(included_indices),
        "exact_reduction": True,
        "status": "PASS_EXACT_BACKWARD_CAUSAL_CONE",
    }
    return CausalConeCertificate(**semantic, digest=_digest(semantic))


# ---------------------------------------------------------------------------
# Layer 2: sparse Heisenberg Pauli propagation
# ---------------------------------------------------------------------------


_PAULI = {
    "I": np.eye(2, dtype=complex),
    "X": np.array([[0, 1], [1, 0]], dtype=complex),
    "Y": np.array([[0, -1j], [1j, 0]], dtype=complex),
    "Z": np.array([[1, 0], [0, -1]], dtype=complex),
}


def _gate_matrix(instruction: CircuitInstruction) -> np.ndarray:
    name = instruction.name.upper()
    if name == "H":
        return np.array([[1, 1], [1, -1]], dtype=complex) / np.sqrt(2.0)
    if name == "X":
        return _PAULI["X"]
    if name == "Y":
        return _PAULI["Y"]
    if name == "Z":
        return _PAULI["Z"]
    if name == "S":
        return np.diag([1.0, 1.0j]).astype(complex)
    if name == "SDG":
        return np.diag([1.0, -1.0j]).astype(complex)
    if name == "T":
        return np.diag([1.0, np.exp(1.0j * np.pi / 4.0)]).astype(complex)
    if name == "TDG":
        return np.diag([1.0, np.exp(-1.0j * np.pi / 4.0)]).astype(complex)
    if name in {"RX", "RY", "RZ"}:
        if len(instruction.parameters) != 1:
            raise ValueError(f"{name} requires one angle")
        theta = float(instruction.parameters[0])
        generator = _PAULI[name[-1]]
        return np.cos(theta / 2.0) * _PAULI["I"] - 1.0j * np.sin(theta / 2.0) * generator
    if name == "CNOT":
        return np.array(
            [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1], [0, 0, 1, 0]],
            dtype=complex,
        )
    if name == "CZ":
        return np.diag([1, 1, 1, -1]).astype(complex)
    if name == "SWAP":
        return np.array(
            [[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 1]],
            dtype=complex,
        )
    raise ValueError(f"unsupported Pauli-propagation gate {instruction.name}")


def _local_pauli_decomposition(matrix: np.ndarray, qubit_arity: int) -> dict[tuple[str, ...], complex]:
    if matrix.shape != (2**qubit_arity, 2**qubit_arity):
        raise ValueError("local operator shape disagrees with gate arity")
    labels = ("I", "X", "Y", "Z")
    result: dict[tuple[str, ...], complex] = {}
    for flat_index in range(4**qubit_arity):
        index = flat_index
        local_labels: list[str] = []
        for _ in range(qubit_arity):
            local_labels.append(labels[index % 4])
            index //= 4
        local_labels.reverse()
        basis = _PAULI[local_labels[0]]
        for label in local_labels[1:]:
            basis = np.kron(basis, _PAULI[label])
        coefficient = np.trace(basis.conj().T @ matrix) / (2**qubit_arity)
        if abs(coefficient) > 1e-13:
            result[tuple(local_labels)] = complex(coefficient)
    return result


def _replace_local_paulis(
    key: PauliKey,
    gate_qubits: tuple[int, ...],
    replacement: tuple[str, ...],
) -> PauliKey:
    mapping = dict(key)
    for q, label in zip(gate_qubits, replacement, strict=True):
        if label == "I":
            mapping.pop(q, None)
        else:
            mapping[q] = label
    return tuple(sorted(mapping.items()))


def propagate_pauli_observable(
    observable: SparsePauliObservable,
    instructions: Sequence[CircuitInstruction],
    *,
    instruction_indices: Sequence[int] | None = None,
    max_terms: int = 4096,
    allocated_error_budget: float = 1e-10,
    coefficient_tolerance: float = 1e-14,
) -> PauliPropagationCertificate:
    """Propagate an observable as ``U† O U`` without a state vector.

    The l1 norm of every discarded Pauli coefficient is accumulated.  Because
    each Pauli string has operator norm one and subsequent conjugations are
    unitary, this is a valid worst-case expectation-value error bound.
    """

    if max_terms <= 0:
        raise ValueError("max_terms must be positive")
    if allocated_error_budget < 0 or not isfinite(allocated_error_budget):
        raise ValueError("allocated_error_budget must be finite and non-negative")
    selected = tuple(range(len(instructions))) if instruction_indices is None else tuple(int(i) for i in instruction_indices)
    if any(i < 0 or i >= len(instructions) for i in selected):
        raise ValueError("instruction index outside circuit")

    terms = observable.to_mapping()
    dropped_l1 = 0.0
    maximum_count = len(terms)
    for index in reversed(selected):
        instruction = instructions[index]
        matrix = _gate_matrix(instruction)
        arity = len(instruction.qubits)
        if arity not in {1, 2}:
            raise ValueError("Pauli propagation currently supports one- and two-qubit gates")
        if matrix.shape != (2**arity, 2**arity):
            raise ValueError("gate matrix shape disagrees with instruction arity")
        updated: dict[PauliKey, complex] = {}
        for key, coefficient in terms.items():
            local_map = dict(key)
            local_operator = _PAULI[local_map.get(instruction.qubits[0], "I")]
            for q in instruction.qubits[1:]:
                local_operator = np.kron(local_operator, _PAULI[local_map.get(q, "I")])
            transformed = matrix.conj().T @ local_operator @ matrix
            for local_labels, local_coefficient in _local_pauli_decomposition(transformed, arity).items():
                new_key = _replace_local_paulis(key, instruction.qubits, local_labels)
                updated[new_key] = updated.get(new_key, 0.0 + 0.0j) + coefficient * local_coefficient

        tiny = [key for key, value in updated.items() if abs(value) <= coefficient_tolerance]
        dropped_l1 += float(sum(abs(updated[key]) for key in tiny))
        for key in tiny:
            del updated[key]
        if len(updated) > max_terms:
            ordered = sorted(updated.items(), key=lambda item: abs(item[1]), reverse=True)
            retained = ordered[:max_terms]
            dropped_l1 += float(sum(abs(value) for _, value in ordered[max_terms:]))
            updated = dict(retained)
        terms = updated
        maximum_count = max(maximum_count, len(terms))

    status = (
        "PASS_PAULI_OBSERVABLE_PROPAGATION"
        if dropped_l1 <= allocated_error_budget
        else "BLOCKED_PAULI_TRUNCATION_ERROR_BUDGET_EXCEEDED"
    )
    serialized_terms = tuple(
        (key, (float(value.real), float(value.imag)))
        for key, value in sorted(terms.items(), key=lambda item: item[0])
    )
    semantic = {
        "schema": "qpdtr-pauli-observable-propagation/v1",
        "qubit_count": observable.qubit_count,
        "input_term_count": len(observable.terms),
        "output_term_count": len(terms),
        "processed_instruction_count": len(selected),
        "maximum_intermediate_term_count": maximum_count,
        "retained_term_budget": max_terms,
        "dropped_l1_error_bound": dropped_l1,
        "allocated_error_budget": float(allocated_error_budget),
        "output_terms": serialized_terms,
        "status": status,
        "claim_scope": (
            "Heisenberg propagation of sparse Pauli observables through registered one- and two-qubit gates. "
            "The result is an observable, not a full state or an unrestricted output sampler."
        ),
    }
    return PauliPropagationCertificate(**semantic, digest=_digest(semantic))


# ---------------------------------------------------------------------------
# Layer 3: graph tensor-network belief propagation
# ---------------------------------------------------------------------------


def _validate_graph_tensor_nodes(nodes: Sequence[GraphTensorNode]) -> tuple[dict[int, GraphTensorNode], int]:
    by_id = {int(node.node_id): node for node in nodes}
    if len(by_id) != len(nodes) or not nodes:
        raise ValueError("graph tensor nodes must be non-empty and uniquely identified")
    edge_count = 0
    for node in nodes:
        tensor = np.asarray(node.tensor, dtype=complex)
        if tensor.ndim != len(node.neighbors):
            raise ValueError("node tensor rank must equal neighbor count")
        if len(set(node.neighbors)) != len(node.neighbors):
            raise ValueError("node neighbor list contains duplicates")
        for axis, neighbor in enumerate(node.neighbors):
            if neighbor not in by_id:
                raise ValueError("graph references an unknown neighbor")
            other = by_id[neighbor]
            if node.node_id not in other.neighbors:
                raise ValueError("graph adjacency must be symmetric")
            other_axis = other.neighbors.index(node.node_id)
            if tensor.shape[axis] != np.asarray(other.tensor).shape[other_axis]:
                raise ValueError("edge dimensions disagree")
            if node.node_id < neighbor:
                edge_count += 1
    return by_id, edge_count


def _message_from_node(
    node: GraphTensorNode,
    target_neighbor: int,
    incoming: Mapping[tuple[int, int], np.ndarray],
) -> np.ndarray:
    tensor = np.asarray(node.tensor, dtype=complex)
    target_axis = node.neighbors.index(target_neighbor)
    work = np.moveaxis(tensor, target_axis, 0)
    reordered_neighbors = (target_neighbor,) + tuple(n for n in node.neighbors if n != target_neighbor)
    for axis, neighbor in enumerate(reordered_neighbors[1:], start=1):
        message = np.asarray(incoming[(neighbor, node.node_id)], dtype=complex)
        shape = [1] * work.ndim
        shape[axis] = len(message)
        work = work * message.reshape(shape)
    if work.ndim == 1:
        return work
    return np.sum(work, axis=tuple(range(1, work.ndim)))


def _tree_contraction(by_id: Mapping[int, GraphTensorNode], root: int) -> complex:
    parent: dict[int, int | None] = {root: None}
    order = [root]
    for node_id in order:
        for neighbor in by_id[node_id].neighbors:
            if neighbor == parent[node_id]:
                continue
            if neighbor in parent:
                raise ValueError("tree traversal detected a cycle")
            parent[neighbor] = node_id
            order.append(neighbor)
    if len(order) != len(by_id):
        raise ValueError("graph is disconnected")

    messages: dict[tuple[int, int], np.ndarray] = {}
    for node_id in reversed(order[1:]):
        parent_id = parent[node_id]
        assert parent_id is not None
        messages[(node_id, parent_id)] = _message_from_node(by_id[node_id], parent_id, messages)

    root_tensor = np.asarray(by_id[root].tensor, dtype=complex)
    work = root_tensor.copy()
    for axis, neighbor in enumerate(by_id[root].neighbors):
        message = messages[(neighbor, root)]
        shape = [1] * work.ndim
        shape[axis] = len(message)
        work = work * message.reshape(shape)
    return complex(np.sum(work))


def contract_graph_tensor_network_bp(
    nodes: Sequence[GraphTensorNode],
    *,
    allocated_error_budget: float = 1e-10,
    maximum_iterations: int = 256,
    residual_tolerance: float = 1e-12,
    independent_reference: complex | None = None,
    allow_loopy_approximation: bool = False,
) -> GraphBPContractionCertificate:
    by_id, edge_count = _validate_graph_tensor_nodes(nodes)
    is_tree = edge_count == len(nodes) - 1
    contraction: complex | None = None
    residual = 0.0
    iterations = 0
    exact_tree = False

    if is_tree:
        contraction = _tree_contraction(by_id, min(by_id))
        exact_tree = True
        status = "PASS_GRAPH_TENSOR_BP"
    else:
        messages: dict[tuple[int, int], np.ndarray] = {}
        for node in nodes:
            tensor = np.asarray(node.tensor)
            for axis, neighbor in enumerate(node.neighbors):
                messages[(node.node_id, neighbor)] = np.ones(tensor.shape[axis], dtype=complex)
        for iterations in range(1, maximum_iterations + 1):
            updated: dict[tuple[int, int], np.ndarray] = {}
            residual = 0.0
            for node in nodes:
                for neighbor in node.neighbors:
                    raw = _message_from_node(node, neighbor, messages)
                    scale = float(np.linalg.norm(raw))
                    normalized = raw if scale == 0.0 else raw / scale
                    residual = max(residual, float(np.linalg.norm(normalized - messages[(node.node_id, neighbor)])))
                    updated[(node.node_id, neighbor)] = normalized
            messages = updated
            if residual <= residual_tolerance:
                break

        node_factors: list[complex] = []
        for node in nodes:
            work = np.asarray(node.tensor, dtype=complex).copy()
            for axis, neighbor in enumerate(node.neighbors):
                message = messages[(neighbor, node.node_id)]
                shape = [1] * work.ndim
                shape[axis] = len(message)
                work *= message.reshape(shape)
            node_factors.append(complex(np.sum(work)))
        edge_factors: list[complex] = []
        for node in nodes:
            for neighbor in node.neighbors:
                if node.node_id < neighbor:
                    edge_factors.append(complex(np.dot(messages[(node.node_id, neighbor)], messages[(neighbor, node.node_id)])))
        denominator = np.prod(edge_factors) if edge_factors else 1.0 + 0.0j
        contraction = complex(np.prod(node_factors) / denominator) if denominator != 0 else None
        status = (
            "PASS_GRAPH_TENSOR_BP"
            if allow_loopy_approximation
            and residual <= residual_tolerance
            and independent_reference is not None
            and contraction is not None
            and abs(contraction - independent_reference) <= allocated_error_budget
            else "BLOCKED_LOOPY_GRAPH_BP_REQUIRES_CLUSTER_OR_REFERENCE_CERTIFICATE"
        )

    reference_gap = None if independent_reference is None or contraction is None else float(abs(contraction - independent_reference))
    if exact_tree and reference_gap is not None and reference_gap > allocated_error_budget:
        status = "FAIL_GRAPH_TENSOR_TREE_REFERENCE_MISMATCH"
    semantic = {
        "schema": "qpdtr-graph-tensor-belief-propagation/v1",
        "node_count": len(nodes),
        "edge_count": edge_count,
        "is_tree": is_tree,
        "exact_tree_contraction": exact_tree,
        "iteration_count": iterations,
        "message_residual": float(residual),
        "contraction_value": None if contraction is None else (float(contraction.real), float(contraction.imag)),
        "independent_reference_value": (
            None
            if independent_reference is None
            else (float(complex(independent_reference).real), float(complex(independent_reference).imag))
        ),
        "reference_gap": reference_gap,
        "allocated_error_budget": float(allocated_error_budget),
        "status": status,
        "claim_scope": (
            "Tensor-network belief propagation is exact on connected trees. Loopy graphs remain blocked unless "
            "a converged message residual and an independent reference or cluster-correction certificate bound the error."
        ),
    }
    return GraphBPContractionCertificate(**semantic, digest=_digest(semantic))


# ---------------------------------------------------------------------------
# Single authoritative resource-factorized owner
# ---------------------------------------------------------------------------


class AdaptiveResourceFactorizedEmulator:
    owner_id = "PHI-Q1000-ARFE"

    def plan(self, profile: StructuralProfile) -> StructuralRouteDecision:
        if profile.qubit_count < 0:
            raise ValueError("qubit_count cannot be negative")
        if profile.requested_total_error_budget <= 0 or not isfinite(profile.requested_total_error_budget):
            raise ValueError("requested_total_error_budget must be finite and positive")

        reasons: list[str] = ["single observable-first PHI-Q1000-ARFE owner"]
        rejected: list[str] = []
        patch_owners: list[str] = []

        effective_qubits = profile.qubit_count
        if (
            profile.simulation_object in {"observable", "reduced_state", "sample"}
            and profile.causal_cone_qubit_count is not None
            and profile.qubit_count > 0
            and 0 < profile.causal_cone_qubit_count <= profile.qubit_count
        ):
            effective_qubits = profile.causal_cone_qubit_count
            patch_owners.append("QCM-CAUSAL-CONE")
            reasons.append("exact backward causal-cone reduction")

        primary: str | None = None
        if profile.verified_code_compiled_schedule:
            primary = "QCM-CODE-COMPILED-TN"
            reasons.append("verified diagonal-plus-permutation compilation certificate")
        elif (
            profile.verified_phase_polynomial_lowering
            and profile.estimated_linear_rank_width is not None
            and profile.estimated_treewidth is not None
            and profile.estimated_linear_rank_width + 2 < profile.estimated_treewidth
        ):
            primary = "QCM-FEYNMAN-DD-LRW"
            reasons.append("verified phase-polynomial lowering with favorable linear-rank width")
        elif profile.clifford_only:
            primary = "QCM-STABILIZER"
            reasons.append("Clifford-only circuit certificate")
        elif profile.gaussian_fermionic:
            primary = "QCM-FERMION-GAUSSIAN"
            reasons.append("quasi-free fermionic closure certificate")
        elif profile.one_dimensional_local_lindblad:
            primary = "QCM-CPTP-TT-LINDBLAD"
            reasons.append("one-dimensional local GKSL structure")
        elif (
            profile.basis_adaptive_sparse_admissible
            and profile.estimated_computational_basis_participation_ratio is not None
            and profile.sparse_budget is not None
            and profile.sparse_budget > 0
            and profile.estimated_computational_basis_participation_ratio > profile.sparse_budget
        ):
            primary = "QCM-BASS"
            reasons.append("verified product-basis sparse-state crossover")
        elif profile.non_markovian_memory:
            if profile.estimated_process_tensor_bond_dimension is None:
                rejected.append("temporal process-tensor bond dimension remains unquantified")
            elif profile.spatially_entangled_multiqubit_process and profile.estimated_spacetime_bond_dimension is None:
                rejected.append("joint spatial-temporal bond dimension remains unquantified")
            else:
                primary = "QCM-TEMPO"
                reasons.append("bounded process-tensor memory certificate")
        elif (
            profile.pauli_observable_admissible
            and profile.simulation_object == "observable"
            and profile.estimated_pauli_term_count is not None
            and profile.pauli_term_budget is not None
            and profile.estimated_pauli_term_count <= profile.pauli_term_budget
        ):
            primary = "QCM-PAULI-OBS"
            reasons.append("observable complexity fits the sparse Pauli budget")
        elif profile.graph_bp_admissible:
            if profile.graph_is_tree is True:
                primary = "QCM-GTN-BP"
                reasons.append("tree graph gives an exact graph-TN BP contraction")
            elif (
                profile.estimated_graph_bp_residual is not None
                and profile.estimated_graph_bp_residual <= profile.requested_total_error_budget
            ):
                primary = "QCM-GTN-BP"
                reasons.append("loopy graph BP has a declared residual inside the budget")
                rejected.append("independent cluster/reference certificate still required at execution")
            else:
                rejected.append("loopy graph BP lacks a bounded residual/reference certificate")
        elif profile.magic_injection_admissible:
            rejected.append("MAST owner remains blocked until delayed-projection boundary contracts are implemented")
        elif profile.expected_low_treewidth:
            primary = "QCM-ADAPTIVE-TTN"
            reasons.append("low-treewidth structural prior")
        elif effective_qubits <= 24 and effective_qubits > 0:
            primary = "QCM-EXACT-SV"
            reasons.append("effective causal register fits the bounded exact-state control")
        elif profile.simulation_object == "full_state" and effective_qubits >= 64:
            rejected.append("generic large-register full-state materialization is exponentially blocked")
        else:
            primary = "QCM-GENERAL-TN"
            reasons.append("no stronger constructive representation certificate is available")

        if profile.real_calibration_snapshot and not profile.multitime_calibration_record_count:
            rejected.append("non-Markovian hardware identification requires multitime calibration records")
        if profile.conditional_measurements and not profile.multitime_interventions:
            rejected.append("conditional measurements require an intervention-complete process description")

        if primary is not None:
            patch_owners.append(primary)
            status = "PASS_RESOURCE_FACTORIZED_ROUTE_SELECTED"
        else:
            status = "BLOCKED_NO_CERTIFIED_RESOURCE_FACTORIZED_ROUTE"

        semantic = {
            "schema": "qpdtr-phi-q1000-arfe-route/v1",
            "selected_method_id": "QCM-PHI-Q1000-ARFE",
            "primary_patch_owner_id": primary,
            "patch_owner_ids": tuple(dict.fromkeys(patch_owners)),
            "status": status,
            "reasons": tuple(reasons),
            "rejected_shortcuts": tuple(rejected),
            "profile": asdict(profile),
        }
        return StructuralRouteDecision(**semantic, digest=_digest(semantic))

    def boundary_contract(
        self,
        *,
        boundary_id: str,
        authoritative_owner: str,
        representation: str,
        support: Sequence[int],
        input_signature: Sequence[str],
        output_signature: Sequence[str],
        error_metric: str,
        error_bound: float,
    ) -> BoundaryContract:
        if error_bound < 0 or not isfinite(error_bound):
            raise ValueError("boundary error must be finite and non-negative")
        semantic = {
            "schema": "qpdtr-resource-patch-boundary/v1",
            "boundary_id": str(boundary_id),
            "authoritative_owner": str(authoritative_owner),
            "representation": str(representation),
            "support": tuple(sorted(int(q) for q in support)),
            "input_signature": tuple(str(value) for value in input_signature),
            "output_signature": tuple(str(value) for value in output_signature),
            "error_metric": str(error_metric),
            "error_bound": float(error_bound),
            "status": "PASS_TYPED_BOUNDARY_CONTRACT",
        }
        return BoundaryContract(**semantic, digest=_digest(semantic))


_ACTIVE_OWNER = AdaptiveResourceFactorizedEmulator()


def plan_resource_factorized_emulation(profile: StructuralProfile) -> StructuralRouteDecision:
    return _ACTIVE_OWNER.plan(profile)


def select_structural_owner(profile: StructuralProfile) -> StructuralRouteDecision:
    """Thin compatibility wrapper around the single active PHI-Q1000-ARFE owner."""

    return plan_resource_factorized_emulation(profile)


def _dense_pauli_matrix(observable: SparsePauliObservable) -> np.ndarray:
    if observable.qubit_count > 12:
        raise ValueError("dense Pauli materialization is restricted to small references")
    result = np.zeros((2**observable.qubit_count, 2**observable.qubit_count), dtype=complex)
    for key, coefficient in observable.terms:
        mapping = dict(key)
        term = _PAULI[mapping.get(0, "I")]
        for q in range(1, observable.qubit_count):
            term = np.kron(term, _PAULI[mapping.get(q, "I")])
        result += coefficient * term
    return result


def _dense_circuit_unitary(qubit_count: int, instructions: Sequence[CircuitInstruction]) -> np.ndarray:
    if qubit_count > 10:
        raise ValueError("dense circuit materialization is restricted to small references")
    unitary = np.eye(2**qubit_count, dtype=complex)
    for instruction in instructions:
        local = _gate_matrix(instruction)
        gate_qubits = instruction.qubits
        if len(gate_qubits) == 1:
            q = gate_qubits[0]
            full = None
            for site in range(qubit_count):
                factor = local if site == q else _PAULI["I"]
                full = factor if full is None else np.kron(full, factor)
        elif len(gate_qubits) == 2:
            # Dense reference only needs adjacent ordered controls in qualification.
            q0, q1 = gate_qubits
            if q1 != q0 + 1:
                raise ValueError("dense two-qubit reference requires adjacent ordered qubits")
            full = None
            site = 0
            while site < qubit_count:
                if site == q0:
                    factor = local
                    site += 2
                else:
                    factor = _PAULI["I"]
                    site += 1
                full = factor if full is None else np.kron(full, factor)
        else:
            raise ValueError("dense reference supports one- and two-qubit gates")
        unitary = full @ unitary
    return unitary


def qualify_phi_q1000_arfe() -> ARFEQualificationCertificate:
    # 1000-qubit exact causal reduction to a 16-qubit light cone.
    instructions: list[CircuitInstruction] = [CircuitInstruction("H", (q,)) for q in range(1000)]
    instructions.extend(CircuitInstruction("CNOT", (q, q + 1)) for q in range(15))
    cone = compute_backward_causal_cone(1000, instructions, observable_support=(15,))

    observable = SparsePauliObservable.from_terms(1000, {((15, "Z"),): 1.0})
    pauli = propagate_pauli_observable(
        observable,
        instructions,
        instruction_indices=cone.included_instruction_indices,
        max_terms=64,
        allocated_error_budget=1e-12,
    )

    # Independent dense reference on a small non-Clifford circuit.
    small_instructions = (
        CircuitInstruction("H", (0,)),
        CircuitInstruction("CNOT", (0, 1)),
        CircuitInstruction("RZ", (1,), parameters=(0.37,)),
    )
    small_observable = SparsePauliObservable.from_terms(2, {((1, "X"),): 1.0})
    small_pauli = propagate_pauli_observable(
        small_observable,
        small_instructions,
        max_terms=16,
        allocated_error_budget=1e-12,
    )
    propagated_small = SparsePauliObservable.from_terms(
        2,
        {
            key: complex(real, imag)
            for key, (real, imag) in small_pauli.output_terms
        },
    )
    dense_u = _dense_circuit_unitary(2, small_instructions)
    dense_reference = dense_u.conj().T @ _dense_pauli_matrix(small_observable) @ dense_u
    dense_gap = float(np.linalg.norm(_dense_pauli_matrix(propagated_small) - dense_reference, ord=2))

    # Exact BP contraction on a 1000-node tree tensor network.
    transition = np.array([[0.9, 0.1], [0.2, 0.8]], dtype=complex)
    graph_nodes: list[GraphTensorNode] = [GraphTensorNode(0, (1,), np.array([0.6, 0.4], dtype=complex))]
    for node_id in range(1, 999):
        graph_nodes.append(GraphTensorNode(node_id, (node_id - 1, node_id + 1), transition.copy()))
    graph_nodes.append(GraphTensorNode(999, (998,), np.ones(2, dtype=complex)))
    direct = np.array([0.6, 0.4], dtype=complex)
    for _ in range(998):
        direct = direct @ transition
    graph_reference = complex(direct @ np.ones(2, dtype=complex))
    graph_bp = contract_graph_tensor_network_bp(
        graph_nodes,
        allocated_error_budget=1e-11,
        independent_reference=graph_reference,
    )

    boundaries = (
        _ACTIVE_OWNER.boundary_contract(
            boundary_id="ARFE-CAUSAL-CONE-BOUNDARY",
            authoritative_owner="QCM-CAUSAL-CONE",
            representation="QUBIT_SUPPORT_SET",
            support=cone.causal_qubits,
            input_signature=("1000-qubit typed circuit", "local observable support"),
            output_signature=("exact reduced circuit", "causal support"),
            error_metric="OPERATOR_NORM",
            error_bound=0.0,
        ),
        _ACTIVE_OWNER.boundary_contract(
            boundary_id="ARFE-PAULI-BOUNDARY",
            authoritative_owner="QCM-PAULI-OBS",
            representation="SPARSE_PAULI_MAP",
            support=cone.causal_qubits,
            input_signature=("sparse observable", "reduced circuit"),
            output_signature=("Heisenberg sparse observable",),
            error_metric="EXPECTATION_ABSOLUTE_ERROR",
            error_bound=pauli.dropped_l1_error_bound,
        ),
        _ACTIVE_OWNER.boundary_contract(
            boundary_id="ARFE-GTN-BP-BOUNDARY",
            authoritative_owner="QCM-GTN-BP",
            representation="TREE_TENSOR_MESSAGE",
            support=tuple(range(1000)),
            input_signature=("graph tensor network",),
            output_signature=("scalar contraction",),
            error_metric="ABSOLUTE_CONTRACTION_ERROR",
            error_bound=0.0 if graph_bp.reference_gap is None else graph_bp.reference_gap,
        ),
    )

    budget = build_unified_quantum_error_budget(
        (
            QuantumErrorAllocation(
                component_id="causal_cone",
                owner="QCM-CAUSAL-CONE",
                metric="ABSOLUTE_OBSERVABLE_ERROR",
                observed_bound=0.0,
                allocated_budget=1e-12,
                combination_rule="SUM",
                compatible_group="ARFE_OBSERVABLE",
                status="PASS",
            ),
            QuantumErrorAllocation(
                component_id="pauli_propagation",
                owner="QCM-PAULI-OBS",
                metric="ABSOLUTE_OBSERVABLE_ERROR",
                observed_bound=max(pauli.dropped_l1_error_bound, dense_gap),
                allocated_budget=1e-11,
                combination_rule="SUM",
                compatible_group="ARFE_OBSERVABLE",
                status="PASS" if dense_gap <= 1e-11 else "FAIL_REFERENCE",
            ),
            QuantumErrorAllocation(
                component_id="graph_tensor_bp",
                owner="QCM-GTN-BP",
                metric="ABSOLUTE_OBSERVABLE_ERROR",
                observed_bound=graph_bp.reference_gap,
                allocated_budget=1e-11,
                combination_rule="SUM",
                compatible_group="ARFE_OBSERVABLE",
                status="PASS" if graph_bp.passed else "FAIL_REFERENCE",
            ),
        )
    )

    route_profiles = {
        "observable_1000_clifford": StructuralProfile(
            qubit_count=1000,
            simulation_object="observable",
            causal_cone_qubit_count=16,
            clifford_only=True,
        ),
        "observable_1000_pauli": StructuralProfile(
            qubit_count=1000,
            simulation_object="observable",
            causal_cone_qubit_count=96,
            pauli_observable_admissible=True,
            estimated_pauli_term_count=2048,
            pauli_term_budget=4096,
        ),
        "graph_tree_1000": StructuralProfile(
            qubit_count=1000,
            simulation_object="observable",
            graph_bp_admissible=True,
            graph_is_tree=True,
        ),
        "generic_full_state_1000": StructuralProfile(
            qubit_count=1000,
            simulation_object="full_state",
        ),
        "unimplemented_mast": StructuralProfile(
            qubit_count=1000,
            simulation_object="observable",
            magic_injection_admissible=True,
            estimated_magic_bond_dimension=512,
            magic_bond_budget=1024,
        ),
    }
    route_cases = {name: _ACTIVE_OWNER.plan(profile).to_dict() for name, profile in route_profiles.items()}

    passed = (
        cone.passed
        and len(cone.causal_qubits) == 16
        and pauli.passed
        and dense_gap <= 1e-11
        and graph_bp.passed
        and graph_bp.node_count == 1000
        and all(contract.passed for contract in boundaries)
        and budget.status == "PASS_UNIFIED_SPATIAL_TEMPORAL_ERROR_BUDGET"
        and route_cases["observable_1000_clifford"]["primary_patch_owner_id"] == "QCM-STABILIZER"
        and route_cases["observable_1000_pauli"]["primary_patch_owner_id"] == "QCM-PAULI-OBS"
        and route_cases["graph_tree_1000"]["primary_patch_owner_id"] == "QCM-GTN-BP"
        and route_cases["generic_full_state_1000"]["status"] == "BLOCKED_NO_CERTIFIED_RESOURCE_FACTORIZED_ROUTE"
        and route_cases["unimplemented_mast"]["status"] == "BLOCKED_NO_CERTIFIED_RESOURCE_FACTORIZED_ROUTE"
    )
    semantic = {
        "schema": "qpdtr-phi-q1000-arfe-qualification/v1",
        "owner_id": _ACTIVE_OWNER.owner_id,
        "causal_cone": cone.to_dict(),
        "pauli_observable": pauli.to_dict() | {"small_dense_reference_gap": dense_gap},
        "graph_tensor_bp": graph_bp.to_dict(),
        "boundary_contracts": [contract.to_dict() for contract in boundaries],
        "unified_error_budget": budget.to_dict(),
        "route_cases": route_cases,
        "status": (
            "PASS_PHI_Q1000_ADAPTIVE_RESOURCE_FACTORIZED_EMULATOR"
            if passed
            else "FAIL_PHI_Q1000_ADAPTIVE_RESOURCE_FACTORIZED_EMULATOR"
        ),
        "claim_scope": (
            "Qualified controls are: exact backward causal reduction on a typed 1000-qubit circuit, "
            "statevector-free sparse-Pauli observable propagation, and exact graph-TN belief propagation "
            "on a 1000-node tree under one typed boundary/error contract. This is not a generic exact "
            "1000-qubit full-state simulator. Loopy GTN, MAST and graph influence-functional BP remain blocked."
        ),
    }
    digest = _digest(semantic)
    return ARFEQualificationCertificate(
        schema=semantic["schema"],
        owner_id=semantic["owner_id"],
        causal_cone=cone,
        pauli_observable=pauli,
        graph_tensor_bp=graph_bp,
        boundary_contracts=boundaries,
        unified_error_budget=budget.to_dict(),
        route_cases=route_cases,
        status=semantic["status"],
        claim_scope=semantic["claim_scope"],
        digest=digest,
    )


def qualify_structural_owner_router() -> dict[str, Any]:
    """Thin compatibility wrapper returning the active ARFE qualification."""

    return qualify_phi_q1000_arfe().to_dict()
