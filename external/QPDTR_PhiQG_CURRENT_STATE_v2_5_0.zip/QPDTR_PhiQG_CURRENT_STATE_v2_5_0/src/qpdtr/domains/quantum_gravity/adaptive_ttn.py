"""Persistent adaptive tree-tensor-network state owner.

The active owner stores a rooted binary TTN and applies one-site gates exactly and
arbitrary two-site gates through deterministic local tree rotations.  The update
contracts and refactorizes only tensors on the exposed tree path; it never
materializes the global state vector.  Singular-value truncation is controlled by
one cumulative discarded-weight budget.

Dense state-vector reconstruction remains available only as a bounded reference
operation for independent small-system equality tests.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Mapping, Sequence
import hashlib
import json
import math

import networkx as nx
import numpy as np


@dataclass(frozen=True, slots=True)
class TTNTopology:
    leaves: tuple[int, ...]
    left: "TTNTopology | None" = None
    right: "TTNTopology | None" = None

    @property
    def is_leaf(self) -> bool:
        return len(self.leaves) == 1

    def to_dict(self) -> dict[str, Any]:
        return {
            "leaves": list(self.leaves),
            "left": None if self.left is None else self.left.to_dict(),
            "right": None if self.right is None else self.right.to_dict(),
        }


@dataclass(slots=True)
class _TensorNode:
    topology: TTNTopology
    tensor: np.ndarray
    left: "_TensorNode | None" = None
    right: "_TensorNode | None" = None


@dataclass(frozen=True, slots=True)
class TTNRefactorCertificate:
    qubit_count: int
    maximum_bond: int
    used_maximum_bond: int
    total_discarded_weight: float
    reconstruction_error: float | None
    topology_cut_cost: float
    topology_rebuild_count: int
    gate_count: int
    statevector_materialization_bytes: int
    update_scope: str
    status: str
    digest: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class TTNScalableCertificate:
    qubit_count: int
    maximum_bond: int
    used_maximum_bond: int
    total_discarded_weight: float
    norm_gap: float
    gate_count: int
    two_site_gate_count: int
    local_path_update_count: int
    tree_rotation_count: int
    topology_rebuild_count: int
    entangled_site_count: int
    maximum_single_site_entropy: float
    maximum_zz_correlation_gap: float
    global_x_string_gap: float
    statevector_materialized: bool
    update_scope: str
    status: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_STRUCTURED_50_QUBIT_LOCAL_PATH_TTN"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"passed": self.passed}


def _balanced(leaves: Sequence[int]) -> TTNTopology:
    values = tuple(int(x) for x in leaves)
    if not values:
        raise ValueError("TTN topology requires at least one leaf")
    if len(values) == 1:
        return TTNTopology(values)
    mid = len(values) // 2
    left = _balanced(values[:mid])
    right = _balanced(values[mid:])
    return TTNTopology(values, left, right)


def _graph_tree(graph: nx.Graph, leaves: Sequence[int]) -> TTNTopology:
    values = tuple(sorted(int(x) for x in leaves))
    if len(values) <= 2:
        return _balanced(values)
    sub = graph.subgraph(values).copy()
    if sub.number_of_edges() == 0 or not nx.is_connected(sub):
        return _balanced(values)
    try:
        a, b = nx.community.kernighan_lin_bisection(sub, weight="weight", seed=0)
        left_values, right_values = tuple(sorted(a)), tuple(sorted(b))
        if not left_values or not right_values:
            return _balanced(values)
        left_topology = _graph_tree(graph, left_values)
        right_topology = _graph_tree(graph, right_values)
        return TTNTopology(
            tuple(left_topology.leaves + right_topology.leaves),
            left_topology,
            right_topology,
        )
    except Exception:
        return _balanced(values)


def _topology_cut_cost(topology: TTNTopology, graph: nx.Graph) -> float:
    if topology.is_leaf:
        return 0.0
    assert topology.left is not None and topology.right is not None
    left = set(topology.left.leaves)
    right = set(topology.right.leaves)
    crossing = 0.0
    for u, v, data in graph.edges(data=True):
        if (u in left and v in right) or (u in right and v in left):
            crossing += float(data.get("weight", 1.0))
    return (
        crossing * len(topology.leaves)
        + _topology_cut_cost(topology.left, graph)
        + _topology_cut_cost(topology.right, graph)
    )


def _rank(singular_values: np.ndarray, max_bond: int, local_budget: float) -> tuple[int, float]:
    upper = min(int(max_bond), singular_values.size)
    squares = np.square(np.abs(singular_values))
    for rank in range(1, upper + 1):
        discarded = float(squares[rank:].sum())
        if discarded <= local_budget:
            return rank, discarded
    return upper, float(squares[upper:].sum())


def _topology_from_children(left: _TensorNode, right: _TensorNode) -> TTNTopology:
    return TTNTopology(
        tuple(left.topology.leaves + right.topology.leaves),
        left.topology,
        right.topology,
    )


class PersistentAdaptiveTTN:
    """Persistent binary TTN with local-path gate updates and tree rotations."""

    def __init__(
        self,
        statevector: np.ndarray,
        *,
        qubit_count: int,
        max_bond: int = 32,
        discarded_weight_budget: float = 1e-8,
        interaction_graph: nx.Graph | None = None,
        maximum_refactor_qubits: int = 14,
    ):
        if qubit_count < 2 or qubit_count > maximum_refactor_qubits:
            raise ValueError("Dense TTN import supports 2..maximum_refactor_qubits")
        self._initialize_metadata(
            qubit_count=qubit_count,
            max_bond=max_bond,
            discarded_weight_budget=discarded_weight_budget,
            interaction_graph=interaction_graph,
            maximum_refactor_qubits=maximum_refactor_qubits,
        )
        self.topology = _graph_tree(self.graph, range(self.qubit_count))
        self.root: _TensorNode | None = None
        self._factor(np.asarray(statevector, dtype=complex).reshape(-1), reset_error=True)

    def _initialize_metadata(
        self,
        *,
        qubit_count: int,
        max_bond: int,
        discarded_weight_budget: float,
        interaction_graph: nx.Graph | None,
        maximum_refactor_qubits: int,
    ) -> None:
        if qubit_count < 2:
            raise ValueError("TTN requires at least two qubits")
        if max_bond < 1 or discarded_weight_budget < 0.0:
            raise ValueError("TTN bond and truncation controls are inadmissible")
        self.qubit_count = int(qubit_count)
        self.max_bond = int(max_bond)
        self.discarded_weight_budget = float(discarded_weight_budget)
        self.maximum_refactor_qubits = int(maximum_refactor_qubits)
        self.graph = interaction_graph.copy() if interaction_graph is not None else nx.Graph()
        self.graph.add_nodes_from(range(self.qubit_count))
        self.total_discarded_weight = 0.0
        self.used_maximum_bond = 1
        self.topology_rebuild_count = 0
        self.tree_rotation_count = 0
        self.local_path_update_count = 0
        self.gate_count = 0
        self.two_site_gate_count = 0
        self._statevector_materialized = False

    @classmethod
    def product_state(cls, bits: Sequence[int], **kwargs: Any) -> "PersistentAdaptiveTTN":
        values = tuple(int(bit) for bit in bits)
        if len(values) < 2 or any(bit not in {0, 1} for bit in values):
            raise ValueError("Product-state bits must contain at least two zeros or ones")
        obj = cls.__new__(cls)
        obj._initialize_metadata(
            qubit_count=len(values),
            max_bond=int(kwargs.pop("max_bond", 32)),
            discarded_weight_budget=float(kwargs.pop("discarded_weight_budget", 1e-8)),
            interaction_graph=kwargs.pop("interaction_graph", None),
            maximum_refactor_qubits=int(kwargs.pop("maximum_refactor_qubits", 14)),
        )
        if kwargs:
            raise TypeError(f"Unknown TTN constructor arguments: {sorted(kwargs)}")
        obj.topology = _graph_tree(obj.graph, range(obj.qubit_count))

        def build(topology: TTNTopology) -> _TensorNode:
            if topology.is_leaf:
                tensor = np.zeros((2, 1), dtype=complex)
                tensor[values[topology.leaves[0]], 0] = 1.0
                return _TensorNode(topology, tensor)
            assert topology.left is not None and topology.right is not None
            left = build(topology.left)
            right = build(topology.right)
            return _TensorNode(topology, np.ones((1, 1, 1), dtype=complex), left, right)

        obj.root = build(obj.topology)
        return obj

    def _remaining_budget(self, divisor: int = 1) -> float:
        remaining = max(0.0, self.discarded_weight_budget - self.total_discarded_weight)
        return remaining / max(1, int(divisor))

    def _record_svd(self, singular_values: np.ndarray, divisor: int = 1) -> int:
        rank, discarded = _rank(
            singular_values,
            self.max_bond,
            self._remaining_budget(divisor),
        )
        self.total_discarded_weight += discarded
        self.used_maximum_bond = max(self.used_maximum_bond, rank)
        return rank

    def _decompose(self, topology: TTNTopology, tensor: np.ndarray, local_budget: float) -> _TensorNode:
        parent_dim = tensor.shape[-1]
        if topology.is_leaf:
            if tensor.shape != (2, parent_dim):
                raise ValueError("Leaf tensor shape mismatch")
            return _TensorNode(topology, tensor.copy())
        assert topology.left is not None and topology.right is not None
        n_left = len(topology.left.leaves)
        n_right = len(topology.right.leaves)
        matrix = tensor.reshape(2**n_left, 2**n_right * parent_dim)
        u, s, vh = np.linalg.svd(matrix, full_matrices=False)
        rank_left, discarded_left = _rank(s, self.max_bond, local_budget)
        self.total_discarded_weight += discarded_left
        self.used_maximum_bond = max(self.used_maximum_bond, rank_left)
        left_tensor = u[:, :rank_left].reshape((2,) * n_left + (rank_left,))
        remainder = (s[:rank_left, None] * vh[:rank_left, :]).reshape(
            rank_left, *((2,) * n_right), parent_dim
        )
        perm = tuple(range(1, n_right + 1)) + (0, n_right + 1)
        right_matrix = np.transpose(remainder, perm).reshape(2**n_right, rank_left * parent_dim)
        ur, sr, vhr = np.linalg.svd(right_matrix, full_matrices=False)
        rank_right, discarded_right = _rank(sr, self.max_bond, local_budget)
        self.total_discarded_weight += discarded_right
        self.used_maximum_bond = max(self.used_maximum_bond, rank_right)
        right_tensor = ur[:, :rank_right].reshape((2,) * n_right + (rank_right,))
        core = (sr[:rank_right, None] * vhr[:rank_right, :]).reshape(
            rank_right, rank_left, parent_dim
        )
        core = np.transpose(core, (1, 0, 2))
        left_node = self._decompose(topology.left, left_tensor, local_budget)
        right_node = self._decompose(topology.right, right_tensor, local_budget)
        return _TensorNode(topology, core, left_node, right_node)

    def _factor(self, statevector: np.ndarray, *, reset_error: bool = False) -> None:
        state = np.asarray(statevector, dtype=complex).reshape(-1)
        if state.size != 2**self.qubit_count:
            raise ValueError("Statevector dimension mismatch")
        norm = np.linalg.norm(state)
        if not np.isfinite(norm) or norm <= 0:
            raise ValueError("Statevector must have finite nonzero norm")
        state = state / norm
        if reset_error:
            self.total_discarded_weight = 0.0
            self.used_maximum_bond = 1
        internal_count = max(1, self.qubit_count - 1)
        local_budget = self.discarded_weight_budget / (2 * internal_count)
        tensor = state.reshape((2,) * self.qubit_count + (1,))
        # The graph partition may order physical leaves non-canonically.  The
        # decomposition must see axes in exactly ``topology.leaves`` order;
        # otherwise labels and tensor axes diverge after the first tree rotation.
        axis_order = tuple(self.topology.leaves) + (self.qubit_count,)
        tensor = np.transpose(tensor, axis_order)
        self.root = self._decompose(self.topology, tensor, local_budget)
        self.normalize()

    def _reconstruct(self, node: _TensorNode) -> np.ndarray:
        if node.topology.is_leaf:
            return node.tensor
        assert node.left is not None and node.right is not None
        left = self._reconstruct(node.left)
        right = self._reconstruct(node.right)
        temporary = np.tensordot(left, node.tensor, axes=([-1], [0]))
        combined = np.tensordot(temporary, right, axes=([-2], [-1]))
        return np.moveaxis(combined, len(node.topology.left.leaves), -1)

    def to_statevector(self, maximum_qubits: int | None = None) -> np.ndarray:
        limit = self.maximum_refactor_qubits if maximum_qubits is None else int(maximum_qubits)
        if self.qubit_count > limit:
            raise ValueError("State-vector materialization is forbidden above the reference limit")
        if self.root is None:
            raise RuntimeError("TTN has no root")
        self._statevector_materialized = True
        tensor = self._reconstruct(self.root)
        leaf_order = self.root.topology.leaves
        if tuple(leaf_order) != tuple(range(self.qubit_count)):
            positions = {site: index for index, site in enumerate(leaf_order)}
            permutation = tuple(positions[site] for site in range(self.qubit_count)) + (self.qubit_count,)
            tensor = np.transpose(tensor, permutation)
        return tensor[..., 0].reshape(-1)

    def _metric(self, node: _TensorNode) -> np.ndarray:
        if node.topology.is_leaf:
            return np.einsum("ia,ib->ab", node.tensor.conj(), node.tensor, optimize=True)
        assert node.left is not None and node.right is not None
        left = self._metric(node.left)
        right = self._metric(node.right)
        return np.einsum(
            "abp,ac,bd,cdq->pq",
            node.tensor.conj(),
            left,
            right,
            node.tensor,
            optimize=True,
        )

    def norm_squared(self) -> float:
        if self.root is None:
            raise RuntimeError("TTN has no root")
        value = self._metric(self.root)
        return float(np.real_if_close(value[0, 0]).real)

    def normalize(self) -> float:
        norm2 = self.norm_squared()
        if not np.isfinite(norm2) or norm2 <= 0.0:
            raise RuntimeError("TTN has invalid norm")
        norm = math.sqrt(norm2)
        assert self.root is not None
        self.root.tensor /= norm
        return norm

    @staticmethod
    def _contains(node: _TensorNode, site: int) -> bool:
        return int(site) in node.topology.leaves

    @staticmethod
    def _swap_children(node: _TensorNode) -> _TensorNode:
        if node.topology.is_leaf or node.left is None or node.right is None:
            raise ValueError("Cannot swap a TTN leaf")
        node.left, node.right = node.right, node.left
        node.tensor = np.transpose(node.tensor, (1, 0, 2))
        node.topology = _topology_from_children(node.left, node.right)
        return node

    def _rotate_right(self, node: _TensorNode) -> _TensorNode:
        if node.left is None or node.left.topology.is_leaf or node.right is None:
            raise ValueError("Right rotation requires an internal left child")
        left_parent = node.left
        assert left_parent.left is not None and left_parent.right is not None
        x, y, z = left_parent.left, left_parent.right, node.right
        # M[a,b,c,p] = sum_d A[a,b,d] P[d,c,p]
        merged = np.einsum("abd,dcp->abcp", left_parent.tensor, node.tensor, optimize=True)
        a, b, c, p = merged.shape
        matrix = np.transpose(merged, (0, 3, 1, 2)).reshape(a * p, b * c)
        u, s, vh = np.linalg.svd(matrix, full_matrices=False)
        rank = self._record_svd(s)
        new_root_tensor = u[:, :rank].reshape(a, p, rank).transpose(0, 2, 1)
        new_right_tensor = (s[:rank, None] * vh[:rank, :]).reshape(rank, b, c).transpose(1, 2, 0)
        new_right = _TensorNode(_topology_from_children(y, z), new_right_tensor, y, z)
        self.tree_rotation_count += 1
        return _TensorNode(_topology_from_children(x, new_right), new_root_tensor, x, new_right)

    def _rotate_left(self, node: _TensorNode) -> _TensorNode:
        if node.right is None or node.right.topology.is_leaf or node.left is None:
            raise ValueError("Left rotation requires an internal right child")
        right_parent = node.right
        assert right_parent.left is not None and right_parent.right is not None
        x, y, z = node.left, right_parent.left, right_parent.right
        # M[a,b,c,p] = sum_d P[a,d,p] A[b,c,d]
        merged = np.einsum("adp,bcd->abcp", node.tensor, right_parent.tensor, optimize=True)
        a, b, c, p = merged.shape
        matrix = merged.reshape(a * b, c * p)
        u, s, vh = np.linalg.svd(matrix, full_matrices=False)
        rank = self._record_svd(s)
        new_left_tensor = u[:, :rank].reshape(a, b, rank)
        new_root_tensor = (s[:rank, None] * vh[:rank, :]).reshape(rank, c, p)
        new_left = _TensorNode(_topology_from_children(x, y), new_left_tensor, x, y)
        self.tree_rotation_count += 1
        return _TensorNode(_topology_from_children(new_left, z), new_root_tensor, new_left, z)

    def _promote_left(self, node: _TensorNode, site: int) -> _TensorNode:
        if node.topology.is_leaf:
            if node.topology.leaves[0] != site:
                raise ValueError("Requested site is not in TTN subtree")
            return node
        assert node.left is not None and node.right is not None
        if not self._contains(node.left, site):
            if not self._contains(node.right, site):
                raise ValueError("Requested site is not in TTN subtree")
            node = self._swap_children(node)
        assert node.left is not None
        if node.left.topology.is_leaf:
            return node
        node.left = self._promote_left(node.left, site)
        node.topology = _topology_from_children(node.left, node.right)
        return self._rotate_right(node)

    def _expose_pair_at_root(self, first: int, second: int) -> tuple[_TensorNode, _TensorNode]:
        if self.root is None:
            raise RuntimeError("TTN has no root")
        root = self._promote_left(self.root, first)
        assert root.left is not None and root.right is not None
        if not self._contains(root.right, second):
            raise RuntimeError("TTN pair exposure lost the second site")
        if root.right.topology.is_leaf:
            pair = root
        else:
            root.right = self._promote_left(root.right, second)
            root.topology = _topology_from_children(root.left, root.right)
            root = self._rotate_left(root)
            assert root.left is not None
            pair = root.left
        if pair.left is None or pair.right is None:
            raise RuntimeError("TTN pair exposure did not produce an internal pair node")
        if pair.left.topology.leaves != (first,) or pair.right.topology.leaves != (second,):
            raise RuntimeError("TTN pair exposure produced the wrong site order")
        self.root = root
        self.topology = root.topology
        return root, pair

    def apply_one_site_gate(self, site: int, gate: np.ndarray) -> None:
        matrix = np.asarray(gate, dtype=complex)
        if matrix.shape != (2, 2) or site < 0 or site >= self.qubit_count:
            raise ValueError("Invalid TTN one-site gate")

        def visit(node: _TensorNode) -> bool:
            if node.topology.is_leaf:
                if node.topology.leaves[0] == site:
                    node.tensor = matrix @ node.tensor
                    return True
                return False
            assert node.left is not None and node.right is not None
            return visit(node.left) if self._contains(node.left, site) else visit(node.right)

        assert self.root is not None
        if not visit(self.root):
            raise RuntimeError("TTN site not found")
        self.gate_count += 1
        self.normalize()

    def _apply_sibling_gate(self, pair: _TensorNode, gate: np.ndarray) -> None:
        assert pair.left is not None and pair.right is not None
        if not pair.left.topology.is_leaf or not pair.right.topology.is_leaf:
            raise ValueError("Local TTN two-site update requires exposed leaf siblings")
        left_tensor = pair.left.tensor
        right_tensor = pair.right.tensor
        theta = np.einsum("ia,jb,abp->ijp", left_tensor, right_tensor, pair.tensor, optimize=True)
        transformed = (gate @ theta.reshape(4, -1)).reshape(theta.shape)
        _, _, parent_dim = transformed.shape
        matrix = transformed.reshape(2, 2 * parent_dim)
        u, s, vh = np.linalg.svd(matrix, full_matrices=False)
        rank_left = self._record_svd(s, divisor=2)
        new_left = u[:, :rank_left]
        remainder = (s[:rank_left, None] * vh[:rank_left, :]).reshape(rank_left, 2, parent_dim)
        right_matrix = np.transpose(remainder, (1, 0, 2)).reshape(2, rank_left * parent_dim)
        ur, sr, vhr = np.linalg.svd(right_matrix, full_matrices=False)
        rank_right = self._record_svd(sr, divisor=1)
        new_right = ur[:, :rank_right]
        new_core = (sr[:rank_right, None] * vhr[:rank_right, :]).reshape(
            rank_right, rank_left, parent_dim
        ).transpose(1, 0, 2)
        pair.left.tensor = new_left
        pair.right.tensor = new_right
        pair.tensor = new_core

    def apply_two_site_gate(self, first: int, second: int, gate: np.ndarray, *, adapt: bool = True) -> None:
        if first == second or min(first, second) < 0 or max(first, second) >= self.qubit_count:
            raise ValueError("Invalid TTN two-site gate sites")
        matrix = np.asarray(gate, dtype=complex)
        if matrix.shape != (4, 4):
            raise ValueError("Two-site gate must be 4x4")
        rotations_before = self.tree_rotation_count
        _, pair = self._expose_pair_at_root(first, second)
        self._apply_sibling_gate(pair, matrix)
        self.graph.add_edge(
            first,
            second,
            weight=float(self.graph.get_edge_data(first, second, {}).get("weight", 0.0)) + 1.0,
        )
        rotations_used = self.tree_rotation_count - rotations_before
        if adapt and rotations_used:
            self.topology_rebuild_count += 1
        self.local_path_update_count += 1
        self.two_site_gate_count += 1
        self.gate_count += 1
        assert self.root is not None
        self.topology = self.root.topology
        self.normalize()

    def _operator_transfer(self, node: _TensorNode, operators: Mapping[int, np.ndarray]) -> np.ndarray:
        if node.topology.is_leaf:
            site = node.topology.leaves[0]
            operator = np.asarray(operators.get(site, np.eye(2)), dtype=complex)
            if operator.shape != (2, 2):
                raise ValueError("TTN local operator must be 2x2")
            return np.einsum(
                "ia,ij,jb->ab",
                node.tensor.conj(),
                operator,
                node.tensor,
                optimize=True,
            )
        assert node.left is not None and node.right is not None
        left = self._operator_transfer(node.left, operators)
        right = self._operator_transfer(node.right, operators)
        return np.einsum(
            "abp,ac,bd,cdq->pq",
            node.tensor.conj(),
            left,
            right,
            node.tensor,
            optimize=True,
        )

    def expectation(self, operators: Mapping[int, np.ndarray]) -> complex:
        if self.root is None:
            raise RuntimeError("TTN has no root")
        value = self._operator_transfer(self.root, operators)[0, 0]
        return complex(value / self.norm_squared())

    def one_site_density_matrices(self) -> tuple[np.ndarray, ...]:
        if self.root is None:
            raise RuntimeError("TTN has no root")
        metrics: dict[int, np.ndarray] = {}

        def upward(node: _TensorNode) -> np.ndarray:
            if node.topology.is_leaf:
                value = np.einsum("ia,ib->ab", node.tensor.conj(), node.tensor, optimize=True)
            else:
                assert node.left is not None and node.right is not None
                left_value = upward(node.left)
                right_value = upward(node.right)
                value = np.einsum(
                    "abp,ac,bd,cdq->pq",
                    node.tensor.conj(),
                    left_value,
                    right_value,
                    node.tensor,
                    optimize=True,
                )
            metrics[id(node)] = value
            return value

        upward(self.root)
        densities: list[np.ndarray | None] = [None] * self.qubit_count

        def descend(node: _TensorNode, environment: np.ndarray) -> None:
            if node.topology.is_leaf:
                rho = np.einsum(
                    "ia,ab,jb->ij",
                    node.tensor,
                    environment,
                    node.tensor.conj(),
                    optimize=True,
                )
                rho = 0.5 * (rho + rho.conj().T)
                trace = complex(np.trace(rho))
                if abs(trace) <= 0.0:
                    raise RuntimeError("TTN leaf reduced density has zero trace")
                densities[node.topology.leaves[0]] = rho / trace
                return
            assert node.left is not None and node.right is not None
            left_metric = metrics[id(node.left)]
            right_metric = metrics[id(node.right)]
            left_env = np.einsum(
                "abp,bd,pq,cdq->ac",
                node.tensor.conj(),
                right_metric,
                environment,
                node.tensor,
                optimize=True,
            )
            right_env = np.einsum(
                "abp,ac,pq,cdq->bd",
                node.tensor.conj(),
                left_metric,
                environment,
                node.tensor,
                optimize=True,
            )
            descend(node.left, left_env)
            descend(node.right, right_env)

        descend(self.root, np.ones((1, 1), dtype=complex))
        return tuple(np.asarray(rho) for rho in densities if rho is not None)

    def single_site_entropies(self) -> tuple[float, ...]:
        values: list[float] = []
        for rho in self.one_site_density_matrices():
            eigenvalues = np.clip(np.linalg.eigvalsh(rho).real, 0.0, 1.0)
            nz = eigenvalues[eigenvalues > 1e-15]
            values.append(float(-np.sum(nz * np.log2(nz))))
        return tuple(values)

    def certificate(self, reference_state: np.ndarray | None = None) -> TTNRefactorCertificate:
        reconstruction_error = None
        if reference_state is not None:
            state = self.to_statevector(maximum_qubits=self.maximum_refactor_qubits)
            ref = np.asarray(reference_state, dtype=complex).reshape(-1)
            ref = ref / np.linalg.norm(ref)
            phase = np.vdot(ref, state)
            aligned = state * np.exp(-1j * np.angle(phase)) if abs(phase) else state
            reconstruction_error = float(np.linalg.norm(ref - aligned))
        status = (
            "PASS_BOUNDED_PERSISTENT_ADAPTIVE_TTN"
            if self.total_discarded_weight <= self.discarded_weight_budget * 1.05
            else "BLOCKED_TRUNCATION_BUDGET"
        )
        payload = {
            "qubit_count": self.qubit_count,
            "maximum_bond": self.max_bond,
            "used_maximum_bond": self.used_maximum_bond,
            "total_discarded_weight": float(self.total_discarded_weight),
            "reconstruction_error": reconstruction_error,
            "topology_cut_cost": float(_topology_cut_cost(self.topology, self.graph)),
            "topology_rebuild_count": self.topology_rebuild_count,
            "gate_count": self.gate_count,
            "statevector_materialization_bytes": int((2**self.qubit_count) * np.dtype(np.complex128).itemsize),
            "update_scope": "local-path TTN gate updates; dense reconstruction used only for bounded reference equality",
            "status": status,
        }
        digest = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        return TTNRefactorCertificate(**payload, digest=digest)


def qualify_persistent_adaptive_ttn(seed: int = 7) -> TTNRefactorCertificate:
    """Independent bounded equality control against a dense ten-qubit reference."""
    rng = np.random.default_rng(seed)
    del rng  # seed remains in the contract even though the gate schedule is deterministic.
    n = 10
    graph = nx.complete_graph(n)
    for u, v in graph.edges:
        graph[u][v]["weight"] = 1.0 + 0.1 * ((u + v) % 3)
    state = PersistentAdaptiveTTN.product_state(
        [0] * n,
        max_bond=32,
        discarded_weight_budget=1e-9,
        interaction_graph=graph,
        maximum_refactor_qubits=12,
    )
    reference = np.zeros(2**n, dtype=complex)
    reference[0] = 1.0
    h = np.array([[1, 1], [1, -1]], dtype=complex) / math.sqrt(2)
    cnot = np.array(
        [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1], [0, 0, 1, 0]],
        dtype=complex,
    )
    state.apply_one_site_gate(0, h)
    pairs = [(0, 9), (1, 7), (2, 8), (3, 6), (4, 9), (0, 5), (2, 7)]
    for a, b in pairs:
        state.apply_two_site_gate(a, b, cnot, adapt=True)
    ref = reference.reshape((2,) * n)
    moved = np.moveaxis(ref, 0, 0).reshape(2, -1)
    moved = h @ moved
    ref = np.moveaxis(moved.reshape((2,) + (2,) * (n - 1)), 0, 0)
    for a, b in pairs:
        moved = np.moveaxis(ref, (a, b), (0, 1))
        moved = (cnot @ moved.reshape(4, -1)).reshape(moved.shape)
        ref = np.moveaxis(moved, (0, 1), (a, b))
    return state.certificate(ref.reshape(-1))


def qualify_scalable_adaptive_ttn(qubit_count: int = 50) -> TTNScalableCertificate:
    """Qualify a real statevector-free structured 50-qubit GHZ circuit.

    This proves local-path TTN execution for a low-rank but globally entangled
    workload.  It does not prove efficient simulation of arbitrary high-entanglement
    circuits or Hamiltonian quenches.
    """
    if qubit_count < 16:
        raise ValueError("Scalable TTN qualification requires at least 16 qubits")
    state = PersistentAdaptiveTTN.product_state(
        [0] * qubit_count,
        max_bond=16,
        discarded_weight_budget=1e-10,
        interaction_graph=nx.path_graph(qubit_count),
        maximum_refactor_qubits=14,
    )
    h = np.array([[1, 1], [1, -1]], dtype=complex) / math.sqrt(2)
    cnot = np.array(
        [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1], [0, 0, 1, 0]],
        dtype=complex,
    )
    state.apply_one_site_gate(0, h)
    for target in range(1, qubit_count):
        state.apply_two_site_gate(0, target, cnot, adapt=True)
    norm_gap = abs(state.norm_squared() - 1.0)
    entropies = state.single_site_entropies()
    z = np.array([[1, 0], [0, -1]], dtype=complex)
    x = np.array([[0, 1], [1, 0]], dtype=complex)
    zz_gaps = [abs(state.expectation({0: z, site: z}).real - 1.0) for site in range(1, qubit_count)]
    x_string_gap = abs(state.expectation({site: x for site in range(qubit_count)}).real - 1.0)
    entangled_count = sum(value > 0.999999 for value in entropies)
    passed = (
        norm_gap < 1e-10
        and state.total_discarded_weight <= state.discarded_weight_budget * 1.05
        and entangled_count == qubit_count
        and max(zz_gaps, default=0.0) < 1e-10
        and x_string_gap < 1e-10
        and not state._statevector_materialized
    )
    status = (
        "PASS_STRUCTURED_50_QUBIT_LOCAL_PATH_TTN"
        if passed
        else "BLOCKED_STRUCTURED_TTN_QUALIFICATION_FAILED"
    )
    payload = {
        "qubit_count": state.qubit_count,
        "maximum_bond": state.max_bond,
        "used_maximum_bond": state.used_maximum_bond,
        "total_discarded_weight": float(state.total_discarded_weight),
        "norm_gap": float(norm_gap),
        "gate_count": state.gate_count,
        "two_site_gate_count": state.two_site_gate_count,
        "local_path_update_count": state.local_path_update_count,
        "tree_rotation_count": state.tree_rotation_count,
        "topology_rebuild_count": state.topology_rebuild_count,
        "entangled_site_count": int(entangled_count),
        "maximum_single_site_entropy": float(max(entropies)),
        "maximum_zz_correlation_gap": float(max(zz_gaps, default=0.0)),
        "global_x_string_gap": float(x_string_gap),
        "statevector_materialized": bool(state._statevector_materialized),
        "update_scope": (
            "arbitrary two-site gates via exact/local-SVD tree rotations and path exposure; "
            "qualified on a structured low-Schmidt-rank GHZ circuit, not arbitrary high-entanglement dynamics"
        ),
        "status": status,
    }
    digest = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return TTNScalableCertificate(**payload, digest=digest)
