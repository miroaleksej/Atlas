from __future__ import annotations

from dataclasses import asdict, dataclass
from itertools import combinations
from math import acos, factorial, pi, sqrt

import numpy as np


Edge = tuple[int, int]
Triangle = tuple[int, int, int]
Simplex4 = tuple[int, int, int, int, int]


def _edge(a: int, b: int) -> Edge:
    return (a, b) if a < b else (b, a)


def _triangle_area_from_lengths(a: float, b: float, c: float) -> float:
    s = 0.5 * (a + b + c)
    value = s * (s - a) * (s - b) * (s - c)
    if value <= 0.0:
        raise ValueError("Degenerate triangle in Regge geometry")
    return sqrt(value)


def _simplex_coordinates(simplex: Simplex4, lengths: dict[Edge, float]) -> np.ndarray:
    vertices = tuple(simplex)
    origin = vertices[0]
    gram = np.zeros((4, 4), dtype=float)
    for i, vi in enumerate(vertices[1:]):
        for j, vj in enumerate(vertices[1:]):
            gram[i, j] = 0.5 * (
                lengths[_edge(origin, vi)] ** 2
                + lengths[_edge(origin, vj)] ** 2
                - (0.0 if vi == vj else lengths[_edge(vi, vj)] ** 2)
            )
    eigenvalues = np.linalg.eigvalsh(gram)
    if float(np.min(eigenvalues)) <= 1e-12:
        raise ValueError("Edge lengths do not define a non-degenerate Euclidean 4-simplex")
    lower = np.linalg.cholesky(gram)
    coordinates = np.zeros((5, 4), dtype=float)
    coordinates[1:] = lower
    return coordinates


def _simplex_volume(coordinates: np.ndarray) -> float:
    gram = coordinates[1:] @ coordinates[1:].T
    return sqrt(float(np.linalg.det(gram))) / factorial(4)


def _outward_facet_normal(coordinates: np.ndarray, omitted: int) -> np.ndarray:
    indices = [index for index in range(5) if index != omitted]
    facet = coordinates[indices]
    edges = facet[1:] - facet[0]
    _, _, vh = np.linalg.svd(edges)
    normal = vh[-1]
    normal = normal / np.linalg.norm(normal)
    facet_centroid = facet.mean(axis=0)
    inward = coordinates[omitted] - facet_centroid
    if float(np.dot(normal, inward)) > 0.0:
        normal = -normal
    return normal


def _interior_dihedral_angle(coordinates: np.ndarray, omitted_a: int, omitted_b: int) -> float:
    normal_a = _outward_facet_normal(coordinates, omitted_a)
    normal_b = _outward_facet_normal(coordinates, omitted_b)
    cosine = float(np.clip(np.dot(normal_a, normal_b), -1.0, 1.0))
    return pi - acos(cosine)


@dataclass(frozen=True, slots=True)
class ReggeGeometryResult:
    edge_length: float
    four_simplex_count: int
    triangle_count: int
    triangle_area: float
    deficit_angle: float
    integrated_scalar_curvature: float
    total_four_volume: float
    average_scalar_curvature: float
    regge_action_g1: float

    def to_dict(self) -> dict:
        return asdict(self)


def boundary_of_five_simplex(edge_length: float = 1.0) -> ReggeGeometryResult:
    if edge_length <= 0:
        raise ValueError("Edge length must be positive")
    vertices = tuple(range(6))
    four_simplices = [tuple(v for v in vertices if v != omitted) for omitted in vertices]
    incidence: dict[tuple[int, ...], int] = {}
    for simplex in four_simplices:
        for triangle in combinations(simplex, 3):
            incidence[triangle] = incidence.get(triangle, 0) + 1
    if set(incidence.values()) != {3}:
        raise AssertionError("Unexpected regular 5-simplex boundary incidence")
    area = sqrt(3.0) * edge_length**2 / 4.0
    deficit = 2.0 * pi - 3.0 * acos(1.0 / 4.0)
    hinge_sum = sum(area * deficit for _ in incidence)
    integrated = 2.0 * hinge_sum
    total_volume = len(four_simplices) * sqrt(5.0) * edge_length**4 / 96.0
    return ReggeGeometryResult(
        edge_length,
        len(four_simplices),
        len(incidence),
        area,
        deficit,
        integrated,
        total_volume,
        integrated / total_volume,
        hinge_sum / (8.0 * pi),
    )


@dataclass(frozen=True, slots=True)
class ReggeScalingCertificate:
    length_ratio: float
    action_ratio: float
    expected_action_ratio: float
    curvature_ratio: float
    expected_curvature_ratio: float
    invariant_r_sqrt_v_gap: float

    def to_dict(self) -> dict:
        return asdict(self)


def scaling_certificate(l1: float = 1.0, l2: float = 2.0) -> ReggeScalingCertificate:
    a, b = boundary_of_five_simplex(l1), boundary_of_five_simplex(l2)
    ratio = l2 / l1
    return ReggeScalingCertificate(
        ratio,
        b.regge_action_g1 / a.regge_action_g1,
        ratio**2,
        b.average_scalar_curvature / a.average_scalar_curvature,
        ratio**-2,
        abs(
            a.average_scalar_curvature * sqrt(a.total_four_volume)
            - b.average_scalar_curvature * sqrt(b.total_four_volume)
        ),
    )


def five_simplex_boundary_data(edge_lengths: dict[Edge, float]) -> tuple[float, float, dict[Triangle, float]]:
    vertices = tuple(range(6))
    simplices: tuple[Simplex4, ...] = tuple(
        tuple(vertex for vertex in vertices if vertex != omitted) for omitted in vertices
    )
    required_edges = {_edge(a, b) for a, b in combinations(vertices, 2)}
    if set(edge_lengths) != required_edges or any(length <= 0.0 for length in edge_lengths.values()):
        raise ValueError("Boundary of the 5-simplex requires fifteen positive edge lengths")

    coordinates_by_simplex: dict[Simplex4, np.ndarray] = {}
    total_volume = 0.0
    for simplex in simplices:
        coordinates = _simplex_coordinates(simplex, edge_lengths)
        coordinates_by_simplex[simplex] = coordinates
        total_volume += _simplex_volume(coordinates)

    deficits: dict[Triangle, float] = {}
    curvature_sum = 0.0
    for triangle in combinations(vertices, 3):
        triangle = tuple(triangle)
        a, b, c = triangle
        area = _triangle_area_from_lengths(
            edge_lengths[_edge(a, b)], edge_lengths[_edge(a, c)], edge_lengths[_edge(b, c)]
        )
        angle_sum = 0.0
        for simplex in simplices:
            if set(triangle).issubset(simplex):
                omitted_vertices = [vertex for vertex in simplex if vertex not in triangle]
                local_indices = [simplex.index(vertex) for vertex in omitted_vertices]
                angle_sum += _interior_dihedral_angle(
                    coordinates_by_simplex[simplex], local_indices[0], local_indices[1]
                )
        deficit = 2.0 * pi - angle_sum
        deficits[triangle] = deficit
        curvature_sum += area * deficit
    return float(curvature_sum), float(total_volume), deficits


def regge_action(edge_lengths: dict[Edge, float], cosmological_constant: float) -> float:
    curvature, volume, _ = five_simplex_boundary_data(edge_lengths)
    return float(curvature - cosmological_constant * volume)


def _gradient(function, values: dict[Edge, float], relative_step: float) -> dict[Edge, float]:
    gradient: dict[Edge, float] = {}
    for edge, length in values.items():
        step = max(1e-7, relative_step * length)
        plus = dict(values)
        minus = dict(values)
        plus[edge] = length + step
        minus[edge] = length - step
        gradient[edge] = float((function(plus) - function(minus)) / (2.0 * step))
    return gradient


@dataclass(frozen=True, slots=True)
class ReggeEquationCertificate:
    cosmological_constant: float
    equilateral_gradient_norm: float
    equilateral_gradient_component_spread: float
    finite_difference_convergence_gap: float
    perturbed_gradient_norm: float
    perturbation_edge: Edge
    perturbation_fraction: float
    regular_dihedral_gap: float

    @property
    def passed(self) -> bool:
        return (
            self.equilateral_gradient_norm < 2e-6
            and self.equilateral_gradient_component_spread < 2e-6
            and self.finite_difference_convergence_gap < 2e-5
            and self.perturbed_gradient_norm > 100.0 * max(self.equilateral_gradient_norm, 1e-12)
            and self.regular_dihedral_gap < 1e-12
        )

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["passed"] = self.passed
        return payload


def regge_equation_certificate(edge_length: float = 1.0, perturbation_fraction: float = 0.015) -> ReggeEquationCertificate:
    vertices = tuple(range(6))
    lengths = {_edge(a, b): float(edge_length) for a, b in combinations(vertices, 2)}

    curvature_gradient = _gradient(lambda data: five_simplex_boundary_data(data)[0], lengths, 2e-5)
    volume_gradient = _gradient(lambda data: five_simplex_boundary_data(data)[1], lengths, 2e-5)
    c_vector = np.asarray(list(curvature_gradient.values()), dtype=float)
    v_vector = np.asarray(list(volume_gradient.values()), dtype=float)
    cosmological_constant = float(np.dot(c_vector, v_vector) / np.dot(v_vector, v_vector))

    objective = lambda data: regge_action(data, cosmological_constant)
    gradient_a = _gradient(objective, lengths, 2e-5)
    gradient_b = _gradient(objective, lengths, 1e-5)
    vector_a = np.asarray(list(gradient_a.values()), dtype=float)
    vector_b = np.asarray(list(gradient_b.values()), dtype=float)

    perturbation_edge = (0, 1)
    perturbed = dict(lengths)
    perturbed[perturbation_edge] *= 1.0 + perturbation_fraction
    perturbed_gradient = np.asarray(list(_gradient(objective, perturbed, 1e-5).values()), dtype=float)

    regular_coordinates = _simplex_coordinates((0, 1, 2, 3, 4), lengths)
    angle = _interior_dihedral_angle(regular_coordinates, 0, 1)
    return ReggeEquationCertificate(
        cosmological_constant=cosmological_constant,
        equilateral_gradient_norm=float(np.linalg.norm(vector_b)),
        equilateral_gradient_component_spread=float(np.max(vector_b) - np.min(vector_b)),
        finite_difference_convergence_gap=float(np.linalg.norm(vector_a - vector_b)),
        perturbed_gradient_norm=float(np.linalg.norm(perturbed_gradient)),
        perturbation_edge=perturbation_edge,
        perturbation_fraction=float(perturbation_fraction),
        regular_dihedral_gap=abs(angle - acos(1.0 / 4.0)),
    )
