from __future__ import annotations

from dataclasses import asdict, dataclass
from math import ceil, sqrt

import numpy as np


Face = tuple[int, int]


@dataclass(frozen=True, slots=True)
class BoundaryConfiguration:
    twice_spins: tuple[int, ...]
    coefficient_real: float
    coefficient_imag: float
    probability: float

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class CoherentBoundaryCertificate:
    family: str
    face_order: tuple[Face, ...]
    configurations: tuple[BoundaryConfiguration, ...]
    node_normals: dict[int, dict[int, tuple[float, float, float]]]
    closure_residuals: tuple[float, ...]
    normalization_gap: float
    mean_twice_spin: float
    variance_twice_spin: float
    extrinsic_phase_per_face: float
    shape_matching_status: str

    @property
    def passed(self) -> bool:
        return self.normalization_gap < 1e-12 and max(self.closure_residuals, default=0.0) < 1e-12

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["passed"] = self.passed
        return payload


def _tetrahedral_normals() -> np.ndarray:
    normals = np.asarray(
        [
            (1.0, 1.0, 1.0),
            (1.0, -1.0, -1.0),
            (-1.0, 1.0, -1.0),
            (-1.0, -1.0, 1.0),
        ],
        dtype=float,
    )
    return normals / sqrt(3.0)


def isotropic_livine_speziale_boundary_family(
    center_twice_spin: int = 4,
    width_twice_spin: float = 1.25,
    extrinsic_phase_per_face: float = 0.18,
    sigma_window: float = 3.5,
) -> CoherentBoundaryCertificate:
    """Construct a normalized isotropic spin superposition with LS closure data.

    The state is a bounded scale-mode family on the complete five-node 4-simplex boundary
    graph.  Each node carries a closed equal-area Livine-Speziale tetrahedral normal set.
    Shape matching between different tetrahedra is not asserted by this finite family.
    """

    if center_twice_spin < 1 or width_twice_spin <= 0.0:
        raise ValueError("Boundary-state center and width are inadmissible")
    face_order = tuple((a, b) for a in range(5) for b in range(a + 1, 5))
    radius = max(1, int(ceil(sigma_window * width_twice_spin)))
    q_values = list(range(max(1, center_twice_spin - radius), center_twice_spin + radius + 1))
    raw: list[complex] = []
    for q in q_values:
        gaussian = np.exp(-((q - center_twice_spin) ** 2) / (4.0 * width_twice_spin**2))
        dimension_factor = (q + 1.0) ** (len(face_order) / 2.0)
        phase = np.exp(1j * extrinsic_phase_per_face * len(face_order) * q / 2.0)
        raw.append(complex(dimension_factor * gaussian * phase))
    norm = sqrt(sum(abs(value) ** 2 for value in raw))
    coefficients = [value / norm for value in raw]
    configurations = tuple(
        BoundaryConfiguration(
            twice_spins=(q,) * len(face_order),
            coefficient_real=float(value.real),
            coefficient_imag=float(value.imag),
            probability=float(abs(value) ** 2),
        )
        for q, value in zip(q_values, coefficients, strict=True)
    )

    base_normals = _tetrahedral_normals()
    node_normals: dict[int, dict[int, tuple[float, float, float]]] = {}
    closure_residuals: list[float] = []
    for node in range(5):
        neighbours = [other for other in range(5) if other != node]
        assigned = {neighbour: tuple(float(x) for x in base_normals[index]) for index, neighbour in enumerate(neighbours)}
        node_normals[node] = assigned
        vector_sum = np.sum(np.asarray(list(assigned.values()), dtype=float), axis=0)
        closure_residuals.append(float(np.linalg.norm(vector_sum) / 4.0))

    probabilities = np.asarray([configuration.probability for configuration in configurations], dtype=float)
    q_array = np.asarray(q_values, dtype=float)
    mean = float(np.dot(probabilities, q_array))
    variance = float(np.dot(probabilities, (q_array - mean) ** 2))
    return CoherentBoundaryCertificate(
        family="normalized_isotropic_Livine_Speziale_scale_mode",
        face_order=face_order,
        configurations=configurations,
        node_normals=node_normals,
        closure_residuals=tuple(closure_residuals),
        normalization_gap=abs(float(probabilities.sum()) - 1.0),
        mean_twice_spin=mean,
        variance_twice_spin=variance,
        extrinsic_phase_per_face=float(extrinsic_phase_per_face),
        shape_matching_status="OPEN_NOT_ASSERTED_BY_ISOTROPIC_CLOSURE_CONTROL",
    )
