from __future__ import annotations

from dataclasses import asdict, dataclass
import ast
import hashlib
import math
import re
from typing import Any, Callable, Iterable, Mapping, Protocol, Sequence, TypeAlias

import numpy as np
from scipy.linalg import expm


# ---------------------------------------------------------------------------
# Safe scalar expressions used by OpenQASM 3 and OpenPulse.
# ---------------------------------------------------------------------------


class _SafeExpression:
    _BINARY = {
        ast.Add: lambda a, b: a + b,
        ast.Sub: lambda a, b: a - b,
        ast.Mult: lambda a, b: a * b,
        ast.Div: lambda a, b: a / b,
        ast.FloorDiv: lambda a, b: a // b,
        ast.Mod: lambda a, b: a % b,
        ast.Pow: lambda a, b: a**b,
        ast.BitAnd: lambda a, b: int(a) & int(b),
        ast.BitOr: lambda a, b: int(a) | int(b),
        ast.BitXor: lambda a, b: int(a) ^ int(b),
        ast.LShift: lambda a, b: int(a) << int(b),
        ast.RShift: lambda a, b: int(a) >> int(b),
    }
    _UNARY = {
        ast.UAdd: lambda a: +a,
        ast.USub: lambda a: -a,
        ast.Not: lambda a: not bool(a),
        ast.Invert: lambda a: ~int(a),
    }
    _COMPARE = {
        ast.Eq: lambda a, b: a == b,
        ast.NotEq: lambda a, b: a != b,
        ast.Lt: lambda a, b: a < b,
        ast.LtE: lambda a, b: a <= b,
        ast.Gt: lambda a, b: a > b,
        ast.GtE: lambda a, b: a >= b,
    }
    _FUNCTIONS = {
        "sin": np.sin,
        "cos": np.cos,
        "tan": np.tan,
        "exp": np.exp,
        "sqrt": np.sqrt,
        "ln": np.log,
        "log": np.log,
        "abs": abs,
        "ceil": math.ceil,
        "floor": math.floor,
    }

    @classmethod
    def evaluate(
        cls,
        expression: str,
        variables: Mapping[str, Any] | None = None,
        classical_bits: Sequence[int] | None = None,
    ) -> Any:
        source = str(expression).strip().replace("&&", " and ").replace("||", " or ")
        source = re.sub(r"(?<![=!<>])!(?!=)", " not ", source)
        tree = ast.parse(source, mode="eval")
        env = {"pi": float(np.pi), "tau": float(2.0 * np.pi), "euler": float(np.e)}
        if variables:
            env.update(variables)
        bits = tuple(int(value) for value in (classical_bits or ()))

        def visit(node: ast.AST) -> Any:
            if isinstance(node, ast.Expression):
                return visit(node.body)
            if isinstance(node, ast.Constant) and isinstance(node.value, (int, float, bool)):
                return node.value
            if isinstance(node, ast.Name):
                if node.id == "c":
                    value = 0
                    for index, bit in enumerate(bits):
                        value |= (int(bit) & 1) << index
                    return value
                if node.id in env:
                    return env[node.id]
                raise ValueError(f"Unknown expression identifier: {node.id}")
            if isinstance(node, ast.Subscript) and isinstance(node.value, ast.Name) and node.value.id == "c":
                index = int(visit(node.slice))
                if index < 0 or index >= len(bits):
                    raise ValueError("Classical-bit index is outside the declared register")
                return bits[index]
            if isinstance(node, ast.BinOp) and type(node.op) in cls._BINARY:
                return cls._BINARY[type(node.op)](visit(node.left), visit(node.right))
            if isinstance(node, ast.UnaryOp) and type(node.op) in cls._UNARY:
                return cls._UNARY[type(node.op)](visit(node.operand))
            if isinstance(node, ast.BoolOp):
                values = [bool(visit(value)) for value in node.values]
                if isinstance(node.op, ast.And):
                    return all(values)
                if isinstance(node.op, ast.Or):
                    return any(values)
            if isinstance(node, ast.Compare):
                left = visit(node.left)
                for operator, comparator in zip(node.ops, node.comparators, strict=True):
                    function = cls._COMPARE.get(type(operator))
                    if function is None:
                        raise ValueError("Unsupported comparison operator")
                    right = visit(comparator)
                    if not function(left, right):
                        return False
                    left = right
                return True
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                function = cls._FUNCTIONS.get(node.func.id)
                if function is None or node.keywords:
                    raise ValueError("Unsupported expression function")
                return function(*[visit(argument) for argument in node.args])
            raise ValueError(f"Unsupported expression node: {type(node).__name__}")

        value = visit(tree)
        if isinstance(value, (float, np.floating)) and not np.isfinite(value):
            raise ValueError("Expression evaluates to a non-finite value")
        return value


# ---------------------------------------------------------------------------
# OpenQASM 3 executable AST.
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class QuantumInstruction:
    name: str
    qubits: tuple[int, ...]
    parameter: float | None = None


@dataclass(frozen=True, slots=True)
class GateStatement:
    name: str
    qubit_indices: tuple[str, ...]
    parameters: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class MeasureStatement:
    qubit_index: str
    classical_index: str


@dataclass(frozen=True, slots=True)
class ResetStatement:
    qubit_index: str


@dataclass(frozen=True, slots=True)
class DelayStatement:
    duration_ns: float
    qubit_indices: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class BarrierStatement:
    qubit_indices: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class IfStatement:
    condition: str
    then_body: tuple[QASMStatement, ...]
    else_body: tuple[QASMStatement, ...]


@dataclass(frozen=True, slots=True)
class ForStatement:
    variable: str
    start: str
    stop: str
    step: str
    body: tuple[QASMStatement, ...]


@dataclass(frozen=True, slots=True)
class WhileStatement:
    condition: str
    body: tuple[QASMStatement, ...]


QASMStatement: TypeAlias = (
    GateStatement
    | MeasureStatement
    | ResetStatement
    | DelayStatement
    | BarrierStatement
    | IfStatement
    | ForStatement
    | WhileStatement
)


@dataclass(frozen=True, slots=True)
class PulseFrame:
    name: str
    port: str
    frequency_hz: float
    phase_rad: float


@dataclass(frozen=True, slots=True)
class PulseWaveform:
    name: str
    kind: str
    amplitude: float
    duration_ns: float
    sigma_ns: float | None = None
    beta: float = 0.0

    def samples(self, sample_count: int) -> np.ndarray:
        if sample_count < 2:
            raise ValueError("Waveform sampling requires at least two samples")
        time = np.linspace(0.0, self.duration_ns, sample_count, endpoint=False)
        if self.kind == "constant":
            return np.full(sample_count, complex(self.amplitude), dtype=complex)
        center = 0.5 * self.duration_ns
        sigma = float(self.sigma_ns or self.duration_ns / 4.0)
        gaussian = self.amplitude * np.exp(-0.5 * np.square((time - center) / sigma))
        if self.kind == "gaussian":
            return gaussian.astype(complex)
        if self.kind == "drag":
            derivative = -(time - center) / (sigma * sigma) * gaussian
            return (gaussian + 1j * self.beta * derivative).astype(complex)
        raise ValueError(f"Unsupported waveform kind: {self.kind}")


@dataclass(frozen=True, slots=True)
class PulseOperation:
    kind: str
    frame: str
    waveform: str | None = None
    value: float | None = None


@dataclass(frozen=True, slots=True)
class PulseCalibration:
    gate_name: str
    physical_qubits: tuple[int, ...]
    operations: tuple[PulseOperation, ...]


@dataclass(frozen=True, slots=True)
class OpenPulseProgram:
    frames: tuple[PulseFrame, ...]
    waveforms: tuple[PulseWaveform, ...]
    calibrations: tuple[PulseCalibration, ...]

    @property
    def frame_map(self) -> dict[str, PulseFrame]:
        return {frame.name: frame for frame in self.frames}

    @property
    def waveform_map(self) -> dict[str, PulseWaveform]:
        return {waveform.name: waveform for waveform in self.waveforms}


@dataclass(frozen=True, slots=True)
class QuantumCircuitProgram:
    version: str
    qubit_count: int
    classical_bit_count: int
    statements: tuple[QASMStatement, ...]
    pulse_program: OpenPulseProgram | None
    source_sha256: str

    @property
    def instructions(self) -> tuple[QuantumInstruction, ...]:
        """Flatten only a static measurement-free circuit for legacy external comparisons.

        This is a thin compatibility projection, not an alternative parser or executor.  Dynamic
        statements intentionally fail rather than being silently unrolled with guessed outcomes.
        """

        values: list[QuantumInstruction] = []
        for statement in self.statements:
            if not isinstance(statement, GateStatement):
                raise ValueError("Dynamic/timed OpenQASM 3 programs cannot be flattened")
            qubits = tuple(int(_SafeExpression.evaluate(index)) for index in statement.qubit_indices)
            parameters = tuple(float(_SafeExpression.evaluate(item)) for item in statement.parameters)
            if len(parameters) > 1:
                raise ValueError("The active gate kernel accepts at most one scalar gate parameter")
            values.append(
                QuantumInstruction(statement.name, qubits, parameters[0] if parameters else None)
            )
        return tuple(values)

    @property
    def measurement_map(self) -> tuple[tuple[int, int], ...]:
        values: list[tuple[int, int]] = []
        for statement in self.statements:
            if isinstance(statement, MeasureStatement):
                values.append(
                    (
                        int(_SafeExpression.evaluate(statement.qubit_index)),
                        int(_SafeExpression.evaluate(statement.classical_index)),
                    )
                )
        return tuple(values)


class _QASMScanner:
    def __init__(self, source: str):
        source = re.sub(r"/\*.*?\*/", "", source, flags=re.DOTALL)
        self.source = re.sub(r"//.*?$", "", source, flags=re.MULTILINE)
        self.position = 0

    def _skip_space(self) -> None:
        while self.position < len(self.source) and self.source[self.position].isspace():
            self.position += 1

    def _matching(self, start: int, opening: str, closing: str) -> int:
        depth = 0
        quote: str | None = None
        escaped = False
        for index in range(start, len(self.source)):
            char = self.source[index]
            if quote is not None:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == quote:
                    quote = None
                continue
            if char in {'"', "'"}:
                quote = char
                continue
            if char == opening:
                depth += 1
            elif char == closing:
                depth -= 1
                if depth == 0:
                    return index
        raise ValueError(f"Unterminated {opening}{closing} block")

    def read_parenthesized(self) -> str:
        self._skip_space()
        if self.position >= len(self.source) or self.source[self.position] != "(":
            raise ValueError("Expected parenthesized expression")
        end = self._matching(self.position, "(", ")")
        value = self.source[self.position + 1 : end]
        self.position = end + 1
        return value.strip()

    def read_braced(self) -> str:
        self._skip_space()
        if self.position >= len(self.source) or self.source[self.position] != "{":
            raise ValueError("Expected braced block")
        end = self._matching(self.position, "{", "}")
        value = self.source[self.position + 1 : end]
        self.position = end + 1
        return value

    def read_until(self, delimiter: str) -> str:
        start = self.position
        parentheses = brackets = 0
        quote: str | None = None
        escaped = False
        while self.position < len(self.source):
            char = self.source[self.position]
            if quote is not None:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == quote:
                    quote = None
            else:
                if char in {'"', "'"}:
                    quote = char
                elif char == "(":
                    parentheses += 1
                elif char == ")":
                    parentheses -= 1
                elif char == "[":
                    brackets += 1
                elif char == "]":
                    brackets -= 1
                elif char == delimiter and parentheses == 0 and brackets == 0:
                    value = self.source[start : self.position]
                    self.position += 1
                    return value.strip()
            self.position += 1
        raise ValueError(f"Missing delimiter {delimiter}")

    def starts_keyword(self, keyword: str) -> bool:
        self._skip_space()
        end = self.position + len(keyword)
        return (
            self.source[self.position : end].lower() == keyword.lower()
            and (end >= len(self.source) or not (self.source[end].isalnum() or self.source[end] == "_"))
        )

    def consume_keyword(self, keyword: str) -> None:
        if not self.starts_keyword(keyword):
            raise ValueError(f"Expected keyword {keyword}")
        self.position += len(keyword)

    @property
    def finished(self) -> bool:
        self._skip_space()
        return self.position >= len(self.source)


class OpenQASM3Parser:
    """Strict executable OpenQASM 3 profile with dynamic control and timing.

    The parser owns the supported semantics instead of pretending to implement every optional
    grammar extension.  Unsupported declarations are rejected explicitly.  OpenQASM 2 input is
    accepted only as a syntax-compatibility front end and normalized into the same OpenQASM 3 AST.
    """

    _ONE_QUBIT = {"h", "x", "y", "z", "s", "sdg", "t", "tdg"}
    _ROTATIONS = {"rx", "ry", "rz"}
    _TWO_QUBIT = {"cx", "cz", "swap"}

    @staticmethod
    def _duration_ns(expression: str) -> float:
        match = re.fullmatch(r"\s*(.+?)\s*(dt|ns|us|ms|s)\s*", expression, flags=re.IGNORECASE)
        if not match:
            raise ValueError(f"Duration must include a supported unit: {expression}")
        value = float(_SafeExpression.evaluate(match.group(1)))
        scale = {"dt": 1.0, "ns": 1.0, "us": 1e3, "ms": 1e6, "s": 1e9}[match.group(2).lower()]
        result = value * scale
        if not np.isfinite(result) or result < 0.0:
            raise ValueError("Duration must be finite and non-negative")
        return float(result)

    @staticmethod
    def _split_arguments(source: str) -> tuple[str, ...]:
        values: list[str] = []
        start = 0
        depth = 0
        for index, char in enumerate(source):
            if char in "([":
                depth += 1
            elif char in ")]":
                depth -= 1
            elif char == "," and depth == 0:
                values.append(source[start:index].strip())
                start = index + 1
        tail = source[start:].strip()
        if tail:
            values.append(tail)
        return tuple(values)

    @staticmethod
    def _qubit_reference(source: str, register: str = "q") -> str:
        match = re.fullmatch(rf"{re.escape(register)}\s*\[\s*(.+?)\s*\]", source.strip())
        if not match:
            raise ValueError(f"Expected {register}[index] reference: {source}")
        return match.group(1).strip()

    @classmethod
    def _ordinary_statement(
        cls,
        statement: str,
        *,
        qubit_count: int,
        classical_count: int,
    ) -> QASMStatement | None:
        stripped = statement.strip()
        lowered = stripped.lower()
        if not stripped:
            return None
        if lowered.startswith("openqasm ") or lowered.startswith("include "):
            return None
        if re.fullmatch(r"(?:qubit|qreg)(?:\s*\[\s*\d+\s*\])?\s+\w+(?:\s*\[\s*\d+\s*\])?", lowered):
            return None
        if re.fullmatch(r"(?:bit|creg)(?:\s*\[\s*\d+\s*\])?\s+\w+(?:\s*\[\s*\d+\s*\])?", lowered):
            return None
        if lowered.startswith("defcalgrammar "):
            return None
        measure = re.fullmatch(
            r"c\s*\[\s*(.+?)\s*\]\s*=\s*measure\s+q\s*\[\s*(.+?)\s*\]",
            stripped,
            flags=re.IGNORECASE,
        )
        if measure:
            return MeasureStatement(measure.group(2).strip(), measure.group(1).strip())
        measure_arrow = re.fullmatch(
            r"measure\s+q\s*\[\s*(.+?)\s*\]\s*->\s*c\s*\[\s*(.+?)\s*\]",
            stripped,
            flags=re.IGNORECASE,
        )
        if measure_arrow:
            return MeasureStatement(measure_arrow.group(1).strip(), measure_arrow.group(2).strip())
        reset = re.fullmatch(r"reset\s+q\s*\[\s*(.+?)\s*\]", stripped, flags=re.IGNORECASE)
        if reset:
            return ResetStatement(reset.group(1).strip())
        delay = re.fullmatch(r"delay\s*\[\s*(.+?)\s*\]\s+(.+)", stripped, flags=re.IGNORECASE)
        if delay:
            references = cls._split_arguments(delay.group(2))
            return DelayStatement(
                cls._duration_ns(delay.group(1)),
                tuple(cls._qubit_reference(reference) for reference in references),
            )
        barrier = re.fullmatch(r"barrier(?:\s+(.+))?", stripped, flags=re.IGNORECASE)
        if barrier:
            if barrier.group(1) is None or barrier.group(1).strip().lower() == "q":
                return BarrierStatement(tuple(str(index) for index in range(qubit_count)))
            return BarrierStatement(
                tuple(cls._qubit_reference(reference) for reference in cls._split_arguments(barrier.group(1)))
            )
        gate = re.fullmatch(r"([A-Za-z_]\w*)\s*(?:\((.*?)\))?\s+(.+)", stripped)
        if gate:
            name = gate.group(1).lower()
            if name not in cls._ONE_QUBIT | cls._ROTATIONS | cls._TWO_QUBIT | {"cr"}:
                raise ValueError(f"Unsupported OpenQASM 3 operation: {name}")
            qubit_references = cls._split_arguments(gate.group(3))
            indices = tuple(cls._qubit_reference(reference) for reference in qubit_references)
            expected = 2 if name in cls._TWO_QUBIT | {"cr"} else 1
            if len(indices) != expected:
                raise ValueError(f"Gate {name} requires {expected} qubit operands")
            parameters = () if gate.group(2) is None else cls._split_arguments(gate.group(2))
            if name in cls._ROTATIONS and len(parameters) != 1:
                raise ValueError(f"Rotation {name} requires one angle")
            if name not in cls._ROTATIONS and parameters:
                raise ValueError(f"Gate {name} does not accept scalar parameters in the active profile")
            return GateStatement(name, indices, parameters)
        raise ValueError(f"Unsupported OpenQASM 3 statement: {statement}")

    @classmethod
    def _parse_sequence(
        cls,
        source: str,
        *,
        qubit_count: int,
        classical_count: int,
    ) -> tuple[QASMStatement, ...]:
        scanner = _QASMScanner(source)
        statements: list[QASMStatement] = []
        while not scanner.finished:
            if scanner.starts_keyword("if"):
                scanner.consume_keyword("if")
                condition = scanner.read_parenthesized()
                then_source = scanner.read_braced()
                scanner._skip_space()
                else_source = ""
                if scanner.starts_keyword("else"):
                    scanner.consume_keyword("else")
                    else_source = scanner.read_braced()
                statements.append(
                    IfStatement(
                        condition,
                        cls._parse_sequence(
                            then_source, qubit_count=qubit_count, classical_count=classical_count
                        ),
                        cls._parse_sequence(
                            else_source, qubit_count=qubit_count, classical_count=classical_count
                        ),
                    )
                )
                continue
            if scanner.starts_keyword("for"):
                scanner.consume_keyword("for")
                scanner._skip_space()
                header_start = scanner.position
                while scanner.position < len(scanner.source) and scanner.source[scanner.position] != "{":
                    scanner.position += 1
                header = scanner.source[header_start:scanner.position].strip()
                body_source = scanner.read_braced()
                match = re.fullmatch(
                    r"(?:int(?:\s*\[\s*\d+\s*\])?\s+)?([A-Za-z_]\w*)\s+in\s*\[\s*(.+?)\s*\]",
                    header,
                    flags=re.IGNORECASE,
                )
                if not match:
                    raise ValueError(f"Unsupported for-loop header: {header}")
                fields = cls._split_arguments(match.group(2).replace(":", ","))
                if len(fields) == 2:
                    start, stop = fields
                    step = "1"
                elif len(fields) == 3:
                    start, step, stop = fields
                else:
                    raise ValueError("OpenQASM range requires [start:stop] or [start:step:stop]")
                statements.append(
                    ForStatement(
                        match.group(1),
                        start,
                        stop,
                        step,
                        cls._parse_sequence(
                            body_source, qubit_count=qubit_count, classical_count=classical_count
                        ),
                    )
                )
                continue
            if scanner.starts_keyword("while"):
                scanner.consume_keyword("while")
                condition = scanner.read_parenthesized()
                body_source = scanner.read_braced()
                statements.append(
                    WhileStatement(
                        condition,
                        cls._parse_sequence(
                            body_source, qubit_count=qubit_count, classical_count=classical_count
                        ),
                    )
                )
                continue
            ordinary = scanner.read_until(";")
            parsed = cls._ordinary_statement(
                ordinary, qubit_count=qubit_count, classical_count=classical_count
            )
            if parsed is not None:
                statements.append(parsed)
        return tuple(statements)

    @staticmethod
    def _extract_named_blocks(source: str, keyword: str) -> tuple[tuple[str, str], ...]:
        values: list[tuple[str, str]] = []
        pattern = re.compile(rf"\b{keyword}\b", flags=re.IGNORECASE)
        position = 0
        while True:
            match = pattern.search(source, position)
            if match is None:
                break
            brace = source.find("{", match.end())
            if brace < 0:
                raise ValueError(f"{keyword} declaration is missing a body")
            scanner = _QASMScanner(source)
            end = scanner._matching(brace, "{", "}")
            header = source[match.start():brace].strip()
            values.append((header, source[brace + 1 : end]))
            position = end + 1
        return tuple(values)

    @classmethod
    def _parse_pulse(cls, source: str) -> OpenPulseProgram | None:
        if not re.search(r"defcalgrammar\s+['\"]openpulse['\"]", source, flags=re.IGNORECASE):
            return None
        frames: dict[str, PulseFrame] = {}
        waveforms: dict[str, PulseWaveform] = {}
        calibrations: list[PulseCalibration] = []
        cal_blocks = cls._extract_named_blocks(source, "cal")
        # `_extract_named_blocks` also finds the `cal` suffix inside `defcal`; retain only exact cal.
        cal_blocks = tuple(item for item in cal_blocks if re.fullmatch(r"cal", item[0], flags=re.IGNORECASE))
        for _, body in cal_blocks:
            scanner = _QASMScanner(body)
            while not scanner.finished:
                statement = scanner.read_until(";")
                lowered = statement.lower()
                if lowered.startswith("extern port "):
                    continue
                frame = re.fullmatch(
                    r"frame\s+(\w+)\s*=\s*newframe\s*\(\s*(\w+)\s*,\s*(.+?)\s*,\s*(.+?)\s*\)",
                    statement,
                    flags=re.IGNORECASE,
                )
                if frame:
                    frames[frame.group(1)] = PulseFrame(
                        frame.group(1),
                        frame.group(2),
                        float(_SafeExpression.evaluate(frame.group(3))),
                        float(_SafeExpression.evaluate(frame.group(4))),
                    )
                    continue
                waveform = re.fullmatch(
                    r"waveform\s+(\w+)\s*=\s*(gaussian|drag|constant)\s*\((.*?)\)",
                    statement,
                    flags=re.IGNORECASE,
                )
                if waveform:
                    arguments = cls._split_arguments(waveform.group(3))
                    kind = waveform.group(2).lower()
                    if kind == "constant" and len(arguments) != 2:
                        raise ValueError("constant waveform requires amplitude and duration")
                    if kind == "gaussian" and len(arguments) != 3:
                        raise ValueError("gaussian waveform requires amplitude, duration and sigma")
                    if kind == "drag" and len(arguments) != 4:
                        raise ValueError("drag waveform requires amplitude, duration, sigma and beta")
                    waveforms[waveform.group(1)] = PulseWaveform(
                        waveform.group(1),
                        kind,
                        float(_SafeExpression.evaluate(arguments[0])),
                        cls._duration_ns(arguments[1]),
                        None if kind == "constant" else cls._duration_ns(arguments[2]),
                        0.0 if kind != "drag" else float(_SafeExpression.evaluate(arguments[3])),
                    )
                    continue
                raise ValueError(f"Unsupported OpenPulse cal statement: {statement}")
        for header, body in cls._extract_named_blocks(source, "defcal"):
            match = re.fullmatch(r"defcal\s+(\w+)(?:\s*\([^)]*\))?\s+(.+)", header, flags=re.IGNORECASE)
            if not match:
                raise ValueError(f"Unsupported defcal header: {header}")
            gate_name = match.group(1).lower()
            physical = tuple(int(value) for value in re.findall(r"\$(\d+)", match.group(2)))
            if not physical:
                raise ValueError("defcal must bind at least one physical qubit")
            operations: list[PulseOperation] = []
            scanner = _QASMScanner(body)
            while not scanner.finished:
                statement = scanner.read_until(";")
                play = re.fullmatch(r"play\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)", statement, flags=re.IGNORECASE)
                if play:
                    operations.append(PulseOperation("play", play.group(1), play.group(2)))
                    continue
                delay = re.fullmatch(r"delay\s*\[\s*(.+?)\s*\]\s+(\w+)", statement, flags=re.IGNORECASE)
                if delay:
                    operations.append(PulseOperation("delay", delay.group(2), value=cls._duration_ns(delay.group(1))))
                    continue
                phase = re.fullmatch(r"(shift_phase|set_phase)\s*\(\s*(\w+)\s*,\s*(.+?)\s*\)", statement, flags=re.IGNORECASE)
                if phase:
                    operations.append(PulseOperation(phase.group(1).lower(), phase.group(2), value=float(_SafeExpression.evaluate(phase.group(3)))))
                    continue
                frequency = re.fullmatch(r"set_frequency\s*\(\s*(\w+)\s*,\s*(.+?)\s*\)", statement, flags=re.IGNORECASE)
                if frequency:
                    operations.append(PulseOperation("set_frequency", frequency.group(1), value=float(_SafeExpression.evaluate(frequency.group(2)))))
                    continue
                raise ValueError(f"Unsupported OpenPulse defcal statement: {statement}")
            calibrations.append(PulseCalibration(gate_name, physical, tuple(operations)))
        for calibration in calibrations:
            for operation in calibration.operations:
                if operation.frame not in frames:
                    raise ValueError(f"Calibration references unknown frame {operation.frame}")
                if operation.waveform is not None and operation.waveform not in waveforms:
                    raise ValueError(f"Calibration references unknown waveform {operation.waveform}")
        return OpenPulseProgram(tuple(frames.values()), tuple(waveforms.values()), tuple(calibrations))

    @classmethod
    def parse(cls, source: str) -> QuantumCircuitProgram:
        text = re.sub(r"/\*.*?\*/", "", str(source), flags=re.DOTALL)
        text = re.sub(r"//.*?$", "", text, flags=re.MULTILINE)
        version_match = re.search(r"OPENQASM\s+([0-9.]+)\s*;", text, flags=re.IGNORECASE)
        if not version_match or version_match.group(1) not in {"2.0", "3", "3.0"}:
            raise ValueError("The active parser requires OPENQASM 3.0 or the normalized 2.0 compatibility syntax")
        version = "3.0" if version_match.group(1) in {"3", "3.0"} else "2.0-compat"
        q3 = re.search(r"qubit\s*\[\s*(\d+)\s*\]\s+q\s*;", text, flags=re.IGNORECASE)
        q2 = re.search(r"qreg\s+q\s*\[\s*(\d+)\s*\]\s*;", text, flags=re.IGNORECASE)
        qmatch = q3 or q2
        if qmatch is None or int(qmatch.group(1)) < 1:
            raise ValueError("Exactly one positive quantum register named q is required")
        qubit_count = int(qmatch.group(1))
        c3 = re.search(r"bit\s*\[\s*(\d+)\s*\]\s+c\s*;", text, flags=re.IGNORECASE)
        c2 = re.search(r"creg\s+c\s*\[\s*(\d+)\s*\]\s*;", text, flags=re.IGNORECASE)
        classical_count = int((c3 or c2).group(1)) if c3 or c2 else 0
        pulse = cls._parse_pulse(text)

        # Remove calibration blocks before parsing executable statements.
        executable = text
        blocks: list[tuple[int, int]] = []
        for keyword in ("cal", "defcal"):
            pattern = re.compile(rf"\b{keyword}\b", flags=re.IGNORECASE)
            position = 0
            while True:
                match = pattern.search(executable, position)
                if match is None:
                    break
                if keyword == "cal" and executable[max(0, match.start() - 3):match.start()].lower() == "def":
                    position = match.end()
                    continue
                brace = executable.find("{", match.end())
                if brace < 0:
                    break
                scanner = _QASMScanner(executable)
                end = scanner._matching(brace, "{", "}")
                blocks.append((match.start(), end + 1))
                position = end + 1
        for start, end in sorted(blocks, reverse=True):
            executable = executable[:start] + " " * (end - start) + executable[end:]
        statements = cls._parse_sequence(
            executable, qubit_count=qubit_count, classical_count=classical_count
        )
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
        return QuantumCircuitProgram(version, qubit_count, classical_count, statements, pulse, digest)


# ---------------------------------------------------------------------------
# Dynamic circuit execution.
# ---------------------------------------------------------------------------


class StatevectorKernel(Protocol):
    qubit_count: int
    backend_name: str

    def apply_instruction(self, instruction: QuantumInstruction) -> None: ...

    def to_numpy(self) -> np.ndarray: ...

    def set_numpy(self, state: np.ndarray) -> None: ...


@dataclass(frozen=True, slots=True)
class DynamicExecutionResult:
    statevector: np.ndarray
    classical_bits: tuple[int, ...]
    qubit_clock_ns: tuple[float, ...]
    executed_gate_count: int
    measurement_count: int
    loop_iterations: int
    branch_count: int


class OpenQASM3Executor:
    def __init__(
        self,
        kernel: StatevectorKernel,
        *,
        random_seed: int,
        maximum_while_iterations: int = 1024,
        gate_durations_ns: Mapping[str, float] | None = None,
    ):
        self.kernel = kernel
        self.rng = np.random.default_rng(int(random_seed))
        self.maximum_while_iterations = int(maximum_while_iterations)
        if self.maximum_while_iterations < 1:
            raise ValueError("maximum_while_iterations must be positive")
        self.gate_durations = {
            "h": 20.0,
            "x": 20.0,
            "y": 20.0,
            "z": 0.0,
            "s": 0.0,
            "sdg": 0.0,
            "t": 0.0,
            "tdg": 0.0,
            "rx": 20.0,
            "ry": 20.0,
            "rz": 0.0,
            "cx": 160.0,
            "cz": 160.0,
            "swap": 480.0,
            "cr": 160.0,
        }
        if gate_durations_ns:
            self.gate_durations.update({str(key): float(value) for key, value in gate_durations_ns.items()})

    @staticmethod
    def _resolve_index(expression: str, variables: Mapping[str, Any], upper: int) -> int:
        value = int(_SafeExpression.evaluate(expression, variables))
        if value < 0 or value >= upper:
            raise ValueError("Resolved register index is outside the declared register")
        return value

    def _measure(self, qubit: int) -> int:
        state = self.kernel.to_numpy()
        n = self.kernel.qubit_count
        tensor = state.reshape((2,) * n)
        probability_one = float(np.sum(np.abs(np.take(tensor, 1, axis=qubit)) ** 2))
        probability_one = float(np.clip(probability_one, 0.0, 1.0))
        outcome = int(self.rng.random() < probability_one)
        slicer = [slice(None)] * n
        slicer[qubit] = 1 - outcome
        tensor[tuple(slicer)] = 0.0
        norm = float(np.linalg.norm(tensor.reshape(-1)))
        if norm <= 0.0 or not np.isfinite(norm):
            raise RuntimeError("Mid-circuit measurement produced a non-normalizable state")
        self.kernel.set_numpy(tensor.reshape(-1) / norm)
        return outcome

    def execute(self, program: QuantumCircuitProgram) -> DynamicExecutionResult:
        if program.qubit_count != self.kernel.qubit_count:
            raise ValueError("Program and execution kernel qubit counts differ")
        classical = [0] * program.classical_bit_count
        clocks = [0.0] * program.qubit_count
        counters = {"gates": 0, "measurements": 0, "loops": 0, "branches": 0}

        def run(statements: Iterable[QASMStatement], variables: dict[str, Any]) -> None:
            for statement in statements:
                if isinstance(statement, GateStatement):
                    qubits = tuple(
                        self._resolve_index(value, variables, program.qubit_count)
                        for value in statement.qubit_indices
                    )
                    parameters = tuple(
                        float(_SafeExpression.evaluate(value, variables, classical))
                        for value in statement.parameters
                    )
                    instruction = QuantumInstruction(
                        statement.name,
                        qubits,
                        parameters[0] if parameters else None,
                    )
                    self.kernel.apply_instruction(instruction)
                    duration = self.gate_durations.get(statement.name, 0.0)
                    start = max(clocks[index] for index in qubits)
                    for index in qubits:
                        clocks[index] = start + duration
                    counters["gates"] += 1
                elif isinstance(statement, MeasureStatement):
                    qubit = self._resolve_index(statement.qubit_index, variables, program.qubit_count)
                    bit = self._resolve_index(statement.classical_index, variables, program.classical_bit_count)
                    classical[bit] = self._measure(qubit)
                    counters["measurements"] += 1
                elif isinstance(statement, ResetStatement):
                    qubit = self._resolve_index(statement.qubit_index, variables, program.qubit_count)
                    if self._measure(qubit) == 1:
                        self.kernel.apply_instruction(QuantumInstruction("x", (qubit,)))
                        counters["gates"] += 1
                    counters["measurements"] += 1
                elif isinstance(statement, DelayStatement):
                    qubits = tuple(
                        self._resolve_index(value, variables, program.qubit_count)
                        for value in statement.qubit_indices
                    )
                    for qubit in qubits:
                        clocks[qubit] += statement.duration_ns
                elif isinstance(statement, BarrierStatement):
                    qubits = tuple(
                        self._resolve_index(value, variables, program.qubit_count)
                        for value in statement.qubit_indices
                    )
                    synchronized = max(clocks[index] for index in qubits)
                    for index in qubits:
                        clocks[index] = synchronized
                elif isinstance(statement, IfStatement):
                    condition = bool(_SafeExpression.evaluate(statement.condition, variables, classical))
                    counters["branches"] += 1
                    run(statement.then_body if condition else statement.else_body, dict(variables))
                elif isinstance(statement, ForStatement):
                    start = int(_SafeExpression.evaluate(statement.start, variables, classical))
                    stop = int(_SafeExpression.evaluate(statement.stop, variables, classical))
                    step = int(_SafeExpression.evaluate(statement.step, variables, classical))
                    if step == 0:
                        raise ValueError("OpenQASM for-loop step cannot be zero")
                    terminal = stop + (1 if step > 0 else -1)
                    for value in range(start, terminal, step):
                        nested = dict(variables)
                        nested[statement.variable] = value
                        counters["loops"] += 1
                        run(statement.body, nested)
                elif isinstance(statement, WhileStatement):
                    iterations = 0
                    while bool(_SafeExpression.evaluate(statement.condition, variables, classical)):
                        if iterations >= self.maximum_while_iterations:
                            raise RuntimeError("BLOCKED_DYNAMIC_CONTROL:WHILE_LOOP_LIMIT_EXCEEDED")
                        counters["loops"] += 1
                        iterations += 1
                        run(statement.body, dict(variables))
                else:  # pragma: no cover - exhaustive union guard
                    raise TypeError(f"Unsupported AST statement: {type(statement).__name__}")

        run(program.statements, {})
        return DynamicExecutionResult(
            statevector=self.kernel.to_numpy(),
            classical_bits=tuple(classical),
            qubit_clock_ns=tuple(float(value) for value in clocks),
            executed_gate_count=counters["gates"],
            measurement_count=counters["measurements"],
            loop_iterations=counters["loops"],
            branch_count=counters["branches"],
        )


# ---------------------------------------------------------------------------
# OpenPulse qutrit-level physical control.
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class PulseControlCertificate:
    calibration_count: int
    frame_count: int
    waveform_count: int
    single_transmon_process_fidelity: float
    single_transmon_leakage: float
    single_transmon_step_doubling_gap: float
    cross_resonance_process_fidelity: float
    cross_resonance_leakage: float
    cross_resonance_entangling_phase: float
    cross_resonance_step_doubling_gap: float
    total_scheduled_duration_ns: float

    @property
    def passed(self) -> bool:
        return (
            self.calibration_count >= 2
            and self.frame_count >= 2
            and self.waveform_count >= 2
            and self.single_transmon_process_fidelity > 0.995
            and self.single_transmon_leakage < 5e-3
            and self.single_transmon_step_doubling_gap < 1e-4
            and self.cross_resonance_process_fidelity > 0.99
            and self.cross_resonance_leakage < 1e-3
            and abs(self.cross_resonance_entangling_phase) > 0.2
            and self.cross_resonance_step_doubling_gap < 1e-6
            and self.total_scheduled_duration_ns > 0.0
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"passed": self.passed}


class TransmonPulseEngine:
    def __init__(self, anharmonicity_rad_per_ns: float = -0.32):
        self.anharmonicity = float(anharmonicity_rad_per_ns)
        self.a = np.zeros((3, 3), dtype=complex)
        self.a[0, 1] = 1.0
        self.a[1, 2] = np.sqrt(2.0)
        self.n = self.a.conj().T @ self.a
        self.identity = np.eye(3, dtype=complex)

    @staticmethod
    def _phase_align(reference: np.ndarray, candidate: np.ndarray) -> np.ndarray:
        overlap = np.vdot(reference.reshape(-1), candidate.reshape(-1))
        return candidate if abs(overlap) == 0.0 else candidate * np.exp(-1j * np.angle(overlap))

    @staticmethod
    def _process_fidelity(target: np.ndarray, actual: np.ndarray) -> float:
        dimension = target.shape[0]
        return float(abs(np.trace(target.conj().T @ actual)) ** 2 / (dimension * dimension))

    def _single_hamiltonian(self, drive: complex) -> np.ndarray:
        drift = 0.5 * self.anharmonicity * (self.n @ (self.n - self.identity))
        return drift + 0.5 * (drive * self.a.conj().T + np.conjugate(drive) * self.a)

    def _propagate_single(self, samples: np.ndarray, duration_ns: float) -> np.ndarray:
        dt = duration_ns / samples.size
        unitary = np.eye(3, dtype=complex)
        for sample in samples:
            unitary = expm(-1j * dt * self._single_hamiltonian(complex(sample))) @ unitary
        return unitary

    def single_transmon_control(
        self,
        waveform: PulseWaveform,
        target: np.ndarray,
        samples: int = 1600,
    ) -> tuple[float, float, float]:
        coarse_samples = waveform.samples(samples)
        fine_samples = waveform.samples(2 * samples)
        coarse = self._propagate_single(coarse_samples, waveform.duration_ns)
        fine = self._propagate_single(fine_samples, waveform.duration_ns)
        projected = fine[:2, :2]
        aligned = self._phase_align(target, projected)
        fidelity = self._process_fidelity(target, aligned)
        leakage = float(
            max(
                1.0 - np.sum(np.abs(fine[:2, 0]) ** 2),
                1.0 - np.sum(np.abs(fine[:2, 1]) ** 2),
            )
        )
        step_gap = float(np.linalg.norm(self._phase_align(fine, coarse) - fine, ord=2))
        return fidelity, max(0.0, leakage), step_gap

    def _cross_resonance_hamiltonian(self, drive: float, leakage_coupling: float) -> np.ndarray:
        z01 = np.diag([1.0, -1.0, 0.0]).astype(complex)
        x01 = np.zeros((3, 3), dtype=complex)
        x01[0, 1] = x01[1, 0] = 1.0
        drift_single = 0.5 * self.anharmonicity * (self.n @ (self.n - self.identity))
        drift = np.kron(drift_single, self.identity) + np.kron(self.identity, drift_single)
        desired = 0.5 * drive * np.kron(z01, x01)
        leakage = leakage_coupling * np.kron(self.a + self.a.conj().T, self.a + self.a.conj().T)
        return drift + desired + leakage

    def _propagate_cross(self, drive: float, duration_ns: float, leakage_coupling: float, steps: int) -> np.ndarray:
        dt = duration_ns / steps
        hamiltonian = self._cross_resonance_hamiltonian(drive, leakage_coupling)
        step = expm(-1j * dt * hamiltonian)
        return np.linalg.matrix_power(step, steps)

    def cross_resonance_control(
        self,
        *,
        drive: float = 0.012,
        duration_ns: float = 65.44984694978736,
        leakage_coupling: float = 2e-5,
        steps: int = 256,
    ) -> tuple[float, float, float, float]:
        coarse = self._propagate_cross(drive, duration_ns, leakage_coupling, steps)
        fine = self._propagate_cross(drive, duration_ns, leakage_coupling, 2 * steps)
        computational = (0, 1, 3, 4)
        projected = fine[np.ix_(computational, computational)]
        theta = drive * duration_ns
        z = np.diag([1.0, -1.0])
        x = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=complex)
        target = expm(-0.5j * theta * np.kron(z, x))
        aligned = self._phase_align(target, projected)
        fidelity = self._process_fidelity(target, aligned)
        leakage = 0.0
        for column in computational:
            leakage = max(
                leakage,
                1.0 - float(np.sum(np.abs(fine[list(computational), column]) ** 2)),
            )
        step_gap = float(np.linalg.norm(self._phase_align(fine, coarse) - fine, ord=2))
        return fidelity, max(0.0, leakage), theta, step_gap

    def certify(self, pulse_program: OpenPulseProgram) -> PulseControlCertificate:
        waveform_map = pulse_program.waveform_map
        calibrations = {item.gate_name: item for item in pulse_program.calibrations}
        if "x" not in calibrations or "cr" not in calibrations:
            raise ValueError("Pulse qualification requires x and cr calibrations")
        x_waveform_name = next(
            operation.waveform
            for operation in calibrations["x"].operations
            if operation.kind == "play" and operation.waveform is not None
        )
        x_waveform = waveform_map[x_waveform_name]
        target_x = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=complex)
        single_fidelity, single_leakage, single_gap = self.single_transmon_control(x_waveform, target_x)
        cr_waveform_name = next(
            operation.waveform
            for operation in calibrations["cr"].operations
            if operation.kind == "play" and operation.waveform is not None
        )
        cr_waveform = waveform_map[cr_waveform_name]
        cross_fidelity, cross_leakage, cross_phase, cross_gap = self.cross_resonance_control(
            drive=float(cr_waveform.amplitude),
            duration_ns=float(cr_waveform.duration_ns),
        )
        total_duration = 0.0
        for calibration in pulse_program.calibrations:
            for operation in calibration.operations:
                if operation.kind == "play" and operation.waveform is not None:
                    total_duration += waveform_map[operation.waveform].duration_ns
                elif operation.kind == "delay" and operation.value is not None:
                    total_duration += operation.value
        return PulseControlCertificate(
            calibration_count=len(pulse_program.calibrations),
            frame_count=len(pulse_program.frames),
            waveform_count=len(pulse_program.waveforms),
            single_transmon_process_fidelity=single_fidelity,
            single_transmon_leakage=single_leakage,
            single_transmon_step_doubling_gap=single_gap,
            cross_resonance_process_fidelity=cross_fidelity,
            cross_resonance_leakage=cross_leakage,
            cross_resonance_entangling_phase=cross_phase,
            cross_resonance_step_doubling_gap=cross_gap,
            total_scheduled_duration_ns=total_duration,
        )
