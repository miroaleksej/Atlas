from __future__ import annotations

from dataclasses import asdict, dataclass
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
from typing import Any, Iterable

import numpy as np
from scipy.linalg import expm

from .eprl_adapter import SL2CfoamRuntime
from .accelerators import execute_numpy
from .control import OpenQASM3Parser
from .quantum import FiniteQuantumDynamics


@dataclass(frozen=True, slots=True)
class DifferentialCaseResult:
    tool: str
    fixture: str
    status: str
    metric: str | None
    value: float | None
    tolerance: float | None
    tool_version: str | None
    reason: str
    evidence: dict[str, Any]

    @property
    def passed(self) -> bool:
        return self.status == "PASS"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"passed": self.passed}


@dataclass(frozen=True, slots=True)
class DifferentialBenchmarkCertificate:
    cases: tuple[DifferentialCaseResult, ...]

    @property
    def failed(self) -> tuple[str, ...]:
        return tuple(case.tool for case in self.cases if case.status.startswith("FAIL"))

    @property
    def blocked(self) -> tuple[str, ...]:
        return tuple(case.tool for case in self.cases if case.status.startswith("BLOCKED"))

    @property
    def passed_tools(self) -> tuple[str, ...]:
        return tuple(case.tool for case in self.cases if case.passed)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "qpdtr-external-differential-benchmark-current",
            "cases": [case.to_dict() for case in self.cases],
            "summary": {
                "passed": list(self.passed_tools),
                "blocked": list(self.blocked),
                "failed": list(self.failed),
                "fully_qualified": not self.blocked and not self.failed,
            },
        }


def _blocked(tool: str, fixture: str, reason: str) -> DifferentialCaseResult:
    return DifferentialCaseResult(
        tool=tool,
        fixture=fixture,
        status="BLOCKED_EXTERNAL_TOOL_UNAVAILABLE",
        metric=None,
        value=None,
        tolerance=None,
        tool_version=None,
        reason=reason,
        evidence={},
    )


def _align_global_phase(reference: np.ndarray, candidate: np.ndarray) -> np.ndarray:
    overlap = np.vdot(reference, candidate)
    if abs(overlap) == 0.0:
        return candidate
    return candidate * np.exp(-1j * np.angle(overlap))


def _qiskit_aer_case() -> DifferentialCaseResult:
    fixture = "three_qubit_unitary_statevector_v1"
    if importlib.util.find_spec("qiskit") is None or importlib.util.find_spec("qiskit_aer") is None:
        return _blocked("Qiskit Aer", fixture, "qiskit and/or qiskit_aer is not installed")
    try:
        import qiskit
        import qiskit_aer
        from qiskit import QuantumCircuit
        from qiskit_aer import AerSimulator

        source = """
OPENQASM 3.0;
qubit[3] q;
h q[0];
rx(pi/3) q[1];
cx q[0],q[2];
cz q[1],q[2];
ry(-pi/5) q[0];
t q[2];
"""
        internal = execute_numpy(OpenQASM3Parser.parse(source))
        circuit = QuantumCircuit(3)
        circuit.h(0)
        circuit.rx(np.pi / 3.0, 1)
        circuit.cx(0, 2)
        circuit.cz(1, 2)
        circuit.ry(-np.pi / 5.0, 0)
        circuit.t(2)
        circuit.save_statevector()
        external = np.asarray(
            AerSimulator(method="statevector").run(circuit).result().data(0)["statevector"],
            dtype=complex,
        )
        # Qiskit stores basis amplitudes in little-endian qubit order; Atlas axis 0 is q[0].
        external = external.reshape((2, 2, 2)).transpose(2, 1, 0).reshape(-1)
        external = _align_global_phase(internal, external)
        fidelity_loss = float(max(0.0, 1.0 - abs(np.vdot(internal, external)) ** 2))
        state_gap = float(np.linalg.norm(internal - external))
        tolerance = 1e-12
        status = "PASS" if fidelity_loss <= tolerance and state_gap <= 2e-12 else "FAIL_DIFFERENTIAL_MISMATCH"
        return DifferentialCaseResult(
            tool="Qiskit Aer",
            fixture=fixture,
            status=status,
            metric="one_minus_state_fidelity",
            value=fidelity_loss,
            tolerance=tolerance,
            tool_version=f"qiskit-{qiskit.__version__}; qiskit-aer-{qiskit_aer.__version__}",
            reason="same gate sequence and zero-state input",
            evidence={"phase_aligned_l2_gap": state_gap, "qubits": 3},
        )
    except Exception as exc:  # optional external package; failure must be explicit
        return DifferentialCaseResult(
            tool="Qiskit Aer",
            fixture=fixture,
            status="FAIL_EXTERNAL_BENCHMARK_EXECUTION",
            metric=None,
            value=None,
            tolerance=None,
            tool_version=None,
            reason=f"{type(exc).__name__}: {exc}",
            evidence={},
        )


def _qutip_case() -> DifferentialCaseResult:
    fixture = "driven_damped_two_level_gksl_v1"
    if importlib.util.find_spec("qutip") is None:
        return _blocked("QuTiP", fixture, "qutip is not installed")
    try:
        import qutip

        x = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=complex)
        z = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=complex)
        lowering = np.array([[0.0, 1.0], [0.0, 0.0]], dtype=complex)
        detuning = 0.37
        rabi = 1.13
        decay = 0.29
        elapsed = 0.73
        hamiltonian = 0.5 * detuning * z + 0.5 * rabi * x
        collapse = np.sqrt(decay) * lowering
        initial = np.array([[0.0, 0.0], [0.0, 1.0]], dtype=complex)
        internal = FiniteQuantumDynamics(hamiltonian, (collapse,)).evolve_density(initial, elapsed)
        result = qutip.mesolve(
            qutip.Qobj(hamiltonian),
            qutip.Qobj(initial),
            [0.0, elapsed],
            [qutip.Qobj(collapse)],
            options={"store_states": True, "atol": 1e-12, "rtol": 1e-12, "nsteps": 10000},
        )
        external = np.asarray(result.states[-1].full(), dtype=complex)
        difference = 0.5 * float(np.linalg.svd(internal - external, compute_uv=False).sum())
        tolerance = 1e-10
        status = "PASS" if difference <= tolerance else "FAIL_DIFFERENTIAL_MISMATCH"
        return DifferentialCaseResult(
            tool="QuTiP",
            fixture=fixture,
            status=status,
            metric="trace_distance",
            value=difference,
            tolerance=tolerance,
            tool_version=f"qutip-{qutip.__version__}",
            reason="same Hamiltonian, collapse operator, initial density and elapsed model time",
            evidence={
                "internal_trace_gap": abs(float(np.trace(internal).real) - 1.0),
                "external_trace_gap": abs(float(np.trace(external).real) - 1.0),
            },
        )
    except Exception as exc:
        return DifferentialCaseResult(
            tool="QuTiP",
            fixture=fixture,
            status="FAIL_EXTERNAL_BENCHMARK_EXECUTION",
            metric=None,
            value=None,
            tolerance=None,
            tool_version=None,
            reason=f"{type(exc).__name__}: {exc}",
            evidence={},
        )


def _apply_two_site_gate(state: np.ndarray, gate: np.ndarray, left: int, right: int, qubits: int) -> np.ndarray:
    tensor = np.asarray(state, dtype=complex).reshape((2,) * qubits)
    axes = (left, right) + tuple(index for index in range(qubits) if index not in (left, right))
    inverse = np.argsort(axes)
    moved = np.transpose(tensor, axes).reshape(4, -1)
    moved = gate @ moved
    return np.transpose(moved.reshape((2, 2) + (2,) * (qubits - 2)), inverse).reshape(-1)


def _itensor_internal_energy() -> float:
    n = 4
    tau = 0.05
    x = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=complex) / 2.0
    y = np.array([[0.0, -1j], [1j, 0.0]], dtype=complex) / 2.0
    z = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=complex) / 2.0
    local = np.kron(x, x) + np.kron(y, y) + np.kron(z, z)
    gate = expm(-1j * tau * local / 2.0)
    state = np.zeros(2**n, dtype=complex)
    # Tensor-axis convention: axis 0 is site 1. Up=0, Dn=1.
    state[int("0101", 2)] = 1.0
    order = list(range(n - 1)) + list(reversed(range(n - 1)))
    for left in order:
        state = _apply_two_site_gate(state, gate, left, left + 1, n)
    state /= np.linalg.norm(state)
    energy = 0.0
    for left in range(n - 1):
        applied = _apply_two_site_gate(state, local, left, left + 1, n)
        energy += float(np.vdot(state, applied).real)
    return energy


def _itensor_case() -> DifferentialCaseResult:
    fixture = "four_site_heisenberg_tebd_energy_v1"
    julia = shutil.which("julia")
    if julia is None:
        return _blocked("ITensorMPS.jl", fixture, "Julia executable is not installed")
    script = r'''
using ITensors
using ITensorMPS
N = 4
tau = 0.05
s = siteinds("S=1/2", N)
gates = ITensor[]
for j in 1:(N-1)
  h = op("Sz",s[j])*op("Sz",s[j+1]) + 0.5*op("S+",s[j])*op("S-",s[j+1]) + 0.5*op("S-",s[j])*op("S+",s[j+1])
  push!(gates, exp(-1im*tau/2*h))
end
append!(gates, reverse(gates))
psi = MPS(s, ["Up","Dn","Up","Dn"])
psi = apply(gates, psi; cutoff=1e-14)
normalize!(psi)
os = OpSum()
for j in 1:(N-1)
  os += 1.0,"Sz",j,"Sz",j+1
  os += 0.5,"S+",j,"S-",j+1
  os += 0.5,"S-",j,"S+",j+1
end
H = MPO(os,s)
energy = real(inner(psi',H,psi))
println("PHIQG_ENERGY=" * repr(energy))
'''
    try:
        with tempfile.TemporaryDirectory(prefix="phiqg-itensor-") as directory:
            path = Path(directory) / "benchmark.jl"
            path.write_text(script, encoding="utf-8")
            process = subprocess.run(
                [julia, "--startup-file=no", str(path)],
                capture_output=True,
                text=True,
                timeout=180,
                check=False,
            )
        if process.returncode != 0:
            return _blocked(
                "ITensorMPS.jl",
                fixture,
                "Julia is present but ITensors/ITensorMPS benchmark could not run: " + process.stderr.strip()[-500:],
            )
        marker = next((line for line in process.stdout.splitlines() if line.startswith("PHIQG_ENERGY=")), None)
        if marker is None:
            raise RuntimeError("ITensor benchmark did not emit PHIQG_ENERGY")
        external = float(marker.split("=", 1)[1])
        internal = _itensor_internal_energy()
        gap = abs(internal - external)
        tolerance = 1e-8
        status = "PASS" if gap <= tolerance else "FAIL_DIFFERENTIAL_MISMATCH"
        return DifferentialCaseResult(
            tool="ITensorMPS.jl",
            fixture=fixture,
            status=status,
            metric="absolute_energy_gap",
            value=float(gap),
            tolerance=tolerance,
            tool_version="Julia ITensors/ITensorMPS runtime",
            reason="same four-site Heisenberg product state, second-order TEBD gate sequence and model time",
            evidence={"internal_energy": internal, "external_energy": external},
        )
    except Exception as exc:
        return DifferentialCaseResult(
            tool="ITensorMPS.jl",
            fixture=fixture,
            status="FAIL_EXTERNAL_BENCHMARK_EXECUTION",
            metric=None,
            value=None,
            tolerance=None,
            tool_version=None,
            reason=f"{type(exc).__name__}: {exc}",
            evidence={},
        )


def _stim_pymatching_case() -> DifferentialCaseResult:
    fixture = "seven_bit_repetition_detector_decoding_v1"
    if importlib.util.find_spec("stim") is None or importlib.util.find_spec("pymatching") is None:
        return _blocked("Stim + PyMatching", fixture, "stim and/or pymatching is not installed")
    try:
        import stim
        import pymatching

        distance = 7
        probability = 0.035
        shots = 4096
        circuit = stim.Circuit()
        circuit.append("R", range(distance))
        circuit.append("X_ERROR", range(distance), probability)
        circuit.append("M", range(distance))
        for index in range(distance - 1):
            circuit.append("DETECTOR", [stim.target_rec(-distance + index), stim.target_rec(-distance + index + 1)])
        circuit.append("OBSERVABLE_INCLUDE", [stim.target_rec(-distance)], 0)
        detector_model = circuit.detector_error_model(decompose_errors=True)
        matching = pymatching.Matching.from_detector_error_model(detector_model)
        detector_samples, observable_samples = circuit.compile_detector_sampler(seed=20260729).sample(
            shots=shots, separate_observables=True
        )
        external_predictions = np.asarray(matching.decode_batch(detector_samples), dtype=np.uint8).reshape(shots, -1)

        # Independent exhaustive minimum-weight decoder for the same repetition-code syndrome.
        candidates: dict[tuple[int, ...], tuple[int, ...]] = {}
        for mask in range(1 << distance):
            bits = tuple((mask >> (distance - 1 - index)) & 1 for index in range(distance))
            syndrome = tuple(bits[index] ^ bits[index + 1] for index in range(distance - 1))
            current = candidates.get(syndrome)
            if current is None or sum(bits) < sum(current):
                candidates[syndrome] = bits
        internal_predictions = np.zeros((shots, 1), dtype=np.uint8)
        for row, syndrome_array in enumerate(np.asarray(detector_samples, dtype=np.uint8)):
            correction = candidates[tuple(int(value) for value in syndrome_array)]
            # The logical observable is the first data bit after correction.
            internal_predictions[row, 0] = correction[0]
        prediction_divergence = float(np.mean(internal_predictions != external_predictions))
        external_failure_rate = float(np.mean(external_predictions != observable_samples))
        internal_failure_rate = float(np.mean(internal_predictions != observable_samples))
        rate_gap = abs(external_failure_rate - internal_failure_rate)
        tolerance = 1e-6
        status = "PASS" if prediction_divergence <= tolerance and rate_gap <= tolerance else "FAIL_DIFFERENTIAL_MISMATCH"
        return DifferentialCaseResult(
            tool="Stim + PyMatching",
            fixture=fixture,
            status=status,
            metric="decoder_prediction_divergence",
            value=prediction_divergence,
            tolerance=tolerance,
            tool_version=f"stim-{getattr(stim, '__version__', 'unknown')}; pymatching-{getattr(pymatching, '__version__', 'unknown')}",
            reason="same Stim detector samples decoded by PyMatching and an independent exhaustive minimum-weight decoder",
            evidence={
                "shots": shots,
                "distance": distance,
                "external_logical_failure_rate": external_failure_rate,
                "internal_logical_failure_rate": internal_failure_rate,
                "logical_failure_rate_gap": rate_gap,
            },
        )
    except Exception as exc:
        return DifferentialCaseResult(
            tool="Stim + PyMatching",
            fixture=fixture,
            status="FAIL_EXTERNAL_BENCHMARK_EXECUTION",
            metric=None,
            value=None,
            tolerance=None,
            tool_version=None,
            reason=f"{type(exc).__name__}: {exc}",
            evidence={},
        )


def _sl2cfoam_case(eprl_statuses: Iterable[str]) -> DifferentialCaseResult:
    fixture = "provenance_bound_single_vertex_and_delta3_admission_v1"
    statuses = tuple(str(item) for item in eprl_statuses)
    if statuses and all(status == "PASS" for status in statuses):
        return DifferentialCaseResult(
            tool="sl2cfoam-next",
            fixture=fixture,
            status="PASS",
            metric="admitted_target_contract_failures",
            value=0.0,
            tolerance=0.0,
            tool_version="provenance-bound runtime identity recorded in target evidence",
            reason="official backend outputs passed identity, request, shell and tensor-artifact admission",
            evidence={"target_statuses": list(statuses)},
        )
    runtime, reason = SL2CfoamRuntime.discover()
    if runtime is None:
        return _blocked("sl2cfoam-next", fixture, reason)
    return DifferentialCaseResult(
        tool="sl2cfoam-next",
        fixture=fixture,
        status="FAIL_EXTERNAL_BENCHMARK_EXECUTION",
        metric=None,
        value=None,
        tolerance=None,
        tool_version=runtime.commit_sha,
        reason="runtime was discovered but current target probes did not both pass",
        evidence={"target_statuses": list(statuses), "runtime": runtime.to_dict()},
    )


def run_differential_benchmarks(*, eprl_statuses: Iterable[str] = ()) -> DifferentialBenchmarkCertificate:
    """Execute external differential checks without substituting unavailable tools."""

    return DifferentialBenchmarkCertificate(
        cases=(
            _qiskit_aer_case(),
            _qutip_case(),
            _itensor_case(),
            _stim_pymatching_case(),
            _sl2cfoam_case(eprl_statuses),
        )
    )
