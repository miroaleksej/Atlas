from __future__ import annotations

from dataclasses import asdict, dataclass
import gzip
import hashlib
from importlib.resources import files
import json
import math
import re
from typing import Any, Iterable

import numpy as np
from scipy.linalg import expm

_I2 = np.eye(2, dtype=complex)
_X = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=complex)
_Y = np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=complex)
_Z = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=complex)
_ZERO = np.array([1.0, 0.0], dtype=complex)
_ONE = np.array([0.0, 1.0], dtype=complex)
_PLUS = (_ZERO + _ONE) / math.sqrt(2.0)
_MINUS = (_ZERO - _ONE) / math.sqrt(2.0)


def _json_digest(payload: Any) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ).hexdigest()


def _density(state: np.ndarray) -> np.ndarray:
    value = np.asarray(state, dtype=complex).reshape(-1)
    norm = float(np.linalg.norm(value))
    if norm <= 0.0:
        raise ValueError("State vector must be non-zero")
    value = value / norm
    return np.outer(value, value.conj())


def _entropy(density: np.ndarray, base: float = 2.0) -> float:
    value = 0.5 * (np.asarray(density, dtype=complex) + np.asarray(density, dtype=complex).conj().T)
    eigenvalues = np.clip(np.linalg.eigvalsh(value).real, 0.0, 1.0)
    nz = eigenvalues[eigenvalues > 1e-15]
    if nz.size == 0:
        return 0.0
    return float(-np.sum(nz * np.log(nz)) / np.log(base))


def _partial_trace(density: np.ndarray, dimensions: tuple[int, ...], keep: tuple[int, ...]) -> np.ndarray:
    dims = list(int(value) for value in dimensions)
    if int(np.prod(dims)) != density.shape[0] or density.shape[0] != density.shape[1]:
        raise ValueError("Density dimensions are incompatible with the subsystem dimensions")
    retained = set(int(index) for index in keep)
    tensor = np.asarray(density, dtype=complex).reshape(tuple(dims + dims))
    for subsystem in reversed(range(len(dims))):
        if subsystem not in retained:
            tensor = np.trace(tensor, axis1=subsystem, axis2=subsystem + len(dims))
            dims.pop(subsystem)
    final_dimension = int(np.prod(dims)) if dims else 1
    return np.asarray(tensor, dtype=complex).reshape((final_dimension, final_dimension))


def _trace_distance(first: np.ndarray, second: np.ndarray) -> float:
    delta = 0.5 * (np.asarray(first, dtype=complex) - np.asarray(second, dtype=complex))
    delta = 0.5 * (delta + delta.conj().T)
    return float(np.sum(np.abs(np.linalg.eigvalsh(delta))))


def _apply_kraus(density: np.ndarray, operators: Iterable[np.ndarray]) -> np.ndarray:
    return sum(operator @ density @ operator.conj().T for operator in operators)


def _apply_local_kraus(
    density: np.ndarray, operators: Iterable[np.ndarray], subsystem: int, dimensions: tuple[int, int] = (2, 2)
) -> np.ndarray:
    if dimensions != (2, 2):
        raise ValueError("The bounded local-channel control is defined for two qubits")
    result = np.zeros_like(density, dtype=complex)
    for operator in operators:
        full = np.kron(operator, _I2) if subsystem == 0 else np.kron(_I2, operator)
        result += full @ density @ full.conj().T
    return result


def _amplitude_damping(loss_probability: float) -> tuple[np.ndarray, np.ndarray]:
    probability = float(loss_probability)
    if not 0.0 <= probability <= 1.0:
        raise ValueError("Amplitude-damping probability must lie in [0,1]")
    return (
        np.array([[1.0, 0.0], [0.0, math.sqrt(1.0 - probability)]], dtype=complex),
        np.array([[0.0, math.sqrt(probability)], [0.0, 0.0]], dtype=complex),
    )


def _partial_transpose(density: np.ndarray, subsystem: int = 0) -> np.ndarray:
    tensor = np.asarray(density, dtype=complex).reshape(2, 2, 2, 2)
    if subsystem == 0:
        tensor = tensor.transpose(2, 1, 0, 3)
    else:
        tensor = tensor.transpose(0, 3, 2, 1)
    return tensor.reshape(4, 4)


def _negativity(density: np.ndarray) -> float:
    eigenvalues = np.linalg.eigvalsh(0.5 * (_partial_transpose(density) + _partial_transpose(density).conj().T))
    return float(np.sum(np.abs(eigenvalues[eigenvalues < 0.0])))


def _mutual_information(joint: np.ndarray) -> float:
    value = np.asarray(joint, dtype=float)
    px = value.sum(axis=1)
    py = value.sum(axis=0)
    total = 0.0
    for x in range(value.shape[0]):
        for y in range(value.shape[1]):
            if value[x, y] > 0.0 and px[x] > 0.0 and py[y] > 0.0:
                total += value[x, y] * math.log2(value[x, y] / (px[x] * py[y]))
    return float(total)


def _choi_from_kraus(operators: Iterable[np.ndarray]) -> np.ndarray:
    operators = tuple(np.asarray(operator, dtype=complex) for operator in operators)
    dimension = operators[0].shape[0]
    maximally_entangled = sum(
        np.kron(np.eye(dimension, dtype=complex)[:, index], np.eye(dimension, dtype=complex)[:, index])
        for index in range(dimension)
    )
    density = np.outer(maximally_entangled, maximally_entangled.conj())
    return sum(
        np.kron(_I2, operator) @ density @ np.kron(_I2, operator).conj().T
        for operator in operators
    )


def _fukui_chern_number(grid_size: int = 31, mass: float = -1.0) -> tuple[float, float]:
    if grid_size < 7:
        raise ValueError("The Chern-number grid must contain at least seven points per axis")
    states = np.empty((grid_size, grid_size, 2), dtype=complex)
    for ix in range(grid_size):
        kx = -math.pi + 2.0 * math.pi * ix / grid_size
        for iy in range(grid_size):
            ky = -math.pi + 2.0 * math.pi * iy / grid_size
            vector = np.array(
                [math.sin(kx), math.sin(ky), mass + math.cos(kx) + math.cos(ky)], dtype=float
            )
            hamiltonian = vector[0] * _X + vector[1] * _Y + vector[2] * _Z
            _, eigenvectors = np.linalg.eigh(hamiltonian)
            states[ix, iy] = eigenvectors[:, 0]
    curvature_sum = 0.0
    minimum_overlap = 1.0
    for ix in range(grid_size):
        for iy in range(grid_size):
            state = states[ix, iy]
            state_x = states[(ix + 1) % grid_size, iy]
            state_y = states[ix, (iy + 1) % grid_size]
            state_xy = states[(ix + 1) % grid_size, (iy + 1) % grid_size]
            overlaps = (
                np.vdot(state, state_x),
                np.vdot(state, state_y),
                np.vdot(state_y, state_xy),
                np.vdot(state_x, state_xy),
            )
            minimum_overlap = min(minimum_overlap, *(abs(value) for value in overlaps))
            ux = overlaps[0] / abs(overlaps[0])
            uy = overlaps[1] / abs(overlaps[1])
            ux_y = overlaps[2] / abs(overlaps[2])
            uy_x = overlaps[3] / abs(overlaps[3])
            curvature_sum += float(np.angle(ux * uy_x / (ux_y * uy)))
    return curvature_sum / (2.0 * math.pi), minimum_overlap


@dataclass(frozen=True, slots=True)
class LawRegistryCertificate:
    source_workbook_sha256: str
    registry_gzip_sha256: str
    registry_uncompressed_sha256: str
    row_count: int
    unique_cell_ids: int
    unique_cell_execution_digests: int
    proof_counts: dict[str, int]
    owner_selection_counts: dict[str, int]
    quantum_relevant_count: int
    quantum_proof_counts: dict[str, int]
    theorem_contract_count: int
    qualification_owner_tokens: int
    uncovered_qualification_owners: tuple[str, ...]
    p4_without_independent_evidence: tuple[str, ...]
    open_cell_ids: tuple[str, ...]
    semantic_digest: str

    @property
    def passed(self) -> bool:
        return (
            self.row_count == 9383
            and self.unique_cell_ids == self.row_count
            and self.unique_cell_execution_digests == self.row_count
            and self.proof_counts
            == {
                "P1 OPEN": 1,
                "P2 CONDITIONAL": 9255,
                "P3 OWNER-BOUND": 86,
                "P4 EVIDENCE-BOUND": 41,
            }
            and not self.uncovered_qualification_owners
            and not self.p4_without_independent_evidence
            and len(self.open_cell_ids) == 1
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"passed": self.passed}


@dataclass(frozen=True, slots=True)
class QuantumLawValidationCertificate:
    mapped_cell_ids: dict[str, str]
    strong_subadditivity_min_gap_bits: float
    schmidt_reconstruction_gap: float
    schmidt_spectrum_gap: float
    entropic_uncertainty_min_gap_bits: float
    speed_limit_orthogonality_gap: float
    speed_limit_bound_gap: float
    povm_completeness_gap: float
    born_probability_sum_gap: float
    born_probability_minimum: float
    holevo_chi_bits: float
    accessible_information_bits: float
    holevo_bound_gap_bits: float
    qfi: float
    classical_fisher_information: float
    cramer_rao_gap: float
    kraus_completeness_gap: float
    choi_min_eigenvalue: float
    trace_distance_before: float
    trace_distance_after: float
    data_processing_gap: float
    negativity_before: float
    negativity_after_local_channel: float
    locc_monotonicity_gap: float
    nonlinear_ensemble_dependence_trace_distance: float
    finite_ensemble_holevo_bits: float
    coherent_information_bits: float
    entanglement_assisted_mutual_information_bits: float
    chern_number: float
    chern_integer_gap: float
    chern_minimum_link_overlap: float
    diffusive_sme_ensemble_gap: float
    diffusive_sme_trace_gap: float
    diffusive_sme_min_eigenvalue: float
    physical_claim_status: str

    @property
    def passed(self) -> bool:
        return (
            self.strong_subadditivity_min_gap_bits > -1e-11
            and self.schmidt_reconstruction_gap < 1e-12
            and self.schmidt_spectrum_gap < 1e-12
            and self.entropic_uncertainty_min_gap_bits > -1e-11
            and self.speed_limit_orthogonality_gap < 1e-12
            and abs(self.speed_limit_bound_gap) < 1e-12
            and self.povm_completeness_gap < 1e-12
            and self.born_probability_sum_gap < 1e-12
            and self.born_probability_minimum >= -1e-12
            and self.holevo_bound_gap_bits >= -1e-12
            and self.cramer_rao_gap >= -1e-12
            and self.kraus_completeness_gap < 1e-12
            and self.choi_min_eigenvalue > -1e-12
            and self.data_processing_gap >= -1e-12
            and self.locc_monotonicity_gap >= -1e-12
            and self.nonlinear_ensemble_dependence_trace_distance > 0.1
            and self.chern_integer_gap < 1e-10
            and abs(abs(self.chern_number) - 1.0) < 1e-10
            and self.diffusive_sme_ensemble_gap < 0.035
            and self.diffusive_sme_trace_gap < 1e-12
            and self.diffusive_sme_min_eigenvalue > -1e-12
            and self.physical_claim_status == "IMPLEMENTATION_VALIDATED_PHYSICAL_PROOF_WITHHELD"
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"passed": self.passed}


@dataclass(frozen=True, slots=True)
class PhysicalLawTableCertificate:
    registry: LawRegistryCertificate
    quantum_laws: QuantumLawValidationCertificate
    proof_boundary: dict[str, str]

    @property
    def passed(self) -> bool:
        return self.registry.passed and self.quantum_laws.passed

    def to_dict(self) -> dict[str, Any]:
        return {
            "registry": self.registry.to_dict(),
            "quantum_laws": self.quantum_laws.to_dict(),
            "proof_boundary": dict(self.proof_boundary),
            "passed": self.passed,
        }


class PhysicalLawQualificationOwner:
    """Authoritative owner for table-derived theorem and implementation qualification.

    The owner proves only executable mathematical properties under declared assumptions.  It is
    deliberately unable to promote a synthetic or self-consistency run to an empirical law.
    """

    _CELL_PATTERN = re.compile(r"CELL-[0-9A-F]{12}\Z")
    _DIGEST_PATTERN = re.compile(r"[0-9a-f]{24}\Z")

    def __init__(self, random_seed: int = 20260729):
        self.random_seed = int(random_seed)
        data_root = files("qpdtr.data")
        self.registry_resource = data_root.joinpath("physical_law_registry_v3.json.gz")
        self.contract_resource = data_root.joinpath("proof_contracts_v3.json")
        self.metadata_resource = data_root.joinpath("registry_metadata.json")

    def _load(self) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], bytes]:
        compressed = self.registry_resource.read_bytes()
        raw = gzip.decompress(compressed)
        registry = json.loads(raw.decode("utf-8"))
        contracts = json.loads(self.contract_resource.read_text(encoding="utf-8"))
        metadata = json.loads(self.metadata_resource.read_text(encoding="utf-8"))
        return registry, contracts, metadata, raw

    @staticmethod
    def _normalize_owner_token(token: str) -> str:
        return re.sub(r"\s*\([^)]*\)\s*", "", token).strip()

    def _registry_certificate(
        self, registry: dict[str, Any], contracts: dict[str, Any], metadata: dict[str, Any], raw: bytes
    ) -> LawRegistryCertificate:
        cells = registry["cells"]
        cell_ids = [str(cell["cell_id"]) for cell in cells]
        execution_digests = [str(cell["cell_execution_digest"]) for cell in cells]
        if any(not self._CELL_PATTERN.fullmatch(cell_id) for cell_id in cell_ids):
            raise ValueError("The law registry contains an invalid Cell ID")
        if any(not self._DIGEST_PATTERN.fullmatch(value) for value in execution_digests):
            raise ValueError("The law registry contains an invalid cell execution digest")
        contract_ids = {str(contract["id"]) for contract in contracts["contracts"]}
        owner_tokens = 0
        uncovered: set[str] = set()
        for cell in cells:
            if cell["owner_selection_mode"] not in {
                "REFERENCE_OPERATOR_OWNER",
                "CONTROLLED_NEAR_OWNER",
                "P0_REPLACEMENT_OWNER",
            }:
                continue
            owner = str(cell["authoritative_owner"] or "")
            if owner.startswith("OPR::"):
                owner = owner.removeprefix("OPR::")
            for raw_token in owner.split("+"):
                token = self._normalize_owner_token(raw_token)
                if not token:
                    continue
                owner_tokens += 1
                if token not in contract_ids:
                    uncovered.add(token)
        p4_without_evidence = tuple(
            sorted(
                str(cell["cell_id"])
                for cell in cells
                if cell["proof_level"] == "P4 EVIDENCE-BOUND"
                and cell["independent_evidence"] != "PASS_ALL_OWNER_SOURCES"
            )
        )
        open_cells = tuple(
            sorted(str(cell["cell_id"]) for cell in cells if cell["proof_level"] == "P1 OPEN")
        )
        semantic = {
            "source_workbook_sha256": registry["source_workbook_sha256"],
            "row_count": registry["row_count"],
            "proof_counts": registry["proof_counts"],
            "owner_selection_counts": registry["owner_selection_counts"],
            "quantum_relevant_count": registry["quantum_relevant_count"],
            "quantum_proof_counts": registry["quantum_proof_counts"],
            "theorem_contract_count": contracts["count"],
            "open_cell_ids": open_cells,
        }
        return LawRegistryCertificate(
            source_workbook_sha256=str(registry["source_workbook_sha256"]),
            registry_gzip_sha256=hashlib.sha256(self.registry_resource.read_bytes()).hexdigest(),
            registry_uncompressed_sha256=hashlib.sha256(raw).hexdigest(),
            row_count=len(cells),
            unique_cell_ids=len(set(cell_ids)),
            unique_cell_execution_digests=len(set(execution_digests)),
            proof_counts={str(key): int(value) for key, value in registry["proof_counts"].items()},
            owner_selection_counts={
                str(key): int(value) for key, value in registry["owner_selection_counts"].items()
            },
            quantum_relevant_count=int(registry["quantum_relevant_count"]),
            quantum_proof_counts={
                str(key): int(value) for key, value in registry["quantum_proof_counts"].items()
            },
            theorem_contract_count=int(contracts["count"]),
            qualification_owner_tokens=owner_tokens,
            uncovered_qualification_owners=tuple(sorted(uncovered)),
            p4_without_independent_evidence=p4_without_evidence,
            open_cell_ids=open_cells,
            semantic_digest=_json_digest(semantic),
        )

    @staticmethod
    def _cell_map(cells: list[dict[str, Any]]) -> dict[str, str]:
        requested = {
            "strong_subadditivity": "QTM-30",
            "locc_monotonicity": "QTM-48",
            "quantum_speed_limit": "QTM-45",
            "schmidt_decomposition": "QTM-23",
            "entropic_uncertainty": "QTM-26",
            "born_povm": "QTM-03",
            "holevo_bound": "QTM-32",
            "quantum_cramer_rao": "QTM-47",
            "channel_capacities": "QTM-49",
            "gksl": "QTM-15",
            "kraus": "QTM-22",
            "diffusive_sme": "QTM-46",
            "chern_number": "MAT-11",
        }
        result: dict[str, str] = {}
        for name, code in requested.items():
            matches = [str(cell["cell_id"]) for cell in cells if code in str(cell["authoritative_owner"])]
            if len(matches) != 1:
                raise ValueError(f"Expected one table cell for {code}, found {len(matches)}")
            result[name] = matches[0]
        return result

    def _quantum_validation(self, cells: list[dict[str, Any]]) -> QuantumLawValidationCertificate:
        rng = np.random.default_rng(self.random_seed)
        mapped = self._cell_map(cells)

        # Strong subadditivity over an independent deterministic random corpus.
        ssa_values: list[float] = []
        for _ in range(24):
            state = rng.normal(size=8) + 1j * rng.normal(size=8)
            state /= np.linalg.norm(state)
            rho_abc = _density(state)
            rho_ab = _partial_trace(rho_abc, (2, 2, 2), (0, 1))
            rho_bc = _partial_trace(rho_abc, (2, 2, 2), (1, 2))
            rho_b = _partial_trace(rho_abc, (2, 2, 2), (1,))
            ssa_values.append(
                _entropy(rho_ab) + _entropy(rho_bc) - _entropy(rho_b) - _entropy(rho_abc)
            )

        # Schmidt decomposition and spectrum equality.
        coefficient = rng.normal(size=(2, 3)) + 1j * rng.normal(size=(2, 3))
        coefficient /= np.linalg.norm(coefficient)
        u, singular, vh = np.linalg.svd(coefficient, full_matrices=False)
        schmidt_reconstruction = np.linalg.norm(coefficient - (u * singular) @ vh)
        state_23 = coefficient.reshape(6)
        rho_23 = _density(state_23)
        reduced_a = _partial_trace(rho_23, (2, 3), (0,))
        reduced_b = _partial_trace(rho_23, (2, 3), (1,))
        nonzero_b = np.sort(np.linalg.eigvalsh(reduced_b).real)[-2:]
        schmidt_spectrum_gap = max(
            float(np.linalg.norm(np.sort(np.linalg.eigvalsh(reduced_a).real) - np.sort(singular**2))),
            float(np.linalg.norm(nonzero_b - np.sort(singular**2))),
        )

        # Maassen-Uffink entropic uncertainty for X and Z on a deterministic corpus.
        uncertainty_gaps: list[float] = []
        x_vectors = np.column_stack((_PLUS, _MINUS))
        for _ in range(32):
            state = rng.normal(size=2) + 1j * rng.normal(size=2)
            state /= np.linalg.norm(state)
            pz = np.abs(state) ** 2
            px = np.abs(x_vectors.conj().T @ state) ** 2
            hz = -sum(float(p * math.log2(p)) for p in pz if p > 1e-15)
            hx = -sum(float(p * math.log2(p)) for p in px if p > 1e-15)
            uncertainty_gaps.append(hx + hz - 1.0)

        # Saturating Mandelstam-Tamm and Margolus-Levitin control.
        hamiltonian = np.diag([0.0, 1.0]).astype(complex)
        initial = _PLUS
        orthogonal_time = math.pi
        evolved = expm(-1j * orthogonal_time * hamiltonian) @ initial
        mean_energy = float(np.vdot(initial, hamiltonian @ initial).real)
        variance = float(np.vdot(initial, hamiltonian @ hamiltonian @ initial).real - mean_energy**2)
        qsl_bound = max(math.pi / (2.0 * math.sqrt(variance)), math.pi / (2.0 * mean_energy))

        # Born/POVM normalization on a nonprojective two-outcome measurement.
        eta_povm = 0.4
        effect0 = 0.5 * (_I2 + eta_povm * _Z)
        effect1 = _I2 - effect0
        povm_completeness_gap = float(np.linalg.norm(effect0 + effect1 - _I2, ord=2))
        born_probabilities = np.array(
            [np.trace(effect0 @ _density(_PLUS)).real, np.trace(effect1 @ _density(_PLUS)).real],
            dtype=float,
        )

        # Holevo information and the accessible information of the Helstrom measurement.
        rho0, rho1 = _density(_ZERO), _density(_PLUS)
        average = 0.5 * (rho0 + rho1)
        holevo = _entropy(average)
        delta = 0.5 * rho0 - 0.5 * rho1
        eigenvalues, eigenvectors = np.linalg.eigh(delta)
        positive = eigenvectors[:, eigenvalues >= 0.0]
        projector0 = positive @ positive.conj().T
        projector1 = _I2 - projector0
        joint = np.array(
            [
                [0.5 * np.trace(projector0 @ rho0).real, 0.5 * np.trace(projector1 @ rho0).real],
                [0.5 * np.trace(projector0 @ rho1).real, 0.5 * np.trace(projector1 @ rho1).real],
            ]
        )
        accessible = _mutual_information(joint)

        # Quantum Fisher information and a saturating X measurement.
        theta = 0.73
        state_theta = np.array([1.0, np.exp(1j * theta)], dtype=complex) / math.sqrt(2.0)
        derivative_state = np.array([0.0, 1j * np.exp(1j * theta)], dtype=complex) / math.sqrt(2.0)
        rho_theta = _density(state_theta)
        derivative_rho = np.outer(derivative_state, state_theta.conj()) + np.outer(
            state_theta, derivative_state.conj()
        )
        lambdas, vectors = np.linalg.eigh(rho_theta)
        qfi = 0.0
        transformed = vectors.conj().T @ derivative_rho @ vectors
        for i in range(2):
            for j in range(2):
                denominator = lambdas[i] + lambdas[j]
                if denominator > 1e-14:
                    qfi += 2.0 * abs(transformed[i, j]) ** 2 / denominator
        probabilities = np.array([(1.0 + math.cos(theta)) / 2.0, (1.0 - math.cos(theta)) / 2.0])
        derivatives = np.array([-math.sin(theta) / 2.0, math.sin(theta) / 2.0])
        classical_fisher = float(np.sum(derivatives**2 / probabilities))

        # Kraus/Choi, data processing and local entanglement monotonicity.
        damping = _amplitude_damping(0.25)
        completeness = sum(operator.conj().T @ operator for operator in damping)
        kraus_gap = float(np.linalg.norm(completeness - _I2, ord=2))
        choi = _choi_from_kraus(damping)
        choi_min = float(np.min(np.linalg.eigvalsh(0.5 * (choi + choi.conj().T))).real)
        before_distance = _trace_distance(rho0, rho1)
        after_distance = _trace_distance(_apply_kraus(rho0, damping), _apply_kraus(rho1, damping))
        bell = np.kron(_ZERO, _ZERO) + np.kron(_ONE, _ONE)
        bell /= np.linalg.norm(bell)
        bell_density = _density(bell)
        damped_bell = _apply_local_kraus(bell_density, damping, subsystem=0)
        negativity_before = _negativity(bell_density)
        negativity_after = _negativity(damped_bell)

        # Explicit operational rejection of a deterministic nonlinear pure-state law.
        def nonlinear_map(state: np.ndarray, coupling: float = 0.4) -> np.ndarray:
            z_expectation = float(np.vdot(state, _Z @ state).real)
            return expm(-1j * coupling * z_expectation * _X) @ state

        def ensemble_density(states: tuple[np.ndarray, np.ndarray]) -> np.ndarray:
            return 0.5 * sum(_density(nonlinear_map(state)) for state in states)

        nonlinear_dependence = _trace_distance(
            ensemble_density((_ZERO, _ONE)), ensemble_density((_PLUS, _MINUS))
        )

        # One-shot channel information functionals; explicitly not regularized capacities.
        eta = 0.8
        channel = _amplitude_damping(1.0 - eta)
        output0, output1 = _apply_kraus(rho0, channel), _apply_kraus(_density(_ONE), channel)
        finite_holevo = _entropy(0.5 * (output0 + output1)) - 0.5 * (
            _entropy(output0) + _entropy(output1)
        )
        input_mixed = 0.5 * _I2
        isometry = np.zeros((4, 2), dtype=complex)
        isometry[0, 0] = 1.0
        isometry[2, 1] = math.sqrt(eta)
        isometry[1, 1] = math.sqrt(1.0 - eta)
        output_be = isometry @ input_mixed @ isometry.conj().T
        output_b = _partial_trace(output_be, (2, 2), (0,))
        output_e = _partial_trace(output_be, (2, 2), (1,))
        coherent_information = _entropy(output_b) - _entropy(output_e)
        reference_bell = bell_density
        rb_output = _apply_local_kraus(reference_bell, channel, subsystem=1)
        rho_r = _partial_trace(rb_output, (2, 2), (0,))
        rho_b = _partial_trace(rb_output, (2, 2), (1,))
        entanglement_assisted = _entropy(rho_r) + _entropy(rho_b) - _entropy(rb_output)

        # Integer topological invariant of a two-band Chern insulator.
        chern, minimum_link = _fukui_chern_number()

        # Diffusive stochastic Schrödinger unravelling of kappa D[Z].
        trajectory_count = 2048
        step_count = 250
        elapsed = 0.25
        dt = elapsed / step_count
        kappa = 0.7
        states = np.tile(_PLUS, (trajectory_count, 1)).astype(complex)
        diagonal_l = math.sqrt(kappa) * np.array([1.0, -1.0])
        for _ in range(step_count):
            probabilities_state = np.abs(states) ** 2
            mean_l = probabilities_state @ diagonal_l
            centered = diagonal_l[None, :] - mean_l[:, None]
            dw = rng.normal(0.0, math.sqrt(dt), size=trajectory_count)
            states += -0.5 * centered**2 * states * dt + centered * states * dw[:, None]
            states /= np.linalg.norm(states, axis=1)[:, None]
        ensemble = np.einsum("ni,nj->ij", states, states.conj()) / trajectory_count
        exact = np.array(
            [[0.5, 0.5 * math.exp(-2.0 * kappa * elapsed)], [0.5 * math.exp(-2.0 * kappa * elapsed), 0.5]],
            dtype=complex,
        )
        ensemble_gap = _trace_distance(ensemble, exact)

        return QuantumLawValidationCertificate(
            mapped_cell_ids=mapped,
            strong_subadditivity_min_gap_bits=float(min(ssa_values)),
            schmidt_reconstruction_gap=float(schmidt_reconstruction),
            schmidt_spectrum_gap=float(schmidt_spectrum_gap),
            entropic_uncertainty_min_gap_bits=float(min(uncertainty_gaps)),
            speed_limit_orthogonality_gap=float(abs(np.vdot(initial, evolved))),
            speed_limit_bound_gap=float(orthogonal_time - qsl_bound),
            povm_completeness_gap=povm_completeness_gap,
            born_probability_sum_gap=float(abs(np.sum(born_probabilities) - 1.0)),
            born_probability_minimum=float(np.min(born_probabilities)),
            holevo_chi_bits=float(holevo),
            accessible_information_bits=float(accessible),
            holevo_bound_gap_bits=float(holevo - accessible),
            qfi=float(qfi),
            classical_fisher_information=classical_fisher,
            cramer_rao_gap=float(qfi - classical_fisher),
            kraus_completeness_gap=kraus_gap,
            choi_min_eigenvalue=choi_min,
            trace_distance_before=before_distance,
            trace_distance_after=after_distance,
            data_processing_gap=float(before_distance - after_distance),
            negativity_before=negativity_before,
            negativity_after_local_channel=negativity_after,
            locc_monotonicity_gap=float(negativity_before - negativity_after),
            nonlinear_ensemble_dependence_trace_distance=nonlinear_dependence,
            finite_ensemble_holevo_bits=float(finite_holevo),
            coherent_information_bits=float(coherent_information),
            entanglement_assisted_mutual_information_bits=float(entanglement_assisted),
            chern_number=float(chern),
            chern_integer_gap=float(abs(chern - round(chern))),
            chern_minimum_link_overlap=float(minimum_link),
            diffusive_sme_ensemble_gap=float(ensemble_gap),
            diffusive_sme_trace_gap=float(abs(np.trace(ensemble) - 1.0)),
            diffusive_sme_min_eigenvalue=float(np.min(np.linalg.eigvalsh(ensemble)).real),
            physical_claim_status="IMPLEMENTATION_VALIDATED_PHYSICAL_PROOF_WITHHELD",
        )

    def execute(self) -> PhysicalLawTableCertificate:
        registry, contracts, metadata, raw = self._load()
        if hashlib.sha256(raw).hexdigest() != metadata["registry_uncompressed_sha256"]:
            raise ValueError("Physical-law registry uncompressed digest mismatch")
        if hashlib.sha256(self.registry_resource.read_bytes()).hexdigest() != metadata["registry_gzip_sha256"]:
            raise ValueError("Physical-law registry compressed digest mismatch")
        registry_certificate = self._registry_certificate(registry, contracts, metadata, raw)
        quantum_certificate = self._quantum_validation(registry["cells"])
        return PhysicalLawTableCertificate(
            registry=registry_certificate,
            quantum_laws=quantum_certificate,
            proof_boundary={
                "P2": "A successful simulation validates implementation and assumptions, not physical realization.",
                "P3": "An owner theorem is admitted only in its stated domain and cannot be transferred to neighbouring cells.",
                "P4": "Physical promotion requires owner-domain matching and independent evidence; simulation alone is prohibited.",
                "new_law": "A new physical law requires a parameter-free distinguishing prediction and held-out external data.",
            },
        )
