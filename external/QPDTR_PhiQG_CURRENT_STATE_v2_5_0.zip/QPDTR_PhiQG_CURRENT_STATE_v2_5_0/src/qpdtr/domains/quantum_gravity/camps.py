from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from typing import Any, Iterable, Sequence

import numpy as np

from .quantum import MatrixProductState


_I2 = np.eye(2, dtype=np.complex128)
_X = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=np.complex128)
_Y = np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=np.complex128)
_Z = np.diag([1.0, -1.0]).astype(np.complex128)
_H = np.array([[1.0, 1.0], [1.0, -1.0]], dtype=np.complex128) / np.sqrt(2.0)
_S = np.diag([1.0, 1.0j]).astype(np.complex128)
_SDG = np.diag([1.0, -1.0j]).astype(np.complex128)
_T = np.diag([1.0, np.exp(1.0j * np.pi / 4.0)]).astype(np.complex128)
_CNOT = np.array(
    [[1.0, 0.0, 0.0, 0.0],
     [0.0, 1.0, 0.0, 0.0],
     [0.0, 0.0, 0.0, 1.0],
     [0.0, 0.0, 1.0, 0.0]],
    dtype=np.complex128,
)
_CZ = np.diag([1.0, 1.0, 1.0, -1.0]).astype(np.complex128)
_SWAP = np.array(
    [[1.0, 0.0, 0.0, 0.0],
     [0.0, 0.0, 1.0, 0.0],
     [0.0, 1.0, 0.0, 0.0],
     [0.0, 0.0, 0.0, 1.0]],
    dtype=np.complex128,
)
_SINGLE = {"H": _H, "S": _S, "SDG": _SDG, "X": _X, "Y": _Y, "Z": _Z, "T": _T}
_TWO = {"CNOT": _CNOT, "CZ": _CZ, "SWAP": _SWAP}
_CLIFFORD = frozenset({"H", "S", "SDG", "X", "Y", "Z", "CNOT", "CZ", "SWAP"})


def _qubit(value: int, qubit_count: int) -> int:
    q = int(value)
    if q < 0 or q >= qubit_count:
        raise IndexError(f"qubit {q} is outside [0,{qubit_count})")
    return q


@dataclass(frozen=True, slots=True)
class PauliWord:
    """Exact Pauli word i^phase prod_q X_q^x_q Z_q^z_q."""

    x: np.ndarray
    z: np.ndarray
    phase: int = 0

    def __post_init__(self) -> None:
        x = np.asarray(self.x, dtype=np.uint8).reshape(-1) & np.uint8(1)
        z = np.asarray(self.z, dtype=np.uint8).reshape(-1) & np.uint8(1)
        if x.shape != z.shape:
            raise ValueError("Pauli x/z vectors must have identical shapes")
        object.__setattr__(self, "x", x)
        object.__setattr__(self, "z", z)
        object.__setattr__(self, "phase", int(self.phase) % 4)

    @classmethod
    def identity(cls, qubit_count: int, *, phase: int = 0) -> "PauliWord":
        return cls(np.zeros(qubit_count, np.uint8), np.zeros(qubit_count, np.uint8), phase)

    @classmethod
    def generator(cls, qubit_count: int, qubit: int, symbol: str, *, sign: int = 1) -> "PauliWord":
        q = _qubit(qubit, qubit_count)
        x = np.zeros(qubit_count, np.uint8)
        z = np.zeros(qubit_count, np.uint8)
        name = symbol.upper()
        phase = 0 if sign >= 0 else 2
        if name == "X":
            x[q] = 1
        elif name == "Z":
            z[q] = 1
        elif name == "Y":
            x[q] = 1
            z[q] = 1
            phase += 1
        elif name != "I":
            raise ValueError(f"Unsupported Pauli symbol {symbol!r}")
        return cls(x, z, phase)

    @property
    def qubit_count(self) -> int:
        return int(self.x.size)

    @property
    def support_size(self) -> int:
        return int(np.count_nonzero(self.x | self.z))

    @property
    def is_hermitian(self) -> bool:
        y_count = int(np.count_nonzero(self.x & self.z))
        return (self.phase - y_count) % 2 == 0

    @property
    def hermitian_sign(self) -> int:
        if not self.is_hermitian:
            raise ValueError("Pauli word is not Hermitian")
        y_count = int(np.count_nonzero(self.x & self.z))
        residual = (self.phase - y_count) % 4
        if residual == 0:
            return 1
        if residual == 2:
            return -1
        raise ArithmeticError("Hermitian Pauli phase is inconsistent")

    def multiply(self, other: "PauliWord") -> "PauliWord":
        if self.qubit_count != other.qubit_count:
            raise ValueError("Pauli multiplication requires equal qubit counts")
        crossing = int(np.dot(self.z.astype(np.int64), other.x.astype(np.int64)))
        return PauliWord(
            self.x ^ other.x,
            self.z ^ other.z,
            self.phase + other.phase + 2 * crossing,
        )

    def symplectic_inner(self, other: "PauliWord") -> int:
        if self.qubit_count != other.qubit_count:
            raise ValueError("Symplectic product requires equal qubit counts")
        value = int(np.dot(self.x, other.z) + np.dot(self.z, other.x))
        return value & 1

    def to_symbols(self) -> tuple[str, ...]:
        symbols: list[str] = []
        for x, z in zip(self.x, self.z, strict=True):
            symbols.append("Y" if x and z else "X" if x else "Z" if z else "I")
        return tuple(symbols)

    def to_dict(self) -> dict[str, Any]:
        return {
            "symbols": "".join(self.to_symbols()),
            "phase_mod_4": self.phase,
            "hermitian": self.is_hermitian,
            "hermitian_sign": self.hermitian_sign if self.is_hermitian else None,
            "support_size": self.support_size,
        }


class CliffordFrame:
    """Symplectic Clifford frame without a stored circuit or dense unitary.

    The rows are the exact images C^dagger X_q C and C^dagger Z_q C.
    A physical Clifford gate updates these images in place.  No historical gate
    sequence is retained by the active frame.
    """

    def __init__(self, qubit_count: int) -> None:
        n = int(qubit_count)
        if n < 1:
            raise ValueError("Clifford frame requires at least one qubit")
        self.qubit_count = n
        self.images_x = [PauliWord.generator(n, q, "X") for q in range(n)]
        self.images_z = [PauliWord.generator(n, q, "Z") for q in range(n)]
        self.gate_count = 0

    @property
    def memory_bytes(self) -> int:
        return int(sum(word.x.nbytes + word.z.nbytes + 1 for word in self.images_x + self.images_z))

    def map_word(self, word: PauliWord) -> PauliWord:
        if word.qubit_count != self.qubit_count:
            raise ValueError("Pauli word lies outside the Clifford frame")
        result = PauliWord.identity(self.qubit_count, phase=word.phase)
        for q in range(self.qubit_count):
            if word.x[q]:
                result = result.multiply(self.images_x[q])
            if word.z[q]:
                result = result.multiply(self.images_z[q])
        return result

    def twisted_z(self, qubit: int) -> PauliWord:
        return self.images_z[_qubit(qubit, self.qubit_count)]

    def _canonical_product(self, factors: Iterable[tuple[int, str, int]]) -> PauliWord:
        result = PauliWord.identity(self.qubit_count)
        for qubit, symbol, sign in factors:
            result = result.multiply(PauliWord.generator(self.qubit_count, qubit, symbol, sign=sign))
        return result

    def apply(self, gate: str, *qubits: int) -> None:
        name = gate.upper()
        if name not in _CLIFFORD:
            raise ValueError(f"Unsupported Clifford gate {gate!r}")
        old_x = self.images_x
        old_z = self.images_z

        def map_old(word: PauliWord) -> PauliWord:
            result = PauliWord.identity(self.qubit_count, phase=word.phase)
            for q in range(self.qubit_count):
                if word.x[q]:
                    result = result.multiply(old_x[q])
                if word.z[q]:
                    result = result.multiply(old_z[q])
            return result

        new_x = list(old_x)
        new_z = list(old_z)
        if name in {"H", "S", "SDG", "X", "Y", "Z"}:
            q = _qubit(qubits[0], self.qubit_count)
            if name == "H":
                pre_x = PauliWord.generator(self.qubit_count, q, "Z")
                pre_z = PauliWord.generator(self.qubit_count, q, "X")
            elif name == "S":
                pre_x = PauliWord.generator(self.qubit_count, q, "Y", sign=-1)
                pre_z = PauliWord.generator(self.qubit_count, q, "Z")
            elif name == "SDG":
                pre_x = PauliWord.generator(self.qubit_count, q, "Y")
                pre_z = PauliWord.generator(self.qubit_count, q, "Z")
            elif name == "X":
                pre_x = PauliWord.generator(self.qubit_count, q, "X")
                pre_z = PauliWord.generator(self.qubit_count, q, "Z", sign=-1)
            elif name == "Y":
                pre_x = PauliWord.generator(self.qubit_count, q, "X", sign=-1)
                pre_z = PauliWord.generator(self.qubit_count, q, "Z", sign=-1)
            else:
                pre_x = PauliWord.generator(self.qubit_count, q, "X", sign=-1)
                pre_z = PauliWord.generator(self.qubit_count, q, "Z")
            new_x[q] = map_old(pre_x)
            new_z[q] = map_old(pre_z)
        else:
            a = _qubit(qubits[0], self.qubit_count)
            b = _qubit(qubits[1], self.qubit_count)
            if a == b:
                raise ValueError(f"{name} requires distinct qubits")
            if name == "CNOT":
                pre_xa = self._canonical_product(((a, "X", 1), (b, "X", 1)))
                pre_za = PauliWord.generator(self.qubit_count, a, "Z")
                pre_xb = PauliWord.generator(self.qubit_count, b, "X")
                pre_zb = self._canonical_product(((a, "Z", 1), (b, "Z", 1)))
            elif name == "CZ":
                pre_xa = self._canonical_product(((a, "X", 1), (b, "Z", 1)))
                pre_za = PauliWord.generator(self.qubit_count, a, "Z")
                pre_xb = self._canonical_product(((a, "Z", 1), (b, "X", 1)))
                pre_zb = PauliWord.generator(self.qubit_count, b, "Z")
            else:
                pre_xa = PauliWord.generator(self.qubit_count, b, "X")
                pre_za = PauliWord.generator(self.qubit_count, b, "Z")
                pre_xb = PauliWord.generator(self.qubit_count, a, "X")
                pre_zb = PauliWord.generator(self.qubit_count, a, "Z")
            new_x[a] = map_old(pre_xa)
            new_z[a] = map_old(pre_za)
            new_x[b] = map_old(pre_xb)
            new_z[b] = map_old(pre_zb)
        self.images_x = new_x
        self.images_z = new_z
        self.gate_count += 1

    def canonical_pair_gap(self) -> int:
        words = self.images_x + self.images_z
        x = np.stack([word.x for word in words]).astype(np.int64)
        z = np.stack([word.z for word in words]).astype(np.int64)
        observed = (x @ z.T + z @ x.T) & 1
        expected = np.zeros_like(observed)
        n = self.qubit_count
        indices = np.arange(n)
        expected[indices, n + indices] = 1
        expected[n + indices, indices] = 1
        return int(np.count_nonzero(observed != expected))


class CliffordAugmentedMPS:
    """Current CAMPS owner for Clifford+T circuits.

    The physical state is |psi> = C |phi_MPS>.  Clifford gates update only the
    symplectic frame.  A T gate is lowered exactly (up to controlled MPS
    truncation) to exp(-i*pi*P/8), P=C^dagger Z C, on the residual MPS.
    """

    def __init__(
        self,
        qubit_count: int,
        *,
        max_bond: int,
        discarded_weight_budget: float,
    ) -> None:
        n = int(qubit_count)
        if n < 1 or max_bond < 1 or discarded_weight_budget < 0.0:
            raise ValueError("CAMPS resource contract is inadmissible")
        self.qubit_count = n
        self.max_bond = int(max_bond)
        self.discarded_weight_budget = float(discarded_weight_budget)
        self.frame = CliffordFrame(n)
        self.residual = MatrixProductState.product_state([0] * n)
        self.global_phase = 1.0 + 0.0j
        self.t_gate_count = 0
        self.cumulative_discarded_weight = 0.0
        self.maximum_used_bond = 1
        self.maximum_twisted_pauli_support = 0
        self.twisted_pauli_supports: list[int] = []

    def apply_clifford(self, gate: str, *qubits: int) -> None:
        self.frame.apply(gate, *qubits)

    def _apply_pauli_word(self, word: PauliWord) -> MatrixProductState:
        if not word.is_hermitian:
            raise ValueError("CAMPS Pauli rotation requires a Hermitian word")
        state = self.residual.copy()
        for q, (x, z) in enumerate(zip(word.x, word.z, strict=True)):
            matrix = _I2
            if x:
                matrix = matrix @ _X
            if z:
                matrix = matrix @ _Z
            if x or z:
                state.apply_one_site_gate(q, matrix)
        state.tensors[0] *= (1.0j ** word.phase)
        return state

    def apply_t(self, qubit: int) -> None:
        q = _qubit(qubit, self.qubit_count)
        word = self.frame.twisted_z(q)
        if not word.is_hermitian:
            raise ArithmeticError("Clifford conjugation produced a non-Hermitian twisted Pauli")
        angle = np.pi / 8.0
        support = [index for index, value in enumerate(word.x | word.z) if value]
        sign = word.hermitian_sign
        symbols = word.to_symbols()
        discarded = 0.0
        used = self.residual.max_bond
        if len(support) == 0:
            self.residual.tensors[0] *= np.exp(-1.0j * angle * sign)
        elif len(support) == 1:
            site = support[0]
            sigma = {"X": _X, "Y": _Y, "Z": _Z}[symbols[site]]
            gate = np.cos(angle) * _I2 - 1.0j * np.sin(angle) * sign * sigma
            self.residual.apply_one_site_gate(site, gate)
        elif len(support) == 2:
            first, second = support
            sigma_first = {"X": _X, "Y": _Y, "Z": _Z}[symbols[first]]
            sigma_second = {"X": _X, "Y": _Y, "Z": _Z}[symbols[second]]
            generator = sign * np.kron(sigma_first, sigma_second)
            gate = np.cos(angle) * np.eye(4, dtype=np.complex128) - 1.0j * np.sin(angle) * generator
            remaining = max(self.discarded_weight_budget - self.cumulative_discarded_weight, 0.0)
            discarded, used = self.residual.apply_two_site_gate(
                first, second, gate, max_bond=self.max_bond, discarded_weight_budget=remaining
            )
        else:
            transformed = self._apply_pauli_word(word)
            combined = MatrixProductState.linear_combination(
                ((np.cos(angle), self.residual), (-1.0j * np.sin(angle), transformed))
            )
            remaining = max(self.discarded_weight_budget - self.cumulative_discarded_weight, 0.0)
            per_bond = remaining / max(1, self.qubit_count - 1)
            discarded, used = combined.compress(max_bond=self.max_bond, discarded_weight_budget=per_bond)
            pre_normalization_gap = abs(combined.norm_squared() - 1.0)
            if discarded > 0.0 or pre_normalization_gap > 1e-15:
                combined.normalize()
            self.residual = combined
        self.cumulative_discarded_weight += discarded
        self.maximum_used_bond = max(self.maximum_used_bond, used, self.residual.max_bond)
        self.maximum_twisted_pauli_support = max(self.maximum_twisted_pauli_support, word.support_size)
        self.twisted_pauli_supports.append(word.support_size)
        self.global_phase *= np.exp(1.0j * np.pi / 8.0)
        self.t_gate_count += 1

    def residual_norm_gap(self) -> float:
        return abs(self.residual.norm_squared() - 1.0)


@dataclass(frozen=True, slots=True)
class CAMPSBoundedCertificate:
    qubit_count: int
    t_gate_count: int
    clifford_gate_count: int
    frame_canonical_pair_gap: int
    residual_maximum_bond: int
    standard_mps_maximum_bond: int
    cumulative_discarded_weight: float
    phase_aligned_state_gap: float
    residual_norm_gap: float
    maximum_twisted_pauli_support: int
    status: str
    claim_scope: str

    @property
    def passed(self) -> bool:
        return self.status.startswith("PASS")

    def to_dict(self) -> dict[str, Any]:
        return {
            "qubit_count": self.qubit_count,
            "t_gate_count": self.t_gate_count,
            "clifford_gate_count": self.clifford_gate_count,
            "frame_canonical_pair_gap": self.frame_canonical_pair_gap,
            "residual_maximum_bond": self.residual_maximum_bond,
            "standard_mps_maximum_bond": self.standard_mps_maximum_bond,
            "cumulative_discarded_weight": self.cumulative_discarded_weight,
            "phase_aligned_state_gap": self.phase_aligned_state_gap,
            "residual_norm_gap": self.residual_norm_gap,
            "maximum_twisted_pauli_support": self.maximum_twisted_pauli_support,
            "status": self.status,
            "claim_scope": self.claim_scope,
        }


@dataclass(frozen=True, slots=True)
class CAMPSScalableHoldout:
    seed: int
    qubit_count: int
    circuit_depth: int
    t_gate_count: int
    clifford_gate_count: int
    frame_canonical_pair_gap: int
    residual_maximum_bond: int
    standard_mps_maximum_bond: int
    residual_norm_gap: float
    camps_discarded_weight: float
    standard_mps_discarded_weight: float
    maximum_twisted_pauli_support: int
    statevector_materialized: bool
    status: str

    @property
    def passed(self) -> bool:
        return self.status.startswith("PASS")

    def to_dict(self) -> dict[str, Any]:
        return {
            "seed": self.seed,
            "qubit_count": self.qubit_count,
            "circuit_depth": self.circuit_depth,
            "t_gate_count": self.t_gate_count,
            "clifford_gate_count": self.clifford_gate_count,
            "frame_canonical_pair_gap": self.frame_canonical_pair_gap,
            "residual_maximum_bond": self.residual_maximum_bond,
            "standard_mps_maximum_bond": self.standard_mps_maximum_bond,
            "residual_norm_gap": self.residual_norm_gap,
            "camps_discarded_weight": self.camps_discarded_weight,
            "standard_mps_discarded_weight": self.standard_mps_discarded_weight,
            "maximum_twisted_pauli_support": self.maximum_twisted_pauli_support,
            "statevector_materialized": self.statevector_materialized,
            "status": self.status,
        }


@dataclass(frozen=True, slots=True)
class CAMPSRuntimeCertificate:
    bounded_exact: CAMPSBoundedCertificate
    scalable_holdouts: tuple[CAMPSScalableHoldout, ...]
    status: str
    claim_scope: str
    source_method: str = (
        "Clifford-augmented MPS: symplectic Clifford frame plus residual MPS Pauli rotations; "
        "bounded by residual entanglement and magic placement"
    )

    @property
    def passed(self) -> bool:
        return self.status.startswith("PASS")

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "bounded_exact": self.bounded_exact.to_dict(),
            "scalable_holdouts": [item.to_dict() for item in self.scalable_holdouts],
            "status": self.status,
            "claim_scope": self.claim_scope,
            "source_method": self.source_method,
        }
        payload["sha256"] = hashlib.sha256(
            json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        return payload


def _apply_statevector_one(state: np.ndarray, gate: np.ndarray, site: int, qubit_count: int) -> None:
    tensor = state.reshape((2,) * qubit_count)
    moved = np.moveaxis(tensor, site, 0).reshape(2, -1)
    moved = gate @ moved
    state[:] = np.moveaxis(moved.reshape((2,) + (2,) * (qubit_count - 1)), 0, site).reshape(-1)


def _apply_statevector_two(state: np.ndarray, gate: np.ndarray, first: int, second: int, qubit_count: int) -> None:
    tensor = state.reshape((2,) * qubit_count)
    moved = np.moveaxis(tensor, (first, second), (0, 1))
    shape = moved.shape
    transformed = gate @ moved.reshape(4, -1)
    moved = transformed.reshape(shape)
    state[:] = np.moveaxis(moved, (0, 1), (first, second)).reshape(-1)


def _apply_direct(state: np.ndarray, gate: str, qubits: Sequence[int], qubit_count: int) -> None:
    name = gate.upper()
    if name in _SINGLE:
        _apply_statevector_one(state, _SINGLE[name], int(qubits[0]), qubit_count)
    elif name in _TWO:
        _apply_statevector_two(state, _TWO[name], int(qubits[0]), int(qubits[1]), qubit_count)
    else:
        raise ValueError(f"Unsupported direct-reference gate {gate!r}")


def _apply_standard_mps(
    state: MatrixProductState,
    gate: str,
    qubits: Sequence[int],
    *,
    max_bond: int,
    per_gate_discarded_budget: float,
) -> tuple[float, int]:
    name = gate.upper()
    if name in _SINGLE:
        state.apply_one_site_gate(int(qubits[0]), _SINGLE[name])
        return 0.0, state.max_bond
    if name in _TWO:
        return state.apply_two_site_gate(
            int(qubits[0]), int(qubits[1]), _TWO[name],
            max_bond=max_bond,
            discarded_weight_budget=per_gate_discarded_budget,
        )
    raise ValueError(f"Unsupported MPS gate {gate!r}")


def _phase_aligned_gap(reference: np.ndarray, candidate: np.ndarray) -> float:
    overlap = np.vdot(reference, candidate)
    if abs(overlap) > 0.0:
        candidate = candidate * np.exp(-1.0j * np.angle(overlap))
    return float(np.linalg.norm(reference - candidate))


def _bounded_operations(qubit_count: int) -> tuple[tuple[str, tuple[int, ...]], ...]:
    operations: list[tuple[str, tuple[int, ...]]] = []
    for q in range(qubit_count):
        operations.append(("H" if q % 2 == 0 else "S", (q,)))
    for left in range(0, qubit_count - 1, 2):
        operations.append(("CNOT", (left, left + 1)))
    for q in (0, 2, 5, 7, 9, 11):
        if q < qubit_count:
            operations.append(("T", (q,)))
    for left in range(1, qubit_count - 1, 2):
        operations.append(("CZ", (left, left + 1)))
    for q in range(qubit_count):
        if q % 3 == 0:
            operations.append(("H", (q,)))
    for q in (1, 4):
        if q < qubit_count:
            operations.append(("T", (q,)))
    for left in range(0, qubit_count - 1):
        if left % 3 == 1:
            operations.append(("CNOT", (left, left + 1)))
    return tuple(operations)


def qualify_bounded_camps_exact(
    *,
    qubit_count: int = 12,
    max_bond: int = 256,
    tolerance: float = 1e-10,
) -> CAMPSBoundedCertificate:
    n = int(qubit_count)
    runtime = CliffordAugmentedMPS(n, max_bond=max_bond, discarded_weight_budget=0.0)
    standard = MatrixProductState.product_state([0] * n)
    direct = np.zeros(1 << n, dtype=np.complex128)
    direct[0] = 1.0
    clifford_operations: list[tuple[str, tuple[int, ...]]] = []
    standard_maximum = 1
    for gate, qubits in _bounded_operations(n):
        _apply_direct(direct, gate, qubits, n)
        _, used = _apply_standard_mps(
            standard, gate, qubits, max_bond=1 << (n // 2), per_gate_discarded_budget=0.0
        )
        standard_maximum = max(standard_maximum, used, standard.max_bond)
        if gate == "T":
            runtime.apply_t(qubits[0])
        else:
            runtime.apply_clifford(gate, *qubits)
            clifford_operations.append((gate, qubits))

    candidate = runtime.residual.to_statevector(maximum_qubits=n) * runtime.global_phase
    for gate, qubits in clifford_operations:
        _apply_direct(candidate, gate, qubits, n)
    gap = _phase_aligned_gap(direct, candidate)
    frame_gap = runtime.frame.canonical_pair_gap()
    norm_gap = runtime.residual_norm_gap()
    passed = (
        gap <= tolerance
        and frame_gap == 0
        and norm_gap <= tolerance
        and runtime.cumulative_discarded_weight <= tolerance
    )
    return CAMPSBoundedCertificate(
        qubit_count=n,
        t_gate_count=runtime.t_gate_count,
        clifford_gate_count=runtime.frame.gate_count,
        frame_canonical_pair_gap=frame_gap,
        residual_maximum_bond=runtime.maximum_used_bond,
        standard_mps_maximum_bond=standard_maximum,
        cumulative_discarded_weight=runtime.cumulative_discarded_weight,
        phase_aligned_state_gap=gap,
        residual_norm_gap=norm_gap,
        maximum_twisted_pauli_support=runtime.maximum_twisted_pauli_support,
        status="PASS_BOUNDED_EXACT_CAMPS_STATEVECTOR_EQUALITY" if passed else "FAIL_BOUNDED_CAMPS_CONTROL",
        claim_scope=(
            "Exact bounded Clifford+T equality against an independently evolved state vector; "
            "not a scalable arbitrary-magic certificate."
        ),
    )


def _structured_holdout_operations(
    qubit_count: int,
    *,
    depth: int,
    t_gate_count: int,
    seed: int,
) -> tuple[tuple[str, tuple[int, ...]], ...]:
    rng = np.random.default_rng(seed)
    operations: list[tuple[str, tuple[int, ...]]] = []
    delayed_count = min(4, max(0, t_gate_count // 8))
    early_count = t_gate_count - delayed_count
    early = np.linspace(0, qubit_count - 1, max(1, early_count), dtype=int)[:early_count]
    delayed = np.linspace(1, qubit_count - 2, max(1, delayed_count), dtype=int)[:delayed_count]
    early_set = set(int(value) for value in early)
    for q in range(qubit_count):
        gate = "H" if q in early_set or rng.integers(0, 2) else "S"
        operations.append((gate, (q,)))
    for q in sorted(early_set):
        operations.append(("T", (q,)))
    for layer in range(depth):
        for q in range(qubit_count):
            draw = int(rng.integers(0, 3))
            operations.append((("H", "S", "SDG")[draw], (q,)))
        offset = layer & 1
        two_gate = "CNOT" if layer % 3 != 1 else "CZ"
        for left in range(offset, qubit_count - 1, 2):
            if two_gate == "CNOT" and (layer + left) % 4 >= 2:
                operations.append((two_gate, (left + 1, left)))
            else:
                operations.append((two_gate, (left, left + 1)))
        if layer == 0:
            for q in sorted(set(int(value) for value in delayed)):
                operations.append(("T", (q,)))
    return tuple(operations)


def qualify_structured_200_camps_holdout(
    *,
    qubit_count: int = 200,
    circuit_depth: int = 4,
    t_gate_count: int = 32,
    seeds: Sequence[int] = (271828, 314159, 161803),
    camps_max_bond: int = 16,
    standard_mps_max_bond: int = 16,
    discarded_weight_budget: float = 1e-10,
) -> tuple[CAMPSScalableHoldout, ...]:
    results: list[CAMPSScalableHoldout] = []
    for seed in seeds:
        runtime = CliffordAugmentedMPS(
            qubit_count, max_bond=camps_max_bond, discarded_weight_budget=discarded_weight_budget
        )
        standard = MatrixProductState.product_state([0] * qubit_count)
        standard_maximum = 1
        standard_discarded = 0.0
        operations = _structured_holdout_operations(
            qubit_count, depth=circuit_depth, t_gate_count=t_gate_count, seed=int(seed)
        )
        per_gate_budget = discarded_weight_budget / max(1, len(operations) * max(1, qubit_count - 1))
        for gate, qubits in operations:
            if gate == "T":
                runtime.apply_t(qubits[0])
            else:
                runtime.apply_clifford(gate, *qubits)
            discarded, used = _apply_standard_mps(
                standard,
                gate,
                qubits,
                max_bond=standard_mps_max_bond,
                per_gate_discarded_budget=per_gate_budget,
            )
            standard_discarded += discarded
            standard_maximum = max(standard_maximum, used, standard.max_bond)
        frame_gap = runtime.frame.canonical_pair_gap()
        norm_gap = runtime.residual_norm_gap()
        passed = (
            frame_gap == 0
            and norm_gap <= 1e-9
            and runtime.cumulative_discarded_weight <= discarded_weight_budget
            and runtime.maximum_used_bond < standard_maximum
        )
        results.append(
            CAMPSScalableHoldout(
                seed=int(seed),
                qubit_count=qubit_count,
                circuit_depth=circuit_depth,
                t_gate_count=runtime.t_gate_count,
                clifford_gate_count=runtime.frame.gate_count,
                frame_canonical_pair_gap=frame_gap,
                residual_maximum_bond=runtime.maximum_used_bond,
                standard_mps_maximum_bond=standard_maximum,
                residual_norm_gap=norm_gap,
                camps_discarded_weight=runtime.cumulative_discarded_weight,
                standard_mps_discarded_weight=standard_discarded,
                maximum_twisted_pauli_support=runtime.maximum_twisted_pauli_support,
                statevector_materialized=False,
                status=(
                    "PASS_STRUCTURED_200_CAMPS_HOLDOUT_STATEVECTOR_FREE"
                    if passed else "FAIL_STRUCTURED_200_CAMPS_HOLDOUT"
                ),
            )
        )
    return tuple(results)


def qualify_camps_runtime() -> CAMPSRuntimeCertificate:
    bounded = qualify_bounded_camps_exact()
    holdouts = qualify_structured_200_camps_holdout()
    passed = bounded.passed and all(item.passed for item in holdouts)
    return CAMPSRuntimeCertificate(
        bounded_exact=bounded,
        scalable_holdouts=holdouts,
        status="PASS_CURRENT_CAMPS_BOUNDED_AND_STRUCTURED_200" if passed else "FAIL_CURRENT_CAMPS_QUALIFICATION",
        claim_scope=(
            "Qualified only for the exact bounded control and the declared 200-qubit one-dimensional "
            "Clifford-frame/low-residual-magic holdout family. Arbitrary placement of magic, two-dimensional "
            "circuits, volume-law residual states and universal 200-qubit Clifford+T simulation remain OPEN."
        ),
    )
