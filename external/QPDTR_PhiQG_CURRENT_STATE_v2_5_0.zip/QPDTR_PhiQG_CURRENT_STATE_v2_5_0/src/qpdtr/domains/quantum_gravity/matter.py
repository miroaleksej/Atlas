from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
from functools import lru_cache
import json
from itertools import combinations

import numpy as np

from .quantum import (
    AdaptiveExecutionPolicy,
    AdaptiveQuantumDynamics,
    FiniteQuantumDynamics,
    LocalPauliHamiltonian,
    LocalPauliTerm,
    QuantumEvolutionCertificate,
    ScalableQuantumCertificate,
    TrajectoryEnsembleCertificate,
    ProcessorEmulatorCertificate,
    ProcessorNoiseSpec,
)


@dataclass(frozen=True, slots=True)
class SimplicialQubitMatterCertificate:
    qubit_count: int
    encoding: str
    simplex_count: int
    interaction_edge_count: int
    interaction_graph_bandwidth: int
    simplicial_complex_digest: str
    mass: float
    hopping: float
    interaction: float
    dephasing_rate: float
    elapsed_time: float
    exact_reference_qubits: int
    exact_reference: ScalableQuantumCertificate
    general_graph_contraction_control: ScalableQuantumCertificate
    scalable_closed_dynamics: ScalableQuantumCertificate
    scalable_open_dynamics: TrajectoryEnsembleCertificate
    processor_emulator: ProcessorEmulatorCertificate
    bounded_four_level_reference: QuantumEvolutionCertificate

    @property
    def passed(self) -> bool:
        return (
            self.qubit_count >= 50
            and self.encoding == "LOCAL_TWO_LEVEL_DEGREE_OF_FREEDOM_PER_SIMPLICIAL_VERTEX"
            and self.exact_reference.passed
            and self.general_graph_contraction_control.passed
            and self.scalable_closed_dynamics.passed
            and self.scalable_open_dynamics.passed
            and self.processor_emulator.passed
            and self.bounded_four_level_reference.closed_passed
            and self.bounded_four_level_reference.open_passed
        )

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["passed"] = self.passed
        payload["exact_reference"]["passed"] = self.exact_reference.passed
        payload["general_graph_contraction_control"]["passed"] = (
            self.general_graph_contraction_control.passed
        )
        payload["scalable_closed_dynamics"]["passed"] = self.scalable_closed_dynamics.passed
        payload["scalable_open_dynamics"]["passed"] = self.scalable_open_dynamics.passed
        payload["processor_emulator"]["passed"] = self.processor_emulator.passed
        if self.processor_emulator.lorentzian_memory is not None:
            payload["processor_emulator"]["lorentzian_memory"]["passed"] = self.processor_emulator.lorentzian_memory.passed
        if self.processor_emulator.toric_code is not None:
            payload["processor_emulator"]["toric_code"]["passed"] = self.processor_emulator.toric_code.passed
        if self.processor_emulator.retyped_open_systems is not None:
            payload["processor_emulator"]["retyped_open_systems"]["passed"] = self.processor_emulator.retyped_open_systems.passed
        for name, value in (
            ("accelerator_qualification", self.processor_emulator.accelerator_qualification),
            ("pulse_control", self.processor_emulator.pulse_control),
            ("adaptive_jump_control", self.processor_emulator.adaptive_jump_control),
            ("circuit_level_qec", self.processor_emulator.circuit_level_qec),
        ):
            if value is not None:
                payload["processor_emulator"][name]["passed"] = value.passed
        payload["bounded_four_level_reference"]["closed_passed"] = self.bounded_four_level_reference.closed_passed
        payload["bounded_four_level_reference"]["open_passed"] = self.bounded_four_level_reference.open_passed
        return payload


def _tetrahedral_chain(qubit_count: int) -> tuple[tuple[int, int, int, int], ...]:
    if qubit_count < 4:
        raise ValueError("The simplicial qubit sector requires at least four vertices")
    return tuple((index, index + 1, index + 2, index + 3) for index in range(qubit_count - 3))


def _simplicial_edges(simplices: tuple[tuple[int, int, int, int], ...]) -> tuple[tuple[int, int], ...]:
    edges = {
        tuple(sorted(edge))
        for simplex in simplices
        for edge in combinations(simplex, 2)
    }
    return tuple(sorted(edges))


def simplicial_qubit_hamiltonian(
    qubit_count: int,
    mass: float,
    hopping: float,
    interaction: float,
) -> tuple[LocalPauliHamiltonian, tuple[tuple[int, int, int, int], ...], tuple[tuple[int, int], ...]]:
    """Construct the active local many-qubit matter Hamiltonian on a tetrahedral chain.

    Each simplicial vertex owns one genuine two-level degree of freedom.  The Hamiltonian is

        H = sum_v m/2 (I - Z_v)
            + sum_(u,v) J/2 (X_u X_v + Y_u Y_v)
            + sum_(u,v) U Z_u Z_v.

    It is stored exclusively as local Pauli terms; no 2^n by 2^n matrix is materialized.
    """

    if qubit_count < 4 or mass < 0.0 or hopping <= 0.0 or interaction < 0.0:
        raise ValueError("Simplicial-qubit Hamiltonian parameters are inadmissible")
    simplices = _tetrahedral_chain(qubit_count)
    simplicial_edges = _simplicial_edges(simplices)
    # Every edge of the overlapping tetrahedral 1-skeleton participates in the active dynamics.
    # The graph has finite bandwidth three in the canonical vertex ordering, so arbitrary
    # two-site gates remain exact at the gate level and are executed through contiguous-block tensor contraction and SVD refactorization.
    edges = simplicial_edges
    terms: list[LocalPauliTerm] = []
    for site in range(qubit_count):
        # The identity part of m/2(I-Z) is a global phase and is deliberately omitted.
        terms.append(LocalPauliTerm((site,), ("Z",), -0.5 * mass, f"mass_Z_{site}"))
    for left, right in edges:
        terms.extend(
            (
                LocalPauliTerm((left, right), ("X", "X"), 0.5 * hopping, f"hop_XX_{left}_{right}"),
                LocalPauliTerm((left, right), ("Y", "Y"), 0.5 * hopping, f"hop_YY_{left}_{right}"),
                LocalPauliTerm((left, right), ("Z", "Z"), interaction, f"interaction_ZZ_{left}_{right}"),
            )
        )
    return LocalPauliHamiltonian(qubit_count, terms), simplices, edges



_GENERAL_GRAPH_CONTROL_EDGES: tuple[tuple[int, int], ...] = (
    (0, 1),
    (0, 5),
    (0, 8),
    (1, 10),
    (1, 13),
    (2, 3),
    (2, 4),
    (2, 12),
    (3, 11),
    (3, 13),
    (4, 6),
    (4, 10),
    (5, 8),
    (5, 11),
    (6, 7),
    (6, 9),
    (7, 11),
    (7, 12),
    (8, 13),
    (9, 10),
    (9, 12),
)


def general_graph_contraction_control(
    mass: float = 0.35,
    hopping: float = 0.12,
    interaction: float = 0.025,
    elapsed_time: float = 0.01,
    policy: AdaptiveExecutionPolicy | None = None,
) -> ScalableQuantumCertificate:
    """Bounded exact control for the active general-graph contraction-tree route.

    The deterministic 14-vertex 3-regular graph has canonical-label bandwidth twelve and a
    min-fill treewidth upper bound four.  It is deliberately outside the MPS interaction-span
    admission contract.  The same local Hamiltonian algebra is executed by an explicitly planned
    contraction tree under a 131072-element intermediate budget, forcing exact binary slicing.
    The final state is independently compared with matrix-free Krylov evolution.
    """

    qubit_count = 14
    terms: list[LocalPauliTerm] = []
    for site in range(qubit_count):
        terms.append(LocalPauliTerm((site,), ("Z",), -0.5 * mass, f"control_mass_Z_{site}"))
    for left, right in _GENERAL_GRAPH_CONTROL_EDGES:
        terms.extend(
            (
                LocalPauliTerm((left, right), ("X", "X"), 0.5 * hopping, f"control_XX_{left}_{right}"),
                LocalPauliTerm((left, right), ("Y", "Y"), 0.5 * hopping, f"control_YY_{left}_{right}"),
                LocalPauliTerm((left, right), ("Z", "Z"), interaction, f"control_ZZ_{left}_{right}"),
            )
        )
    hamiltonian = LocalPauliHamiltonian(qubit_count, terms)
    active_policy = policy or AdaptiveExecutionPolicy(
        statevector_memory_limit_bytes=1024,
        statevector_workspace_factor=6,
        mps_max_bond=32,
        mps_discarded_weight_budget=1e-12,
        mps_max_interaction_span=4,
        trotter_steps=1,
        trajectory_count=2,
        random_seed=20260728,
        contraction_optimizer="greedy",
        contraction_memory_limit_elements=131_072,
        contraction_max_slices=64,
        contraction_parallel_workers=2,
        contraction_statevector_max_qubits=18,
        contraction_backend="numpy",
        contraction_enable_mpi=False,
        force_contraction_tree=True,
    )
    active_policy.validate()
    if not active_policy.force_contraction_tree:
        raise ValueError("General-graph control requires the contraction-tree representation")
    return AdaptiveQuantumDynamics(hamiltonian, active_policy).execute_closed(elapsed_time)


def _bounded_four_level_reference(
    mass: float,
    hopping: float,
    dephasing_rate: float,
    elapsed_time: float,
) -> QuantumEvolutionCertificate:
    """Bounded four-level regression reference, not as the active qubit model."""

    adjacency = np.ones((4, 4), dtype=float) - np.eye(4)
    laplacian = np.diag(adjacency.sum(axis=1)) - adjacency
    hamiltonian = hopping * laplacian + mass * np.eye(4)
    initial = np.array([1.0, 0.0, 0.0, 0.0], dtype=complex)
    collapse = []
    for vertex in range(4):
        operator = np.zeros((4, 4), dtype=complex)
        operator[vertex, vertex] = np.sqrt(dephasing_rate)
        collapse.append(operator)
    return FiniteQuantumDynamics(hamiltonian, collapse).certify(initial, elapsed_time)


@lru_cache(maxsize=8)
def processor_emulator_control(
    processor_qubits: int = 8,
    processor_backend: str = "auto",
    processor_trajectory_count: int = 2048,
    processor_readout_shots: int = 8192,
    processor_t1: float = 60.0,
    processor_t2: float = 45.0,
    processor_one_qubit_gate_time: float = 0.04,
    processor_two_qubit_gate_time: float = 0.16,
    processor_readout_0_to_1: float = 0.015,
    processor_readout_1_to_0: float = 0.025,
    toric_lattice_size: int = 5,
    toric_trials: int = 256,
    toric_error_probability: float = 0.02,
    lorentzian_linewidth: float = 0.4,
    lorentzian_coupling_rate: float = 2.0,
    random_seed: int = 20260727,
) -> ProcessorEmulatorCertificate:
    """Cached bounded processor control executed by the sole adaptive quantum owner."""

    reference = LocalPauliHamiltonian(
        3,
        (
            LocalPauliTerm((0,), ("Z",), 0.1, "processor_owner_z0"),
            LocalPauliTerm((1,), ("Z",), 0.1, "processor_owner_z1"),
            LocalPauliTerm((2,), ("Z",), 0.1, "processor_owner_z2"),
            LocalPauliTerm((0, 1), ("X", "X"), 0.05, "processor_owner_xx01"),
        ),
    )
    owner = AdaptiveQuantumDynamics(
        reference,
        AdaptiveExecutionPolicy(trotter_steps=1, trajectory_count=2, random_seed=random_seed),
    )
    return owner.execute_processor_emulator(
        requested_backend=processor_backend,
        processor_qubits=processor_qubits,
        noise=ProcessorNoiseSpec(
            t1=processor_t1,
            t2=processor_t2,
            one_qubit_gate_time=processor_one_qubit_gate_time,
            two_qubit_gate_time=processor_two_qubit_gate_time,
            readout_0_to_1=processor_readout_0_to_1,
            readout_1_to_0=processor_readout_1_to_0,
        ),
        trajectory_count=processor_trajectory_count,
        readout_shots=processor_readout_shots,
        toric_lattice_size=toric_lattice_size,
        toric_trials=toric_trials,
        toric_error_probability=toric_error_probability,
        lorentzian_linewidth=lorentzian_linewidth,
        lorentzian_coupling_rate=lorentzian_coupling_rate,
    )


@lru_cache(maxsize=8)
def _simplicial_qubit_matter_control_cached(
    qubit_count: int = 50,
    mass: float = 0.35,
    hopping: float = 0.12,
    interaction: float = 0.025,
    dephasing_rate: float = 0.3,
    elapsed_time: float = 0.04,
    policy: AdaptiveExecutionPolicy | None = None,
    general_graph_policy: AdaptiveExecutionPolicy | None = None,
    processor_qubits: int = 8,
    processor_backend: str = "auto",
    processor_trajectory_count: int = 2048,
    processor_readout_shots: int = 8192,
    processor_t1: float = 60.0,
    processor_t2: float = 45.0,
    processor_one_qubit_gate_time: float = 0.04,
    processor_two_qubit_gate_time: float = 0.16,
    processor_readout_0_to_1: float = 0.015,
    processor_readout_1_to_0: float = 0.025,
    toric_lattice_size: int = 5,
    toric_trials: int = 256,
    toric_error_probability: float = 0.02,
    lorentzian_linewidth: float = 0.4,
    lorentzian_coupling_rate: float = 2.0,
) -> SimplicialQubitMatterCertificate:
    """Execute the active scalable local-qubit sector and its exact bounded references."""

    if dephasing_rate < 0.0 or elapsed_time <= 0.0:
        raise ValueError("Matter-control time and dephasing parameters are inadmissible")
    if policy is None or general_graph_policy is None:
        raise ValueError("Internal matter control requires normalized policies")
    active_policy = policy
    active_policy.validate()

    hamiltonian, simplices, edges = simplicial_qubit_hamiltonian(
        qubit_count=qubit_count,
        mass=mass,
        hopping=hopping,
        interaction=interaction,
    )
    scalable = AdaptiveQuantumDynamics(hamiltonian, active_policy)
    closed_certificate = scalable.execute_closed(elapsed_time)
    open_certificate = scalable.execute_dephasing_trajectories(elapsed_time, dephasing_rate)
    processor_certificate = processor_emulator_control(
        processor_qubits=processor_qubits,
        processor_backend=processor_backend,
        processor_trajectory_count=processor_trajectory_count,
        processor_readout_shots=processor_readout_shots,
        processor_t1=processor_t1,
        processor_t2=processor_t2,
        processor_one_qubit_gate_time=processor_one_qubit_gate_time,
        processor_two_qubit_gate_time=processor_two_qubit_gate_time,
        processor_readout_0_to_1=processor_readout_0_to_1,
        processor_readout_1_to_0=processor_readout_1_to_0,
        toric_lattice_size=toric_lattice_size,
        toric_trials=toric_trials,
        toric_error_probability=toric_error_probability,
        lorentzian_linewidth=lorentzian_linewidth,
        lorentzian_coupling_rate=lorentzian_coupling_rate,
        random_seed=active_policy.random_seed,
    )

    reference_qubits = min(6, qubit_count)
    reference_hamiltonian, _, _ = simplicial_qubit_hamiltonian(
        qubit_count=reference_qubits,
        mass=mass,
        hopping=hopping,
        interaction=interaction,
    )
    # Force MPS for the bounded reference so that it is compared against independent Krylov action.
    reference_policy = AdaptiveExecutionPolicy(
        exact_choi_max_qubits=active_policy.exact_choi_max_qubits,
        statevector_memory_limit_bytes=active_policy.statevector_memory_limit_bytes,
        statevector_workspace_factor=active_policy.statevector_workspace_factor,
        mps_max_bond=max(64, active_policy.mps_max_bond),
        mps_discarded_weight_budget=min(1e-26, active_policy.mps_discarded_weight_budget),
        trotter_steps=max(4, active_policy.trotter_steps),
        trajectory_count=active_policy.trajectory_count,
        random_seed=active_policy.random_seed,
        force_mps=True,
    )
    exact_reference = AdaptiveQuantumDynamics(reference_hamiltonian, reference_policy).execute_closed(elapsed_time)

    complex_payload = json.dumps(simplices, separators=(",", ":"), sort_keys=False).encode("utf-8")
    general_graph = general_graph_contraction_control(
        mass=mass,
        hopping=hopping,
        interaction=interaction,
        policy=general_graph_policy,
    )
    bounded_reference = _bounded_four_level_reference(mass, hopping, dephasing_rate, elapsed_time)
    return SimplicialQubitMatterCertificate(
        qubit_count=qubit_count,
        encoding="LOCAL_TWO_LEVEL_DEGREE_OF_FREEDOM_PER_SIMPLICIAL_VERTEX",
        simplex_count=len(simplices),
        interaction_edge_count=len(edges),
        interaction_graph_bandwidth=max(abs(right - left) for left, right in edges),
        simplicial_complex_digest=sha256(complex_payload).hexdigest(),
        mass=float(mass),
        hopping=float(hopping),
        interaction=float(interaction),
        dephasing_rate=float(dephasing_rate),
        elapsed_time=float(elapsed_time),
        exact_reference_qubits=reference_qubits,
        exact_reference=exact_reference,
        general_graph_contraction_control=general_graph,
        scalable_closed_dynamics=closed_certificate,
        scalable_open_dynamics=open_certificate,
        processor_emulator=processor_certificate,
        bounded_four_level_reference=bounded_reference,
    )


def simplicial_qubit_matter_control(
    qubit_count: int = 50,
    mass: float = 0.35,
    hopping: float = 0.12,
    interaction: float = 0.025,
    dephasing_rate: float = 0.3,
    elapsed_time: float = 0.04,
    policy: AdaptiveExecutionPolicy | None = None,
    general_graph_policy: AdaptiveExecutionPolicy | None = None,
    processor_qubits: int = 8,
    processor_backend: str = "auto",
    processor_trajectory_count: int = 2048,
    processor_readout_shots: int = 8192,
    processor_t1: float = 60.0,
    processor_t2: float = 45.0,
    processor_one_qubit_gate_time: float = 0.04,
    processor_two_qubit_gate_time: float = 0.16,
    processor_readout_0_to_1: float = 0.015,
    processor_readout_1_to_0: float = 0.025,
    toric_lattice_size: int = 5,
    toric_trials: int = 256,
    toric_error_probability: float = 0.02,
    lorentzian_linewidth: float = 0.4,
    lorentzian_coupling_rate: float = 2.0,
) -> SimplicialQubitMatterCertificate:
    """Canonical public entry that normalizes policies before cached owner execution."""

    normalized_policy = policy or AdaptiveExecutionPolicy()
    normalized_policy.validate()
    normalized_general = general_graph_policy or AdaptiveExecutionPolicy(
        exact_choi_max_qubits=normalized_policy.exact_choi_max_qubits,
        statevector_memory_limit_bytes=1024,
        statevector_workspace_factor=normalized_policy.statevector_workspace_factor,
        mps_max_bond=normalized_policy.mps_max_bond,
        mps_discarded_weight_budget=normalized_policy.mps_discarded_weight_budget,
        mps_max_interaction_span=normalized_policy.mps_max_interaction_span,
        trotter_steps=normalized_policy.trotter_steps,
        trajectory_count=2,
        random_seed=normalized_policy.random_seed + 1,
        contraction_optimizer=normalized_policy.contraction_optimizer,
        contraction_memory_limit_elements=normalized_policy.contraction_memory_limit_elements,
        contraction_max_slices=normalized_policy.contraction_max_slices,
        contraction_parallel_workers=normalized_policy.contraction_parallel_workers,
        contraction_statevector_max_qubits=normalized_policy.contraction_statevector_max_qubits,
        contraction_observable_max_count=normalized_policy.contraction_observable_max_count,
        contraction_backend=normalized_policy.contraction_backend,
        contraction_enable_mpi=normalized_policy.contraction_enable_mpi,
        force_contraction_tree=True,
    )
    normalized_general.validate()
    return _simplicial_qubit_matter_control_cached(
        qubit_count,
        mass,
        hopping,
        interaction,
        dephasing_rate,
        elapsed_time,
        normalized_policy,
        normalized_general,
        processor_qubits,
        processor_backend,
        processor_trajectory_count,
        processor_readout_shots,
        processor_t1,
        processor_t2,
        processor_one_qubit_gate_time,
        processor_two_qubit_gate_time,
        processor_readout_0_to_1,
        processor_readout_1_to_0,
        toric_lattice_size,
        toric_trials,
        toric_error_probability,
        lorentzian_linewidth,
        lorentzian_coupling_rate,
    )


# Thin, algorithm-free compatibility wrapper.  The active runtime calls
# ``simplicial_qubit_matter_control`` directly and no longer treats a four-level single-particle
# sector as a many-qubit model.
def tetrahedral_scalar_matter_control(
    mass_squared: float = 0.35,
    hopping: float = 0.12,
    dephasing_rate: float = 0.3,
    elapsed_time: float = 0.04,
) -> SimplicialQubitMatterCertificate:
    return simplicial_qubit_matter_control(
        qubit_count=50,
        mass=mass_squared,
        hopping=hopping,
        interaction=0.025,
        dephasing_rate=dephasing_rate,
        elapsed_time=elapsed_time,
    )
