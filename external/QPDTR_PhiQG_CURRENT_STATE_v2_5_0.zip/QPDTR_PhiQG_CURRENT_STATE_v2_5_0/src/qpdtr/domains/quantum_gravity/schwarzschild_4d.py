from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from typing import Any

import numpy as np
from scipy.integrate import solve_ivp


@dataclass(frozen=True, slots=True)
class GreybodyMode:
    angular_momentum: int
    frequency: float
    transmission: float
    reflection: float
    flux_gap: float


@dataclass(frozen=True, slots=True)
class Schwarzschild4DCertificate:
    schema: str
    mass: float
    angular_cutoff: int
    maximum_angular_cutoff: int
    adaptive_angular_converged: bool
    spectral_node_count: int
    radial_mode_count: int
    maximum_flux_gap: float
    low_frequency_s_wave_ratio_to_16_m2w2: float
    maximum_radial_refinement_gap: float
    maximum_angular_cutoff_spectral_gap: float
    angular_cutoff_correlation_gap: float
    angular_cutoff_population_gap: float
    correlation_rank_gap_17_33: float
    correlation_rank_gap_33_65: float
    reduced_population_rank_gap_17_33: float
    reduced_population_rank_gap_33_65: float
    kms_detailed_balance_gap: float
    modes: tuple[GreybodyMode, ...]
    status: str
    claim_boundary: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_BOUNDED_4D_ADAPTIVE_ANGULAR_AND_FINITE_TIME_DYNAMICS"

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["passed"] = self.passed
        return payload


def _digest(payload: dict[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), default=float).encode("utf-8")
    ).hexdigest()


def schwarzschild_tortoise(radius: float, mass: float) -> float:
    radius = float(radius)
    mass = float(mass)
    if mass <= 0.0 or radius <= 2.0 * mass:
        raise ValueError("Schwarzschild tortoise coordinate requires M>0 and r>2M")
    return float(radius + 2.0 * mass * np.log(radius / (2.0 * mass) - 1.0))


def scalar_regge_wheeler_potential(radius: float, angular_momentum: int, mass: float) -> float:
    radius = float(radius)
    ell = int(angular_momentum)
    mass = float(mass)
    if ell < 0 or radius <= 2.0 * mass:
        raise ValueError("Regge-Wheeler potential requires ell>=0 and r>2M")
    f = 1.0 - 2.0 * mass / radius
    return float(f * (ell * (ell + 1.0) / radius**2 + 2.0 * mass / radius**3))


def scalar_greybody_mode(
    angular_momentum: int,
    frequency: float,
    *,
    mass: float = 1.0,
    radius_max: float = 120.0,
    horizon_epsilon: float = 1e-5,
    rtol: float = 2e-9,
    atol: float = 2e-11,
) -> GreybodyMode:
    """Solve the 3+1D massless-scalar Regge-Wheeler scattering problem.

    The horizon solution is normalized to unit ingoing amplitude. At large radius it is
    decomposed into incoming/outgoing plane waves in the tortoise coordinate. The resulting
    transmission is 1/|A_in|^2 and is checked against flux conservation T+R=1.
    """

    ell = int(angular_momentum)
    omega = float(frequency)
    mass = float(mass)
    if ell < 0 or omega <= 0.0 or mass <= 0.0 or radius_max <= 2.0 * mass:
        raise ValueError("Greybody mode parameters are inadmissible")
    radius_h = 2.0 * mass * (1.0 + float(horizon_epsilon))
    rstar_h = schwarzschild_tortoise(radius_h, mass)
    u_h = np.exp(-1j * omega * rstar_h)
    p_h = -1j * omega * u_h

    def rhs(radius: float, state: np.ndarray) -> np.ndarray:
        u, p = state
        f = 1.0 - 2.0 * mass / radius
        potential = scalar_regge_wheeler_potential(radius, ell, mass)
        return np.asarray([p / f, -(omega**2 - potential) * u / f], dtype=complex)

    solution = solve_ivp(
        rhs,
        (radius_h, float(radius_max)),
        np.asarray([u_h, p_h], dtype=complex),
        method="DOP853",
        rtol=float(rtol),
        atol=float(atol),
    )
    if not solution.success:
        raise RuntimeError(f"BLOCKED_NUMERICAL:RADIAL_INTEGRATION_FAILED:{solution.message}")
    u, p = solution.y[:, -1]
    rstar = schwarzschild_tortoise(float(radius_max), mass)
    incoming_wave = 0.5 * (u - p / (1j * omega))
    outgoing_wave = 0.5 * (u + p / (1j * omega))
    a_in = incoming_wave / np.exp(-1j * omega * rstar)
    a_out = outgoing_wave / np.exp(1j * omega * rstar)
    transmission = float(1.0 / abs(a_in) ** 2)
    reflection = float(abs(a_out / a_in) ** 2)
    # Tiny overshoots are numerical only and are retained in flux_gap before clipping.
    flux_gap = float(abs(transmission + reflection - 1.0))
    return GreybodyMode(
        angular_momentum=ell,
        frequency=omega,
        transmission=float(np.clip(transmission, 0.0, 1.0)),
        reflection=float(np.clip(reflection, 0.0, 1.0)),
        flux_gap=flux_gap,
    )


def _trapezoid_weights(nodes: np.ndarray) -> np.ndarray:
    weights = np.zeros_like(nodes)
    weights[1:-1] = 0.5 * (nodes[2:] - nodes[:-2])
    weights[0] = 0.5 * (nodes[1] - nodes[0])
    weights[-1] = 0.5 * (nodes[-1] - nodes[-2])
    return weights


def _spectral_density(
    frequencies: np.ndarray,
    transmissions: np.ndarray,
    angular_cutoff: int,
    ultraviolet_scale: float = 1.2,
) -> np.ndarray:
    degeneracies = np.asarray([2 * ell + 1 for ell in range(angular_cutoff + 1)], dtype=float)
    weighted = degeneracies @ transmissions[: angular_cutoff + 1, :]
    return np.maximum(weighted * np.exp(-(frequencies / ultraviolet_scale) ** 2) / (4.0 * np.pi), 0.0)


def _bath_correlation(frequencies: np.ndarray, spectral: np.ndarray, times: np.ndarray) -> np.ndarray:
    weights = _trapezoid_weights(frequencies)
    return np.sum(
        (weights * spectral)[:, None] * np.exp(-1j * frequencies[:, None] * times[None, :]),
        axis=0,
    )


def _one_excitation_population(
    frequencies: np.ndarray,
    spectral: np.ndarray,
    times: np.ndarray,
    *,
    detector_gap: float = 0.30,
    coupling_scale: float = 0.08,
    broadening: float = 0.01,
) -> np.ndarray:
    weights = _trapezoid_weights(frequencies)
    couplings = coupling_scale * np.sqrt(np.maximum(spectral * weights, 0.0))

    def rhs(_: float, state: np.ndarray) -> np.ndarray:
        detector = state[0]
        bath = state[1:]
        detector_rate = -1j * detector_gap * detector - 1j * np.dot(couplings, bath)
        bath_rate = -(1j * frequencies + broadening) * bath - 1j * couplings * detector
        return np.concatenate(([detector_rate], bath_rate))

    initial = np.concatenate(([1.0 + 0.0j], np.zeros(len(frequencies), dtype=complex)))
    solution = solve_ivp(
        rhs,
        (float(times[0]), float(times[-1])),
        initial,
        t_eval=times,
        method="DOP853",
        rtol=1e-9,
        atol=1e-11,
    )
    if not solution.success:
        raise RuntimeError(f"BLOCKED_NUMERICAL:REDUCED_DYNAMICS_FAILED:{solution.message}")
    return np.abs(solution.y[0]) ** 2


def qualify_schwarzschild_4d_radial_modes(
    *,
    mass: float = 1.0,
    angular_cutoff: int | None = None,
    maximum_angular_cutoff: int = 8,
    spectral_node_count: int = 65,
    angular_correlation_tolerance: float = 3e-3,
    angular_population_tolerance: float = 2e-4,
) -> Schwarzschild4DCertificate:
    """Bounded 3+1D radial-mode qualification with adaptive angular truncation.

    The active owner solves actual spherical Regge-Wheeler scattering modes. If no
    angular cutoff is prescribed, it increases ell until both the bath correlation
    and the declared finite-time detector population are converged relative to the
    preceding cutoff. Frequency refinement uses nested 17/33/65 grids. This remains
    a finite-window certificate, not a full Wightman/process-tensor continuum theorem.
    """

    if maximum_angular_cutoff < 2:
        raise ValueError("maximum_angular_cutoff must be at least two")
    if spectral_node_count != 65:
        raise ValueError("The active nested frequency control uses exactly 65 nodes")
    if angular_cutoff is not None and not (1 <= angular_cutoff <= maximum_angular_cutoff):
        raise ValueError("Explicit angular_cutoff is outside the declared range")

    frequencies = np.linspace(0.03, 1.20, spectral_node_count)
    times = np.linspace(0.0, 20.0, 161)
    transmission = np.zeros((maximum_angular_cutoff + 1, spectral_node_count), dtype=float)
    modes_by_ell: list[list[GreybodyMode]] = []
    maximum_flux_gap = 0.0
    selected_cutoff: int | None = None
    adaptive_converged = False
    angular_spectral_gap = float("inf")
    angular_correlation_gap = float("inf")
    angular_population_gap = float("inf")
    previous_spectral: np.ndarray | None = None
    previous_correlation: np.ndarray | None = None
    previous_population: np.ndarray | None = None

    target_cutoff = angular_cutoff if angular_cutoff is not None else maximum_angular_cutoff
    for ell in range(target_cutoff + 1):
        current_modes: list[GreybodyMode] = []
        for index, omega in enumerate(frequencies):
            mode = scalar_greybody_mode(ell, float(omega), mass=mass)
            transmission[ell, index] = mode.transmission
            current_modes.append(mode)
            maximum_flux_gap = max(maximum_flux_gap, mode.flux_gap)
        modes_by_ell.append(current_modes)
        spectral = _spectral_density(frequencies, transmission, ell)
        correlation = _bath_correlation(frequencies, spectral, times)
        population = _one_excitation_population(frequencies, spectral, times)
        if previous_spectral is not None:
            angular_spectral_gap = float(np.max(np.abs(spectral - previous_spectral)))
            angular_correlation_gap = float(np.max(np.abs(correlation - previous_correlation)))
            angular_population_gap = float(np.max(np.abs(population - previous_population)))
            if (
                angular_cutoff is None
                and ell >= 2
                and angular_correlation_gap < angular_correlation_tolerance
                and angular_population_gap < angular_population_tolerance
            ):
                selected_cutoff = ell
                adaptive_converged = True
                break
        previous_spectral = spectral
        previous_correlation = correlation
        previous_population = population

    if selected_cutoff is None:
        selected_cutoff = int(target_cutoff)
        adaptive_converged = (
            angular_correlation_gap < angular_correlation_tolerance
            and angular_population_gap < angular_population_tolerance
        )
    modes = tuple(mode for ell_modes in modes_by_ell[: selected_cutoff + 1] for mode in ell_modes)
    transmission = transmission[: selected_cutoff + 1, :]

    low_mode = scalar_greybody_mode(0, 0.01 / mass, mass=mass, radius_max=400.0 * mass)
    asymptotic = 16.0 * (mass * low_mode.frequency) ** 2
    low_frequency_ratio = float(low_mode.transmission / asymptotic)

    refinement_points = [(0, 0.12), (1, 0.30), (2, 0.60)]
    if selected_cutoff >= 3:
        refinement_points.append((3, 1.00))
    if selected_cutoff >= 5:
        refinement_points.append((5, 1.10))
    if selected_cutoff >= 6:
        refinement_points.append((6, 1.18))
    radial_refinement_gap = 0.0
    for ell, omega in refinement_points:
        coarse = scalar_greybody_mode(ell, omega, mass=mass, radius_max=80.0 * mass)
        fine = scalar_greybody_mode(ell, omega, mass=mass, radius_max=160.0 * mass)
        radial_refinement_gap = max(radial_refinement_gap, abs(coarse.transmission - fine.transmission))

    spectral_full = _spectral_density(frequencies, transmission, selected_cutoff)
    nested_sizes = (17, 33, 65)
    correlations: list[np.ndarray] = []
    populations: list[np.ndarray] = []
    for size in nested_sizes:
        indices = np.linspace(0, spectral_node_count - 1, size, dtype=int)
        selected_frequencies = frequencies[indices]
        selected_spectral = spectral_full[indices]
        correlations.append(_bath_correlation(selected_frequencies, selected_spectral, times))
        populations.append(_one_excitation_population(selected_frequencies, selected_spectral, times))
    correlation_17_33 = float(np.max(np.abs(correlations[0] - correlations[1])))
    correlation_33_65 = float(np.max(np.abs(correlations[1] - correlations[2])))
    population_17_33 = float(np.max(np.abs(populations[0] - populations[1])))
    population_33_65 = float(np.max(np.abs(populations[1] - populations[2])))

    radius_detector = 8.0 * mass
    hawking_temperature = 1.0 / (8.0 * np.pi * mass)
    local_temperature = hawking_temperature / np.sqrt(1.0 - 2.0 * mass / radius_detector)
    gap = 0.30 / mass
    occupation = 1.0 / np.expm1(gap / local_temperature)
    detailed_balance = occupation / (occupation + 1.0)
    kms_gap = float(abs(detailed_balance - np.exp(-gap / local_temperature)))

    checks = {
        "flux": maximum_flux_gap < 5e-8,
        "low_frequency_s_wave": abs(low_frequency_ratio - 1.0) < 0.25,
        "radial_refinement": radial_refinement_gap < 5e-3,
        "adaptive_angular": adaptive_converged,
        "correlation_frequency_refinement": correlation_33_65 < correlation_17_33 and correlation_33_65 < 3e-3,
        "reduced_dynamics_frequency_refinement": population_33_65 < population_17_33 and population_33_65 < 5e-4,
        "kms": kms_gap < 1e-12,
    }
    status = (
        "PASS_BOUNDED_4D_ADAPTIVE_ANGULAR_AND_FINITE_TIME_DYNAMICS"
        if all(checks.values())
        else "FAIL_BOUNDED_4D_ADAPTIVE_ANGULAR_QUALIFICATION"
    )
    semantic: dict[str, Any] = {
        "schema": "qpdtr-schwarzschild-4d-radial-modes/v2",
        "mass": float(mass),
        "angular_cutoff": selected_cutoff,
        "maximum_angular_cutoff": int(maximum_angular_cutoff),
        "adaptive_angular_converged": adaptive_converged,
        "spectral_node_count": spectral_node_count,
        "radial_mode_count": len(modes),
        "maximum_flux_gap": maximum_flux_gap,
        "low_frequency_s_wave_ratio_to_16_m2w2": low_frequency_ratio,
        "maximum_radial_refinement_gap": radial_refinement_gap,
        "maximum_angular_cutoff_spectral_gap": angular_spectral_gap,
        "angular_cutoff_correlation_gap": angular_correlation_gap,
        "angular_cutoff_population_gap": angular_population_gap,
        "correlation_rank_gap_17_33": correlation_17_33,
        "correlation_rank_gap_33_65": correlation_33_65,
        "reduced_population_rank_gap_17_33": population_17_33,
        "reduced_population_rank_gap_33_65": population_33_65,
        "kms_detailed_balance_gap": kms_gap,
        "modes": modes,
        "status": status,
        "claim_boundary": (
            "Actual 3+1D scalar Regge-Wheeler radial modes are qualified with adaptive finite angular "
            "truncation and nested 17/33/65 frequency refinement for a declared finite-time one-excitation "
            "detector dynamics. The raw pointwise spectral increment need not be small; the certified objects "
            "are the bath correlation and reduced population on the declared window. Full 4D Wightman "
            "reconstruction, generic process-tensor tomography, simultaneous removal of radial/frequency/"
            "angular regulators and a theorem for arbitrary reduced dynamics remain open."
        ),
    }
    digest_payload = {**semantic, "modes": [asdict(mode) for mode in modes]}
    return Schwarzschild4DCertificate(**semantic, digest=_digest(digest_payload))

