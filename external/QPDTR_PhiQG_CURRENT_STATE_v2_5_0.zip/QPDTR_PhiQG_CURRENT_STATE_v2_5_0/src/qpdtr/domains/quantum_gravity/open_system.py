from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Callable, Sequence

import numpy as np
from scipy.linalg import expm


HamiltonianLike = np.ndarray | Callable[[float], np.ndarray]


@dataclass(frozen=True, slots=True)
class JumpTrajectoryResult:
    state: np.ndarray
    jump_count: int
    accepted_steps: int
    rejected_steps: int
    minimum_step: float
    maximum_step: float
    norm_gap: float


@dataclass(frozen=True, slots=True)
class AdaptiveJumpCertificate:
    dimension: int
    trajectory_count: int
    elapsed_time: float
    ensemble_trace_gap: float
    ensemble_min_eigenvalue: float
    exact_trace_distance: float
    maximum_trajectory_norm_gap: float
    mean_jump_count: float
    maximum_sampling_standard_error: float
    total_accepted_steps: int
    total_rejected_steps: int
    minimum_admitted_step: float
    maximum_admitted_step: float
    pseudomode_survival_gap: float

    @property
    def passed(self) -> bool:
        return (
            self.dimension >= 2
            and self.trajectory_count >= 256
            and self.ensemble_trace_gap < 1e-12
            and self.ensemble_min_eigenvalue > -1e-12
            and self.exact_trace_distance < 0.045
            and self.maximum_trajectory_norm_gap < 1e-11
            and self.maximum_sampling_standard_error < 0.04
            and self.total_accepted_steps > 0
            and self.total_rejected_steps >= 0
            and self.minimum_admitted_step > 0.0
            and self.maximum_admitted_step >= self.minimum_admitted_step
            and self.pseudomode_survival_gap < 2e-6
        )

    def to_dict(self) -> dict:
        return asdict(self) | {"passed": self.passed}


class AdaptiveQuantumJumpSolver:
    """Event-resolved Monte-Carlo wave-function owner.

    For a constant Hamiltonian the no-jump propagation is exact within floating-point matrix
    exponentiation.  For a time-dependent Hamiltonian a midpoint exponential is controlled by
    step doubling and rejected when the local state error exceeds the requested tolerance.
    Jump times are located by bisection on the monotonically decreasing no-jump norm.
    """

    def __init__(
        self,
        hamiltonian: HamiltonianLike,
        collapse_operators: Sequence[np.ndarray],
        *,
        relative_tolerance: float = 1e-8,
        absolute_tolerance: float = 1e-10,
        minimum_step: float = 1e-6,
        maximum_step: float = 0.05,
    ):
        initial_h = self._hamiltonian_at(hamiltonian, 0.0)
        if initial_h.ndim != 2 or initial_h.shape[0] != initial_h.shape[1]:
            raise ValueError("Hamiltonian must be square")
        if not np.allclose(initial_h, initial_h.conj().T, atol=1e-12, rtol=0.0):
            raise ValueError("Hamiltonian must be Hermitian")
        self.hamiltonian = hamiltonian
        self.dimension = initial_h.shape[0]
        self.collapse = tuple(np.asarray(operator, dtype=complex) for operator in collapse_operators)
        if any(operator.shape != initial_h.shape for operator in self.collapse):
            raise ValueError("Collapse operators must match Hamiltonian dimension")
        self.grams = tuple(operator.conj().T @ operator for operator in self.collapse)
        self.relative_tolerance = float(relative_tolerance)
        self.absolute_tolerance = float(absolute_tolerance)
        self.minimum_step = float(minimum_step)
        self.maximum_step = float(maximum_step)
        if (
            self.relative_tolerance <= 0.0
            or self.absolute_tolerance <= 0.0
            or self.minimum_step <= 0.0
            or self.maximum_step < self.minimum_step
        ):
            raise ValueError("Adaptive jump tolerances and steps are inadmissible")

    @staticmethod
    def _hamiltonian_at(hamiltonian: HamiltonianLike, time: float) -> np.ndarray:
        value = hamiltonian(time) if callable(hamiltonian) else hamiltonian
        return np.asarray(value, dtype=complex)

    def _effective(self, time: float) -> np.ndarray:
        value = self._hamiltonian_at(self.hamiltonian, time).copy()
        for gram in self.grams:
            value -= 0.5j * gram
        return value

    def _propagate(self, state: np.ndarray, time: float, step: float) -> tuple[np.ndarray, float]:
        midpoint = time + 0.5 * step
        full = expm(-1j * step * self._effective(midpoint)) @ state
        if not callable(self.hamiltonian):
            return full, 0.0
        first = expm(-0.5j * step * self._effective(time + 0.25 * step)) @ state
        half = expm(-0.5j * step * self._effective(time + 0.75 * step)) @ first
        scale = self.absolute_tolerance + self.relative_tolerance * max(np.linalg.norm(half), 1.0)
        return half, float(np.linalg.norm(half - full) / scale)

    def _locate_jump(
        self,
        state: np.ndarray,
        time: float,
        step: float,
        threshold: float,
    ) -> tuple[float, np.ndarray]:
        lower = 0.0
        upper = step
        upper_state, _ = self._propagate(state, time, upper)
        for _ in range(60):
            middle = 0.5 * (lower + upper)
            middle_state, _ = self._propagate(state, time, middle)
            if float(np.vdot(middle_state, middle_state).real) > threshold:
                lower = middle
            else:
                upper = middle
                upper_state = middle_state
            if upper - lower <= max(1e-13, 1e-11 * step):
                break
        return upper, upper_state

    def trajectory(
        self,
        initial_state: np.ndarray,
        elapsed_time: float,
        rng: np.random.Generator,
    ) -> JumpTrajectoryResult:
        state = np.asarray(initial_state, dtype=complex).reshape(-1)
        if state.size != self.dimension:
            raise ValueError("Initial state dimension differs from Hamiltonian dimension")
        norm = float(np.linalg.norm(state))
        if norm <= 0.0 or not np.isfinite(norm):
            raise ValueError("Initial state must be normalizable")
        state = state / norm
        elapsed = float(elapsed_time)
        if elapsed < 0.0:
            raise ValueError("Elapsed time must be non-negative")
        time = 0.0
        step = min(self.maximum_step, max(self.minimum_step, elapsed / 32.0 if elapsed else self.minimum_step))
        threshold = float(rng.random())
        jumps = accepted = rejected = 0
        min_seen = np.inf
        max_seen = 0.0
        while time < elapsed - 1e-15:
            step = min(step, elapsed - time)
            candidate, error_ratio = self._propagate(state, time, step)
            if error_ratio > 1.0 and step > self.minimum_step * (1.0 + 1e-12):
                step = max(self.minimum_step, 0.8 * step * error_ratio ** (-0.5))
                rejected += 1
                continue
            candidate_norm2 = float(np.vdot(candidate, candidate).real)
            if candidate_norm2 <= threshold and self.collapse:
                jump_step, pre_jump = self._locate_jump(state, time, step, threshold)
                pre_norm = float(np.linalg.norm(pre_jump))
                if pre_norm <= 0.0:
                    raise RuntimeError("No-jump trajectory vanished before a channel could be selected")
                normalized = pre_jump / pre_norm
                rates = np.array(
                    [float(np.vdot(normalized, gram @ normalized).real) for gram in self.grams],
                    dtype=float,
                )
                rates = np.clip(rates, 0.0, None)
                if rates.sum() <= 0.0:
                    # The threshold crossing can only be numerical in a dark state; preserve it.
                    state = normalized
                    time += jump_step
                else:
                    channel = int(rng.choice(len(self.collapse), p=rates / rates.sum()))
                    jumped = self.collapse[channel] @ normalized
                    jumped_norm = float(np.linalg.norm(jumped))
                    if jumped_norm <= 0.0:
                        raise RuntimeError("Selected jump operator annihilated the state")
                    state = jumped / jumped_norm
                    time += jump_step
                    jumps += 1
                threshold = float(rng.random())
                accepted += 1
                min_seen = min(min_seen, jump_step)
                max_seen = max(max_seen, jump_step)
                step = max(self.minimum_step, min(step - jump_step, self.maximum_step))
                if step <= 1e-15:
                    step = self.minimum_step
                continue
            state = candidate
            time += step
            accepted += 1
            min_seen = min(min_seen, step)
            max_seen = max(max_seen, step)
            if error_ratio < 0.05:
                step = min(self.maximum_step, 1.5 * step)
            elif error_ratio > 0.5:
                step = max(self.minimum_step, 0.9 * step * error_ratio ** (-0.5))
        final_norm = float(np.linalg.norm(state))
        if final_norm <= 0.0:
            raise RuntimeError("Final trajectory state is not normalizable")
        state = state / final_norm
        return JumpTrajectoryResult(
            state=state,
            jump_count=jumps,
            accepted_steps=accepted,
            rejected_steps=rejected,
            minimum_step=float(min_seen if np.isfinite(min_seen) else 0.0),
            maximum_step=float(max_seen),
            norm_gap=abs(float(np.vdot(state, state).real) - 1.0),
        )

    def ensemble(
        self,
        initial_state: np.ndarray,
        elapsed_time: float,
        trajectory_count: int,
        seed: int,
    ) -> tuple[np.ndarray, tuple[JumpTrajectoryResult, ...], float]:
        if trajectory_count < 2:
            raise ValueError("Trajectory ensemble requires at least two realizations")
        root = np.random.SeedSequence(int(seed))
        children = root.spawn(int(trajectory_count))
        results = tuple(
            self.trajectory(initial_state, elapsed_time, np.random.default_rng(child))
            for child in children
        )
        density = np.zeros((self.dimension, self.dimension), dtype=complex)
        observables = []
        for result in results:
            density += np.outer(result.state, result.state.conj())
            observables.append(np.abs(result.state) ** 2)
        density /= float(trajectory_count)
        samples = np.asarray(observables, dtype=float)
        standard_error = float(np.max(samples.std(axis=0, ddof=1) / np.sqrt(trajectory_count)))
        return density, results, standard_error


def lorentzian_pseudomode_survival(
    times: np.ndarray,
    *,
    linewidth: float,
    coupling_rate: float,
) -> np.ndarray:
    """One-excitation pseudomode embedding of a Lorentzian reservoir."""

    values = np.asarray(times, dtype=float)
    coupling = np.sqrt(0.5 * coupling_rate * linewidth)
    generator = np.array([[0.0, coupling], [coupling, -1.0j * linewidth]], dtype=complex)
    amplitudes = np.empty(values.size, dtype=complex)
    initial = np.array([1.0, 0.0], dtype=complex)
    for index, time in enumerate(values):
        amplitudes[index] = (expm(-1j * time * generator) @ initial)[0]
    return amplitudes


def lorentzian_analytic_survival(
    times: np.ndarray,
    *,
    linewidth: float,
    coupling_rate: float,
) -> np.ndarray:
    values = np.asarray(times, dtype=float)
    discriminant = complex(linewidth * linewidth - 2.0 * coupling_rate * linewidth) ** 0.5
    if abs(discriminant) < 1e-14:
        return np.exp(-0.5 * linewidth * values) * (1.0 + 0.5 * linewidth * values)
    return np.exp(-0.5 * linewidth * values) * (
        np.cosh(0.5 * discriminant * values)
        + linewidth / discriminant * np.sinh(0.5 * discriminant * values)
    )


def certify_adaptive_quantum_jumps(
    *,
    trajectory_count: int = 512,
    elapsed_time: float = 1.2,
    seed: int = 20260729,
) -> AdaptiveJumpCertificate:
    from .quantum import FiniteQuantumDynamics

    sigma_x = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=complex)
    sigma_z = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=complex)
    lowering = np.array([[0.0, 1.0], [0.0, 0.0]], dtype=complex)
    hamiltonian = 0.31 * sigma_z + 0.73 * sigma_x
    collapse = np.sqrt(0.42) * lowering
    initial = np.array([0.0, 1.0], dtype=complex)
    solver = AdaptiveQuantumJumpSolver(
        hamiltonian,
        (collapse,),
        relative_tolerance=1e-9,
        absolute_tolerance=1e-11,
        maximum_step=0.04,
    )
    ensemble, trajectories, standard_error = solver.ensemble(
        initial, elapsed_time, trajectory_count, seed
    )
    exact = FiniteQuantumDynamics(hamiltonian, (collapse,)).evolve_density(
        np.outer(initial, initial.conj()), elapsed_time
    )
    trace_distance = 0.5 * float(np.linalg.svd(ensemble - exact, compute_uv=False).sum())
    times = np.linspace(0.0, 20.0, 401)
    pseudomode = lorentzian_pseudomode_survival(times, linewidth=0.4, coupling_rate=2.0)
    analytic = lorentzian_analytic_survival(times, linewidth=0.4, coupling_rate=2.0)
    return AdaptiveJumpCertificate(
        dimension=2,
        trajectory_count=int(trajectory_count),
        elapsed_time=float(elapsed_time),
        ensemble_trace_gap=abs(complex(np.trace(ensemble)) - 1.0),
        ensemble_min_eigenvalue=float(np.min(np.linalg.eigvalsh(ensemble)).real),
        exact_trace_distance=trace_distance,
        maximum_trajectory_norm_gap=max(result.norm_gap for result in trajectories),
        mean_jump_count=float(np.mean([result.jump_count for result in trajectories])),
        maximum_sampling_standard_error=standard_error,
        total_accepted_steps=sum(result.accepted_steps for result in trajectories),
        total_rejected_steps=sum(result.rejected_steps for result in trajectories),
        minimum_admitted_step=min(result.minimum_step for result in trajectories),
        maximum_admitted_step=max(result.maximum_step for result in trajectories),
        pseudomode_survival_gap=float(np.max(np.abs(pseudomode - analytic))),
    )
