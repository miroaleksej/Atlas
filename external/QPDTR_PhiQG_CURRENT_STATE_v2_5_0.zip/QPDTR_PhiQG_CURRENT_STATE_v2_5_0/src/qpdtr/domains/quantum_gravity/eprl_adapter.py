from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import tomllib
from typing import Any, Protocol

import numpy as np

_OFFICIAL_REPOSITORY = "https://github.com/qg-cpt-marseille/sl2cfoam-next"
_PROVENANCE_SCHEMA = "qpdtr-sl2cfoam-backend-provenance-current"
_REQUIRED_JULIA_SYMBOLS = (
    "cinit",
    "cclear",
    "vertex_compute",
    "coherentstate_compute",
    "contract",
    "intertwiner_range",
)


def _canonical_digest(payload: Any) -> str:
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def source_tree_digest(root: Path) -> str:
    """Digest immutable backend sources while excluding binaries, tables and mutable caches."""

    root = root.resolve()
    excluded = {".git", "lib", "build", "data_sl2cfoam", "__pycache__", ".cache"}
    digest = hashlib.sha256()
    files = [
        path
        for path in root.rglob("*")
        if path.is_file() and not any(part in excluded for part in path.relative_to(root).parts)
    ]
    for path in sorted(files, key=lambda item: item.relative_to(root).as_posix()):
        relative = path.relative_to(root).as_posix().encode("utf-8")
        data = path.read_bytes()
        digest.update(len(relative).to_bytes(4, "big"))
        digest.update(relative)
        digest.update(len(data).to_bytes(8, "big"))
        digest.update(data)
    return digest.hexdigest()


def _is_sha256(value: Any) -> bool:
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value.lower()) is not None


def _is_commit_sha(value: Any) -> bool:
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{40}", value.lower()) is not None


def _finite_complex(value: Any) -> bool:
    return (
        isinstance(value, dict)
        and isinstance(value.get("real"), (int, float))
        and isinstance(value.get("imag"), (int, float))
        and math.isfinite(float(value["real"]))
        and math.isfinite(float(value["imag"]))
    )


def _complex_value(value: dict[str, Any]) -> complex:
    return complex(float(value["real"]), float(value["imag"]))


def _safe_artifact_path(workdir: Path, relative: Any) -> Path | None:
    if not isinstance(relative, str) or not relative:
        return None
    candidate = (workdir / relative).resolve()
    root = workdir.resolve()
    try:
        candidate.relative_to(root)
    except ValueError:
        return None
    return candidate


def load_raw_tensor(workdir: Path, artifact: dict[str, Any]) -> np.ndarray:
    """Load one raw tensor after repeating all artifact-integrity checks."""

    path = _safe_artifact_path(workdir, artifact.get("relative_path"))
    if path is None or not path.is_file():
        raise ValueError("Tensor artifact path is missing or escapes the execution directory")
    if _sha256_file(path) != artifact.get("sha256"):
        raise ValueError("Tensor artifact digest mismatch")
    shape = tuple(int(value) for value in artifact.get("shape", []))
    if not shape or any(value <= 0 for value in shape):
        raise ValueError("Tensor artifact shape is inadmissible")
    if artifact.get("dtype") != "float64_le":
        raise ValueError("Only little-endian float64 target tensors are admitted")
    expected = int(np.prod(shape, dtype=np.int64))
    data = np.fromfile(path, dtype=np.dtype("<f8"))
    if data.size != expected or expected != int(artifact.get("element_count", -1)):
        raise ValueError("Tensor artifact element count mismatch")
    return data.reshape(shape, order="F")


def assess_shell_sequence(sequence: list[dict[str, Any]], policy: dict[str, Any]) -> dict[str, Any]:
    """Recompute the active adaptive-shell certificate from reported amplitudes.

    The last successive-shell difference is an estimator only.  `converged` means that the
    configured finite stability window was met; it is not a theorem about the infinite sum.
    """

    minimum_shell = int(policy["minimum_shell"])
    maximum_shell = int(policy["maximum_shell"])
    minimum_samples = int(policy["minimum_samples"])
    stable_steps = int(policy["stable_steps"])
    absolute_tolerance = float(policy["absolute_tolerance"])
    relative_tolerance = float(policy["relative_tolerance"])
    relative_floor = float(policy["relative_floor"])

    shells = [int(entry["shell"]) for entry in sequence]
    if not shells or shells[0] != minimum_shell:
        raise ValueError("Shell sequence does not start at the configured minimum")
    if shells != list(range(minimum_shell, shells[-1] + 1)) or shells[-1] > maximum_shell:
        raise ValueError("Shell sequence must be a contiguous prefix of the configured grid")
    amplitudes = [_complex_value(entry["contracted_amplitude"]) for entry in sequence]
    increments: list[dict[str, Any]] = []
    stable_run = 0
    maximum_stable_run = 0
    for index in range(1, len(amplitudes)):
        absolute = float(abs(amplitudes[index] - amplitudes[index - 1]))
        scale = max(abs(amplitudes[index]), abs(amplitudes[index - 1]), relative_floor)
        relative = float(absolute / scale)
        stable = bool(absolute <= absolute_tolerance or relative <= relative_tolerance)
        stable_run = stable_run + 1 if stable else 0
        maximum_stable_run = max(maximum_stable_run, stable_run)
        increments.append(
            {
                "from_shell": shells[index - 1],
                "to_shell": shells[index],
                "absolute_successive_difference": absolute,
                "relative_successive_difference": relative,
                "stable": stable,
            }
        )
    converged = bool(len(sequence) >= minimum_samples and stable_run >= stable_steps)
    termination_reason = "stable_window" if converged else "maximum_shell_reached"
    if not converged and shells[-1] != maximum_shell:
        termination_reason = "premature_termination"
    return {
        "sequence": sequence,
        "increments": increments,
        "executed_shells": shells,
        "successive_shell_estimator": increments[-1]["absolute_successive_difference"] if increments else math.inf,
        "relative_successive_shell_estimator": increments[-1]["relative_successive_difference"] if increments else math.inf,
        "stable_steps_observed": stable_run,
        "maximum_stable_run": maximum_stable_run,
        "converged": converged,
        "termination_reason": termination_reason,
        "interpretation": "finite successive-shell stability certificate; not a rigorous infinite-tail bound",
    }


def _validate_julia_api(module_path: Path) -> tuple[bool, list[str]]:
    text = module_path.read_text(encoding="utf-8", errors="replace")
    missing = [symbol for symbol in _REQUIRED_JULIA_SYMBOLS if symbol not in text]
    return not missing, missing


@dataclass(frozen=True, slots=True)
class SL2CfoamRuntime:
    root: Path
    tables: Path
    julia: Path
    provenance_path: Path
    commit_sha: str
    source_digest: str
    library_path: Path
    library_digest: str
    julia_module_path: Path
    julia_module_digest: str
    table_artifacts: tuple[dict[str, str], ...]
    y_map: str
    build_identity_digest: str
    backend_identity_digest: str
    provenance: dict[str, Any]

    @classmethod
    def from_paths(
        cls,
        *,
        root: Path,
        tables: Path,
        julia: Path,
        provenance_path: Path,
    ) -> tuple[SL2CfoamRuntime | None, str]:
        root = root.expanduser().resolve()
        tables = tables.expanduser().resolve()
        julia = julia.expanduser().resolve()
        provenance_path = provenance_path.expanduser().resolve()
        if not root.is_dir():
            return None, "Pinned sl2cfoam-next root is unavailable"
        if not tables.is_dir():
            return None, "FASTWIGXJ table directory is unavailable"
        if not julia.is_file():
            return None, "Julia executable is unavailable"
        if not provenance_path.is_file():
            return None, "Backend provenance JSON is unavailable"
        try:
            provenance = json.loads(provenance_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            return None, f"Backend provenance JSON cannot be read: {exc}"
        if not isinstance(provenance, dict) or provenance.get("schema") != _PROVENANCE_SCHEMA:
            return None, "Backend provenance schema is not current"
        if provenance.get("backend") != "sl2cfoam-next":
            return None, "Backend provenance identity is not sl2cfoam-next"
        if provenance.get("upstream_repository") != _OFFICIAL_REPOSITORY:
            return None, "Backend provenance does not bind the official repository"
        commit_sha = str(provenance.get("commit_sha", "")).lower()
        if not _is_commit_sha(commit_sha):
            return None, "Backend provenance must contain an exact 40-character commit SHA"
        y_map = str(provenance.get("y_map", ""))
        if y_map not in {"gamma_j_plus_one", "gamma_j"}:
            return None, "Backend provenance contains an inadmissible Y-map convention"

        source_expected = str(provenance.get("source_tree_sha256", "")).lower()
        if not _is_sha256(source_expected):
            return None, "Backend provenance lacks source_tree_sha256"
        source_actual = source_tree_digest(root)
        if source_actual != source_expected:
            return None, f"Backend source-tree digest mismatch: expected {source_expected}, actual {source_actual}"

        library_relative = provenance.get("library_relative_path")
        module_relative = provenance.get("julia_module_relative_path")
        if not isinstance(library_relative, str) or not isinstance(module_relative, str):
            return None, "Backend provenance lacks library/module relative paths"
        library_path = (root / library_relative).resolve()
        module_path = (root / module_relative).resolve()
        try:
            library_path.relative_to(root)
            module_path.relative_to(root)
        except ValueError:
            return None, "Backend provenance path escapes the pinned root"
        if not library_path.is_file() or not module_path.is_file():
            return None, "Pinned backend lacks the declared library or Julia module"
        library_digest = _sha256_file(library_path)
        module_digest = _sha256_file(module_path)
        if library_digest != str(provenance.get("library_sha256", "")).lower():
            return None, "Compiled sl2cfoam library digest mismatch"
        if module_digest != str(provenance.get("julia_module_sha256", "")).lower():
            return None, "SL2Cfoam Julia module digest mismatch"
        api_ok, missing_symbols = _validate_julia_api(module_path)
        if not api_ok:
            return None, "SL2Cfoam Julia API is missing: " + ", ".join(missing_symbols)

        table_entries = provenance.get("fastwigxj_tables")
        if not isinstance(table_entries, list) or len(table_entries) != 2:
            return None, "Backend provenance must bind exactly one .3j and one .6j FASTWIGXJ table"
        admitted_tables: list[dict[str, str]] = []
        suffixes: set[str] = set()
        for entry in table_entries:
            if not isinstance(entry, dict):
                return None, "FASTWIGXJ provenance entry is malformed"
            relative = entry.get("relative_path")
            expected = str(entry.get("sha256", "")).lower()
            if not isinstance(relative, str) or not _is_sha256(expected):
                return None, "FASTWIGXJ provenance entry lacks path or digest"
            path = (tables / relative).resolve()
            try:
                path.relative_to(tables)
            except ValueError:
                return None, "FASTWIGXJ provenance path escapes the table directory"
            if not path.is_file() or _sha256_file(path) != expected:
                return None, f"FASTWIGXJ table digest mismatch: {relative}"
            suffixes.add(path.suffix)
            admitted_tables.append({"relative_path": relative, "sha256": expected})
        if suffixes != {".3j", ".6j"}:
            return None, "FASTWIGXJ provenance must contain one .3j and one .6j table"

        build = provenance.get("build")
        dependencies = provenance.get("dependencies")
        if not isinstance(build, dict) or not build.get("command") or not build.get("compiler"):
            return None, "Backend provenance lacks an explicit build command/compiler"
        if not isinstance(dependencies, dict) or not dependencies:
            return None, "Backend provenance lacks dependency identities"
        build_identity_digest = _canonical_digest({"build": build, "dependencies": dependencies})
        provenance_build_digest = str(provenance.get("build_identity_sha256", "")).lower()
        if provenance_build_digest != build_identity_digest:
            return None, "Backend build-identity digest mismatch"

        identity_payload = {
            "backend": "sl2cfoam-next",
            "upstream_repository": _OFFICIAL_REPOSITORY,
            "commit_sha": commit_sha,
            "source_tree_sha256": source_actual,
            "library_sha256": library_digest,
            "julia_module_sha256": module_digest,
            "fastwigxj_tables": admitted_tables,
            "y_map": y_map,
            "build_identity_sha256": build_identity_digest,
        }
        identity_digest = _canonical_digest(identity_payload)
        if provenance.get("backend_identity_sha256") != identity_digest:
            return None, "Backend identity digest mismatch"
        return (
            cls(
                root=root,
                tables=tables,
                julia=julia,
                provenance_path=provenance_path,
                commit_sha=commit_sha,
                source_digest=source_actual,
                library_path=library_path,
                library_digest=library_digest,
                julia_module_path=module_path,
                julia_module_digest=module_digest,
                table_artifacts=tuple(admitted_tables),
                y_map=y_map,
                build_identity_digest=build_identity_digest,
                backend_identity_digest=identity_digest,
                provenance=provenance,
            ),
            "runtime available",
        )

    @classmethod
    def discover(cls) -> tuple[SL2CfoamRuntime | None, str]:
        root_value = os.environ.get("QPDTR_SL2CFOAM_ROOT", "").strip()
        provenance_value = os.environ.get("QPDTR_SL2CFOAM_PROVENANCE", "").strip()
        tables_value = os.environ.get("QPDTR_SL2CFOAM_TABLES", "").strip()
        julia_value = os.environ.get("QPDTR_JULIA", "julia").strip()
        if not root_value:
            return None, "QPDTR_SL2CFOAM_ROOT is not configured"
        if not provenance_value:
            return None, "QPDTR_SL2CFOAM_PROVENANCE is not configured"
        if not tables_value:
            return None, "QPDTR_SL2CFOAM_TABLES is not configured"
        julia_resolved = shutil.which(julia_value)
        julia = Path(julia_resolved) if julia_resolved else Path(julia_value)
        return cls.from_paths(
            root=Path(root_value),
            tables=Path(tables_value),
            julia=julia,
            provenance_path=Path(provenance_value),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "root": str(self.root),
            "tables": str(self.tables),
            "julia": str(self.julia),
            "provenance_path": str(self.provenance_path),
            "commit_sha": self.commit_sha,
            "source_digest": self.source_digest,
            "library_path": str(self.library_path),
            "library_digest": self.library_digest,
            "julia_module_digest": self.julia_module_digest,
            "table_artifacts": list(self.table_artifacts),
            "y_map": self.y_map,
            "build_identity_digest": self.build_identity_digest,
            "backend_identity_digest": self.backend_identity_digest,
        }


@dataclass(frozen=True, slots=True)
class BackendInvocation:
    runtime: SL2CfoamRuntime
    bridge_path: Path
    request: dict[str, Any]
    request_digest: str
    request_script: Path
    response_toml: Path
    workdir: Path
    timeout_seconds: int


class BackendRunner(Protocol):
    def execute(self, invocation: BackendInvocation) -> dict[str, Any]: ...


class NativeJuliaRunner:
    """Launch-only plumbing for the official sl2cfoam-next Julia module."""

    @staticmethod
    def _julia_literal(value: Any) -> str:
        if value is None:
            return "nothing"
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, int):
            return str(value)
        if isinstance(value, float):
            if not math.isfinite(value):
                raise ValueError("Non-finite request number")
            return repr(value)
        if isinstance(value, str):
            return json.dumps(value, ensure_ascii=False)
        if isinstance(value, (list, tuple)):
            return "Any[" + ",".join(NativeJuliaRunner._julia_literal(item) for item in value) + "]"
        if isinstance(value, dict):
            entries = ",".join(
                f"{NativeJuliaRunner._julia_literal(str(key))}=>{NativeJuliaRunner._julia_literal(item)}"
                for key, item in sorted(value.items(), key=lambda pair: str(pair[0]))
            )
            return "Dict{String,Any}(" + entries + ")"
        raise TypeError(f"Unsupported request type: {type(value).__name__}")

    def execute(self, invocation: BackendInvocation) -> dict[str, Any]:
        runtime = invocation.runtime
        payload = {
            "request_digest": invocation.request_digest,
            "backend_identity_digest": runtime.backend_identity_digest,
            "commit_sha": runtime.commit_sha,
            "source_digest": runtime.source_digest,
            "library_digest": runtime.library_digest,
            "julia_module_digest": runtime.julia_module_digest,
            "build_identity_digest": runtime.build_identity_digest,
            "table_artifacts": list(runtime.table_artifacts),
            "y_map": runtime.y_map,
            "root": str(runtime.root),
            "tables": str(runtime.tables),
            "workdir": str(invocation.workdir),
            "response_toml": str(invocation.response_toml),
            "request": invocation.request,
        }
        invocation.request_script.write_text(
            "const QPDTR_REQUEST = " + self._julia_literal(payload) + "\n",
            encoding="utf-8",
        )
        completed = subprocess.run(
            [
                str(runtime.julia),
                "--startup-file=no",
                "--history-file=no",
                str(invocation.bridge_path),
                str(invocation.request_script),
            ],
            cwd=invocation.workdir,
            capture_output=True,
            text=True,
            timeout=invocation.timeout_seconds,
            check=False,
        )
        (invocation.workdir / "backend_stdout.txt").write_text(completed.stdout, encoding="utf-8")
        (invocation.workdir / "backend_stderr.txt").write_text(completed.stderr, encoding="utf-8")
        if completed.returncode != 0:
            raise RuntimeError(f"sl2cfoam-next bridge returned {completed.returncode}: {completed.stderr[-2000:]}")
        if not invocation.response_toml.is_file():
            raise RuntimeError("sl2cfoam-next bridge did not produce response TOML")
        with invocation.response_toml.open("rb") as stream:
            output = tomllib.load(stream)
        if not isinstance(output, dict):
            raise RuntimeError("sl2cfoam-next response is not a TOML table")
        return output


@dataclass(frozen=True, slots=True)
class EPRLProbeResult:
    status: str
    backend: str
    request: dict[str, Any]
    request_digest: str
    reason: str
    contract_checks: dict[str, bool]
    shell_certificate: dict[str, Any] | None = None
    tensor_shell_certificates: tuple[dict[str, Any], ...] = ()
    runtime: dict[str, Any] | None = None
    tensor_artifacts: tuple[dict[str, Any], ...] = ()
    output: dict[str, Any] | None = None
    workdir: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload.pop("workdir", None)
        return payload



class AdmittedVertexAmplitudeCache:
    """Content-addressed cache for already admitted sl2cfoam-next tensor evidence.

    The cache never computes or accepts amplitudes.  Only a PASS probe whose artifact hashes,
    shell stability and immutable backend identity were already checked by ``SL2CfoamAdapter``
    can be copied into it.  A cache hit repeats every file digest before returning metadata.
    """

    def __init__(self, root: Path):
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _key(probe: EPRLProbeResult) -> str:
        runtime = probe.runtime or {}
        identity = str(runtime.get("backend_identity_digest", ""))
        if not _is_sha256(identity) or not _is_sha256(probe.request_digest):
            raise ValueError("Admitted cache entry requires backend and request SHA-256 identities")
        return _canonical_digest({"backend_identity_digest": identity, "request_digest": probe.request_digest})

    def admit(self, probe: EPRLProbeResult) -> dict[str, Any]:
        if probe.status != "PASS" or probe.workdir is None or probe.output is None or probe.runtime is None:
            raise ValueError("Only a fully admitted EPRL probe can enter the vertex cache")
        key = self._key(probe)
        destination = self.root / key
        temporary = self.root / f".{key}.tmp"
        if temporary.exists():
            shutil.rmtree(temporary)
        temporary.mkdir(parents=True)
        source_root = Path(probe.workdir).resolve()
        cached_artifacts: list[dict[str, Any]] = []
        for index, artifact in enumerate(probe.tensor_artifacts):
            tensor = load_raw_tensor(source_root, artifact)
            source = _safe_artifact_path(source_root, artifact.get("relative_path"))
            if source is None:
                raise ValueError("Admitted artifact path is invalid")
            target_name = f"tensor_{index:04d}.bin"
            target = temporary / target_name
            shutil.copyfile(source, target)
            copied = dict(artifact)
            copied["relative_path"] = target_name
            copied["sha256"] = _sha256_file(target)
            copied["element_count"] = int(tensor.size)
            cached_artifacts.append(copied)
        metadata = {
            "schema": "qpdtr-admitted-eprl-vertex-cache-current",
            "cache_key": key,
            "request_digest": probe.request_digest,
            "backend_identity_digest": probe.runtime["backend_identity_digest"],
            "commit_sha": probe.runtime["commit_sha"],
            "source_digest": probe.runtime["source_digest"],
            "library_digest": probe.runtime["library_digest"],
            "julia_module_digest": probe.runtime["julia_module_digest"],
            "build_identity_digest": probe.runtime["build_identity_digest"],
            "shell_certificate": probe.shell_certificate,
            "tensor_shell_certificates": list(probe.tensor_shell_certificates),
            "tensor_artifacts": cached_artifacts,
            "contracted_amplitude": probe.output.get("contracted_amplitude"),
        }
        (temporary / "metadata.json").write_text(
            json.dumps(metadata, indent=2, sort_keys=True, ensure_ascii=False), encoding="utf-8"
        )
        if destination.exists():
            existing = self.lookup(probe.request_digest, probe.runtime["backend_identity_digest"])
            shutil.rmtree(temporary)
            return existing
        temporary.replace(destination)
        return self.lookup(probe.request_digest, probe.runtime["backend_identity_digest"])

    def lookup(self, request_digest: str, backend_identity_digest: str) -> dict[str, Any]:
        key = _canonical_digest(
            {"backend_identity_digest": backend_identity_digest, "request_digest": request_digest}
        )
        directory = self.root / key
        metadata_path = directory / "metadata.json"
        if not metadata_path.is_file():
            raise KeyError(key)
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        if (
            metadata.get("schema") != "qpdtr-admitted-eprl-vertex-cache-current"
            or metadata.get("cache_key") != key
            or metadata.get("request_digest") != request_digest
            or metadata.get("backend_identity_digest") != backend_identity_digest
        ):
            raise ValueError("Vertex cache metadata identity mismatch")
        for artifact in metadata.get("tensor_artifacts", []):
            path = _safe_artifact_path(directory, artifact.get("relative_path"))
            if path is None or not path.is_file() or _sha256_file(path) != artifact.get("sha256"):
                raise ValueError("Vertex cache artifact integrity mismatch")
        return metadata


class SL2CfoamAdapter:
    """Sole fail-closed adapter; it contains no EPRL amplitude surrogate."""

    def __init__(
        self,
        *,
        runtime: SL2CfoamRuntime | None = None,
        runner: BackendRunner | None = None,
        timeout_seconds: int = 21600,
    ):
        self.runtime = runtime
        self.runner = runner or NativeJuliaRunner()
        self.timeout_seconds = int(timeout_seconds)

    @staticmethod
    def _expected_amplitude_ids(request: dict[str, Any]) -> list[str]:
        entries = request.get("amplitude_configurations", [])
        return [str(item.get("configuration_id")) for item in entries if isinstance(item, dict)]

    @classmethod
    def _validate_artifacts(
        cls,
        output: dict[str, Any],
        request: dict[str, Any],
        workdir: Path,
        shell_certificate: dict[str, Any],
    ) -> tuple[bool, tuple[dict[str, Any], ...], tuple[dict[str, Any], ...]]:
        artifacts = output.get("tensor_artifacts")
        expected_ids = cls._expected_amplitude_ids(request)
        executed_shells = shell_certificate.get("executed_shells", [])
        if not isinstance(artifacts, list) or len(executed_shells) < 2:
            return False, (), ()
        shell_pair = tuple(int(value) for value in executed_shells[-2:])
        expected_role = (
            "single_vertex_tensor"
            if request.get("task") == "single_vertex_coherent_family"
            else "delta3_constituent_vertex_tensor"
        )
        by_key: dict[tuple[str, int], dict[str, Any]] = {}
        for artifact in artifacts:
            if not isinstance(artifact, dict):
                return False, (), ()
            path = _safe_artifact_path(workdir, artifact.get("relative_path"))
            shape = artifact.get("shape")
            element_count = artifact.get("element_count")
            configuration_id = artifact.get("configuration_id")
            shell = artifact.get("shell")
            valid = (
                path is not None
                and path.is_file()
                and artifact.get("dtype") == "float64_le"
                and artifact.get("storage") == "raw_column_major"
                and isinstance(shape, list)
                and len(shape) == 5
                and all(isinstance(value, int) and value > 0 for value in shape)
                and isinstance(element_count, int)
                and element_count == math.prod(shape)
                and path.stat().st_size == element_count * 8
                and artifact.get("sha256") == _sha256_file(path)
                and isinstance(configuration_id, str)
                and configuration_id in expected_ids
                and isinstance(shell, int)
                and shell in shell_pair
                and artifact.get("role") == expected_role
            )
            if not valid:
                return False, (), ()
            key = (configuration_id, shell)
            if key in by_key:
                return False, (), ()
            by_key[key] = dict(artifact)
        expected_keys = {(configuration_id, shell) for configuration_id in expected_ids for shell in shell_pair}
        if set(by_key) != expected_keys:
            return False, (), ()

        policy = request["shell_policy"]
        abs_tol = float(policy["tensor_absolute_tolerance"])
        rel_tol = float(policy["tensor_relative_tolerance"])
        floor = float(policy["relative_floor"])
        certificates: list[dict[str, Any]] = []
        final_artifacts: list[dict[str, Any]] = []
        previous_shell, final_shell = shell_pair
        for configuration_id in expected_ids:
            previous_artifact = by_key[(configuration_id, previous_shell)]
            final_artifact = by_key[(configuration_id, final_shell)]
            previous_tensor = load_raw_tensor(workdir, previous_artifact)
            final_tensor = load_raw_tensor(workdir, final_artifact)
            if previous_tensor.shape != final_tensor.shape:
                return False, (), ()
            absolute = float(np.linalg.norm(final_tensor - previous_tensor))
            denominator = max(float(np.linalg.norm(final_tensor)), float(np.linalg.norm(previous_tensor)), floor)
            relative = float(absolute / denominator)
            passed = bool(absolute <= abs_tol or relative <= rel_tol)
            certificates.append(
                {
                    "configuration_id": configuration_id,
                    "from_shell": previous_shell,
                    "to_shell": final_shell,
                    "absolute_frobenius_difference": absolute,
                    "relative_frobenius_difference": relative,
                    "absolute_tolerance": abs_tol,
                    "relative_tolerance": rel_tol,
                    "passed": passed,
                    "interpretation": "last-two-shell tensor stability; not an infinite-shell remainder bound",
                }
            )
            final_artifacts.append(final_artifact)
        return True, tuple(final_artifacts), tuple(certificates)

    @classmethod
    def _validate_response(
        cls,
        output: dict[str, Any],
        request: dict[str, Any],
        request_digest: str,
        runtime: SL2CfoamRuntime,
        workdir: Path,
    ) -> tuple[dict[str, bool], str, dict[str, Any] | None, tuple[dict[str, Any], ...], tuple[dict[str, Any], ...]]:
        expected_ids = cls._expected_amplitude_ids(request)
        reported = output.get("configuration_amplitudes")
        reported_ids = [str(item.get("configuration_id")) for item in reported] if isinstance(reported, list) else []
        configuration_valid = (
            isinstance(reported, list)
            and len(reported) == len(expected_ids)
            and reported_ids == expected_ids
            and all(_finite_complex(item.get("amplitude")) for item in reported)
        )

        shell_report = output.get("shell_convergence")
        shell_certificate: dict[str, Any] | None = None
        shell_report_valid = False
        if isinstance(shell_report, dict) and isinstance(shell_report.get("sequence"), list):
            try:
                shell_certificate = assess_shell_sequence(shell_report["sequence"], request["shell_policy"])
                shell_report_valid = (
                    shell_report.get("policy_digest") == _canonical_digest(request["shell_policy"])
                    and shell_report.get("increments") == shell_certificate["increments"]
                    and shell_report.get("executed_shells") == shell_certificate["executed_shells"]
                    and shell_report.get("converged") is shell_certificate["converged"]
                    and shell_report.get("termination_reason") == shell_certificate["termination_reason"]
                    and math.isclose(
                        float(shell_report.get("successive_shell_estimator", math.inf)),
                        float(shell_certificate["successive_shell_estimator"]),
                        rel_tol=1e-12,
                        abs_tol=1e-15,
                    )
                    and math.isclose(
                        float(shell_report.get("relative_successive_shell_estimator", math.inf)),
                        float(shell_certificate["relative_successive_shell_estimator"]),
                        rel_tol=1e-12,
                        abs_tol=1e-15,
                    )
                )
            except (KeyError, TypeError, ValueError, OverflowError):
                shell_certificate = None
                shell_report_valid = False

        artifacts_valid = False
        artifacts: tuple[dict[str, Any], ...] = ()
        tensor_certificates: tuple[dict[str, Any], ...] = ()
        if shell_certificate is not None:
            artifacts_valid, artifacts, tensor_certificates = cls._validate_artifacts(
                output, request, workdir, shell_certificate
            )

        checks = {
            "backend_identity": output.get("backend") == "sl2cfoam-next",
            "backend_identity_digest_binding": output.get("backend_identity_digest") == runtime.backend_identity_digest,
            "commit_binding": output.get("commit_sha") == runtime.commit_sha,
            "source_digest_binding": output.get("source_digest") == runtime.source_digest,
            "library_digest_binding": output.get("library_digest") == runtime.library_digest,
            "julia_module_digest_binding": output.get("julia_module_digest") == runtime.julia_module_digest,
            "build_identity_binding": output.get("build_identity_digest") == runtime.build_identity_digest,
            "table_binding": output.get("table_artifacts") == list(runtime.table_artifacts),
            "y_map_binding": output.get("y_map") == runtime.y_map == request.get("y_map"),
            "request_binding": output.get("request_digest") == request_digest,
            "precision_declared": isinstance(output.get("precision"), str) and bool(output.get("precision")),
            "boundary_family_binding": output.get("boundary_family_digest")
            == request.get("boundary_family", {}).get("family_digest"),
            "complex_contract_binding": (
                request.get("complex_contract_digest") == _canonical_digest(request.get("complex_contract", {}))
                and output.get("complex_contract_digest") == request.get("complex_contract_digest")
            ),
            "configuration_amplitudes_complete": configuration_valid,
            "finite_contracted_amplitude": _finite_complex(output.get("contracted_amplitude")),
            "adaptive_shell_report_recomputed": shell_report_valid,
            "last_two_shell_tensor_artifacts_admitted": artifacts_valid,
        }
        failed = [name for name, passed in checks.items() if not passed]
        reason = "response contract satisfied" if not failed else "failed checks: " + ", ".join(failed)
        return checks, reason, shell_certificate, artifacts, tensor_certificates

    def probe(self, request: dict[str, Any], workdir: Path) -> EPRLProbeResult:
        workdir = Path(workdir)
        workdir.mkdir(parents=True, exist_ok=True)
        request_digest = _canonical_digest(request)
        envelope = {
            "contract": "qpdtr-sl2cfoam-native-current",
            "request_digest": request_digest,
            "request": request,
        }
        (workdir / "eprl_request.json").write_text(
            json.dumps(envelope, indent=2, sort_keys=True, ensure_ascii=False), encoding="utf-8"
        )

        runtime = self.runtime
        reason = "runtime supplied"
        if runtime is None:
            runtime, reason = SL2CfoamRuntime.discover()
        if runtime is None:
            return EPRLProbeResult(
                "BLOCKED_EXTERNAL_BACKEND",
                "sl2cfoam-next",
                request,
                request_digest,
                reason,
                {},
                None,
                (),
                None,
                (),
                None,
                str(workdir),
            )
        if runtime.y_map != request.get("y_map"):
            return EPRLProbeResult(
                "FAIL_EXTERNAL_CONTRACT",
                "sl2cfoam-next",
                request,
                request_digest,
                "Pinned backend Y-map differs from the active model request",
                {"y_map_binding": False},
                None,
                (),
                runtime.to_dict(),
                (),
                None,
                str(workdir),
            )

        bridge = Path(__file__).with_name("sl2cfoam_bridge.jl")
        if not bridge.is_file():
            return EPRLProbeResult(
                "FAIL_EXTERNAL_CONTRACT",
                "sl2cfoam-next",
                request,
                request_digest,
                "Native bridge file is missing",
                {},
                None,
                (),
                runtime.to_dict(),
                (),
                None,
                str(workdir),
            )
        invocation = BackendInvocation(
            runtime=runtime,
            bridge_path=bridge,
            request=request,
            request_digest=request_digest,
            request_script=workdir / "eprl_request.jl",
            response_toml=workdir / "eprl_response.toml",
            workdir=workdir,
            timeout_seconds=self.timeout_seconds,
        )
        try:
            output = self.runner.execute(invocation)
        except (OSError, RuntimeError, subprocess.SubprocessError, tomllib.TOMLDecodeError) as exc:
            return EPRLProbeResult(
                "FAIL_EXTERNAL_BACKEND",
                "sl2cfoam-next",
                request,
                request_digest,
                str(exc),
                {},
                None,
                (),
                runtime.to_dict(),
                (),
                None,
                str(workdir),
            )
        (workdir / "eprl_response.json").write_text(
            json.dumps(output, indent=2, sort_keys=True, ensure_ascii=False), encoding="utf-8"
        )
        checks, contract_reason, shell_certificate, artifacts, tensor_certificates = self._validate_response(
            output, request, request_digest, runtime, workdir
        )
        if not checks or not all(checks.values()):
            status = "FAIL_EXTERNAL_CONTRACT"
            reason = contract_reason
        else:
            amplitude_stable = bool(shell_certificate and shell_certificate["converged"])
            tensors_stable = bool(tensor_certificates and all(item["passed"] for item in tensor_certificates))
            if amplitude_stable and tensors_stable:
                status = "PASS"
                reason = "provenance, adaptive amplitude shell stability and tensor shell stability passed"
            else:
                status = "PARTIAL_SHELL_NOT_CONVERGED"
                reason = (
                    f"valid backend result but finite shell stability is incomplete: "
                    f"amplitude={amplitude_stable}, tensors={tensors_stable}"
                )
        return EPRLProbeResult(
            status,
            "sl2cfoam-next",
            request,
            request_digest,
            reason,
            checks,
            shell_certificate,
            tensor_certificates,
            runtime.to_dict(),
            artifacts,
            output,
            str(workdir),
        )
