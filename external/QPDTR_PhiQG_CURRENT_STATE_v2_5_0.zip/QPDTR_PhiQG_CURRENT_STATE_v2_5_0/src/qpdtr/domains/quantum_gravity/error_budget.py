from __future__ import annotations

from dataclasses import asdict, dataclass
from math import isfinite, sqrt
from typing import Iterable, Sequence

import numpy as np


@dataclass(frozen=True, slots=True)
class ErrorComponent:
    owner: str
    quantity: str
    bound: float | None
    status: str
    method: str
    norm_or_metric: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ErrorBudget:
    """Typed heterogeneous error inventory.

    Components with unlike norms are never silently added.  A scalar joint bound
    is produced only for a declared compatible group.
    """

    components: tuple[ErrorComponent, ...]
    bounded_component_count: int
    unbounded_components: tuple[str, ...]
    failed_components: tuple[str, ...]
    status: str

    def to_dict(self) -> dict:
        return {
            "components": [c.to_dict() for c in self.components],
            "bounded_component_count": self.bounded_component_count,
            "unbounded_components": list(self.unbounded_components),
            "failed_components": list(self.failed_components),
            "status": self.status,
        }


@dataclass(frozen=True, slots=True)
class QuantumErrorAllocation:
    component_id: str
    owner: str
    metric: str
    observed_bound: float | None
    allocated_budget: float
    combination_rule: str
    compatible_group: str
    status: str

    @property
    def utilization(self) -> float | None:
        if self.observed_bound is None or self.allocated_budget <= 0:
            return None
        return float(self.observed_bound / self.allocated_budget)

    def to_dict(self) -> dict:
        return asdict(self) | {"utilization": self.utilization}


@dataclass(frozen=True, slots=True)
class UnifiedQuantumErrorBudget:
    allocations: tuple[QuantumErrorAllocation, ...]
    compatible_group_bounds: tuple[tuple[str, float], ...]
    compatible_group_budgets: tuple[tuple[str, float], ...]
    unbounded_components: tuple[str, ...]
    exceeded_components: tuple[str, ...]
    exceeded_groups: tuple[str, ...]
    status: str
    claim_scope: str

    def to_dict(self) -> dict:
        return {
            "allocations": [x.to_dict() for x in self.allocations],
            "compatible_group_bounds": {k: v for k, v in self.compatible_group_bounds},
            "compatible_group_budgets": {k: v for k, v in self.compatible_group_budgets},
            "unbounded_components": list(self.unbounded_components),
            "exceeded_components": list(self.exceeded_components),
            "exceeded_groups": list(self.exceeded_groups),
            "status": self.status,
            "claim_scope": self.claim_scope,
        }


def build_error_budget(components: list[ErrorComponent]) -> ErrorBudget:
    bounded = tuple(c.quantity for c in components if c.bound is not None and isfinite(c.bound))
    unbounded = tuple(c.quantity for c in components if c.bound is None or not isfinite(c.bound))
    failed = tuple(c.quantity for c in components if c.status.startswith("FAIL"))
    if failed:
        status = "FAILED"
    elif unbounded:
        status = "PARTIALLY_BOUNDED"
    else:
        status = "COMPONENTWISE_BOUNDED"
    return ErrorBudget(tuple(components), len(bounded), unbounded, failed, status)


def _combine_error_values(values: Sequence[float], rule: str) -> float:
    if rule == "SUM":
        return float(sum(values))
    if rule == "RSS":
        return float(sqrt(sum(value * value for value in values)))
    if rule in {"MAX", "SEPARATE"}:
        return float(max(values))
    raise ValueError(f"unsupported combination rule {rule}")


def build_unified_quantum_error_budget(
    allocations: Iterable[QuantumErrorAllocation],
) -> UnifiedQuantumErrorBudget:
    """Build one fail-closed spatial-temporal quantum error ledger.

    Each component is first checked against its own allocation.  Components that
    share a certified metric are then combined with one declared rule and the
    resulting group bound is checked against the group allocation obtained with
    that same rule.  Thus a collection of individually small errors can no longer
    silently exceed the joint process-tensor/TN budget.
    """

    rows = tuple(allocations)
    if len({row.component_id for row in rows}) != len(rows):
        raise ValueError("quantum error component IDs must be unique")
    if any(row.allocated_budget <= 0.0 or not isfinite(row.allocated_budget) for row in rows):
        raise ValueError("every quantum error component requires a finite positive allocation")

    unbounded = tuple(
        row.component_id
        for row in rows
        if row.observed_bound is None or not isfinite(row.observed_bound)
    )
    exceeded = tuple(
        row.component_id
        for row in rows
        if row.observed_bound is not None
        and isfinite(row.observed_bound)
        and row.observed_bound > row.allocated_budget
    )

    grouped: dict[str, list[QuantumErrorAllocation]] = {}
    for row in rows:
        grouped.setdefault(row.compatible_group, []).append(row)

    group_bounds: list[tuple[str, float]] = []
    group_budgets: list[tuple[str, float]] = []
    exceeded_groups: list[str] = []
    for group, items in sorted(grouped.items()):
        rules = {item.combination_rule for item in items}
        if len(rules) != 1:
            raise ValueError(f"compatible group {group} mixes combination rules")
        rule = next(iter(rules))
        observed_values = [
            float(item.observed_bound)
            for item in items
            if item.observed_bound is not None and isfinite(item.observed_bound)
        ]
        allocated_values = [float(item.allocated_budget) for item in items]
        group_budget = _combine_error_values(allocated_values, rule)
        group_budgets.append((group, group_budget))
        if observed_values:
            group_bound = _combine_error_values(observed_values, rule)
            group_bounds.append((group, group_bound))
            if group_bound > group_budget:
                exceeded_groups.append(group)

    if exceeded or exceeded_groups:
        status = "BLOCKED_UNIFIED_ERROR_BUDGET_EXCEEDED"
    elif unbounded:
        status = "OPEN_UNIFIED_ERROR_BUDGET_PARTIALLY_BOUNDED"
    else:
        status = "PASS_UNIFIED_SPATIAL_TEMPORAL_ERROR_BUDGET"

    return UnifiedQuantumErrorBudget(
        rows,
        tuple(group_bounds),
        tuple(group_budgets),
        unbounded,
        exceeded,
        tuple(exceeded_groups),
        status,
        (
            "Spatial tensor-network truncation, temporal process-tensor compression, "
            "intervention prediction, calibration and sampling terms share one ledger. "
            "Only components with the same declared metric are combined, and both "
            "component and group allocations are enforced."
        ),
    )


@dataclass(frozen=True, slots=True)
class ErrorInterferenceCertificate:
    """Correlation-aware aggregation for errors represented in one Hilbert norm.

    The tighter quadratic bound is certified only when the Gram matrix is
    supplied by explicit error vectors or by an independently certified
    positive-semidefinite upper-bound contract.  Otherwise the triangle bound
    remains the only admissible claim.
    """

    component_ids: tuple[str, ...]
    component_norms: tuple[float, ...]
    triangle_bound: float
    root_sum_square_bound: float
    interference_bound: float | None
    actual_aggregate_norm: float | None
    gram_minimum_eigenvalue: float | None
    gram_source: str
    status: str
    claim_scope: str

    def to_dict(self) -> dict:
        return asdict(self)


def build_interference_aware_error_bound(
    component_ids: Sequence[str],
    component_norms: Sequence[float],
    *,
    normalized_gram: np.ndarray | None = None,
    explicit_error_vectors: np.ndarray | None = None,
    certified_gram_upper_bound: bool = False,
) -> ErrorInterferenceCertificate:
    """Build a fail-closed interference-aware error certificate.

    ``explicit_error_vectors`` must have one row per component.  Its exact Gram
    matrix gives a certified aggregate norm.  A user-supplied normalized Gram
    matrix is accepted only as a certified bound when
    ``certified_gram_upper_bound`` is true; otherwise it is diagnostic and the
    triangle inequality remains authoritative.
    """

    ids = tuple(str(value) for value in component_ids)
    norms = np.asarray(tuple(float(value) for value in component_norms), dtype=float)
    if len(ids) != len(norms) or len(ids) == 0:
        raise ValueError('component ids and norms must be non-empty and aligned')
    if len(set(ids)) != len(ids):
        raise ValueError('component ids must be unique')
    if np.any(~np.isfinite(norms)) or np.any(norms < 0.0):
        raise ValueError('component norms must be finite and non-negative')

    triangle = float(np.sum(norms))
    rss = float(np.linalg.norm(norms))
    gram: np.ndarray | None = None
    actual: float | None = None
    source = 'NONE'
    certified = False

    if explicit_error_vectors is not None:
        vectors = np.asarray(explicit_error_vectors, dtype=float)
        if vectors.ndim != 2 or vectors.shape[0] != len(ids):
            raise ValueError('explicit error vectors must be a matrix with one row per component')
        vector_norms = np.linalg.norm(vectors, axis=1)
        if not np.allclose(vector_norms, norms, atol=1e-12, rtol=1e-10):
            raise ValueError('declared component norms disagree with explicit vectors')
        denom = np.outer(norms, norms)
        raw = vectors @ vectors.T
        gram = np.eye(len(ids), dtype=float)
        nonzero = denom > 0.0
        gram[nonzero] = raw[nonzero] / denom[nonzero]
        zero = norms == 0.0
        gram[zero, :] = 0.0
        gram[:, zero] = 0.0
        np.fill_diagonal(gram, np.where(zero, 0.0, 1.0))
        actual = float(np.linalg.norm(np.sum(vectors, axis=0)))
        source = 'EXPLICIT_ERROR_VECTORS'
        certified = True
    elif normalized_gram is not None:
        gram = np.asarray(normalized_gram, dtype=float)
        if gram.shape != (len(ids), len(ids)):
            raise ValueError('normalized Gram matrix has wrong shape')
        if not np.allclose(gram, gram.T, atol=1e-12):
            raise ValueError('normalized Gram matrix must be symmetric')
        source = 'DECLARED_NORMALIZED_GRAM_UPPER_BOUND' if certified_gram_upper_bound else 'DIAGNOSTIC_NORMALIZED_GRAM'
        certified = bool(certified_gram_upper_bound)

    if gram is None:
        return ErrorInterferenceCertificate(
            ids, tuple(float(x) for x in norms), triangle, rss, None, None, None,
            source, 'PASS_TRIANGLE_BOUND_ONLY',
            'No cross-component geometry was certified; cancellation is not claimed.',
        )

    eigenvalues = np.linalg.eigvalsh(gram)
    minimum = float(np.min(eigenvalues))
    diagonal = np.diag(gram)
    if minimum < -1e-10 or np.any(diagonal < -1e-12) or np.any(diagonal > 1.0 + 1e-10):
        return ErrorInterferenceCertificate(
            ids, tuple(float(x) for x in norms), triangle, rss, None, actual, minimum,
            source, 'BLOCKED_INVALID_GRAM_CERTIFICATE',
            'The proposed cross-error geometry is not a valid positive-semidefinite normalized Gram contract.',
        )

    quadratic = float(norms @ gram @ norms)
    interference = float(sqrt(max(0.0, quadratic)))
    if interference > triangle + 1e-10:
        return ErrorInterferenceCertificate(
            ids, tuple(float(x) for x in norms), triangle, rss, interference, actual, minimum,
            source, 'BLOCKED_GRAM_BOUND_EXCEEDS_TRIANGLE_CONTRACT',
            'A normalized Gram contract may not produce a bound above the triangle inequality.',
        )
    if certified:
        status = 'PASS_CERTIFIED_INTERFERENCE_BOUND'
        scope = 'The tighter bound is valid only for the declared common norm and certified Gram geometry.'
    else:
        status = 'PASS_DIAGNOSTIC_INTERFERENCE_TRIANGLE_REMAINS_AUTHORITATIVE'
        scope = 'Interference is diagnostic; the triangle bound remains the admissible claim.'
    return ErrorInterferenceCertificate(
        ids, tuple(float(x) for x in norms), triangle, rss, interference, actual,
        minimum, source, status, scope,
    )


def qualify_error_interference_control() -> ErrorInterferenceCertificate:
    """Exact finite-dimensional control with constructive cancellation."""

    vectors = np.asarray(
        [
            [0.030, 0.000, 0.000],
            [-0.022, 0.004, 0.000],
            [-0.006, -0.003, 0.001],
        ],
        dtype=float,
    )
    norms = np.linalg.norm(vectors, axis=1)
    certificate = build_interference_aware_error_bound(
        ('segment_1', 'segment_2', 'segment_3'),
        norms,
        explicit_error_vectors=vectors,
    )
    if certificate.actual_aggregate_norm is None or certificate.interference_bound is None:
        raise AssertionError('constructive interference control did not produce a certified bound')
    if abs(certificate.actual_aggregate_norm - certificate.interference_bound) > 1e-12:
        raise AssertionError('Gram aggregation must match the norm of explicit error vectors')
    return certificate
