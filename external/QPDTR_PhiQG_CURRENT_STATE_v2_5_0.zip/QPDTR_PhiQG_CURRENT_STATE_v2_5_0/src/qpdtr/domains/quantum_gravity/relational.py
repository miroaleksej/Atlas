from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np


@dataclass(frozen=True, slots=True)
class RelationalObservableCertificate:
    reference_dimension: int
    vertex_count: int
    resolution: float
    conditional_expectation: float
    conditional_variance: float
    povm_normalization_gap: float
    relabel_covariance_gap: float
    sharp_limit_distance: float

    @property
    def passed(self) -> bool:
        return (
            self.povm_normalization_gap < 1e-12
            and self.relabel_covariance_gap < 1e-12
            and self.conditional_variance >= -1e-14
        )

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["passed"] = self.passed
        return payload


def relational_povm_expectation(
    reference_fields: np.ndarray,
    observable: np.ndarray,
    target: np.ndarray,
    resolution: float,
    vertex_weights: np.ndarray | None = None,
) -> tuple[float, float, np.ndarray]:
    x = np.asarray(reference_fields, dtype=float)
    values = np.asarray(observable, dtype=float).reshape(-1)
    target_value = np.asarray(target, dtype=float).reshape(-1)
    if x.ndim != 2 or x.shape[0] != values.size or x.shape[1] != target_value.size:
        raise ValueError("Relational data dimensions are inconsistent")
    if resolution <= 0.0:
        raise ValueError("POVM resolution must be positive")
    base = np.ones(values.size, dtype=float) if vertex_weights is None else np.asarray(vertex_weights, dtype=float)
    if base.shape != values.shape or np.any(base < 0.0):
        raise ValueError("Vertex weights are inadmissible")
    distances = np.sum((x - target_value) ** 2, axis=1)
    weights = base * np.exp(-0.5 * distances / resolution**2)
    total = float(weights.sum())
    if total <= 0.0:
        raise ValueError("Relational POVM has zero support")
    probabilities = weights / total
    mean = float(np.dot(probabilities, values))
    variance = float(np.dot(probabilities, (values - mean) ** 2))
    return mean, variance, probabilities


def finite_relational_observable_control() -> RelationalObservableCertificate:
    reference = np.asarray(
        [
            (-2.0, 0.0, 0.0, 0.0),
            (0.0, 0.5, 0.5, 0.5),
            (0.0, 0.5, -0.5, -0.5),
            (0.0, -0.5, 0.5, -0.5),
            (0.0, -0.5, -0.5, 0.5),
            (2.0, 0.0, 0.0, 0.0),
        ],
        dtype=float,
    )
    observable = reference[:, 0] ** 2 + np.sum(reference[:, 1:] ** 2, axis=1)
    target = np.zeros(4, dtype=float)
    resolution = 0.65
    mean, variance, probabilities = relational_povm_expectation(reference, observable, target, resolution)

    permutation = np.asarray([5, 2, 0, 4, 1, 3], dtype=int)
    permuted_mean, _, _ = relational_povm_expectation(
        reference[permutation], observable[permutation], target, resolution
    )
    sharp_mean, _, _ = relational_povm_expectation(reference, observable, target, 0.08)
    nearest_value = float(observable[np.argmin(np.sum((reference - target) ** 2, axis=1))])
    return RelationalObservableCertificate(
        reference_dimension=4,
        vertex_count=reference.shape[0],
        resolution=resolution,
        conditional_expectation=mean,
        conditional_variance=variance,
        povm_normalization_gap=abs(float(probabilities.sum()) - 1.0),
        relabel_covariance_gap=abs(mean - permuted_mean),
        sharp_limit_distance=abs(sharp_mean - nearest_value),
    )
