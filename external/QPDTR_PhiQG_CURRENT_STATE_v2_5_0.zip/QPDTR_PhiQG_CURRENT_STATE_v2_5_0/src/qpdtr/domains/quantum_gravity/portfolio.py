from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from typing import Any, Mapping, Sequence


@dataclass(frozen=True, slots=True)
class MethodBinding:
    method_id: str
    authoritative_owner: str | None
    implementation_status: str
    evidence_status: str
    executable_on_current_cpu: bool
    claim_boundary: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class QuantumPortfolioCertificate:
    schema: str
    route_id: str
    method_bindings: tuple[MethodBinding, ...]
    executable_method_count: int
    blocked_external_method_count: int
    missing_method_count: int
    status: str
    route_executable_on_current_cpu: bool
    route_executable_with_blocked_accelerators_removed: bool
    digest: str

    @property
    def passed(self) -> bool:
        return self.status in {"PASS", "PASS_WITH_EXTERNAL_ACCELERATOR_BLOCKED"}

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["passed"] = self.passed
        return payload


_BINDINGS: dict[str, tuple[str | None, str, str]] = {
    "QCM-EXACT-SV": (
        "qpdtr.domains.quantum_gravity.quantum.AdaptiveQuantumDynamics.execute_closed",
        "IMPLEMENTED_BOUNDED",
        "Exact/matrix-free state vectors remain exponentially costly and are admitted only inside the resource gate.",
    ),
    "QCM-EXACT-DM": (
        "qpdtr.domains.quantum_gravity.quantum.certify_quantum_dynamics",
        "IMPLEMENTED_BOUNDED",
        "Exact density and Choi materialization are bounded by the exact-reference qubit gate.",
    ),
    "QCM-MPS-TEBD": (
        "qpdtr.domains.quantum_gravity.quantum.AdaptiveQuantumDynamics.execute_closed",
        "IMPLEMENTED",
        "Valid only while bond growth and discarded-weight budgets remain inside the certificate.",
    ),
    "QCM-TTN": (
        "qpdtr.domains.quantum_gravity.adaptive_ttn.PersistentAdaptiveTTN",
        "IMPLEMENTED",
        "Structured low/moderate-treewidth route; arbitrary volume-law dynamics are not claimed.",
    ),
    "QCM-ADAPTIVE-TTN": (
        "qpdtr.domains.quantum_gravity.adaptive_ttn.PersistentAdaptiveTTN",
        "IMPLEMENTED",
        "Local path exposure and tree rotations are active; scalability is conditional on truncation gates.",
    ),
    "QCM-GENERAL-TN": (
        "qpdtr.domains.quantum_gravity.quantum.AdaptiveQuantumDynamics.execute_closed",
        "IMPLEMENTED_BOUNDED",
        "General-graph contraction is exact or sliced only when the declared contraction budget is feasible.",
    ),
    "QCM-CONTRACTION-OPT": (
        "qpdtr.domains.quantum_gravity.quantum.ContractionTreeEngine",
        "IMPLEMENTED_BOUNDED",
        "The current release qualifies the optimizer on bounded CPU controls, not every graph family.",
    ),
    "QCM-SLICING": (
        "qpdtr.domains.quantum_gravity.quantum.ContractionTreeEngine",
        "IMPLEMENTED_BOUNDED",
        "Exact index slicing is available within the configured slice and memory limits.",
    ),
    "QCM-TEMPO": (
        "qpdtr.domains.quantum_gravity.tempo.qualify_process_tensor_memory",
        "IMPLEMENTED_BOUNDED",
        "The active bounded owner combines intervention-complete temporal memory with a site-factorized two-qubit/two-time TT/MPS process tensor, one enforced spatial-temporal error ledger and a real-device-derived IBM Manila Markov calibration baseline. Non-Markovian hardware identification and unbounded many-qubit scaling remain fail-closed.",
    ),
    "QCM-TRAJECTORIES": (
        "qpdtr.domains.quantum_gravity.quantum.AdaptiveQuantumDynamics.execute_trajectories",
        "IMPLEMENTED",
        "Sampling error and small-system density cross-checks remain mandatory.",
    ),
    "QCM-STABILIZER": (
        "qpdtr.domains.quantum_gravity.stabilizer.qualify_stabilizer_magic_runtime",
        "IMPLEMENTED",
        "Large-qubit claim applies to Clifford tableau dynamics only.",
    ),
    "QCM-STN-MAGIC": (
        "qpdtr.domains.quantum_gravity.camps.qualify_camps_runtime",
        "IMPLEMENTED_BOUNDED",
        "Magic injection is qualified only for the bounded/structured CAMPS branch.",
    ),
    "QCM-MULTIGPU": (
        "qpdtr.domains.quantum_gravity.backend_qualification.qualify_real_backends",
        "BLOCKED_EXTERNAL_BACKEND",
        "No multi-GPU or multi-node claim is admitted without real CUDA and MPI qualification.",
    ),
    "QCM-SYMMETRY": (
        None,
        "NOT_GENERICALLY_IMPLEMENTED",
        "Symmetry checks exist in domain controls, but no generic block-sparse quantum-runtime owner is present.",
    ),
    "QCM-CPTP-TT-LINDBLAD": (
        "qpdtr.domains.quantum_gravity.cptp_tensor_train.CPTPTensorTrainLindbladOwner",
        "IMPLEMENTED_BOUNDED",
        "Qualified for nearest-neighbour one-dimensional qubit GKSL dynamics with local jumps. Local purification makes every represented density positive semidefinite; bond and local-Kraus truncation ledgers remain mandatory.",
    ),
    "QCM-BASS": (
        "qpdtr.domains.quantum_gravity.basis_adaptive_sparse.BasisAdaptiveSparseStateOwner",
        "IMPLEMENTED_BOUNDED",
        "Approximate pure-state top-k simulation in an adaptively selected product basis; admitted only with a sparse-route certificate and explicit support/retention controls.",
    ),
    "QCM-FERMION-GAUSSIAN": (
        "qpdtr.domains.quantum_gravity.fermionic_gaussian.FermionicGaussianLindbladOwner",
        "IMPLEMENTED_BOUNDED",
        "Exact for Gaussian initial states under number-conserving quadratic Hamiltonians and linear gain/loss channels; interactions, pairing and non-Gaussian operations remain outside the active class.",
    ),
    "QCM-FEYNMAN-DD-LRW": (
        "qpdtr.domains.quantum_gravity.decision_diagram.PhasePolynomialDecisionDiagram",
        "IMPLEMENTED_BOUNDED",
        "Exact only for verified Z_8 multilinear phase-polynomial lowerings whose decision diagram remains inside the node budget; generic circuits are not admitted.",
    ),
    "QCM-CODE-COMPILED-TN": (
        "qpdtr.domains.quantum_gravity.code_compiled_tn.PermutationTrackedMPS",
        "IMPLEMENTED_BOUNDED",
        "Exact only after an external verified compilation certificate reduces every post-encoder layer to onsite diagonal gates and classical wire permutations.",
    ),
    "QCM-CAUSAL-CONE": (
        "qpdtr.domains.quantum_gravity.structural_router.compute_backward_causal_cone",
        "IMPLEMENTED",
        "Exact backward reduction for typed local observables, including measurement/feed-forward dependencies; it does not approximate excluded gates.",
    ),
    "QCM-PAULI-OBS": (
        "qpdtr.domains.quantum_gravity.structural_router.propagate_pauli_observable",
        "IMPLEMENTED_BOUNDED",
        "Statevector-free Heisenberg propagation of sparse Pauli observables. The accumulated discarded-coefficient l1 norm bounds expectation error; full-state and unrestricted sampling claims are excluded.",
    ),
    "QCM-GTN-BP": (
        "qpdtr.domains.quantum_gravity.structural_router.contract_graph_tensor_network_bp",
        "IMPLEMENTED_BOUNDED",
        "Exact graph tensor-network contraction on trees. Loopy belief propagation is fail-closed without a cluster or independent-reference error certificate.",
    ),
    "QCM-PHI-Q1000-ARFE": (
        "qpdtr.domains.quantum_gravity.structural_router.plan_resource_factorized_emulation",
        "IMPLEMENTED_BOUNDED",
        "Single observable-first resource-factorized owner. It combines exact causal reduction, typed patch owners, boundary contracts and one error ledger; generic exact 1000-qubit full-state simulation remains blocked.",
    ),
    "QCM-MERA": (
        None,
        "NOT_IMPLEMENTED",
        "No active MERA optimization/evolution owner is present.",
    ),
}


def _digest(payload: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ).hexdigest()


def qualify_method_route(
    route_id: str,
    method_ids: Sequence[str],
    evidence_status: Mapping[str, bool | str],
) -> QuantumPortfolioCertificate:
    """Bind a compiler-selected method route to current QPDTR owners.

    This function contains no emulator algorithm. It is a fail-closed capability/owner binding:
    absent owners remain missing, and unavailable accelerators remain externally blocked.
    """

    bindings: list[MethodBinding] = []
    for method_id in method_ids:
        owner, implementation, boundary = _BINDINGS.get(
            str(method_id),
            (None, "UNKNOWN_METHOD", "The method identifier is not registered in the QPDTR portfolio."),
        )
        raw = evidence_status.get(str(method_id), False)
        if isinstance(raw, bool):
            evidence = "PASS" if raw else "NOT_QUALIFIED"
        else:
            evidence = str(raw)
        executable = implementation.startswith("IMPLEMENTED") and evidence == "PASS"
        bindings.append(
            MethodBinding(
                method_id=str(method_id),
                authoritative_owner=owner,
                implementation_status=implementation,
                evidence_status=evidence,
                executable_on_current_cpu=executable,
                claim_boundary=boundary,
            )
        )

    missing = sum(
        binding.implementation_status in {"NOT_IMPLEMENTED", "NOT_GENERICALLY_IMPLEMENTED", "UNKNOWN_METHOD"}
        for binding in bindings
    )
    blocked = sum(binding.implementation_status == "BLOCKED_EXTERNAL_BACKEND" for binding in bindings)
    executable = sum(binding.executable_on_current_cpu for binding in bindings)
    required_nonaccelerators = [
        binding for binding in bindings if binding.implementation_status != "BLOCKED_EXTERNAL_BACKEND"
    ]
    cpu_without_accelerators = bool(required_nonaccelerators) and all(
        binding.executable_on_current_cpu for binding in required_nonaccelerators
    )
    full_cpu = bool(bindings) and all(binding.executable_on_current_cpu for binding in bindings)
    if missing:
        status = "PARTIAL_MISSING_OWNERS"
    elif blocked and cpu_without_accelerators:
        status = "PASS_WITH_EXTERNAL_ACCELERATOR_BLOCKED"
    elif full_cpu:
        status = "PASS"
    else:
        status = "PARTIAL_UNQUALIFIED_EVIDENCE"

    semantic = {
        "schema": "qpdtr-quantum-portfolio-binding/v1",
        "route_id": str(route_id),
        "method_bindings": [binding.to_dict() for binding in bindings],
        "executable_method_count": executable,
        "blocked_external_method_count": blocked,
        "missing_method_count": missing,
        "status": status,
        "route_executable_on_current_cpu": full_cpu,
        "route_executable_with_blocked_accelerators_removed": cpu_without_accelerators,
    }
    return QuantumPortfolioCertificate(
        schema=str(semantic["schema"]),
        route_id=str(semantic["route_id"]),
        method_bindings=tuple(bindings),
        executable_method_count=int(semantic["executable_method_count"]),
        blocked_external_method_count=int(semantic["blocked_external_method_count"]),
        missing_method_count=int(semantic["missing_method_count"]),
        status=str(semantic["status"]),
        route_executable_on_current_cpu=bool(semantic["route_executable_on_current_cpu"]),
        route_executable_with_blocked_accelerators_removed=bool(semantic["route_executable_with_blocked_accelerators_removed"]),
        digest=_digest(semantic),
    )


def registered_method_bindings() -> dict[str, dict[str, str | None]]:
    return {
        method_id: {
            "authoritative_owner": owner,
            "implementation_status": implementation,
            "claim_boundary": boundary,
        }
        for method_id, (owner, implementation, boundary) in sorted(_BINDINGS.items())
    }
