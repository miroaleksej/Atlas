from __future__ import annotations

from dataclasses import asdict, dataclass
from itertools import combinations
from math import factorial, sqrt

import numpy as np


MINKOWSKI = np.diag([-1.0, 1.0, 1.0, 1.0])


def minkowski_inner(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.asarray(a, dtype=float) @ MINKOWSKI @ np.asarray(b, dtype=float))


def interval_squared(a: np.ndarray, b: np.ndarray) -> float:
    delta = np.asarray(b, dtype=float) - np.asarray(a, dtype=float)
    return minkowski_inner(delta, delta)


def _simplex_gram(points: np.ndarray) -> np.ndarray:
    edges = points[1:] - points[0]
    return edges @ MINKOWSKI @ edges.T


def _four_volume(points: np.ndarray) -> float:
    determinant = float(np.linalg.det(_simplex_gram(points)))
    return sqrt(abs(determinant)) / factorial(4)


def _facet_normal(points: np.ndarray, omitted: int) -> np.ndarray:
    indices = [index for index in range(5) if index != omitted]
    facet = points[indices]
    edges = facet[1:] - facet[0]
    equations = edges @ MINKOWSKI
    _, _, vh = np.linalg.svd(equations)
    normal = vh[-1]
    norm_sq = minkowski_inner(normal, normal)
    if abs(norm_sq) < 1e-14:
        raise ValueError("Null facet normal is not admitted in the bounded Lorentzian control")
    normal = normal / sqrt(abs(norm_sq))
    facet_centroid = facet.mean(axis=0)
    inward = points[omitted] - facet_centroid
    if minkowski_inner(normal, inward) > 0.0:
        normal = -normal
    return normal


@dataclass(frozen=True, slots=True)
class LorentzianGeometryCertificate:
    vertex_coordinates: dict[int, tuple[float, float, float, float]]
    four_simplices: tuple[tuple[int, ...], ...]
    edge_classes: dict[str, int]
    simplex_four_volumes: tuple[float, ...]
    simplex_gram_signatures: tuple[tuple[int, int, int], ...]
    shared_slice_positive_eigenvalues: tuple[float, ...]
    shared_slice_normal_types: tuple[str, str]
    shared_slice_normal_time_signs: tuple[int, int]
    null_edge_count: int
    orientation_compatible: bool

    @property
    def passed(self) -> bool:
        return (
            self.null_edge_count == 0
            and all(volume > 1e-12 for volume in self.simplex_four_volumes)
            and all(signature == (1, 3, 0) for signature in self.simplex_gram_signatures)
            and all(value > 1e-12 for value in self.shared_slice_positive_eigenvalues)
            and self.shared_slice_normal_types == ("timelike", "timelike")
            and self.orientation_compatible
        )

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["passed"] = self.passed
        return payload


def causal_lorentzian_bisimplex() -> LorentzianGeometryCertificate:
    """Build two Lorentzian 4-simplices glued across a spacelike tetrahedron.

    The geometry has one past apex, one future apex, and a regular tetrahedral spatial
    slice.  It validates metric intervals, non-degeneracy, Lorentzian Gram signatures,
    and opposite time orientations of the shared spacelike boundary normals.
    """

    spatial_scale = 0.5
    coordinates = {
        0: np.array((-2.0, 0.0, 0.0, 0.0)),
        1: np.array((0.0, spatial_scale, spatial_scale, spatial_scale)),
        2: np.array((0.0, spatial_scale, -spatial_scale, -spatial_scale)),
        3: np.array((0.0, -spatial_scale, spatial_scale, -spatial_scale)),
        4: np.array((0.0, -spatial_scale, -spatial_scale, spatial_scale)),
        5: np.array((2.0, 0.0, 0.0, 0.0)),
    }
    simplices = ((0, 1, 2, 3, 4), (1, 2, 3, 4, 5))
    all_edges = set()
    for simplex in simplices:
        all_edges.update(combinations(simplex, 2))
    classes = {"timelike": 0, "spacelike": 0, "null": 0}
    for a, b in all_edges:
        value = interval_squared(coordinates[a], coordinates[b])
        if value < -1e-12:
            classes["timelike"] += 1
        elif value > 1e-12:
            classes["spacelike"] += 1
        else:
            classes["null"] += 1

    volumes: list[float] = []
    signatures: list[tuple[int, int, int]] = []
    normals: list[np.ndarray] = []
    for simplex_index, simplex in enumerate(simplices):
        points = np.asarray([coordinates[vertex] for vertex in simplex], dtype=float)
        gram = _simplex_gram(points)
        eigenvalues = np.linalg.eigvalsh(gram)
        signatures.append(
            (
                int(np.sum(eigenvalues < -1e-10)),
                int(np.sum(eigenvalues > 1e-10)),
                int(np.sum(np.abs(eigenvalues) <= 1e-10)),
            )
        )
        volumes.append(_four_volume(points))
        omitted_local = 0 if simplex_index == 0 else 4
        normals.append(_facet_normal(points, omitted_local))

    slice_points = np.asarray([coordinates[index] for index in (1, 2, 3, 4)], dtype=float)
    slice_edges = slice_points[1:] - slice_points[0]
    slice_gram = slice_edges[:, 1:] @ slice_edges[:, 1:].T
    slice_eigenvalues = np.linalg.eigvalsh(slice_gram)

    types = tuple("timelike" if minkowski_inner(normal, normal) < 0.0 else "spacelike" for normal in normals)
    time_signs = tuple(int(np.sign(normal[0])) for normal in normals)
    orientation_compatible = time_signs[0] == -time_signs[1] and all(sign != 0 for sign in time_signs)

    return LorentzianGeometryCertificate(
        vertex_coordinates={key: tuple(float(x) for x in value) for key, value in coordinates.items()},
        four_simplices=simplices,
        edge_classes=classes,
        simplex_four_volumes=tuple(float(value) for value in volumes),
        simplex_gram_signatures=tuple(signatures),
        shared_slice_positive_eigenvalues=tuple(float(value) for value in slice_eigenvalues),
        shared_slice_normal_types=types,
        shared_slice_normal_time_signs=time_signs,
        null_edge_count=classes["null"],
        orientation_compatible=orientation_compatible,
    )
