from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from typing import Any

import numpy as np
from scipy.linalg import expm, solve_continuous_lyapunov


@dataclass(frozen=True, slots=True)
class FermionicGaussianCertificate:
    schema: str
    supported_class: str
    exact_reference_mode_count: int
    scalable_mode_count: int
    exact_one_body_gap: float
    exact_four_point_wick_gap: float
    maximum_hermiticity_gap: float
    minimum_occupation_eigenvalue: float
    maximum_occupation_eigenvalue: float
    steady_state_residual: float
    scalable_physicality_gap: float
    scalable_steady_state_residual: float
    status: str
    claim_boundary: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_QUASI_FREE_FERMIONIC_GAUSSIAN_OWNER"

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["passed"] = self.passed
        return payload


def _digest(payload: dict[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), default=float).encode("utf-8")
    ).hexdigest()


def _require_hermitian(name: str, matrix: np.ndarray, tolerance: float = 1e-11) -> np.ndarray:
    array = np.asarray(matrix, dtype=complex)
    if array.ndim != 2 or array.shape[0] != array.shape[1]:
        raise ValueError(f"{name} must be a square matrix")
    gap = float(np.linalg.norm(array - array.conj().T, ord="fro"))
    if gap > tolerance:
        raise ValueError(f"{name} must be Hermitian; gap={gap:.3e}")
    return 0.5 * (array + array.conj().T)


def _require_psd(name: str, matrix: np.ndarray, tolerance: float = 1e-11) -> np.ndarray:
    array = _require_hermitian(name, matrix, tolerance=tolerance)
    minimum = float(np.min(np.linalg.eigvalsh(array)))
    if minimum < -tolerance:
        raise ValueError(f"{name} must be positive semidefinite; minimum={minimum:.3e}")
    return array


class FermionicGaussianLindbladOwner:
    """Authoritative covariance-matrix owner for a declared quasi-free fermionic class.

    The supported active class is number-conserving quadratic Hamiltonians

        H = sum_ij h_ij c_i^† c_j

    with linear loss and gain channels represented by positive one-particle rate
    matrices Gamma_minus and Gamma_plus. For C_ij=<c_j^† c_i>,

        dC/dt = A C + C A^† + Gamma_plus,
        A = -i h - (Gamma_minus + Gamma_plus)/2.

    This evolution is exact inside the supported Gaussian class. Interactions,
    nonlinear jumps, and operations that generate non-Gaussianity are rejected.
    """

    def __init__(
        self,
        hamiltonian: np.ndarray,
        loss_rates: np.ndarray,
        gain_rates: np.ndarray,
    ) -> None:
        self.hamiltonian = _require_hermitian("hamiltonian", hamiltonian)
        self.loss_rates = _require_psd("loss_rates", loss_rates)
        self.gain_rates = _require_psd("gain_rates", gain_rates)
        if not (
            self.hamiltonian.shape == self.loss_rates.shape == self.gain_rates.shape
        ):
            raise ValueError("Hamiltonian and rate matrices must have identical dimensions")
        self.mode_count = int(self.hamiltonian.shape[0])
        self.drift = (
            -1j * self.hamiltonian
            - 0.5 * (self.loss_rates + self.gain_rates)
        )

    def validate_correlation(self, correlation: np.ndarray, tolerance: float = 1e-10) -> np.ndarray:
        corr = _require_hermitian("correlation", correlation, tolerance=tolerance)
        if corr.shape != (self.mode_count, self.mode_count):
            raise ValueError("Correlation matrix dimension does not match the owner")
        eigenvalues = np.linalg.eigvalsh(corr)
        if float(np.min(eigenvalues)) < -tolerance or float(np.max(eigenvalues)) > 1.0 + tolerance:
            raise ValueError("Fermionic correlation eigenvalues must lie in [0,1]")
        return corr

    def steady_state(self) -> np.ndarray:
        spectral_abscissa = float(np.max(np.real(np.linalg.eigvals(self.drift))))
        if spectral_abscissa >= -1e-12:
            raise RuntimeError(
                "BLOCKED_NONRELAXING_GAUSSIAN_OWNER: a unique Lyapunov steady state requires stable drift"
            )
        # scipy solves A X + X A^H = Q.
        steady = solve_continuous_lyapunov(self.drift, -self.gain_rates)
        return self.validate_correlation(steady, tolerance=2e-8)

    def evolve(self, initial_correlation: np.ndarray, time: float) -> np.ndarray:
        initial = self.validate_correlation(initial_correlation)
        duration = float(time)
        if duration < 0.0:
            raise ValueError("time must be nonnegative")
        if duration == 0.0:
            return initial.copy()
        steady = self.steady_state()
        propagator = expm(self.drift * duration)
        evolved = steady + propagator @ (initial - steady) @ propagator.conj().T
        evolved = 0.5 * (evolved + evolved.conj().T)
        return self.validate_correlation(evolved, tolerance=2e-8)

    def residual(self, correlation: np.ndarray) -> np.ndarray:
        corr = self.validate_correlation(correlation, tolerance=2e-8)
        return self.drift @ corr + corr @ self.drift.conj().T + self.gain_rates


def _annihilation_operator(mode: int, mode_count: int) -> np.ndarray:
    identity = np.eye(2, dtype=complex)
    z = np.diag([1.0, -1.0]).astype(complex)
    lowering = np.array([[0.0, 1.0], [0.0, 0.0]], dtype=complex)
    factors = []
    for index in range(mode_count):
        if index < mode:
            factors.append(z)
        elif index == mode:
            factors.append(lowering)
        else:
            factors.append(identity)
    result = factors[0]
    for factor in factors[1:]:
        result = np.kron(result, factor)
    return result


def _dense_lindblad_evolution(
    hamiltonian: np.ndarray,
    loss_diagonal: np.ndarray,
    gain_diagonal: np.ndarray,
    initial_density: np.ndarray,
    time: float,
) -> tuple[np.ndarray, list[np.ndarray]]:
    mode_count = int(hamiltonian.shape[0])
    annihilators = [_annihilation_operator(index, mode_count) for index in range(mode_count)]
    creators = [operator.conj().T for operator in annihilators]
    dimension = 2**mode_count
    many_body_h = np.zeros((dimension, dimension), dtype=complex)
    for i in range(mode_count):
        for j in range(mode_count):
            many_body_h += hamiltonian[i, j] * creators[i] @ annihilators[j]
    jumps: list[np.ndarray] = []
    for index in range(mode_count):
        if loss_diagonal[index] > 0.0:
            jumps.append(np.sqrt(loss_diagonal[index]) * annihilators[index])
        if gain_diagonal[index] > 0.0:
            jumps.append(np.sqrt(gain_diagonal[index]) * creators[index])
    identity = np.eye(dimension, dtype=complex)
    liouvillian = -1j * (
        np.kron(identity, many_body_h) - np.kron(many_body_h.T, identity)
    )
    for jump in jumps:
        normal = jump.conj().T @ jump
        liouvillian += (
            np.kron(jump.conj(), jump)
            - 0.5 * np.kron(identity, normal)
            - 0.5 * np.kron(normal.T, identity)
        )
    vector = expm(liouvillian * float(time)) @ np.asarray(initial_density, dtype=complex).reshape(-1, order="F")
    density = vector.reshape((dimension, dimension), order="F")
    density = 0.5 * (density + density.conj().T)
    return density, annihilators


def _correlation_from_density(density: np.ndarray, annihilators: list[np.ndarray]) -> np.ndarray:
    mode_count = len(annihilators)
    correlation = np.zeros((mode_count, mode_count), dtype=complex)
    for i in range(mode_count):
        for j in range(mode_count):
            correlation[i, j] = np.trace(
                density @ annihilators[j].conj().T @ annihilators[i]
            )
    return correlation


def qualify_fermionic_gaussian_runtime(
    *,
    exact_mode_count: int = 4,
    scalable_mode_count: int = 128,
) -> FermionicGaussianCertificate:
    if exact_mode_count != 4:
        raise ValueError("The independent dense reference is fixed at four modes")
    if scalable_mode_count < 32:
        raise ValueError("scalable_mode_count must be at least 32")

    # Exact bounded control: boundary-driven free-fermion chain.
    hopping = 0.42
    onsite = np.asarray([0.15, -0.08, 0.04, 0.11], dtype=float)
    hamiltonian = np.diag(onsite).astype(complex)
    for index in range(exact_mode_count - 1):
        hamiltonian[index, index + 1] = hopping
        hamiltonian[index + 1, index] = hopping
    loss_diag = np.asarray([0.03, 0.02, 0.04, 0.31], dtype=float)
    gain_diag = np.asarray([0.27, 0.01, 0.02, 0.03], dtype=float)
    owner = FermionicGaussianLindbladOwner(
        hamiltonian,
        np.diag(loss_diag),
        np.diag(gain_diag),
    )
    initial_occupations = np.asarray([1.0, 0.0, 1.0, 0.0], dtype=float)
    initial_correlation = np.diag(initial_occupations).astype(complex)
    duration = 1.3
    gaussian = owner.evolve(initial_correlation, duration)

    basis_occupations = [1, 0, 1, 0]
    basis_index = 0
    for occupancy in basis_occupations:
        basis_index = 2 * basis_index + occupancy
    initial_density = np.zeros((2**exact_mode_count, 2**exact_mode_count), dtype=complex)
    initial_density[basis_index, basis_index] = 1.0
    density, annihilators = _dense_lindblad_evolution(
        hamiltonian, loss_diag, gain_diag, initial_density, duration
    )
    exact_correlation = _correlation_from_density(density, annihilators)
    exact_one_body_gap = float(np.linalg.norm(gaussian - exact_correlation, ord="fro"))

    i, j = 0, 2
    n_i = annihilators[i].conj().T @ annihilators[i]
    n_j = annihilators[j].conj().T @ annihilators[j]
    exact_four_point = complex(np.trace(density @ n_i @ n_j))
    wick_four_point = gaussian[i, i] * gaussian[j, j] - gaussian[i, j] * gaussian[j, i]
    wick_gap = float(abs(exact_four_point - wick_four_point))

    eigenvalues = np.linalg.eigvalsh(gaussian)
    hermiticity_gap = float(np.linalg.norm(gaussian - gaussian.conj().T, ord="fro"))
    steady = owner.steady_state()
    steady_residual = float(np.linalg.norm(owner.residual(steady), ord="fro"))

    # Scalable statevector-free control. The owner stores O(n^2) data and uses
    # one-particle linear algebra only; no 2^n Hilbert-space object is built.
    n = int(scalable_mode_count)
    h_large = np.zeros((n, n), dtype=complex)
    diagonal = 0.12 * np.cos(np.linspace(0.0, 3.0 * np.pi, n))
    np.fill_diagonal(h_large, diagonal)
    for index in range(n - 1):
        hop = 0.18 + 0.03 * np.cos(0.37 * index)
        h_large[index, index + 1] = hop
        h_large[index + 1, index] = hop
    loss_large = np.full(n, 0.035, dtype=float)
    gain_large = np.full(n, 0.012, dtype=float)
    loss_large[-1] += 0.20
    gain_large[0] += 0.18
    large_owner = FermionicGaussianLindbladOwner(
        h_large, np.diag(loss_large), np.diag(gain_large)
    )
    initial_large = np.diag(np.where(np.arange(n) % 3 == 0, 1.0, 0.0)).astype(complex)
    evolved_large = large_owner.evolve(initial_large, 0.8)
    large_eigenvalues = np.linalg.eigvalsh(evolved_large)
    scalable_physicality_gap = float(
        max(0.0, -float(np.min(large_eigenvalues)), float(np.max(large_eigenvalues)) - 1.0)
    )
    large_steady = large_owner.steady_state()
    scalable_residual = float(np.linalg.norm(large_owner.residual(large_steady), ord="fro") / n)

    checks = {
        "exact_one_body": exact_one_body_gap < 5e-10,
        "wick": wick_gap < 5e-10,
        "hermiticity": hermiticity_gap < 1e-12,
        "finite_physicality": float(np.min(eigenvalues)) >= -1e-10 and float(np.max(eigenvalues)) <= 1.0 + 1e-10,
        "steady_residual": steady_residual < 1e-10,
        "scalable_physicality": scalable_physicality_gap < 2e-8,
        "scalable_residual": scalable_residual < 2e-10,
    }
    status = (
        "PASS_QUASI_FREE_FERMIONIC_GAUSSIAN_OWNER"
        if all(checks.values())
        else "FAIL_QUASI_FREE_FERMIONIC_GAUSSIAN_OWNER"
    )
    semantic: dict[str, Any] = {
        "schema": "qpdtr-fermionic-gaussian-lindblad/v1",
        "supported_class": "number_conserving_quadratic_hamiltonian_with_linear_gain_and_loss",
        "exact_reference_mode_count": exact_mode_count,
        "scalable_mode_count": n,
        "exact_one_body_gap": exact_one_body_gap,
        "exact_four_point_wick_gap": wick_gap,
        "maximum_hermiticity_gap": hermiticity_gap,
        "minimum_occupation_eigenvalue": float(np.min(eigenvalues)),
        "maximum_occupation_eigenvalue": float(np.max(eigenvalues)),
        "steady_state_residual": steady_residual,
        "scalable_physicality_gap": scalable_physicality_gap,
        "scalable_steady_state_residual": scalable_residual,
        "status": status,
        "claim_boundary": (
            "Exact covariance-matrix dynamics is qualified for number-conserving quadratic fermionic "
            "Hamiltonians with linear gain/loss Lindblad channels and Gaussian initial states. Pairing, "
            "quadratic jump operators, interactions and any operation that generates non-Gaussianity are "
            "outside this active owner and must fail closed or route to another representation."
        ),
    }
    return FermionicGaussianCertificate(**semantic, digest=_digest(semantic))
