from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from typing import Any, Mapping, Sequence

import numpy as np
from scipy.linalg import expm


def _digest(payload: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), default=float).encode("utf-8")
    ).hexdigest()


def _one_site_liouvillian(hamiltonian: np.ndarray, jumps: Sequence[np.ndarray]) -> np.ndarray:
    """Column-vectorized one-site GKSL generator."""
    h = np.asarray(hamiltonian, dtype=np.complex128)
    if h.shape != (2, 2) or not np.allclose(h, h.conj().T, atol=1e-12, rtol=0.0):
        raise ValueError("Local Hamiltonian must be Hermitian 2x2")
    identity = np.eye(2, dtype=np.complex128)
    generator = -1j * (np.kron(identity, h) - np.kron(h.T, identity))
    for raw in jumps:
        jump = np.asarray(raw, dtype=np.complex128)
        if jump.shape != (2, 2):
            raise ValueError("Local jump must be 2x2")
        normal = jump.conj().T @ jump
        generator += (
            np.kron(jump.conj(), jump)
            - 0.5 * np.kron(identity, normal)
            - 0.5 * np.kron(normal.T, identity)
        )
    return generator


def _channel_action(superoperator: np.ndarray, operator: np.ndarray) -> np.ndarray:
    vector = np.asarray(operator, dtype=np.complex128).reshape(-1, order="F")
    return (np.asarray(superoperator, dtype=np.complex128) @ vector).reshape(2, 2, order="F")


def _channel_choi(superoperator: np.ndarray) -> np.ndarray:
    blocks: list[list[np.ndarray]] = []
    for i in range(2):
        row: list[np.ndarray] = []
        for j in range(2):
            basis = np.zeros((2, 2), dtype=np.complex128)
            basis[i, j] = 1.0
            row.append(_channel_action(superoperator, basis))
        blocks.append(row)
    choi = np.block(blocks)
    return 0.5 * (choi + choi.conj().T)


def _kraus_from_superoperator(
    superoperator: np.ndarray, *, cutoff: float = 1e-13
) -> tuple[np.ndarray, ...]:
    choi = _channel_choi(superoperator)
    eigenvalues, eigenvectors = np.linalg.eigh(choi)
    kraus = [
        np.sqrt(float(value)) * vector.reshape(2, 2, order="F")
        for value, vector in zip(eigenvalues, eigenvectors.T, strict=True)
        if value > cutoff
    ]
    if not kraus:
        raise RuntimeError("CPTP local channel yielded no Kraus operators")

    def residual(candidate: Sequence[np.ndarray]) -> float:
        worst = 0.0
        for i in range(2):
            for j in range(2):
                basis = np.zeros((2, 2), dtype=np.complex128)
                basis[i, j] = 1.0
                reconstructed = sum(k @ basis @ k.conj().T for k in candidate)
                worst = max(
                    worst,
                    float(np.linalg.norm(reconstructed - _channel_action(superoperator, basis))),
                )
        return worst

    alternate = [
        np.sqrt(float(value)) * vector.reshape(2, 2, order="C")
        for value, vector in zip(eigenvalues, eigenvectors.T, strict=True)
        if value > cutoff
    ]
    if residual(alternate) < residual(kraus):
        kraus = alternate

    completeness = sum(k.conj().T @ k for k in kraus)
    values, vectors = np.linalg.eigh(0.5 * (completeness + completeness.conj().T))
    if float(np.min(values)) <= 0.0:
        raise RuntimeError("Local channel Kraus completeness matrix is singular")
    inverse_sqrt = vectors @ np.diag(values ** -0.5) @ vectors.conj().T
    corrected = tuple(k @ inverse_sqrt for k in kraus)
    if residual(corrected) > 5e-11:
        raise RuntimeError("Kraus reconstruction does not reproduce the local channel")
    return corrected


def _choose_rank(
    singular_values: np.ndarray, *, maximum_rank: int, discarded_weight_budget: float
) -> int:
    upper = min(int(maximum_rank), int(singular_values.size))
    if upper < 1:
        return 1
    squares = np.square(np.abs(singular_values))
    if discarded_weight_budget <= 0.0:
        scale = float(np.max(np.abs(singular_values))) if singular_values.size else 0.0
        threshold = np.finfo(float).eps * max(1, singular_values.size) * scale
        return max(1, int(np.count_nonzero(np.abs(singular_values[:upper]) > threshold)))
    for rank in range(1, upper + 1):
        if float(np.sum(squares[rank:])) <= discarded_weight_budget:
            return rank
    return upper


@dataclass(frozen=True, slots=True)
class CPTPTensorTrainCertificate:
    schema: str
    status: str
    supported_class: str
    exact_reference_qubit_count: int
    scalable_qubit_count: int
    exact_frobenius_gap: float
    timestep_refinement_gap: float
    rank_refinement_gap: float
    maximum_trace_gap: float
    minimum_density_eigenvalue: float
    minimum_local_choi_eigenvalue: float
    maximum_local_kraus_completeness_gap: float
    cumulative_bond_discarded_weight: float
    cumulative_local_kraus_discarded_weight: float
    maximum_bond_rank: int
    maximum_local_kraus_rank: int
    scalable_trace_gap: float
    scalable_population_range_gap: float
    scalable_maximum_bond_rank: int
    scalable_maximum_local_kraus_rank: int
    statevector_materialized_scalable: bool
    claim_boundary: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_CPTP_TENSOR_TRAIN_LINDBLAD_OWNER"

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["passed"] = self.passed
        return payload


class CPTPTensorTrainLindbladOwner:
    """Locally purified tensor-train owner for local one-dimensional GKSL dynamics.

    Each tensor has shape ``(left_bond, physical, local_kraus, right_bond)`` and
    represents a purification ``X`` with ``rho = X X†`` after tracing local Kraus
    indices.  Positivity is therefore structural.  Exact local Kraus channels grow
    only the local purification dimension; nearest-neighbour Hamiltonian gates grow
    only the adjacent tensor-train bond.  Both dimensions are reduced by explicit
    SVD projections whose discarded squared norm is recorded, after which trace is
    normalized.  The nonlinear compression map is not claimed to be a CPTP channel
    on arbitrary inputs, but every represented output density is PSD and unit trace.
    """

    def __init__(
        self,
        local_hamiltonians: Sequence[np.ndarray],
        bond_hamiltonians: Sequence[np.ndarray],
        local_jumps: Sequence[Sequence[np.ndarray]],
        initial_local_densities: Sequence[np.ndarray],
        *,
        maximum_bond_rank: int = 32,
        bond_discarded_weight_budget: float = 1e-12,
        maximum_local_kraus_rank: int = 8,
        local_kraus_discarded_weight_budget: float = 1e-12,
    ) -> None:
        self.site_count = len(local_hamiltonians)
        if self.site_count < 2:
            raise ValueError("CPTP tensor-train owner requires at least two sites")
        if len(bond_hamiltonians) != self.site_count - 1:
            raise ValueError("A nearest-neighbour Hamiltonian is required for every bond")
        if len(local_jumps) != self.site_count or len(initial_local_densities) != self.site_count:
            raise ValueError("Local data must be supplied for every site")
        self.local_hamiltonians = tuple(np.asarray(v, dtype=np.complex128) for v in local_hamiltonians)
        self.bond_hamiltonians = tuple(np.asarray(v, dtype=np.complex128) for v in bond_hamiltonians)
        self.local_jumps = tuple(tuple(np.asarray(j, dtype=np.complex128) for j in site) for site in local_jumps)
        for h in self.local_hamiltonians:
            if h.shape != (2, 2) or not np.allclose(h, h.conj().T, atol=1e-12, rtol=0.0):
                raise ValueError("Local Hamiltonians must be Hermitian 2x2")
        for h in self.bond_hamiltonians:
            if h.shape != (4, 4) or not np.allclose(h, h.conj().T, atol=1e-12, rtol=0.0):
                raise ValueError("Bond Hamiltonians must be Hermitian 4x4")
        self.maximum_bond_rank_limit = int(maximum_bond_rank)
        self.bond_discarded_weight_budget = float(bond_discarded_weight_budget)
        self.maximum_local_kraus_rank_limit = int(maximum_local_kraus_rank)
        self.local_kraus_discarded_weight_budget = float(local_kraus_discarded_weight_budget)
        if self.maximum_bond_rank_limit < 1 or self.maximum_local_kraus_rank_limit < 1:
            raise ValueError("Tensor-train rank controls must be positive")
        if self.bond_discarded_weight_budget < 0.0 or self.local_kraus_discarded_weight_budget < 0.0:
            raise ValueError("Discarded-weight budgets must be non-negative")

        tensors: list[np.ndarray] = []
        for raw in initial_local_densities:
            rho = np.asarray(raw, dtype=np.complex128)
            if rho.shape != (2, 2):
                raise ValueError("Initial local density must be 2x2")
            rho = 0.5 * (rho + rho.conj().T)
            values, vectors = np.linalg.eigh(rho)
            if abs(np.trace(rho) - 1.0) > 1e-11 or float(np.min(values)) < -1e-12:
                raise ValueError("Initial local density must be PSD with unit trace")
            keep = values > 1e-14
            factor = vectors[:, keep] * np.sqrt(np.clip(values[keep], 0.0, None))[None, :]
            tensors.append(factor.reshape(1, 2, factor.shape[1], 1))
        self.tensors = tensors
        self.cumulative_bond_discarded_weight = 0.0
        self.cumulative_local_kraus_discarded_weight = 0.0
        self.maximum_bond_rank_reached = 1
        self.maximum_local_kraus_rank_reached = max(t.shape[2] for t in tensors)
        self.maximum_local_kraus_completeness_gap = 0.0
        self.minimum_local_choi_eigenvalue = float("inf")

    def copy(self) -> "CPTPTensorTrainLindbladOwner":
        duplicate = object.__new__(CPTPTensorTrainLindbladOwner)
        for name in (
            "site_count", "local_hamiltonians", "bond_hamiltonians", "local_jumps",
            "maximum_bond_rank_limit", "bond_discarded_weight_budget",
            "maximum_local_kraus_rank_limit", "local_kraus_discarded_weight_budget",
            "cumulative_bond_discarded_weight", "cumulative_local_kraus_discarded_weight",
            "maximum_bond_rank_reached", "maximum_local_kraus_rank_reached",
            "maximum_local_kraus_completeness_gap", "minimum_local_choi_eigenvalue",
        ):
            setattr(duplicate, name, getattr(self, name))
        duplicate.tensors = [tensor.copy() for tensor in self.tensors]
        return duplicate

    def trace(self) -> float:
        environment = np.ones((1, 1), dtype=np.complex128)
        for tensor in self.tensors:
            environment = np.einsum(
                "ab,askr,bsku->ru", environment, tensor, tensor.conj(), optimize=True
            )
        return float(np.real(environment[0, 0]))

    def _normalize_trace(self) -> None:
        value = self.trace()
        if not np.isfinite(value) or value <= 0.0:
            raise RuntimeError("Locally purified tensor train has invalid trace")
        self.tensors[0] /= np.sqrt(value)

    def _compress_local_kraus(self, site: int) -> None:
        tensor = self.tensors[site]
        left, physical, kraus, right = tensor.shape
        matrix = np.transpose(tensor, (0, 1, 3, 2)).reshape(left * physical * right, kraus)
        u, singular_values, _ = np.linalg.svd(matrix, full_matrices=False)
        rank = _choose_rank(
            singular_values,
            maximum_rank=self.maximum_local_kraus_rank_limit,
            discarded_weight_budget=self.local_kraus_discarded_weight_budget,
        )
        self.cumulative_local_kraus_discarded_weight += float(
            np.sum(np.square(np.abs(singular_values[rank:])))
        )
        reduced = (u[:, :rank] * singular_values[:rank][None, :]).reshape(
            left, physical, right, rank
        )
        self.tensors[site] = np.transpose(reduced, (0, 1, 3, 2))
        self.maximum_local_kraus_rank_reached = max(self.maximum_local_kraus_rank_reached, rank)

    def _apply_local_channel(self, site: int, time_step: float) -> None:
        channel = expm(_one_site_liouvillian(self.local_hamiltonians[site], self.local_jumps[site]) * float(time_step))
        choi = _channel_choi(channel)
        self.minimum_local_choi_eigenvalue = min(
            self.minimum_local_choi_eigenvalue,
            float(np.min(np.linalg.eigvalsh(choi)).real),
        )
        kraus = _kraus_from_superoperator(channel)
        completeness = sum(k.conj().T @ k for k in kraus)
        self.maximum_local_kraus_completeness_gap = max(
            self.maximum_local_kraus_completeness_gap,
            float(np.linalg.norm(completeness - np.eye(2), ord=2)),
        )
        tensor = self.tensors[site]
        # B[l,t,(k,a),r] = sum_s K_a[t,s] A[l,s,k,r].
        expanded = np.einsum("ats,lskr->ltkar", np.asarray(kraus), tensor, optimize=True)
        left, physical, old_kraus, channel_rank, right = expanded.shape
        self.tensors[site] = expanded.reshape(left, physical, old_kraus * channel_rank, right)
        self._compress_local_kraus(site)

    def _apply_bond_unitary(self, bond: int, time_step: float) -> None:
        gate = expm(-1j * float(time_step) * self.bond_hamiltonians[bond]).reshape(2, 2, 2, 2)
        left_tensor = self.tensors[bond]
        right_tensor = self.tensors[bond + 1]
        theta = np.einsum("lskm,mtur->lsktur", left_tensor, right_tensor, optimize=True)
        theta = np.einsum("abst,lsktur->labkur", gate, theta, optimize=True)
        left_bond, _, _, left_kraus, right_kraus, right_bond = theta.shape
        matrix = np.transpose(theta, (0, 1, 3, 2, 4, 5)).reshape(
            left_bond * 2 * left_kraus, 2 * right_kraus * right_bond
        )
        u, singular_values, vh = np.linalg.svd(matrix, full_matrices=False)
        rank = _choose_rank(
            singular_values,
            maximum_rank=self.maximum_bond_rank_limit,
            discarded_weight_budget=self.bond_discarded_weight_budget,
        )
        self.cumulative_bond_discarded_weight += float(
            np.sum(np.square(np.abs(singular_values[rank:])))
        )
        self.tensors[bond] = u[:, :rank].reshape(left_bond, 2, left_kraus, rank)
        self.tensors[bond + 1] = (
            singular_values[:rank, None] * vh[:rank, :]
        ).reshape(rank, 2, right_kraus, right_bond)
        self.maximum_bond_rank_reached = max(self.maximum_bond_rank_reached, rank)

    def step(self, time_step: float) -> None:
        dt = float(time_step)
        if dt <= 0.0:
            raise ValueError("time_step must be positive")
        for site in range(self.site_count):
            self._apply_local_channel(site, 0.5 * dt)
        for bond in range(0, self.site_count - 1, 2):
            self._apply_bond_unitary(bond, 0.5 * dt)
        for bond in range(1, self.site_count - 1, 2):
            self._apply_bond_unitary(bond, dt)
        for bond in range(0, self.site_count - 1, 2):
            self._apply_bond_unitary(bond, 0.5 * dt)
        for site in range(self.site_count):
            self._apply_local_channel(site, 0.5 * dt)
        self._normalize_trace()

    def evolve(self, total_time: float, time_step: float) -> None:
        duration = float(total_time)
        dt = float(time_step)
        if duration < 0.0 or dt <= 0.0:
            raise ValueError("Invalid time interval")
        count = int(round(duration / dt))
        if abs(count * dt - duration) > 1e-12:
            raise ValueError("total_time must be an integer multiple of time_step")
        for _ in range(count):
            self.step(dt)

    def one_site_expectation(self, site: int, operator: np.ndarray) -> complex:
        q = int(site)
        if q < 0 or q >= self.site_count:
            raise ValueError("Site lies outside the chain")
        environment = np.ones((1, 1), dtype=np.complex128)
        for index, tensor in enumerate(self.tensors):
            local = np.asarray(operator if index == q else np.eye(2), dtype=np.complex128)
            environment = np.einsum(
                "ab,askr,btku,ts->ru",
                environment,
                tensor,
                tensor.conj(),
                local,
                optimize=True,
            )
        return complex(environment[0, 0])

    def dense_density(self, maximum_site_count: int = 8) -> np.ndarray:
        if self.site_count > int(maximum_site_count):
            raise RuntimeError("BLOCKED_DENSE_MATERIALIZATION")
        purification = self.tensors[0][0]  # (physical, kraus, right)
        for following in self.tensors[1:]:
            purification = np.tensordot(purification, following, axes=([-1], [0]))
        purification = np.squeeze(purification, axis=-1)
        # axes are p0,k0,p1,k1,...
        physical_axes = list(range(0, 2 * self.site_count, 2))
        kraus_axes = list(range(1, 2 * self.site_count, 2))
        matrix = np.transpose(purification, physical_axes + kraus_axes).reshape(
            1 << self.site_count, -1
        )
        density = matrix @ matrix.conj().T
        return 0.5 * (density + density.conj().T)


def _full_operator(local_operator: np.ndarray, site: int, site_count: int) -> np.ndarray:
    factors = [
        np.asarray(local_operator, dtype=np.complex128) if index == site else np.eye(2, dtype=np.complex128)
        for index in range(site_count)
    ]
    result = factors[0]
    for factor in factors[1:]:
        result = np.kron(result, factor)
    return result


def _full_bond_operator(bond_operator: np.ndarray, bond: int, site_count: int) -> np.ndarray:
    factors: list[np.ndarray] = []
    index = 0
    while index < site_count:
        if index == bond:
            factors.append(np.asarray(bond_operator, dtype=np.complex128))
            index += 2
        else:
            factors.append(np.eye(2, dtype=np.complex128))
            index += 1
    result = factors[0]
    for factor in factors[1:]:
        result = np.kron(result, factor)
    return result


def _dense_reference(
    local_hamiltonians: Sequence[np.ndarray],
    bond_hamiltonians: Sequence[np.ndarray],
    local_jumps: Sequence[Sequence[np.ndarray]],
    initial_density: np.ndarray,
    total_time: float,
) -> np.ndarray:
    site_count = len(local_hamiltonians)
    dimension = 1 << site_count
    hamiltonian = np.zeros((dimension, dimension), dtype=np.complex128)
    for site, local in enumerate(local_hamiltonians):
        hamiltonian += _full_operator(local, site, site_count)
    for bond, local in enumerate(bond_hamiltonians):
        hamiltonian += _full_bond_operator(local, bond, site_count)
    jumps = [
        _full_operator(jump, site, site_count)
        for site, site_jumps in enumerate(local_jumps)
        for jump in site_jumps
    ]
    identity = np.eye(dimension, dtype=np.complex128)
    liouvillian = -1j * (np.kron(identity, hamiltonian) - np.kron(hamiltonian.T, identity))
    for jump in jumps:
        normal = jump.conj().T @ jump
        liouvillian += (
            np.kron(jump.conj(), jump)
            - 0.5 * np.kron(identity, normal)
            - 0.5 * np.kron(normal.T, identity)
        )
    evolved = expm(liouvillian * float(total_time)) @ initial_density.reshape(-1, order="F")
    density = evolved.reshape((dimension, dimension), order="F")
    return 0.5 * (density + density.conj().T)


def _make_chain(
    site_count: int,
    *,
    maximum_bond_rank: int,
    maximum_local_kraus_rank: int,
    bond_budget: float,
    kraus_budget: float,
) -> tuple[CPTPTensorTrainLindbladOwner, list[np.ndarray], list[np.ndarray], list[tuple[np.ndarray, ...]], list[np.ndarray]]:
    x = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=np.complex128)
    y = np.array([[0.0, -1j], [1j, 0.0]], dtype=np.complex128)
    z = np.diag([1.0, -1.0]).astype(np.complex128)
    lowering = np.array([[0.0, 1.0], [0.0, 0.0]], dtype=np.complex128)
    local_hamiltonians = [0.11 * ((-1) ** index) * z for index in range(site_count)]
    bond_hamiltonians = [
        0.18 * (np.kron(x, x) + np.kron(y, y)) + 0.07 * np.kron(z, z)
        for _ in range(site_count - 1)
    ]
    local_jumps: list[tuple[np.ndarray, ...]] = []
    for index in range(site_count):
        site_jumps = [np.sqrt(0.035) * z]
        if index == site_count - 1:
            site_jumps.append(np.sqrt(0.16) * lowering)
        local_jumps.append(tuple(site_jumps))
    excited = np.diag([0.0, 1.0]).astype(np.complex128)
    ground = np.diag([1.0, 0.0]).astype(np.complex128)
    initial = [excited if index == 0 else ground for index in range(site_count)]
    owner = CPTPTensorTrainLindbladOwner(
        local_hamiltonians,
        bond_hamiltonians,
        local_jumps,
        initial,
        maximum_bond_rank=maximum_bond_rank,
        bond_discarded_weight_budget=bond_budget,
        maximum_local_kraus_rank=maximum_local_kraus_rank,
        local_kraus_discarded_weight_budget=kraus_budget,
    )
    return owner, local_hamiltonians, bond_hamiltonians, local_jumps, initial


def qualify_cptp_tensor_train_runtime(
    *, exact_reference_qubit_count: int = 4, scalable_qubit_count: int = 12
) -> CPTPTensorTrainCertificate:
    if exact_reference_qubit_count != 4:
        raise ValueError("The independent dense control is fixed at four qubits")
    if scalable_qubit_count < 8:
        raise ValueError("scalable_qubit_count must be at least eight")
    total_time = 0.16

    coarse, local_h, bond_h, jumps, initial = _make_chain(
        4, maximum_bond_rank=32, maximum_local_kraus_rank=16,
        bond_budget=1e-14, kraus_budget=1e-14,
    )
    coarse.evolve(total_time, 0.04)
    density = coarse.dense_density()
    initial_density = initial[0]
    for local_density in initial[1:]:
        initial_density = np.kron(initial_density, local_density)
    exact = _dense_reference(local_h, bond_h, jumps, initial_density, total_time)
    exact_gap = float(np.linalg.norm(density - exact, ord="fro"))

    fine, *_ = _make_chain(
        4, maximum_bond_rank=32, maximum_local_kraus_rank=16,
        bond_budget=1e-14, kraus_budget=1e-14,
    )
    fine.evolve(total_time, 0.02)
    fine_density = fine.dense_density()
    timestep_gap = float(np.linalg.norm(density - fine_density, ord="fro"))

    low_rank, *_ = _make_chain(
        4, maximum_bond_rank=8, maximum_local_kraus_rank=4,
        bond_budget=1e-9, kraus_budget=1e-8,
    )
    low_rank.evolve(total_time, 0.02)
    rank_gap = float(np.linalg.norm(low_rank.dense_density() - fine_density, ord="fro"))

    trace_gap = float(abs(np.trace(fine_density) - 1.0))
    minimum_eigenvalue = float(np.min(np.linalg.eigvalsh(fine_density)).real)

    scalable, *_ = _make_chain(
        scalable_qubit_count, maximum_bond_rank=16, maximum_local_kraus_rank=4,
        bond_budget=1e-8, kraus_budget=1e-7,
    )
    scalable.evolve(0.08, 0.04)
    number = np.diag([0.0, 1.0]).astype(np.complex128)
    populations = np.asarray([
        float(np.real(scalable.one_site_expectation(site, number)))
        for site in range(scalable_qubit_count)
    ])
    population_range_gap = float(max(0.0, -float(np.min(populations)), float(np.max(populations)) - 1.0))
    scalable_trace_gap = abs(scalable.trace() - 1.0)

    checks = {
        "exact_reference": exact_gap < 2.5e-3,
        "time_refinement": timestep_gap < 8e-4,
        "rank_refinement": rank_gap < 5e-3,
        "trace": trace_gap < 2e-11,
        "positivity_by_factorization": minimum_eigenvalue > -2e-12,
        "local_choi": fine.minimum_local_choi_eigenvalue > -2e-12,
        "kraus_completeness": fine.maximum_local_kraus_completeness_gap < 2e-11,
        "scalable_trace": scalable_trace_gap < 2e-10,
        "scalable_population": population_range_gap < 2e-8,
        "scalable_no_dense": scalable_qubit_count > 8,
    }
    status = "PASS_CPTP_TENSOR_TRAIN_LINDBLAD_OWNER" if all(checks.values()) else "FAIL_CPTP_TENSOR_TRAIN_LINDBLAD_OWNER"
    semantic: dict[str, Any] = {
        "schema": "qpdtr-cptp-tensor-train-lindblad/v2",
        "status": status,
        "supported_class": "nearest_neighbour_one_dimensional_qubit_lindblad_with_local_jumps_and_locally_purified_tensor_train",
        "exact_reference_qubit_count": 4,
        "scalable_qubit_count": int(scalable_qubit_count),
        "exact_frobenius_gap": exact_gap,
        "timestep_refinement_gap": timestep_gap,
        "rank_refinement_gap": rank_gap,
        "maximum_trace_gap": trace_gap,
        "minimum_density_eigenvalue": minimum_eigenvalue,
        "minimum_local_choi_eigenvalue": float(fine.minimum_local_choi_eigenvalue),
        "maximum_local_kraus_completeness_gap": float(fine.maximum_local_kraus_completeness_gap),
        "cumulative_bond_discarded_weight": float(fine.cumulative_bond_discarded_weight),
        "cumulative_local_kraus_discarded_weight": float(fine.cumulative_local_kraus_discarded_weight),
        "maximum_bond_rank": int(fine.maximum_bond_rank_reached),
        "maximum_local_kraus_rank": int(fine.maximum_local_kraus_rank_reached),
        "scalable_trace_gap": float(scalable_trace_gap),
        "scalable_population_range_gap": population_range_gap,
        "scalable_maximum_bond_rank": int(scalable.maximum_bond_rank_reached),
        "scalable_maximum_local_kraus_rank": int(scalable.maximum_local_kraus_rank_reached),
        "statevector_materialized_scalable": False,
        "claim_boundary": (
            "The active owner covers finite nearest-neighbour one-dimensional qubit GKSL models with local jumps. "
            "The exact split layers are local Kraus channels and nearest-neighbour unitaries. The represented compressed output remains positive semidefinite by the local-purification factorization and is explicitly normalized, with bond and local-Kraus discarded weights reported. "
            "State-dependent SVD compression is not claimed to be a linear CPTP superoperator on arbitrary inputs. Long-range and two-dimensional generators, nonlocal jumps, and uncontrolled rank growth remain outside the active class."
        ),
    }
    return CPTPTensorTrainCertificate(**semantic, digest=_digest(semantic))
