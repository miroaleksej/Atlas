#!/usr/bin/env julia

# Native owner bridge for the official sl2cfoam-next Julia API.  It translates the
# authoritative request, executes official vertex/coherent-state operations, serializes
# the last two rank-5 shell tensors, and evaluates the published Delta3 contraction.
# No alternative EPRL amplitude is implemented here.

using TOML
using SHA
using LinearAlgebra
using HalfIntegers

length(ARGS) == 1 || error("usage: sl2cfoam_bridge.jl REQUEST_SCRIPT")
include(abspath(ARGS[1]))
const R = QPDTR_REQUEST
const REQUEST = R["request"]
const WORKDIR = abspath(R["workdir"])
const RESPONSE_PATH = abspath(R["response_toml"])
const ROOT = abspath(R["root"])
const TABLES = abspath(R["tables"])

include(joinpath(ROOT, "julia", "SL2Cfoam.jl"))
using .SL2Cfoam

complex_table(value::Complex) = Dict("real" => Float64(real(value)), "imag" => Float64(imag(value)))
spin_from_twice(q) = half(Int(q))

function tensor_artifact(array::Array{Float64}, relative_path::String, role::String,
                         configuration_id::String, shell::Int)
    ENDIAN_BOM == 0x04030201 || error("current tensor contract requires a little-endian host")
    path = joinpath(WORKDIR, relative_path)
    mkpath(dirname(path))
    open(path, "w") do io
        write(io, vec(array))
    end
    Dict(
        "relative_path" => relative_path,
        "sha256" => bytes2hex(sha256(read(path))),
        "shape" => collect(Int.(size(array))),
        "dtype" => "float64_le",
        "storage" => "raw_column_major",
        "element_count" => length(array),
        "role" => role,
        "configuration_id" => configuration_id,
        "shell" => shell,
    )
end

function remove_artifacts!(artifacts)
    for artifact in artifacts
        path = joinpath(WORKDIR, String(artifact["relative_path"]))
        isfile(path) && rm(path; force=true)
    end
end

function node_coherent_states(twice_spins, node_data)
    states = Vector{Any}(undef, 5)
    for node in node_data
        node_index = Int(node["node_index"]) + 1
        indices = Int.(node["face_indices"]) .+ 1
        js = spin_from_twice.(twice_spins[indices])
        rows = node["angles"]
        length(rows) == 4 || error("each coherent tetrahedron requires four normals")
        angles = Matrix{Float64}(undef, 4, 2)
        for row in 1:4
            angles[row, 1] = Float64(rows[row][1])
            angles[row, 2] = Float64(rows[row][2])
        end
        states[node_index] = SL2Cfoam.coherentstate_compute(js, angles)
    end
    states
end

function weighted_sum(configurations, amplitudes)
    total = 0.0 + 0.0im
    for (configuration, amplitude) in zip(configurations, amplitudes)
        coefficient = configuration["coefficient"]
        total += complex(Float64(coefficient["real"]), Float64(coefficient["imag"])) * amplitude
    end
    total
end

function execute_single_vertex(shell::Int)
    configurations = REQUEST["amplitude_configurations"]
    node_data = REQUEST["complex_contract"]["node_data"]
    amplitudes = ComplexF64[]
    artifacts = Dict{String,Any}[]
    for configuration in configurations
        twice_spins = Int.(configuration["twice_spins"])
        js = spin_from_twice.(twice_spins)
        vertex = SL2Cfoam.vertex_compute(js, shell; result=(ret=true, store=false, store_batches=false))
        coherent_states = node_coherent_states(twice_spins, node_data)
        amplitude = SL2Cfoam.contract(
            vertex,
            coherent_states[5], coherent_states[4], coherent_states[3], coherent_states[2], coherent_states[1],
        )
        push!(amplitudes, ComplexF64(amplitude))
        id = String(configuration["configuration_id"])
        relative = joinpath("tensors", "single_" * id * "_shell_" * string(shell) * ".f64")
        push!(artifacts, tensor_artifact(vertex.a, relative, "single_vertex_tensor", id, shell))
    end
    weighted_sum(configurations, amplitudes), amplitudes, artifacts
end

function integer_phase(exponent)
    value = Float64(exponent)
    rounded = round(Int, value)
    abs(value - rounded) < 1.0e-12 || error("Delta3 phase exponent is not integer")
    isodd(rounded) ? -1.0 : 1.0
end

function delta3_amplitude(vertex, coherent_states, J, x)
    # Published Delta3 graph: three partial-coherent vertices cyclically contracted over
    # their remaining intertwiner indices, with the internal-face dimension and phases.
    tA = SL2Cfoam.contract(vertex, coherent_states[3], coherent_states[2], coherent_states[1])
    tB = SL2Cfoam.contract(vertex, coherent_states[6], coherent_states[5], coherent_states[4])
    tC = SL2Cfoam.contract(vertex, coherent_states[9], coherent_states[8], coherent_states[7])
    irange, isize = SL2Cfoam.intertwiner_range(J, J, J, x)
    isize > 0 || error("Delta3 intertwiner range is empty")
    ks = collect(irange[1]:irange[2])
    size(tA) == (length(ks), length(ks)) || error("Delta3 partial tensor A has unexpected shape")
    size(tB) == size(tA) || error("Delta3 partial tensor B shape mismatch")
    size(tC) == size(tA) || error("Delta3 partial tensor C shape mismatch")
    total = 0.0 + 0.0im
    for ia in eachindex(ks), ib in eachindex(ks), ic in eachindex(ks)
        phase = integer_phase(ks[ia] + ks[ib] + ks[ic])
        total += phase * tA[ib, ia] * tB[ia, ic] * tC[ic, ib]
    end
    integer_phase(x) * Float64(SL2Cfoam.dim(x)) * total
end

function execute_delta3(shell::Int)
    configurations = REQUEST["amplitude_configurations"]
    contract = REQUEST["complex_contract"]
    J = spin_from_twice(contract["boundary_twice_spin"])
    node_angles = contract["node_angles"]
    length(node_angles) == 9 || error("Delta3 requires nine boundary coherent states")
    coherent_states = Vector{Any}(undef, 9)
    for index in 1:9
        angles = Matrix{Float64}(undef, 4, 2)
        for row in 1:4
            angles[row, 1] = Float64(node_angles[index][row][1])
            angles[row, 2] = Float64(node_angles[index][row][2])
        end
        coherent_states[index] = SL2Cfoam.coherentstate_compute(fill(J, 4), angles)
    end

    amplitudes = ComplexF64[]
    artifacts = Dict{String,Any}[]
    contracted = 0.0 + 0.0im
    for configuration in configurations
        x = spin_from_twice(configuration["internal_twice_spin"])
        js = [x, J, J, J, J, J, J, J, J, J]
        vertex = SL2Cfoam.vertex_compute(js, shell; result=(ret=true, store=false, store_batches=false))
        amplitude = delta3_amplitude(vertex, coherent_states, J, x)
        push!(amplitudes, amplitude)
        contracted += Float64(configuration["weight"]) * amplitude
        id = String(configuration["configuration_id"])
        relative = joinpath("tensors", "delta3_" * id * "_shell_" * string(shell) * ".f64")
        push!(artifacts, tensor_artifact(vertex.a, relative, "delta3_constituent_vertex_tensor", id, shell))
    end
    contracted, amplitudes, artifacts
end

function shell_increment(previous::ComplexF64, current::ComplexF64, policy)
    absolute = Float64(abs(current - previous))
    floor = Float64(policy["relative_floor"])
    scale = max(abs(current), abs(previous), floor)
    relative = Float64(absolute / scale)
    stable = absolute <= Float64(policy["absolute_tolerance"]) ||
             relative <= Float64(policy["relative_tolerance"])
    absolute, relative, stable
end

function main()
    max_twice_spin = Int(REQUEST["backend_config"]["max_twice_spin"])
    max_memory = Int(REQUEST["backend_config"]["max_MB_mem_per_thread"])
    accuracy_name = String(REQUEST["backend_config"]["accuracy"])
    accuracy = accuracy_name == "VeryHighAccuracy" ? SL2Cfoam.VeryHighAccuracy :
               accuracy_name == "HighAccuracy" ? SL2Cfoam.HighAccuracy : SL2Cfoam.NormalAccuracy
    config = SL2Cfoam.Config(
        SL2Cfoam.VerbosityOff,
        accuracy,
        spin_from_twice(max_twice_spin),
        max_memory,
    )
    SL2Cfoam.cinit(TABLES, Float64(REQUEST["immirzi"]), config)
    try
        policy = REQUEST["shell_policy"]
        minimum_shell = Int(policy["minimum_shell"])
        maximum_shell = Int(policy["maximum_shell"])
        minimum_samples = Int(policy["minimum_samples"])
        stable_steps = Int(policy["stable_steps"])

        sequence = Dict{String,Any}[]
        increments = Dict{String,Any}[]
        artifact_history = Dict{Int,Vector{Dict{String,Any}}}()
        final_amplitudes = ComplexF64[]
        final_contracted = 0.0 + 0.0im
        stable_run = 0
        converged = false

        for shell in minimum_shell:maximum_shell
            if REQUEST["task"] == "single_vertex_coherent_family"
                contracted, amplitudes, artifacts = execute_single_vertex(shell)
            elseif REQUEST["task"] == "delta3_three_vertex_one_internal_face"
                contracted, amplitudes, artifacts = execute_delta3(shell)
            else
                error("unsupported target task")
            end
            artifact_history[shell] = artifacts
            obsolete_shell = shell - 2
            if haskey(artifact_history, obsolete_shell)
                remove_artifacts!(artifact_history[obsolete_shell])
                delete!(artifact_history, obsolete_shell)
            end

            push!(sequence, Dict("shell" => shell, "contracted_amplitude" => complex_table(contracted)))
            if length(sequence) >= 2
                previous_table = sequence[end-1]["contracted_amplitude"]
                previous = complex(Float64(previous_table["real"]), Float64(previous_table["imag"]))
                absolute, relative, stable = shell_increment(ComplexF64(previous), ComplexF64(contracted), policy)
                stable_run = stable ? stable_run + 1 : 0
                push!(increments, Dict(
                    "from_shell" => shell - 1,
                    "to_shell" => shell,
                    "absolute_successive_difference" => absolute,
                    "relative_successive_difference" => relative,
                    "stable" => stable,
                ))
            end
            final_amplitudes = amplitudes
            final_contracted = contracted
            if length(sequence) >= minimum_samples && stable_run >= stable_steps
                converged = true
                break
            end
        end

        executed_shells = Int[entry["shell"] for entry in sequence]
        length(executed_shells) >= 2 || error("adaptive shell execution produced fewer than two shells")
        final_shell_pair = executed_shells[end-1:end]
        final_artifacts = Dict{String,Any}[]
        for shell in final_shell_pair
            append!(final_artifacts, artifact_history[shell])
        end
        last_increment = increments[end]
        termination_reason = converged ? "stable_window" : "maximum_shell_reached"

        configuration_amplitudes = Dict{String,Any}[]
        for (configuration, amplitude) in zip(REQUEST["amplitude_configurations"], final_amplitudes)
            push!(configuration_amplitudes, Dict(
                "configuration_id" => String(configuration["configuration_id"]),
                "amplitude" => complex_table(amplitude),
            ))
        end
        response = Dict{String,Any}(
            "backend" => "sl2cfoam-next",
            "backend_identity_digest" => String(R["backend_identity_digest"]),
            "commit_sha" => String(R["commit_sha"]),
            "source_digest" => String(R["source_digest"]),
            "library_digest" => String(R["library_digest"]),
            "julia_module_digest" => String(R["julia_module_digest"]),
            "build_identity_digest" => String(R["build_identity_digest"]),
            "table_artifacts" => R["table_artifacts"],
            "y_map" => String(R["y_map"]),
            "request_digest" => String(R["request_digest"]),
            "precision" => "Float64 rank-5 vertex tensors; official configured sl2cfoam-next booster accuracy",
            "boundary_family_digest" => String(REQUEST["boundary_family"]["family_digest"]),
            "complex_contract_digest" => String(REQUEST["complex_contract_digest"]),
            "configuration_amplitudes" => configuration_amplitudes,
            "contracted_amplitude" => complex_table(final_contracted),
            "shell_convergence" => Dict(
                "policy_digest" => String(REQUEST["shell_policy_digest"]),
                "sequence" => sequence,
                "increments" => increments,
                "executed_shells" => executed_shells,
                "successive_shell_estimator" => Float64(last_increment["absolute_successive_difference"]),
                "relative_successive_shell_estimator" => Float64(last_increment["relative_successive_difference"]),
                "stable_steps_observed" => stable_run,
                "converged" => converged,
                "termination_reason" => termination_reason,
                "interpretation" => "finite successive-shell stability certificate; not a rigorous infinite-tail bound",
            ),
            "tensor_artifacts" => final_artifacts,
        )
        mkpath(dirname(RESPONSE_PATH))
        open(RESPONSE_PATH, "w") do io
            TOML.print(io, response)
        end
    finally
        SL2Cfoam.cclear()
    end
end

main()
