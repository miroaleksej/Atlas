"""Authoritative bounded quantum-gravity execution components."""
