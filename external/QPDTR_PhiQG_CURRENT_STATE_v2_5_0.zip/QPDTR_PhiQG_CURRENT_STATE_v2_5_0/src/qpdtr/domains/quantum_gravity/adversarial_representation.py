from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping

from .basis_adaptive_sparse import qualify_basis_adaptive_sparse_runtime
from .cptp_tensor_train import qualify_cptp_tensor_train_runtime
from .structural_router import StructuralProfile, plan_resource_factorized_emulation


def _digest(payload: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=float).encode("utf-8")
    ).hexdigest()


def qualify_representation_adversarial_benchmark() -> dict[str, Any]:
    """Deterministic class-separation check through the single ARFE owner."""

    bass = qualify_basis_adaptive_sparse_runtime()
    cptp = qualify_cptp_tensor_train_runtime()
    cases = {
        "phase_width_separation": (
            StructuralProfile(
                verified_phase_polynomial_lowering=True,
                estimated_treewidth=63,
                estimated_linear_rank_width=1,
            ),
            "QCM-FEYNMAN-DD-LRW",
        ),
        "compiled_code": (StructuralProfile(verified_code_compiled_schedule=True), "QCM-CODE-COMPILED-TN"),
        "clifford": (StructuralProfile(clifford_only=True), "QCM-STABILIZER"),
        "gaussian": (StructuralProfile(gaussian_fermionic=True), "QCM-FERMION-GAUSSIAN"),
        "positive_open_chain": (StructuralProfile(one_dimensional_local_lindblad=True), "QCM-CPTP-TT-LINDBLAD"),
        "basis_sparse_crossover": (
            StructuralProfile(
                basis_adaptive_sparse_admissible=True,
                estimated_computational_basis_participation_ratio=512.0,
                sparse_budget=64,
            ),
            "QCM-BASS",
        ),
        "finite_memory": (
            StructuralProfile(non_markovian_memory=True, estimated_process_tensor_bond_dimension=16),
            "QCM-TEMPO",
        ),
        "observable_pauli": (
            StructuralProfile(
                qubit_count=1000,
                simulation_object="observable",
                causal_cone_qubit_count=64,
                pauli_observable_admissible=True,
                estimated_pauli_term_count=512,
                pauli_term_budget=1024,
            ),
            "QCM-PAULI-OBS",
        ),
        "tree_graph": (
            StructuralProfile(qubit_count=1000, simulation_object="observable", graph_bp_admissible=True, graph_is_tree=True),
            "QCM-GTN-BP",
        ),
        "low_treewidth": (StructuralProfile(expected_low_treewidth=True), "QCM-ADAPTIVE-TTN"),
        "unclassified": (StructuralProfile(estimated_treewidth=15, estimated_linear_rank_width=15), "QCM-GENERAL-TN"),
    }
    decisions: dict[str, Any] = {}
    routing_pass = True
    for name, (profile, expected) in cases.items():
        decision = plan_resource_factorized_emulation(profile)
        actual = decision.primary_patch_owner_id
        decisions[name] = {
            "expected_patch_owner": expected,
            "actual_patch_owner": actual,
            "active_owner": decision.selected_method_id,
            "decision": decision.to_dict(),
        }
        routing_pass = routing_pass and actual == expected and decision.selected_method_id == "QCM-PHI-Q1000-ARFE"
    semantic: dict[str, Any] = {
        "schema": "qpdtr-representation-adversarial-benchmark/v2",
        "status": (
            "PASS_BOUNDED_ADVERSARIAL_REPRESENTATION_BENCHMARK"
            if routing_pass and bass.passed and cptp.passed
            else "FAIL_BOUNDED_ADVERSARIAL_REPRESENTATION_BENCHMARK"
        ),
        "routing_cases": decisions,
        "basis_adaptive_sparse": bass.to_dict(),
        "cptp_tensor_train": cptp.to_dict(),
        "claim_boundary": (
            "This benchmark verifies deterministic patch-owner separation through one PHI-Q1000-ARFE owner. "
            "It is not a wall-clock comparison and does not establish global optimality."
        ),
    }
    semantic["digest"] = _digest(semantic)
    return semantic
