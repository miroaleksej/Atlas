from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass
from functools import cached_property
from itertools import product
import math
from time import perf_counter
from typing import Iterable, Sequence

import networkx as nx
import numpy as np
import opt_einsum as oe
from scipy.linalg import expm
from scipy.signal import find_peaks
from scipy.sparse import csc_array
from scipy.sparse.linalg import LinearOperator, expm_multiply

from .accelerators import (
    AcceleratorQualification,
    TorchStatevectorKernel,
    apply_numpy_gate,
    create_statevector_kernel,
    execute_numpy,
    gate_matrix,
    qualify_accelerators,
)
from .control import (
    OpenQASM3Executor,
    OpenQASM3Parser,
    PulseControlCertificate,
    QuantumCircuitProgram,
    QuantumInstruction,
    TransmonPulseEngine,
)
from .open_system import AdaptiveJumpCertificate, certify_adaptive_quantum_jumps
from .qec import CircuitLevelQECCertificate, certify_circuit_level_qec
from .adaptive_ttn import PersistentAdaptiveTTN


_COMPLEX_BYTES = np.dtype(np.complex128).itemsize
_PAULI: dict[str, np.ndarray] = {
    "I": np.eye(2, dtype=complex),
    "X": np.array([[0, 1], [1, 0]], dtype=complex),
    "Y": np.array([[0, -1j], [1j, 0]], dtype=complex),
    "Z": np.array([[1, 0], [0, -1]], dtype=complex),
}
_SWAP = np.array(
    [[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 1]], dtype=complex
)


def _as_square_complex(matrix: np.ndarray, name: str) -> np.ndarray:
    value = np.asarray(matrix, dtype=complex)
    if value.ndim != 2 or value.shape[0] != value.shape[1]:
        raise ValueError(f"{name} must be a square matrix")
    if not np.isfinite(value.real).all() or not np.isfinite(value.imag).all():
        raise ValueError(f"{name} contains non-finite values")
    return value


def _vec(matrix: np.ndarray) -> np.ndarray:
    return np.asarray(matrix, dtype=complex).reshape(-1, order="F")


def _unvec(vector: np.ndarray, dimension: int) -> np.ndarray:
    return np.asarray(vector, dtype=complex).reshape((dimension, dimension), order="F")


def _normalized_state(state: np.ndarray, dimension: int) -> np.ndarray:
    psi = np.asarray(state, dtype=complex).reshape(-1)
    if psi.size != dimension:
        raise ValueError("State-vector dimension does not match Hamiltonian")
    norm = float(np.linalg.norm(psi))
    if not np.isfinite(norm) or norm <= 0.0:
        raise ValueError("State vector must have finite non-zero norm")
    return psi / norm


@dataclass(frozen=True, slots=True)
class QuantumEvolutionCertificate:
    dimension: int
    elapsed_time: float
    execution_backend: str
    statevector_norm_gap: float
    unitary_gap: float
    statevector_backend_gap: float
    density_trace_gap: float
    density_hermiticity_gap: float
    density_min_eigenvalue: float
    choi_min_eigenvalue: float
    trace_preservation_gap: float
    choi_reshuffle_gap: float
    purity_initial: float
    purity_final: float

    @property
    def closed_passed(self) -> bool:
        return (
            self.statevector_norm_gap < 1e-11
            and self.unitary_gap < 1e-11
            and self.statevector_backend_gap < 1e-11
        )

    @property
    def open_passed(self) -> bool:
        return (
            self.density_trace_gap < 1e-11
            and self.density_hermiticity_gap < 1e-11
            and self.density_min_eigenvalue > -1e-10
            and self.choi_min_eigenvalue > -1e-10
            and self.trace_preservation_gap < 1e-10
            and self.choi_reshuffle_gap < 1e-12
        )

    def to_dict(self) -> dict:
        return asdict(self) | {"closed_passed": self.closed_passed, "open_passed": self.open_passed}


class FiniteQuantumDynamics:
    """Exact bounded reference backend for finite Hilbert spaces.

    The active implementation avoids duplicate matrix exponentials, uses ``expm_multiply`` for
    state and density propagation, and constructs the Choi matrix by the exact superoperator
    reshuffle identity.  Full channel/Choi materialization remains intentionally restricted to
    bounded reference spaces; scalable many-qubit execution is owned by ``AdaptiveQuantumDynamics``.
    """

    def __init__(self, hamiltonian: np.ndarray, collapse_operators: Iterable[np.ndarray] = ()):
        self.hamiltonian = _as_square_complex(hamiltonian, "hamiltonian")
        if not np.allclose(self.hamiltonian, self.hamiltonian.conj().T, atol=1e-12, rtol=0.0):
            raise ValueError("Hamiltonian must be Hermitian")
        self.dimension = self.hamiltonian.shape[0]
        self.collapse_operators = tuple(
            _as_square_complex(operator, "collapse operator") for operator in collapse_operators
        )
        if any(operator.shape != self.hamiltonian.shape for operator in self.collapse_operators):
            raise ValueError("Collapse operators must match the Hamiltonian dimension")
        self._unitary_cache: dict[float, np.ndarray] = {}
        self._channel_cache: dict[float, np.ndarray] = {}
        self._gram_operators = tuple(operator.conj().T @ operator for operator in self.collapse_operators)

    @cached_property
    def _eigendecomposition(self) -> tuple[np.ndarray, np.ndarray]:
        return np.linalg.eigh(self.hamiltonian)

    def unitary(self, elapsed_time: float) -> np.ndarray:
        elapsed = float(elapsed_time)
        if elapsed < 0.0:
            raise ValueError("Elapsed time must be non-negative")
        if elapsed not in self._unitary_cache:
            self._unitary_cache[elapsed] = expm(-1j * elapsed * self.hamiltonian)
        return self._unitary_cache[elapsed]

    def evolve_statevector(self, state: np.ndarray, elapsed_time: float) -> tuple[np.ndarray, float]:
        elapsed = float(elapsed_time)
        if elapsed < 0.0:
            raise ValueError("Elapsed time must be non-negative")
        psi = _normalized_state(state, self.dimension)
        evolved_krylov = expm_multiply(csc_array(-1j * elapsed * self.hamiltonian), psi)
        eigenvalues, eigenvectors = self._eigendecomposition
        evolved_eigen = eigenvectors @ (
            np.exp(-1j * elapsed * eigenvalues) * (eigenvectors.conj().T @ psi)
        )
        return evolved_krylov, float(np.linalg.norm(evolved_krylov - evolved_eigen))

    def _liouvillian_action(self, density: np.ndarray) -> np.ndarray:
        rho = np.asarray(density, dtype=complex)
        result = -1j * (self.hamiltonian @ rho - rho @ self.hamiltonian)
        for operator, gram in zip(self.collapse_operators, self._gram_operators, strict=True):
            result += operator @ rho @ operator.conj().T
            result -= 0.5 * (gram @ rho + rho @ gram)
        return result

    def _liouvillian_adjoint_action(self, observable: np.ndarray) -> np.ndarray:
        value = np.asarray(observable, dtype=complex)
        result = 1j * (self.hamiltonian @ value - value @ self.hamiltonian)
        for operator, gram in zip(self.collapse_operators, self._gram_operators, strict=True):
            result += operator.conj().T @ value @ operator
            result -= 0.5 * (gram @ value + value @ gram)
        return result

    def liouvillian_operator(self) -> LinearOperator:
        d = self.dimension
        size = d * d

        def matvec(vector: np.ndarray) -> np.ndarray:
            return _vec(self._liouvillian_action(_unvec(vector, d)))

        def rmatvec(vector: np.ndarray) -> np.ndarray:
            return _vec(self._liouvillian_adjoint_action(_unvec(vector, d)))

        def matmat(matrix: np.ndarray) -> np.ndarray:
            return np.column_stack([matvec(matrix[:, column]) for column in range(matrix.shape[1])])

        return LinearOperator(
            shape=(size, size),
            dtype=np.dtype(complex),
            matvec=matvec,
            rmatvec=rmatvec,
            matmat=matmat,
        )

    def liouvillian_trace(self) -> complex:
        d = self.dimension
        value = 0.0 + 0.0j
        for operator, gram in zip(self.collapse_operators, self._gram_operators, strict=True):
            value += abs(np.trace(operator)) ** 2 - d * np.trace(gram)
        return complex(value)

    def liouvillian(self) -> np.ndarray:
        """Materialize the exact Liouvillian only for bounded reference certification."""

        d = self.dimension
        identity = np.eye(d, dtype=complex)
        h = self.hamiltonian
        generator = -1j * (np.kron(identity, h) - np.kron(h.T, identity))
        for operator, gram in zip(self.collapse_operators, self._gram_operators, strict=True):
            generator += np.kron(operator.conj(), operator)
            generator -= 0.5 * np.kron(identity, gram)
            generator -= 0.5 * np.kron(gram.T, identity)
        return generator

    def channel_superoperator(self, elapsed_time: float) -> np.ndarray:
        elapsed = float(elapsed_time)
        if elapsed < 0.0:
            raise ValueError("Elapsed time must be non-negative")
        if elapsed not in self._channel_cache:
            self._channel_cache[elapsed] = expm(elapsed * self.liouvillian())
        return self._channel_cache[elapsed]

    def evolve_density(self, density: np.ndarray, elapsed_time: float) -> np.ndarray:
        rho = _as_square_complex(density, "density matrix")
        if rho.shape != self.hamiltonian.shape:
            raise ValueError("Density-matrix dimension does not match Hamiltonian")
        rho = 0.5 * (rho + rho.conj().T)
        trace = np.trace(rho)
        if abs(trace) <= 0.0:
            raise ValueError("Density matrix must have non-zero trace")
        rho = rho / trace
        elapsed = float(elapsed_time)
        operator = elapsed * self.liouvillian_operator()
        evolved_vector = expm_multiply(
            operator,
            _vec(rho),
            traceA=elapsed * self.liouvillian_trace(),
        )
        evolved = _unvec(evolved_vector, self.dimension)
        return 0.5 * (evolved + evolved.conj().T)

    @staticmethod
    def choi_from_superoperator(channel: np.ndarray, dimension: int) -> np.ndarray:
        matrix = _as_square_complex(channel, "channel superoperator")
        if matrix.shape != (dimension * dimension, dimension * dimension):
            raise ValueError("Channel dimension is incompatible with the requested Choi reshuffle")
        indexed = matrix.reshape((dimension, dimension, dimension, dimension), order="F")
        choi = indexed.transpose(2, 0, 3, 1).reshape(
            (dimension * dimension, dimension * dimension), order="C"
        )
        return 0.5 * (choi + choi.conj().T)

    @staticmethod
    def superoperator_from_choi(choi: np.ndarray, dimension: int) -> np.ndarray:
        matrix = _as_square_complex(choi, "Choi matrix")
        if matrix.shape != (dimension * dimension, dimension * dimension):
            raise ValueError("Choi dimension is incompatible with the requested inverse reshuffle")
        indexed = matrix.reshape((dimension, dimension, dimension, dimension), order="C")
        return indexed.transpose(1, 3, 0, 2).reshape(
            (dimension * dimension, dimension * dimension), order="F"
        )

    def choi_matrix(self, elapsed_time: float) -> np.ndarray:
        return self.choi_from_superoperator(self.channel_superoperator(elapsed_time), self.dimension)

    def certify(self, initial_state: np.ndarray, elapsed_time: float) -> QuantumEvolutionCertificate:
        psi = _normalized_state(initial_state, self.dimension)
        evolved, backend_gap = self.evolve_statevector(psi, elapsed_time)
        unitary = self.unitary(elapsed_time)
        rho0 = np.outer(psi, psi.conj())

        # The dense channel is materialized exactly once and then reused for rho and Choi.
        channel = self.channel_superoperator(elapsed_time)
        rho = _unvec(channel @ _vec(rho0), self.dimension)
        rho = 0.5 * (rho + rho.conj().T)
        choi = self.choi_from_superoperator(channel, self.dimension)
        reconstructed = self.superoperator_from_choi(choi, self.dimension)

        d = self.dimension
        tp_matrix = np.trace(choi.reshape(d, d, d, d), axis1=1, axis2=3)
        return QuantumEvolutionCertificate(
            dimension=d,
            elapsed_time=float(elapsed_time),
            execution_backend="EXACT_DENSE_REFERENCE_WITH_KRYLOV_ACTION",
            statevector_norm_gap=abs(float(np.vdot(evolved, evolved).real) - 1.0),
            unitary_gap=float(np.linalg.norm(unitary.conj().T @ unitary - np.eye(d), ord=2)),
            statevector_backend_gap=backend_gap,
            density_trace_gap=abs(complex(np.trace(rho)) - 1.0),
            density_hermiticity_gap=float(np.linalg.norm(rho - rho.conj().T, ord=2)),
            density_min_eigenvalue=float(np.min(np.linalg.eigvalsh(rho)).real),
            choi_min_eigenvalue=float(np.min(np.linalg.eigvalsh(choi)).real),
            trace_preservation_gap=float(np.linalg.norm(tp_matrix - np.eye(d), ord=2)),
            choi_reshuffle_gap=float(np.linalg.norm(reconstructed - channel, ord="fro")),
            purity_initial=float(np.trace(rho0 @ rho0).real),
            purity_final=float(np.trace(rho @ rho).real),
        )


@dataclass(frozen=True, slots=True)
class LocalPauliTerm:
    sites: tuple[int, ...]
    paulis: tuple[str, ...]
    coefficient: float
    label: str

    def validate(self, qubit_count: int) -> None:
        if len(self.sites) not in {1, 2} or len(self.sites) != len(self.paulis):
            raise ValueError("Local Pauli terms must act on one or two sites")
        if len(set(self.sites)) != len(self.sites):
            raise ValueError("A local term cannot repeat a site")
        if any(site < 0 or site >= qubit_count for site in self.sites):
            raise ValueError("Local term site lies outside the qubit register")
        if any(pauli not in _PAULI for pauli in self.paulis):
            raise ValueError("Unsupported Pauli label")
        if not np.isfinite(self.coefficient):
            raise ValueError("Local term coefficient must be finite")

    @property
    def local_matrix(self) -> np.ndarray:
        matrix = np.array([[1.0 + 0.0j]])
        for pauli in self.paulis:
            matrix = np.kron(matrix, _PAULI[pauli])
        return float(self.coefficient) * matrix


class LocalPauliHamiltonian:
    """Matrix-free sum of local one- and two-qubit Pauli terms."""

    def __init__(self, qubit_count: int, terms: Sequence[LocalPauliTerm]):
        if qubit_count < 1:
            raise ValueError("A qubit Hamiltonian requires at least one qubit")
        self.qubit_count = int(qubit_count)
        self.terms = tuple(terms)
        if not self.terms:
            raise ValueError("A local Hamiltonian requires at least one term")
        for term in self.terms:
            term.validate(self.qubit_count)
        self.dimension = 1 << self.qubit_count

    @property
    def statevector_bytes(self) -> int:
        return self.dimension * _COMPLEX_BYTES

    @property
    def dense_choi_bytes(self) -> int:
        return _COMPLEX_BYTES * (self.dimension**4)

    @property
    def trace(self) -> complex:
        value = 0.0 + 0.0j
        for term in self.terms:
            local_trace = complex(term.coefficient)
            for pauli in term.paulis:
                local_trace *= np.trace(_PAULI[pauli])
            value += local_trace * (2 ** (self.qubit_count - len(term.sites)))
        return value

    @staticmethod
    def product_state(bits: Sequence[int]) -> np.ndarray:
        state = np.array([1.0 + 0.0j])
        for bit in bits:
            if bit not in {0, 1}:
                raise ValueError("Product-state bits must be 0 or 1")
            state = np.kron(state, np.array([1.0, 0.0], complex) if bit == 0 else np.array([0.0, 1.0], complex))
        return state

    def _apply_term(self, state: np.ndarray, term: LocalPauliTerm) -> np.ndarray:
        tensor = np.asarray(state, dtype=complex).reshape((2,) * self.qubit_count)
        sites = tuple(term.sites)
        moved = np.moveaxis(tensor, sites, tuple(range(len(sites))))
        flat = moved.reshape((1 << len(sites), -1))
        transformed = term.local_matrix @ flat
        restored = transformed.reshape(moved.shape)
        return np.moveaxis(restored, tuple(range(len(sites))), sites).reshape(-1)

    def apply(self, state: np.ndarray) -> np.ndarray:
        vector = np.asarray(state, dtype=complex).reshape(-1)
        if vector.size != self.dimension:
            raise ValueError("State-vector size does not match the qubit Hamiltonian")
        result = np.zeros_like(vector)
        for term in self.terms:
            result += self._apply_term(vector, term)
        return result

    def linear_operator(self) -> LinearOperator:
        def matvec(vector: np.ndarray) -> np.ndarray:
            return self.apply(vector)

        def rmatvec(vector: np.ndarray) -> np.ndarray:
            return self.apply(vector)

        def matmat(matrix: np.ndarray) -> np.ndarray:
            return np.column_stack([self.apply(matrix[:, column]) for column in range(matrix.shape[1])])

        return LinearOperator(
            shape=(self.dimension, self.dimension),
            dtype=np.dtype(complex),
            matvec=matvec,
            rmatvec=rmatvec,
            matmat=matmat,
        )

    def dense_matrix(self, maximum_qubits: int = 10) -> np.ndarray:
        if self.qubit_count > maximum_qubits:
            raise ValueError("Dense materialization is forbidden above the bounded reference limit")
        basis = np.eye(self.dimension, dtype=complex)
        return np.column_stack([self.apply(basis[:, column]) for column in range(self.dimension)])

    def evolve_krylov(self, state: np.ndarray, elapsed_time: float) -> np.ndarray:
        psi = _normalized_state(state, self.dimension)
        elapsed = float(elapsed_time)
        if elapsed < 0.0:
            raise ValueError("Elapsed time must be non-negative")
        generator = (-1j * elapsed) * self.linear_operator()
        return expm_multiply(generator, psi, traceA=(-1j * elapsed) * self.trace)

    def energy_statevector(self, state: np.ndarray) -> float:
        psi = _normalized_state(state, self.dimension)
        return float(np.vdot(psi, self.apply(psi)).real)

    def interaction_degrees(self) -> tuple[int, ...]:
        degree = [0] * self.qubit_count
        for term in self.terms:
            if len(term.sites) == 2:
                for site in term.sites:
                    degree[site] += 1
        return tuple(degree)

    def interaction_edges(self) -> tuple[tuple[int, int], ...]:
        return tuple(
            sorted(
                {tuple(sorted(term.sites)) for term in self.terms if len(term.sites) == 2}
            )
        )

    def interaction_graph(self) -> nx.Graph:
        graph = nx.Graph()
        graph.add_nodes_from(range(self.qubit_count))
        graph.add_edges_from(self.interaction_edges())
        return graph

    def interaction_graph_bandwidth(self) -> int:
        edges = self.interaction_edges()
        return max((abs(right - left) for left, right in edges), default=0)

    def interaction_treewidth_upper_bound(self) -> int:
        graph = self.interaction_graph()
        if graph.number_of_edges() == 0:
            return 0
        width, _ = nx.approximation.treewidth_min_fill_in(graph)
        return int(width)

    def noncommuting_pair_count(self) -> int:
        count = 0
        mappings = [dict(zip(term.sites, term.paulis, strict=True)) for term in self.terms]
        for left in range(len(self.terms)):
            for right in range(left + 1, len(self.terms)):
                anticommuting_overlaps = 0
                for site in set(mappings[left]).intersection(mappings[right]):
                    a = mappings[left][site]
                    b = mappings[right][site]
                    if a != "I" and b != "I" and a != b:
                        anticommuting_overlaps += 1
                if anticommuting_overlaps % 2:
                    count += 1
        return count


class MatrixProductState:
    """Open-boundary MPS with controlled SVD truncation and arbitrary two-site gates."""

    def __init__(self, tensors: Sequence[np.ndarray]):
        self.tensors = [np.asarray(tensor, dtype=complex) for tensor in tensors]
        if not self.tensors:
            raise ValueError("An MPS requires at least one site")
        for index, tensor in enumerate(self.tensors):
            if tensor.ndim != 3 or tensor.shape[1] != 2:
                raise ValueError("Each MPS tensor must have shape (left, 2, right)")
            if index == 0 and tensor.shape[0] != 1:
                raise ValueError("The first MPS tensor must have left bond one")
            if index == len(self.tensors) - 1 and tensor.shape[2] != 1:
                raise ValueError("The last MPS tensor must have right bond one")
            if index and self.tensors[index - 1].shape[2] != tensor.shape[0]:
                raise ValueError("Adjacent MPS bond dimensions do not match")

    @classmethod
    def product_state(cls, bits: Sequence[int]) -> "MatrixProductState":
        tensors: list[np.ndarray] = []
        for bit in bits:
            if bit not in {0, 1}:
                raise ValueError("Product-state bits must be 0 or 1")
            tensor = np.zeros((1, 2, 1), dtype=complex)
            tensor[0, bit, 0] = 1.0
            tensors.append(tensor)
        return cls(tensors)

    @property
    def qubit_count(self) -> int:
        return len(self.tensors)

    @property
    def max_bond(self) -> int:
        return max(max(tensor.shape[0], tensor.shape[2]) for tensor in self.tensors)

    def copy(self) -> "MatrixProductState":
        return MatrixProductState([tensor.copy() for tensor in self.tensors])

    def scaled(self, coefficient: complex) -> "MatrixProductState":
        result = self.copy()
        result.tensors[0] = complex(coefficient) * result.tensors[0]
        return result

    @classmethod
    def linear_combination(
        cls, terms: Sequence[tuple[complex, "MatrixProductState"]]
    ) -> "MatrixProductState":
        """Construct an exact direct-sum MPS for a finite linear combination.

        This is the authoritative primitive used by Clifford-augmented Pauli
        rotations.  It never materializes a global state vector.
        """
        normalized_terms = [(complex(weight), state) for weight, state in terms if abs(weight) > 0.0]
        if not normalized_terms:
            raise ValueError("At least one non-zero MPS term is required")
        qubit_count = normalized_terms[0][1].qubit_count
        if any(state.qubit_count != qubit_count for _, state in normalized_terms):
            raise ValueError("All MPS terms must have the same qubit count")
        if qubit_count == 1:
            tensor = sum(weight * state.tensors[0] for weight, state in normalized_terms)
            return cls([tensor])

        tensors: list[np.ndarray] = []
        first = np.concatenate(
            [weight * state.tensors[0] for weight, state in normalized_terms], axis=2
        )
        tensors.append(first)
        for site in range(1, qubit_count - 1):
            left_total = sum(state.tensors[site].shape[0] for _, state in normalized_terms)
            right_total = sum(state.tensors[site].shape[2] for _, state in normalized_terms)
            block = np.zeros((left_total, 2, right_total), dtype=complex)
            left_offset = 0
            right_offset = 0
            for _, state in normalized_terms:
                tensor = state.tensors[site]
                left = tensor.shape[0]
                right = tensor.shape[2]
                block[left_offset:left_offset + left, :, right_offset:right_offset + right] = tensor
                left_offset += left
                right_offset += right
            tensors.append(block)
        tensors.append(np.concatenate([state.tensors[-1] for _, state in normalized_terms], axis=0))
        return cls(tensors)

    def compress(
        self,
        *,
        max_bond: int,
        discarded_weight_budget: float,
    ) -> tuple[float, int]:
        """Left-canonical SVD compression with an explicit discarded-weight ledger."""
        if max_bond < 1 or discarded_weight_budget < 0.0:
            raise ValueError("MPS compression bounds are inadmissible")
        total_discarded = 0.0
        maximum_rank = 1
        for site in range(self.qubit_count - 1):
            tensor = self.tensors[site]
            left_dimension, _, right_dimension = tensor.shape
            matrix = tensor.reshape(left_dimension * 2, right_dimension)
            u, singular_values, vh = np.linalg.svd(matrix, full_matrices=False)
            rank = self._truncation_rank(
                singular_values,
                max_bond=max_bond,
                discarded_weight_budget=discarded_weight_budget,
            )
            total_discarded += float(np.square(np.abs(singular_values[rank:])).sum())
            maximum_rank = max(maximum_rank, rank)
            self.tensors[site] = u[:, :rank].reshape(left_dimension, 2, rank)
            transfer = singular_values[:rank, None] * vh[:rank, :]
            self.tensors[site + 1] = np.einsum(
                "ar,rsb->asb", transfer, self.tensors[site + 1], optimize=True
            )
        return total_discarded, maximum_rank

    def inner(self, other: "MatrixProductState") -> complex:
        if self.qubit_count != other.qubit_count:
            raise ValueError("MPS inner product requires the same qubit count")
        environment = np.ones((1, 1), dtype=complex)
        for left, right in zip(self.tensors, other.tensors, strict=True):
            environment = np.einsum("ab,asr,bsq->rq", environment, left.conj(), right, optimize=True)
        return complex(environment[0, 0])

    def norm_squared(self) -> float:
        return float(self.inner(self).real)

    def normalize(self) -> float:
        norm = float(np.sqrt(max(self.norm_squared(), 0.0)))
        if not np.isfinite(norm) or norm <= 0.0:
            raise ValueError("MPS has invalid norm")
        self.tensors[0] /= norm
        return norm

    def to_statevector(self, maximum_qubits: int = 20) -> np.ndarray:
        if self.qubit_count > maximum_qubits:
            raise ValueError("State-vector materialization is forbidden above the reference limit")
        tensor = self.tensors[0]
        for following in self.tensors[1:]:
            tensor = np.tensordot(tensor, following, axes=([-1], [0]))
        return tensor.reshape(-1)

    def apply_one_site_gate(self, site: int, gate: np.ndarray) -> None:
        matrix = _as_square_complex(gate, "one-site gate")
        if matrix.shape != (2, 2) or site < 0 or site >= self.qubit_count:
            raise ValueError("Invalid one-site gate")
        transformed = np.tensordot(matrix, self.tensors[site], axes=([1], [1]))
        self.tensors[site] = np.transpose(transformed, (1, 0, 2))

    @staticmethod
    def _truncation_rank(singular_values: np.ndarray, max_bond: int, discarded_weight_budget: float) -> int:
        upper = min(max_bond, singular_values.size)
        if upper < 1:
            return 1
        if discarded_weight_budget <= 0.0:
            scale = float(np.max(np.abs(singular_values))) if singular_values.size else 0.0
            threshold = np.finfo(float).eps * max(1, singular_values.size) * scale
            numerical_rank = int(np.count_nonzero(np.abs(singular_values[:upper]) > threshold))
            return max(1, numerical_rank)
        squares = np.square(np.abs(singular_values))
        # Choose the smallest retained rank whose discarded squared norm is below the declared discarded-weight budget.
        for rank in range(1, upper + 1):
            discarded = squares[rank:].sum()
            if discarded <= discarded_weight_budget:
                return rank
        return upper

    def apply_adjacent_two_site_gate(
        self,
        left_site: int,
        gate: np.ndarray,
        max_bond: int,
        discarded_weight_budget: float,
    ) -> tuple[float, int]:
        if left_site < 0 or left_site + 1 >= self.qubit_count:
            raise ValueError("Adjacent two-site gate lies outside the MPS")
        matrix = _as_square_complex(gate, "two-site gate")
        if matrix.shape != (4, 4):
            raise ValueError("A two-site gate must be 4x4")
        left = self.tensors[left_site]
        right = self.tensors[left_site + 1]
        theta = np.einsum("lsm,mtr->lstr", left, right, optimize=True)
        gate4 = matrix.reshape(2, 2, 2, 2)
        theta = np.einsum("uvst,lstr->luvr", gate4, theta, optimize=True)
        ldim, _, _, rdim = theta.shape
        flattened = theta.reshape(ldim * 2, 2 * rdim)
        u, singular_values, vh = np.linalg.svd(flattened, full_matrices=False)
        rank = self._truncation_rank(singular_values, max_bond=max_bond, discarded_weight_budget=discarded_weight_budget)
        discarded = float(np.square(np.abs(singular_values[rank:])).sum())
        u = u[:, :rank]
        singular_values = singular_values[:rank]
        vh = vh[:rank, :]
        self.tensors[left_site] = u.reshape(ldim, 2, rank)
        self.tensors[left_site + 1] = (singular_values[:, None] * vh).reshape(rank, 2, rdim)
        return discarded, rank

    def apply_two_site_gate(
        self,
        first_site: int,
        second_site: int,
        gate: np.ndarray,
        max_bond: int,
        discarded_weight_budget: float,
    ) -> tuple[float, int]:
        """Apply a two-site gate by contracting and refactorizing the minimal contiguous block.

        This replaces SWAP routing.  For the active simplicial chain every edge spans at most
        three lattice positions, so the largest temporary block contains four physical sites.
        Contracting that block avoids artificial entanglement and repeated truncation generated
        by forward/backward SWAP gates while preserving the exact local gate before the controlled
        SVD projection.
        """

        if first_site == second_site:
            raise ValueError("Two-site gate requires distinct sites")
        matrix = _as_square_complex(gate, "two-site gate")
        if matrix.shape != (4, 4):
            raise ValueError("A two-site gate must be 4x4")
        if first_site > second_site:
            matrix = _SWAP @ matrix @ _SWAP
            first_site, second_site = second_site, first_site
        if first_site < 0 or second_site >= self.qubit_count:
            raise ValueError("Two-site gate lies outside the MPS")

        block = self.tensors[first_site]
        for site in range(first_site + 1, second_site + 1):
            block = np.tensordot(block, self.tensors[site], axes=([-1], [0]))

        block_length = second_site - first_site + 1
        # block axes are (left, s_first, ..., s_second, right).  Move the two target
        # physical axes next to each other, apply the 4x4 gate, and restore axis order.
        moved = np.moveaxis(block, (1, block_length), (1, 2))
        moved_shape = moved.shape
        flattened = moved.reshape(moved_shape[0], 4, -1)
        transformed = np.einsum("uv,lvr->lur", matrix, flattened, optimize=True)
        moved = transformed.reshape(moved_shape)
        block = np.moveaxis(moved, (1, 2), (1, block_length))

        total_discarded = 0.0
        maximum_rank = self.max_bond
        remaining = block
        for offset, site in enumerate(range(first_site, second_site)):
            left_dimension = remaining.shape[0]
            flattened = remaining.reshape(left_dimension * 2, -1)
            u, singular_values, vh = np.linalg.svd(flattened, full_matrices=False)
            rank = self._truncation_rank(singular_values, max_bond=max_bond, discarded_weight_budget=discarded_weight_budget)
            total_discarded += float(np.square(np.abs(singular_values[rank:])).sum())
            maximum_rank = max(maximum_rank, rank)
            self.tensors[site] = u[:, :rank].reshape(left_dimension, 2, rank)
            remaining = (singular_values[:rank, None] * vh[:rank, :]).reshape(
                (rank,) + remaining.shape[2:]
            )
        self.tensors[second_site] = remaining
        return total_discarded, maximum_rank

    def expectation_pauli_term(self, term: LocalPauliTerm) -> float:
        mapping = dict(zip(term.sites, term.paulis, strict=True))
        environment = np.ones((1, 1), dtype=complex)
        for site, tensor in enumerate(self.tensors):
            operator = _PAULI[mapping.get(site, "I")]
            environment = np.einsum(
                "ab,asr,btq,ts->rq",
                environment,
                tensor,
                tensor.conj(),
                operator,
                optimize=True,
            )
        return float(term.coefficient * environment[0, 0].real)

    def energy(self, hamiltonian: LocalPauliHamiltonian) -> float:
        if hamiltonian.qubit_count != self.qubit_count:
            raise ValueError("MPS and Hamiltonian qubit counts differ")
        return float(sum(self.expectation_pauli_term(term) for term in hamiltonian.terms))

    def one_site_density_matrices(self) -> tuple[np.ndarray, ...]:
        n = self.qubit_count
        left_environments: list[np.ndarray] = [np.ones((1, 1), dtype=complex)]
        for tensor in self.tensors:
            left_environments.append(
                np.einsum(
                    "ab,asr,bsq->rq",
                    left_environments[-1],
                    tensor,
                    tensor.conj(),
                    optimize=True,
                )
            )
        right_environments: list[np.ndarray] = [np.empty((0, 0), dtype=complex)] * (n + 1)
        right_environments[n] = np.ones((1, 1), dtype=complex)
        for site in range(n - 1, -1, -1):
            tensor = self.tensors[site]
            right_environments[site] = np.einsum(
                "asr,bsq,rq->ab",
                tensor,
                tensor.conj(),
                right_environments[site + 1],
                optimize=True,
            )
        densities: list[np.ndarray] = []
        for site, tensor in enumerate(self.tensors):
            rho = np.einsum(
                "ab,asr,btq,rq->st",
                left_environments[site],
                tensor,
                tensor.conj(),
                right_environments[site + 1],
                optimize=True,
            )
            rho = 0.5 * (rho + rho.conj().T)
            rho /= np.trace(rho)
            densities.append(rho)
        return tuple(densities)

    def single_site_entropies(self) -> tuple[float, ...]:
        values: list[float] = []
        for rho in self.one_site_density_matrices():
            eigenvalues = np.clip(np.linalg.eigvalsh(rho).real, 0.0, 1.0)
            nonzero = eigenvalues[eigenvalues > 1e-15]
            values.append(float(-np.sum(nonzero * np.log2(nonzero))))
        return tuple(values)


@dataclass(frozen=True, slots=True)
class ContractionTreePlanSummary:
    optimizer: str
    backend: str
    parallel_mode: str
    mpi_world_size: int
    gpu_available: bool
    unsliced_peak_elements: int
    peak_elements: int
    flop_estimate: float
    sliced_index_count: int
    slice_count: int
    planning_seconds: float
    contraction_seconds: float

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class _ContractionPlan:
    path: tuple[tuple[int, ...], ...]
    sliced_indices: tuple[int, ...]
    unsliced_peak_elements: int
    peak_elements: int
    flop_estimate: float
    planning_seconds: float


class TensorNetworkContractionEngine:
    """General circuit tensor-network contraction with explicit path and slicing ownership.

    The engine is a representation inside ``AdaptiveQuantumDynamics`` rather than a second
    simulator owner.  It builds exact ket or doubled bra-ket networks from the same compiled
    local generators used by MPS/TEBD.  Contraction paths are planned under an explicit peak
    intermediate budget.  When that budget is exceeded, internal binary indices are sliced and
    independently contracted; slices can be reduced by a local thread pool or, when explicitly
    enabled and available, MPI.  CuPy is selected only when a real CUDA device is visible.
    """

    def __init__(
        self,
        qubit_count: int,
        bits: Sequence[int],
        gate_sequence: Sequence[tuple[tuple[int, ...], np.ndarray]],
        policy: "AdaptiveExecutionPolicy",
    ):
        self.qubit_count = int(qubit_count)
        self.bits = tuple(int(bit) for bit in bits)
        self.gate_sequence = tuple(
            (tuple(int(site) for site in sites), np.asarray(gate, dtype=complex))
            for sites, gate in gate_sequence
        )
        self.policy = policy
        if len(self.bits) != self.qubit_count or any(bit not in {0, 1} for bit in self.bits):
            raise ValueError("Tensor-network product state is inadmissible")
        self.backend, self._gpu_available = self._resolve_backend()

    def _resolve_backend(self) -> tuple[str, bool]:
        preference = self.policy.contraction_backend
        if preference not in {"auto", "numpy", "cupy"}:
            raise ValueError("Unsupported tensor contraction backend")
        if preference in {"auto", "cupy"}:
            try:
                import cupy as cp  # type: ignore

                if int(cp.cuda.runtime.getDeviceCount()) > 0:
                    return "cupy", True
            except Exception:
                if preference == "cupy":
                    raise RuntimeError(
                        "BLOCKED_BACKEND_UNAVAILABLE:CUPY_CUDA_DEVICE_NOT_AVAILABLE"
                    )
        return "numpy", False

    @staticmethod
    def _interleaved(
        nodes: Sequence[tuple[np.ndarray, tuple[int, ...]]],
        output_indices: Sequence[int],
    ) -> list[object]:
        arguments: list[object] = []
        for tensor, indices in nodes:
            arguments.extend((tensor, list(indices)))
        arguments.append(list(output_indices))
        return arguments

    def _build_ket_network(
        self,
    ) -> tuple[list[tuple[np.ndarray, tuple[int, ...]]], tuple[int, ...]]:
        nodes: list[tuple[np.ndarray, tuple[int, ...]]] = []
        next_index = 0
        current: list[int] = []
        for bit in self.bits:
            label = next_index
            next_index += 1
            vector = (
                np.array([1.0, 0.0], dtype=complex)
                if bit == 0
                else np.array([0.0, 1.0], dtype=complex)
            )
            nodes.append((vector, (label,)))
            current.append(label)
        for sites, gate in self.gate_sequence:
            outputs = tuple(range(next_index, next_index + len(sites)))
            next_index += len(sites)
            inputs = tuple(current[site] for site in sites)
            nodes.append((gate.reshape((2,) * (2 * len(sites))), outputs + inputs))
            for site, label in zip(sites, outputs, strict=True):
                current[site] = label
        return nodes, tuple(current)

    def _build_double_network(
        self,
        operator_map: dict[int, np.ndarray] | None = None,
    ) -> tuple[list[tuple[np.ndarray, tuple[int, ...]]], tuple[int, ...]]:
        operators = operator_map or {}
        nodes: list[tuple[np.ndarray, tuple[int, ...]]] = []
        next_index = 0
        ket: list[int] = []
        bra: list[int] = []
        for bit in self.bits:
            ket_label = next_index
            bra_label = next_index + 1
            next_index += 2
            vector = (
                np.array([1.0, 0.0], dtype=complex)
                if bit == 0
                else np.array([0.0, 1.0], dtype=complex)
            )
            nodes.append((vector, (ket_label,)))
            nodes.append((vector.conj(), (bra_label,)))
            ket.append(ket_label)
            bra.append(bra_label)
        for sites, gate in self.gate_sequence:
            ket_outputs = tuple(range(next_index, next_index + len(sites)))
            next_index += len(sites)
            bra_outputs = tuple(range(next_index, next_index + len(sites)))
            next_index += len(sites)
            ket_inputs = tuple(ket[site] for site in sites)
            bra_inputs = tuple(bra[site] for site in sites)
            shape = (2,) * (2 * len(sites))
            nodes.append((gate.reshape(shape), ket_outputs + ket_inputs))
            nodes.append((gate.conj().reshape(shape), bra_outputs + bra_inputs))
            for site, label in zip(sites, ket_outputs, strict=True):
                ket[site] = label
            for site, label in zip(sites, bra_outputs, strict=True):
                bra[site] = label
        for site in range(self.qubit_count):
            operator = _as_square_complex(operators.get(site, _PAULI["I"]), "observable")
            if operator.shape != (2, 2):
                raise ValueError("Tensor-network local observable must be 2x2")
            nodes.append((operator, (bra[site], ket[site])))
        return nodes, ()

    @staticmethod
    def _slice_nodes(
        nodes: Sequence[tuple[np.ndarray, tuple[int, ...]]],
        assignment: dict[int, int],
    ) -> list[tuple[np.ndarray, tuple[int, ...]]]:
        sliced: list[tuple[np.ndarray, tuple[int, ...]]] = []
        for tensor, indices in nodes:
            value = tensor
            labels = list(indices)
            for index, fixed_value in assignment.items():
                if index in labels:
                    axis = labels.index(index)
                    value = np.take(value, fixed_value, axis=axis)
                    labels.pop(axis)
            sliced.append((value, tuple(labels)))
        return sliced

    @staticmethod
    def _slice_candidates(
        nodes: Sequence[tuple[np.ndarray, tuple[int, ...]]],
        output_indices: Sequence[int],
    ) -> tuple[int, ...]:
        output = set(output_indices)
        occurrence: dict[int, list[int]] = {}
        dimensions: dict[int, int] = {}
        for tensor_index, (tensor, indices) in enumerate(nodes):
            for axis, label in enumerate(indices):
                occurrence.setdefault(label, []).append(tensor_index)
                dimensions[label] = int(tensor.shape[axis])
        graph = nx.Graph()
        graph.add_nodes_from(range(len(nodes)))
        edge_labels: dict[tuple[int, int], list[int]] = {}
        for label, tensor_indices in occurrence.items():
            if label in output or dimensions[label] != 2 or len(tensor_indices) != 2:
                continue
            left, right = sorted(tensor_indices)
            graph.add_edge(left, right)
            edge_labels.setdefault((left, right), []).append(label)
        if not edge_labels:
            return ()
        centrality = nx.edge_betweenness_centrality(graph, normalized=True)
        scored: list[tuple[float, int]] = []
        for edge, score in centrality.items():
            key = tuple(sorted(edge))
            for label in edge_labels.get(key, ()):
                scored.append((float(score), int(label)))
        scored.sort(key=lambda item: (-item[0], item[1]))
        return tuple(label for _, label in scored)

    def plan(
        self,
        nodes: Sequence[tuple[np.ndarray, tuple[int, ...]]],
        output_indices: Sequence[int],
    ) -> _ContractionPlan:
        started = perf_counter()
        arguments = self._interleaved(nodes, output_indices)
        path, unsliced_info = oe.contract_path(
            *arguments,
            optimize=self.policy.contraction_optimizer,
        )
        unsliced_peak = int(unsliced_info.largest_intermediate)
        selected: list[int] = []
        representative_nodes = list(nodes)
        info = unsliced_info
        candidates = self._slice_candidates(nodes, output_indices)
        while int(info.largest_intermediate) > self.policy.contraction_memory_limit_elements:
            if not candidates or len(selected) >= len(candidates):
                raise RuntimeError(
                    "BLOCKED_RESOURCE_INFEASIBLE:CONTRACTION_MEMORY_BUDGET_UNSATISFIED"
                )
            if 2 ** (len(selected) + 1) > self.policy.contraction_max_slices:
                raise RuntimeError(
                    "BLOCKED_RESOURCE_INFEASIBLE:CONTRACTION_SLICE_BUDGET_EXCEEDED"
                )
            selected.append(candidates[len(selected)])
            representative_nodes = self._slice_nodes(
                nodes, {label: 0 for label in selected}
            )
            path, info = oe.contract_path(
                *self._interleaved(representative_nodes, output_indices),
                optimize=self.policy.contraction_optimizer,
            )
        return _ContractionPlan(
            path=tuple(tuple(int(value) for value in step) for step in path),
            sliced_indices=tuple(selected),
            unsliced_peak_elements=unsliced_peak,
            peak_elements=int(info.largest_intermediate),
            flop_estimate=float(info.opt_cost) * (2 ** len(selected)),
            planning_seconds=float(perf_counter() - started),
        )

    def _backend_contract(
        self,
        nodes: Sequence[tuple[np.ndarray, tuple[int, ...]]],
        output_indices: Sequence[int],
        path: Sequence[tuple[int, ...]],
    ) -> np.ndarray:
        if self.backend == "numpy":
            return np.asarray(
                oe.contract(
                    *self._interleaved(nodes, output_indices),
                    optimize=path,
                    backend="numpy",
                )
            )
        import cupy as cp  # type: ignore

        gpu_nodes = [(cp.asarray(tensor), indices) for tensor, indices in nodes]
        value = oe.contract(
            *self._interleaved(gpu_nodes, output_indices),
            optimize=path,
            backend="cupy",
        )
        return np.asarray(cp.asnumpy(value))

    def contract(
        self,
        nodes: Sequence[tuple[np.ndarray, tuple[int, ...]]],
        output_indices: Sequence[int],
        plan: _ContractionPlan,
    ) -> tuple[np.ndarray, ContractionTreePlanSummary]:
        started = perf_counter()
        assignments = tuple(
            dict(zip(plan.sliced_indices, values, strict=True))
            for values in product((0, 1), repeat=len(plan.sliced_indices))
        ) or ({},)
        mpi_world_size = 1
        parallel_mode = "SERIAL"
        mpi_comm = None
        if self.policy.contraction_enable_mpi:
            try:
                from mpi4py import MPI  # type: ignore

                mpi_comm = MPI.COMM_WORLD
                mpi_world_size = int(mpi_comm.Get_size())
            except Exception as error:
                raise RuntimeError(
                    "BLOCKED_BACKEND_UNAVAILABLE:MPI4PY_OR_MPI_RUNTIME_NOT_AVAILABLE"
                ) from error
            if mpi_world_size <= 1:
                raise RuntimeError(
                    "BLOCKED_BACKEND_UNAVAILABLE:MPI_WORLD_SIZE_MUST_EXCEED_ONE"
                )
        if mpi_comm is not None and mpi_world_size > 1:
            rank = int(mpi_comm.Get_rank())
            local_assignments = assignments[rank::mpi_world_size]
            local_value = None
            for assignment in local_assignments:
                value = self._backend_contract(
                    self._slice_nodes(nodes, assignment), output_indices, plan.path
                )
                local_value = value if local_value is None else local_value + value
            if local_value is None:
                local_value = np.zeros((2,) * len(output_indices), dtype=complex)
            result = np.asarray(mpi_comm.allreduce(local_value))
            parallel_mode = f"MPI_ALLREDUCE_{mpi_world_size}"
        elif len(assignments) > 1 and self.policy.contraction_parallel_workers > 1 and self.backend == "numpy":
            workers = min(self.policy.contraction_parallel_workers, len(assignments))

            def execute(assignment: dict[int, int]) -> np.ndarray:
                return self._backend_contract(
                    self._slice_nodes(nodes, assignment), output_indices, plan.path
                )

            with ThreadPoolExecutor(max_workers=workers) as executor:
                values = tuple(executor.map(execute, assignments))
            result = np.asarray(sum(values[1:], values[0]))
            parallel_mode = f"THREAD_POOL_{workers}"
        else:
            result = None
            for assignment in assignments:
                value = self._backend_contract(
                    self._slice_nodes(nodes, assignment), output_indices, plan.path
                )
                result = value if result is None else result + value
            if result is None:
                raise RuntimeError("Tensor contraction produced no slices")
            result = np.asarray(result)
            if self.backend == "cupy":
                parallel_mode = "CUDA_SINGLE_STREAM"
        elapsed = float(perf_counter() - started)
        summary = ContractionTreePlanSummary(
            optimizer=self.policy.contraction_optimizer,
            backend="CUPY_CUDA" if self.backend == "cupy" else "NUMPY_CPU",
            parallel_mode=parallel_mode,
            mpi_world_size=mpi_world_size,
            gpu_available=self._gpu_available,
            unsliced_peak_elements=plan.unsliced_peak_elements,
            peak_elements=plan.peak_elements,
            flop_estimate=plan.flop_estimate,
            sliced_index_count=len(plan.sliced_indices),
            slice_count=len(assignments),
            planning_seconds=plan.planning_seconds,
            contraction_seconds=elapsed,
        )
        return result, summary

    def contract_statevector(self) -> tuple[np.ndarray, ContractionTreePlanSummary]:
        nodes, outputs = self._build_ket_network()
        plan = self.plan(nodes, outputs)
        value, summary = self.contract(nodes, outputs, plan)
        return np.asarray(value, dtype=complex).reshape(-1), summary

    def contract_expectation(
        self,
        operator_map: dict[int, np.ndarray] | None = None,
        plan: _ContractionPlan | None = None,
    ) -> tuple[complex, ContractionTreePlanSummary, _ContractionPlan]:
        nodes, outputs = self._build_double_network(operator_map)
        active_plan = plan or self.plan(nodes, outputs)
        value, summary = self.contract(nodes, outputs, active_plan)
        return complex(np.asarray(value).reshape(())), summary, active_plan


@dataclass(frozen=True, slots=True)
class QuantumWorkloadProfile:
    """Runtime projection of the multidimensional quantum-method axis space.

    Only coordinates that affect executable representation selection live here.
    The full 70-axis registry remains authoritative in PhiCompiler; its digest is
    carried so a runtime decision cannot be detached from the scanned space.
    """

    qubit_count: int
    state_type: str = "pure_state"
    circuit_depth: int | None = None
    circuit_geometry: str = "general"
    tensor_network_geometry: str = "unspecified"
    entanglement_growth_rate: str = "unknown"
    estimated_treewidth: int | None = None
    t_gate_count: int | None = None
    magic_monotone: str = "unknown"
    open_system_regime: str = "closed"
    temporal_memory_length: int = 0
    observable_scope: str = "state_and_local_observables"
    target_error: float = 1e-6
    axis_registry_digest: str | None = None
    open_axes: tuple[str, ...] = ()

    def validate(self) -> None:
        if self.qubit_count < 1:
            raise ValueError("Workload qubit_count must be positive")
        if self.circuit_depth is not None and self.circuit_depth < 0:
            raise ValueError("Workload circuit_depth cannot be negative")
        if self.estimated_treewidth is not None and self.estimated_treewidth < 0:
            raise ValueError("Workload treewidth cannot be negative")
        if self.t_gate_count is not None and self.t_gate_count < 0:
            raise ValueError("Workload T-count cannot be negative")
        if self.temporal_memory_length < 0 or self.target_error <= 0.0:
            raise ValueError("Workload memory and error controls are inadmissible")
        if self.entanglement_growth_rate not in {"low", "moderate", "high", "unknown"}:
            raise ValueError("Unsupported entanglement-growth class")


@dataclass(frozen=True, slots=True)
class QuantumMethodDecision:
    representation: str
    reasons: tuple[str, ...]
    assumptions: tuple[str, ...]
    unmet_axes: tuple[str, ...]
    axis_registry_digest: str | None
    digest: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class AdaptiveExecutionPolicy:
    exact_choi_max_qubits: int = 6
    statevector_memory_limit_bytes: int = 512 * 1024 * 1024
    statevector_workspace_factor: int = 6
    mps_max_bond: int = 64
    mps_discarded_weight_budget: float = 1e-7
    mps_max_interaction_span: int = 4
    trotter_steps: int = 1
    trajectory_count: int = 8
    random_seed: int = 20260727
    contraction_optimizer: str = "greedy"
    contraction_memory_limit_elements: int = 131_072
    contraction_max_slices: int = 64
    contraction_parallel_workers: int = 2
    contraction_statevector_max_qubits: int = 18
    contraction_observable_max_count: int = 1024
    contraction_backend: str = "numpy"
    contraction_enable_mpi: bool = False
    ttn_enabled: bool = True
    ttn_max_bond: int = 64
    ttn_discarded_weight_budget: float = 1e-7
    ttn_treewidth_upper_bound: int = 12
    force_mps: bool = False
    force_ttn: bool = False
    force_contraction_tree: bool = False

    def validate(self) -> None:
        if self.exact_choi_max_qubits < 1:
            raise ValueError("Exact Choi limit must be positive")
        if self.statevector_memory_limit_bytes < 1024 or self.statevector_workspace_factor < 2:
            raise ValueError("State-vector memory/workspace contract is inadmissible")
        if (
            self.mps_max_bond < 2
            or self.mps_discarded_weight_budget <= 0.0
            or self.mps_max_interaction_span < 1
        ):
            raise ValueError("MPS bond, truncation and graph-span controls are inadmissible")
        if self.trotter_steps < 1 or self.trajectory_count < 2:
            raise ValueError("Evolution steps and trajectory count are inadmissible")
        if self.contraction_optimizer not in {
            "greedy",
            "auto",
            "auto-hq",
            "random-greedy",
            "random-greedy-128",
        }:
            raise ValueError("Unsupported contraction-tree optimizer")
        if (
            self.contraction_memory_limit_elements < 1024
            or self.contraction_max_slices < 1
            or self.contraction_parallel_workers < 1
            or self.contraction_statevector_max_qubits < 2
            or self.contraction_observable_max_count < 4
        ):
            raise ValueError("Contraction resource policy is inadmissible")
        if self.contraction_backend not in {"auto", "numpy", "cupy"}:
            raise ValueError("Contraction backend policy is inadmissible")
        if (
            self.ttn_max_bond < 2
            or self.ttn_discarded_weight_budget <= 0.0
            or self.ttn_treewidth_upper_bound < 1
        ):
            raise ValueError("TTN bond, truncation and treewidth controls are inadmissible")
        if sum(bool(value) for value in (self.force_mps, self.force_ttn, self.force_contraction_tree)) > 1:
            raise ValueError("Only one forced representation can be active")


@dataclass(frozen=True, slots=True)
class ScalableQuantumCertificate:
    qubit_count: int
    representation: str
    elapsed_time: float
    trotter_steps: int
    statevector_bytes_estimate: int
    statevector_workspace_bytes_estimate: int
    dense_choi_bytes_estimate: int
    interaction_term_count: int
    compiled_local_generator_count: int
    minimum_interaction_degree: int
    noncommuting_term_pairs: int
    max_bond_limit: int
    max_bond_used: int
    total_discarded_weight: float
    norm_gap: float
    energy_initial: float
    energy_final: float
    relative_energy_drift: float
    trotter_step_doubling_gap: float
    exact_reference_gap: float | None
    entangled_site_count: int
    maximum_single_site_entropy: float
    interaction_graph_bandwidth: int = 0
    interaction_treewidth_upper_bound: int = 0
    contraction_backend: str | None = None
    contraction_optimizer: str | None = None
    contraction_parallel_mode: str | None = None
    contraction_mpi_world_size: int = 1
    contraction_gpu_available: bool = False
    contraction_slice_count: int = 0
    contraction_sliced_index_count: int = 0
    contraction_unsliced_peak_elements: int = 0
    contraction_peak_elements: int = 0
    contraction_flop_estimate: float = 0.0
    contraction_planning_seconds: float = 0.0
    contraction_seconds: float = 0.0
    contraction_norm_crosscheck_gap: float | None = None
    ttn_tree_rotation_count: int = 0
    ttn_local_path_update_count: int = 0
    ttn_topology_rebuild_count: int = 0
    ttn_statevector_materialized: bool = False
    method_decision_digest: str | None = None
    blocked_reason: str | None = None

    @property
    def passed(self) -> bool:
        return (
            self.blocked_reason is None
            and self.minimum_interaction_degree > 0
            and self.noncommuting_term_pairs > 0
            and self.norm_gap < 1e-9
            and self.total_discarded_weight < 1e-5
            and self.relative_energy_drift < 5e-2
            and self.trotter_step_doubling_gap < 5e-2
            and (self.exact_reference_gap is None or self.exact_reference_gap < 1e-7)
            and (
                self.contraction_norm_crosscheck_gap is None
                or self.contraction_norm_crosscheck_gap < 1e-10
            )
            and self.entangled_site_count > 0
            and self.maximum_single_site_entropy > 1e-8
        )

    def to_dict(self) -> dict:
        return asdict(self) | {"passed": self.passed}


@dataclass(frozen=True, slots=True)
class TrajectoryEnsembleCertificate:
    qubit_count: int
    representation: str
    elapsed_time: float
    trotter_steps: int
    trajectory_count: int
    dephasing_rate: float
    random_seed: int
    max_bond_used: int
    total_discarded_weight: float
    maximum_norm_gap: float
    mean_excitation_probability: tuple[float, ...]
    mean_x_expectation: tuple[float, ...]
    maximum_sampling_standard_error: float
    small_system_density_gap: float
    blocked_reason: str | None = None

    @property
    def passed(self) -> bool:
        return (
            self.blocked_reason is None
            and self.trajectory_count >= 2
            and self.maximum_norm_gap < 1e-9
            and self.total_discarded_weight < 1e-4
            and self.maximum_sampling_standard_error < 0.5
            and self.small_system_density_gap < 0.08
            and all(0.0 <= value <= 1.0 for value in self.mean_excitation_probability)
        )

    def to_dict(self) -> dict:
        return asdict(self) | {"passed": self.passed}


@dataclass(frozen=True, slots=True)
class ProcessorNoiseSpec:
    """Physical single-qubit relaxation, dephasing and readout contract.

    Times use one common arbitrary unit.  The contract rejects, rather than silently clips,
    parameters violating the completely-positive relaxation bound ``T2 <= 2*T1``.
    """

    t1: float = 60.0
    t2: float = 45.0
    one_qubit_gate_time: float = 0.04
    two_qubit_gate_time: float = 0.16
    readout_0_to_1: float = 0.015
    readout_1_to_0: float = 0.025

    def validate(self) -> None:
        values = (
            self.t1,
            self.t2,
            self.one_qubit_gate_time,
            self.two_qubit_gate_time,
            self.readout_0_to_1,
            self.readout_1_to_0,
        )
        if not all(np.isfinite(value) for value in values):
            raise ValueError("Processor-noise parameters must be finite")
        if self.t1 <= 0.0 or self.t2 <= 0.0:
            raise ValueError("T1 and T2 must be positive")
        if self.t2 > 2.0 * self.t1 + 1e-12:
            raise ValueError("Physical relaxation requires T2 <= 2*T1")
        if self.one_qubit_gate_time <= 0.0 or self.two_qubit_gate_time <= 0.0:
            raise ValueError("Gate durations must be positive")
        if not (0.0 <= self.readout_0_to_1 <= 1.0 and 0.0 <= self.readout_1_to_0 <= 1.0):
            raise ValueError("Readout assignment probabilities must lie in [0,1]")

    @property
    def pure_dephasing_time(self) -> float:
        inverse = 1.0 / self.t2 - 1.0 / (2.0 * self.t1)
        return float(np.inf if inverse <= 1e-15 else 1.0 / inverse)

    def kraus_parameters(self, duration: float) -> tuple[float, float]:
        elapsed = float(duration)
        if elapsed < 0.0:
            raise ValueError("Channel duration must be non-negative")
        amplitude = 1.0 - np.exp(-elapsed / self.t1)
        t_phi = self.pure_dephasing_time
        # The phase-damping Kraus form below multiplies coherence by sqrt(1-p_phi).
        # Therefore p_phi = 1-exp(-2*dt/T_phi) is required to reproduce exp(-dt/T_phi)
        # and hence 1/T2 = 1/(2*T1) + 1/T_phi.
        phase = 0.0 if np.isinf(t_phi) else 1.0 - np.exp(-2.0 * elapsed / t_phi)
        return float(amplitude), float(phase)

    @property
    def readout_assignment(self) -> np.ndarray:
        return np.array(
            [
                [1.0 - self.readout_0_to_1, self.readout_0_to_1],
                [self.readout_1_to_0, 1.0 - self.readout_1_to_0],
            ],
            dtype=float,
        )


@dataclass(frozen=True, slots=True)
class LorentzianMemoryCertificate:
    linewidth: float
    coupling_rate: float
    maximum_kraus_completeness_gap: float
    minimum_survival_probability: float
    maximum_survival_probability: float
    blp_backflow: float
    markov_control_backflow: float
    backflow_detected: bool

    @property
    def passed(self) -> bool:
        return (
            self.linewidth > 0.0
            and self.coupling_rate > 0.0
            and self.maximum_kraus_completeness_gap < 1e-11
            and self.minimum_survival_probability >= -1e-12
            and self.maximum_survival_probability <= 1.0 + 1e-12
            and self.blp_backflow > 1e-5
            and self.markov_control_backflow < 1e-9
            and self.backflow_detected
        )

    def to_dict(self) -> dict:
        return asdict(self) | {"passed": self.passed}


@dataclass(frozen=True, slots=True)
class ToricCodeCertificate:
    lattice_size: int
    physical_qubit_count: int
    all_single_x_errors_corrected: bool
    all_single_z_errors_corrected: bool
    residual_syndrome_gap: int
    noncontractible_x_loop_detected: bool
    noncontractible_z_loop_detected: bool
    monte_carlo_trials: int
    physical_error_probability: float
    logical_failure_rate: float

    @property
    def passed(self) -> bool:
        return (
            self.lattice_size >= 3
            and self.physical_qubit_count == 2 * self.lattice_size * self.lattice_size
            and self.all_single_x_errors_corrected
            and self.all_single_z_errors_corrected
            and self.residual_syndrome_gap == 0
            and self.noncontractible_x_loop_detected
            and self.noncontractible_z_loop_detected
            and self.monte_carlo_trials > 0
            and 0.0 <= self.logical_failure_rate <= 1.0
        )

    def to_dict(self) -> dict:
        return asdict(self) | {"passed": self.passed}



@dataclass(frozen=True, slots=True)
class RetypedCellRecord:
    cell_id: str
    original_family: str
    corrected_family: str
    linearity_label: str
    owner_control: str
    admission: str
    correction: str


@dataclass(frozen=True, slots=True)
class RetypedOpenSystemsCertificate:
    """Executable correction of the supplied quantum_closed+driven NO-GO patterns.

    The density-matrix evolution remains linear and completely positive.  A ``nonlinear``
    cell is represented by a nonlinear Hamiltonian (Kerr interaction), never by a
    state-dependent fundamental quantum law; this preserves the no-signalling contract.
    """

    cell_records: tuple[RetypedCellRecord, ...]
    corrected_family: str
    master_equation_contract: str
    mollow_steady_population_analytic: float
    mollow_steady_population_numeric: float
    mollow_population_gap: float
    mollow_liouvillian_residual: float
    mollow_peak_frequencies: tuple[float, ...]
    mollow_sideband_frequency_gap: float
    mollow_triplet_detected: bool
    no_signalling_extension_gap: float
    closed_limit_trace_gap: float
    kerr_fock_dimension: int
    kerr_steady_residual: float
    kerr_trace_gap: float
    kerr_min_eigenvalue: float
    kerr_semiclassical_positive_roots: tuple[float, ...]
    kerr_stationary_state_kernel_dimension: int
    spatial_kernel_min_eigenvalue: float
    spatial_coherence_formula_gap: float
    spatial_dfs_suppression_ratio: float
    topological_flux_periodicity_gap: float
    topological_visibility_formula_gap: float
    topological_kraus_completeness_gap: float
    eft_generator_trace_gap: float
    eft_number_derivative_gap: float
    eft_channel_trace_gap: float
    eft_channel_min_eigenvalue: float
    eft_hierarchy_ratio: float
    rg_fixed_point_residual: float
    rg_scaling_exponent_gap: float
    rg_critical_slowing_ratio: float

    @property
    def passed(self) -> bool:
        return (
            len(self.cell_records) == 12
            and self.corrected_family == "quantum_open"
            and self.master_equation_contract == "LINEAR_GKSL_WITH_OPTIONAL_NONLINEAR_HAMILTONIAN"
            and self.mollow_population_gap < 1e-11
            and self.mollow_liouvillian_residual < 1e-11
            and self.mollow_triplet_detected
            and self.mollow_sideband_frequency_gap < 0.25
            and self.no_signalling_extension_gap < 1e-12
            and self.closed_limit_trace_gap < 1e-12
            and self.kerr_steady_residual < 1e-10
            and self.kerr_trace_gap < 1e-12
            and self.kerr_min_eigenvalue > -1e-10
            and len(self.kerr_semiclassical_positive_roots) == 3
            and self.kerr_stationary_state_kernel_dimension == 1
            and self.spatial_kernel_min_eigenvalue > -1e-12
            and self.spatial_coherence_formula_gap < 1e-10
            and self.spatial_dfs_suppression_ratio < 0.05
            and self.topological_flux_periodicity_gap < 1e-12
            and self.topological_visibility_formula_gap < 1e-10
            and self.topological_kraus_completeness_gap < 1e-12
            and self.eft_generator_trace_gap < 1e-11
            and self.eft_number_derivative_gap < 1e-10
            and self.eft_channel_trace_gap < 1e-11
            and self.eft_channel_min_eigenvalue > -1e-10
            and 0.0 < self.eft_hierarchy_ratio < 1.0
            and self.rg_fixed_point_residual < 1e-14
            and self.rg_scaling_exponent_gap < 1e-12
            and self.rg_critical_slowing_ratio > 9.0
        )

    def to_dict(self) -> dict:
        return asdict(self) | {"passed": self.passed}


def _steady_state_density(hamiltonian: np.ndarray, collapse_operators: Sequence[np.ndarray]) -> tuple[np.ndarray, np.ndarray]:
    dynamics = FiniteQuantumDynamics(hamiltonian, collapse_operators)
    generator = dynamics.liouvillian()
    dimension = hamiltonian.shape[0]
    constrained = generator.copy()
    target = np.zeros(dimension * dimension, dtype=complex)
    constrained[-1, :] = _vec(np.eye(dimension)).conj()
    target[-1] = 1.0
    state = np.linalg.lstsq(constrained, target, rcond=None)[0]
    density = _unvec(state, dimension)
    density = 0.5 * (density + density.conj().T)
    density /= np.trace(density)
    return density, generator


def _annihilation_operator(dimension: int) -> np.ndarray:
    if dimension < 2:
        raise ValueError("Fock-space dimension must be at least two")
    operator = np.zeros((dimension, dimension), dtype=complex)
    for occupation in range(1, dimension):
        operator[occupation - 1, occupation] = np.sqrt(float(occupation))
    return operator


def _partial_trace_first_qubit(density: np.ndarray) -> np.ndarray:
    tensor = np.asarray(density, dtype=complex).reshape(2, 2, 2, 2)
    return np.trace(tensor, axis1=0, axis2=2)


def _mollow_control() -> dict[str, object]:
    sigma_minus = np.array([[0.0, 1.0], [0.0, 0.0]], dtype=complex)
    sigma_plus = sigma_minus.conj().T
    omega_rabi = 5.0
    decay_rate = 1.0
    hamiltonian = 0.5 * omega_rabi * _PAULI["X"]
    density, generator = _steady_state_density(
        hamiltonian, (np.sqrt(decay_rate) * sigma_minus,)
    )
    analytic_population = omega_rabi**2 / (decay_rate**2 + 2.0 * omega_rabi**2)
    numerical_population = float(density[1, 1].real)
    residual = float(np.linalg.norm(generator @ _vec(density)))

    mean_lowering = np.trace(sigma_minus @ density)
    regression_seed = sigma_minus @ density - mean_lowering * density
    frequency_grid = np.linspace(-8.0, 8.0, 1601)
    spectrum = np.empty_like(frequency_grid)
    identity = np.eye(generator.shape[0], dtype=complex)
    for index, frequency in enumerate(frequency_grid):
        response = np.linalg.lstsq(
            generator + 1j * frequency * identity,
            _vec(regression_seed),
            rcond=None,
        )[0]
        spectrum[index] = float(
            np.real(-np.trace(sigma_plus @ _unvec(response, 2)))
        )
    peak_indices, _ = find_peaks(
        spectrum,
        prominence=max(1e-12, 0.02 * float(np.max(spectrum))),
        distance=120,
    )
    selected = sorted(
        peak_indices,
        key=lambda item: float(spectrum[item]),
        reverse=True,
    )[:3]
    peak_frequencies = tuple(sorted(float(frequency_grid[item]) for item in selected))
    triplet = len(peak_frequencies) == 3 and peak_frequencies[0] < -1.0 and peak_frequencies[2] > 1.0
    sideband_gap = float("inf")
    if triplet:
        sideband_gap = max(
            abs(abs(peak_frequencies[0]) - omega_rabi),
            abs(abs(peak_frequencies[2]) - omega_rabi),
            abs(peak_frequencies[1]),
        )

    bell = np.zeros(4, dtype=complex)
    bell[0] = bell[-1] = 1.0 / np.sqrt(2.0)
    bell_density = np.outer(bell, bell.conj())
    reduced_before = _partial_trace_first_qubit(bell_density)
    damped = _apply_local_kraus_density(
        bell_density, _amplitude_damping_kraus(0.23), 0, 2
    )
    reduced_after = _partial_trace_first_qubit(damped)
    no_signalling_gap = float(np.linalg.norm(reduced_after - reduced_before, ord="fro"))

    unitary_channel = expm(-1j * hamiltonian * 0.17)
    closed_density = unitary_channel @ density @ unitary_channel.conj().T
    closed_trace_gap = abs(float(np.trace(closed_density).real) - 1.0)
    return {
        "analytic_population": float(analytic_population),
        "numeric_population": numerical_population,
        "population_gap": abs(numerical_population - analytic_population),
        "residual": residual,
        "peak_frequencies": peak_frequencies,
        "sideband_gap": sideband_gap,
        "triplet": bool(triplet),
        "no_signalling_gap": no_signalling_gap,
        "closed_trace_gap": closed_trace_gap,
    }


def _kerr_control() -> dict[str, object]:
    dimension = 12
    annihilation = _annihilation_operator(dimension)
    creation = annihilation.conj().T
    number = creation @ annihilation
    detuning = -3.0
    nonlinearity = 1.0
    drive = 1.5
    loss = 1.0
    hamiltonian = (
        detuning * number
        + 0.5 * nonlinearity * (creation @ creation @ annihilation @ annihilation)
        + 1j * drive * (creation - annihilation)
    )
    density, generator = _steady_state_density(
        hamiltonian, (np.sqrt(loss) * annihilation,)
    )
    coefficients = (
        nonlinearity**2,
        2.0 * detuning * nonlinearity,
        detuning**2 + (loss / 2.0) ** 2,
        -(drive**2),
    )
    roots = np.roots(coefficients)
    positive_roots = tuple(
        sorted(
            float(root.real)
            for root in roots
            if abs(root.imag) < 1e-9 and root.real >= 0.0
        )
    )
    zero_modes = int(np.count_nonzero(np.abs(np.linalg.eigvals(generator)) < 1e-8))
    return {
        "dimension": dimension,
        "residual": float(np.linalg.norm(generator @ _vec(density))),
        "trace_gap": abs(float(np.trace(density).real) - 1.0),
        "min_eigenvalue": float(np.min(np.linalg.eigvalsh(density)).real),
        "positive_roots": positive_roots,
        "kernel_dimension": zero_modes,
    }


def _spatially_correlated_noise_control() -> dict[str, float]:
    gamma = 0.4
    correlation_length = 1.0
    near_separation = 0.2
    far_separation = 5.0
    near_correlation = float(np.exp(-(near_separation**2) / (2.0 * correlation_length**2)))
    far_correlation = float(np.exp(-(far_separation**2) / (2.0 * correlation_length**2)))
    correlation = gamma * np.array(
        [[1.0, near_correlation], [near_correlation, 1.0]], dtype=float
    )
    eigenvalues, eigenvectors = np.linalg.eigh(correlation)
    z_0 = np.kron(_PAULI["Z"], _PAULI["I"])
    z_1 = np.kron(_PAULI["I"], _PAULI["Z"])
    collapse: list[np.ndarray] = []
    for mode, eigenvalue in enumerate(eigenvalues):
        if eigenvalue > 1e-15:
            vector = eigenvectors[:, mode]
            collapse.append(np.sqrt(eigenvalue) * (vector[0] * z_0 + vector[1] * z_1))
    state = np.zeros(4, dtype=complex)
    state[1] = state[2] = 1.0 / np.sqrt(2.0)
    density = np.outer(state, state.conj())
    elapsed = 0.7
    evolved = FiniteQuantumDynamics(np.zeros((4, 4), dtype=complex), collapse).evolve_density(
        density, elapsed
    )
    near_rate = 4.0 * gamma * (1.0 - near_correlation)
    far_rate = 4.0 * gamma * (1.0 - far_correlation)
    expected_coherence = 0.5 * np.exp(-near_rate * elapsed)
    return {
        "kernel_min_eigenvalue": float(np.min(eigenvalues)),
        "coherence_gap": abs(float(abs(evolved[1, 2])) - expected_coherence),
        "dfs_ratio": float(near_rate / far_rate),
    }


def _topological_flux_control() -> dict[str, float]:
    flux = 0.237
    tunnelling = 0.8
    def hamiltonian(value: float) -> np.ndarray:
        phase = np.exp(2j * np.pi * value)
        return -tunnelling * np.array([[0.0, phase], [phase.conjugate(), 0.0]], dtype=complex)
    periodicity_gap = float(np.linalg.norm(hamiltonian(flux + 1.0) - hamiltonian(flux)))
    flux_noise = 0.02
    flux_quantum = 1.0
    rate = 2.0 * np.pi**2 * flux_noise / (flux_quantum**2)
    collapse = (np.sqrt(rate / 2.0) * _PAULI["Z"],)
    plus = np.array([1.0, 1.0], dtype=complex) / np.sqrt(2.0)
    density = np.outer(plus, plus.conj())
    elapsed = 0.8
    evolved = FiniteQuantumDynamics(np.zeros((2, 2), dtype=complex), collapse).evolve_density(
        density, elapsed
    )
    expected = 0.5 * np.exp(-rate * elapsed)
    probability = 1.0 - np.exp(-rate * elapsed)
    completeness = _kraus_completeness_gap(_phase_damping_kraus(probability))
    return {
        "periodicity_gap": periodicity_gap,
        "visibility_gap": abs(float(abs(evolved[0, 1])) - expected),
        "kraus_gap": float(completeness),
    }


def _open_eft_control() -> dict[str, float]:
    dimension = 10
    annihilation = _annihilation_operator(dimension)
    creation = annihilation.conj().T
    number = creation @ annihilation
    gamma_one = 0.3
    gamma_two = 0.8
    cutoff = 5.0
    collapse = (
        np.sqrt(gamma_one) * annihilation,
        np.sqrt(gamma_two) / cutoff * (annihilation @ annihilation),
    )
    hamiltonian = 0.2 * number
    dynamics = FiniteQuantumDynamics(hamiltonian, collapse)
    generator = dynamics.liouvillian()
    trace_row = _vec(np.eye(dimension)).conj() @ generator
    trace_generator_gap = float(np.linalg.norm(trace_row))

    alpha = 1.1
    coefficients = np.array(
        [alpha**occupation / np.sqrt(float(math.factorial(occupation))) for occupation in range(dimension)],
        dtype=complex,
    ) * np.exp(-0.5 * alpha**2)
    coefficients /= np.linalg.norm(coefficients)
    density = np.outer(coefficients, coefficients.conj())
    generator_density = _unvec(generator @ _vec(density), dimension)
    numerical_derivative = float(np.real(np.trace(number @ generator_density)))
    mean_number = float(np.real(np.trace(number @ density)))
    factorial_second = float(
        np.real(np.trace((number @ (number - np.eye(dimension))) @ density))
    )
    analytic_derivative = (
        -gamma_one * mean_number
        - 2.0 * gamma_two / cutoff**2 * factorial_second
    )
    hierarchy_ratio = (
        (2.0 * gamma_two / cutoff**2 * factorial_second)
        / max(gamma_one * mean_number, 1e-30)
    )
    evolved = dynamics.evolve_density(density, 0.02)
    return {
        "trace_generator_gap": trace_generator_gap,
        "derivative_gap": abs(numerical_derivative - analytic_derivative),
        "channel_trace_gap": abs(float(np.trace(evolved).real) - 1.0),
        "channel_min_eigenvalue": float(np.min(np.linalg.eigvalsh(evolved)).real),
        "hierarchy_ratio": float(hierarchy_ratio),
    }


def _driven_dissipative_rg_control() -> dict[str, float]:
    fixed_point = 1.3
    relevant_exponent = 0.7
    initial_delta = 0.4
    scales = np.exp(np.linspace(0.0, 4.0, 41))
    running = fixed_point + initial_delta * scales ** (-relevant_exponent)
    fitted = -float(
        np.polyfit(np.log(scales), np.log(np.abs(running - fixed_point)), 1)[0]
    )
    fixed_residual = abs(-relevant_exponent * (fixed_point - fixed_point))
    distances = np.array([0.5, 0.25, 0.1, 0.05])
    relaxation_times = distances ** (-1.0)
    return {
        "fixed_residual": float(fixed_residual),
        "exponent_gap": abs(fitted - relevant_exponent),
        "slowing_ratio": float(relaxation_times[-1] / relaxation_times[0]),
    }


def _retyped_cell_records() -> tuple[RetypedCellRecord, ...]:
    rows = (
        ("CELL-EC2D2685B5D9", "linear", "driven_two_level_gksl", "KNOWN_REFERENCE"),
        ("CELL-37633C578732", "nonlinear", "driven_kerr_gksl", "KNOWN_REFERENCE"),
        ("CELL-164D5C0F09DB", "linear", "spatially_correlated_gksl", "KNOWN_REFERENCE"),
        ("CELL-3F5F872CDEC5", "nonlinear", "spatially_correlated_gksl", "PARAMETRIC_CONTROL"),
        ("CELL-758BF24C85FA", "linear", "topological_flux_dephasing", "PARAMETRIC_CONTROL"),
        ("CELL-0350E68AC947", "nonlinear", "topological_flux_dephasing", "PARAMETRIC_CONTROL"),
        ("CELL-B58642DEEAA7", "linear", "driven_dissipative_rg", "PARAMETRIC_CONTROL"),
        ("CELL-0AF61C80B45C", "nonlinear", "driven_dissipative_rg", "PARAMETRIC_CONTROL"),
        ("CELL-E71F0D72B889", "linear", "open_eft_lindblad", "PARAMETRIC_CONTROL"),
        ("CELL-13F3C5830C63", "nonlinear", "open_eft_lindblad", "PARAMETRIC_CONTROL"),
        ("CELL-53ACF20A3230", "linear", "running_coupling_rg", "PARAMETRIC_CONTROL"),
        ("CELL-7046A69ACF2E", "nonlinear", "running_coupling_rg", "PARAMETRIC_CONTROL"),
    )
    return tuple(
        RetypedCellRecord(
            cell_id=cell_id,
            original_family="quantum_closed",
            corrected_family="quantum_open",
            linearity_label=linearity,
            owner_control=owner,
            admission=admission,
            correction=(
                "RETYPE_CLOSED_DRIVEN_TO_OPEN_GKSL; "
                "NONLINEAR_LABEL_MEANS_NONLINEAR_HAMILTONIAN_NOT_NONLINEAR_STATE_MAP"
            ),
        )
        for cell_id, linearity, owner, admission in rows
    )


def retyped_open_systems_control() -> RetypedOpenSystemsCertificate:
    mollow = _mollow_control()
    kerr = _kerr_control()
    spatial = _spatially_correlated_noise_control()
    topology = _topological_flux_control()
    eft = _open_eft_control()
    rg = _driven_dissipative_rg_control()
    return RetypedOpenSystemsCertificate(
        cell_records=_retyped_cell_records(),
        corrected_family="quantum_open",
        master_equation_contract="LINEAR_GKSL_WITH_OPTIONAL_NONLINEAR_HAMILTONIAN",
        mollow_steady_population_analytic=mollow["analytic_population"],
        mollow_steady_population_numeric=mollow["numeric_population"],
        mollow_population_gap=mollow["population_gap"],
        mollow_liouvillian_residual=mollow["residual"],
        mollow_peak_frequencies=mollow["peak_frequencies"],
        mollow_sideband_frequency_gap=mollow["sideband_gap"],
        mollow_triplet_detected=mollow["triplet"],
        no_signalling_extension_gap=mollow["no_signalling_gap"],
        closed_limit_trace_gap=mollow["closed_trace_gap"],
        kerr_fock_dimension=kerr["dimension"],
        kerr_steady_residual=kerr["residual"],
        kerr_trace_gap=kerr["trace_gap"],
        kerr_min_eigenvalue=kerr["min_eigenvalue"],
        kerr_semiclassical_positive_roots=kerr["positive_roots"],
        kerr_stationary_state_kernel_dimension=kerr["kernel_dimension"],
        spatial_kernel_min_eigenvalue=spatial["kernel_min_eigenvalue"],
        spatial_coherence_formula_gap=spatial["coherence_gap"],
        spatial_dfs_suppression_ratio=spatial["dfs_ratio"],
        topological_flux_periodicity_gap=topology["periodicity_gap"],
        topological_visibility_formula_gap=topology["visibility_gap"],
        topological_kraus_completeness_gap=topology["kraus_gap"],
        eft_generator_trace_gap=eft["trace_generator_gap"],
        eft_number_derivative_gap=eft["derivative_gap"],
        eft_channel_trace_gap=eft["channel_trace_gap"],
        eft_channel_min_eigenvalue=eft["channel_min_eigenvalue"],
        eft_hierarchy_ratio=eft["hierarchy_ratio"],
        rg_fixed_point_residual=rg["fixed_residual"],
        rg_scaling_exponent_gap=rg["exponent_gap"],
        rg_critical_slowing_ratio=rg["slowing_ratio"],
    )


@dataclass(frozen=True, slots=True)
class ProcessorEmulatorCertificate:
    qubit_count: int
    openqasm_version: str
    source_sha256: str
    backend_requested: str
    backend_resolved: str | None
    accelerator_runtime: str | None
    circuit_instruction_count: int
    statevector_norm_gap: float | None
    accelerator_numpy_state_gap: float | None
    ghz_support_leakage: float | None
    ghz_balance_gap: float | None
    arbitrary_control_target_gap: float | None
    dynamic_measurement_count: int
    dynamic_loop_iterations: int
    dynamic_branch_count: int
    dynamic_feedforward_gap: float | None
    dynamic_max_clock_ns: float | None
    maximum_kraus_completeness_gap: float | None
    trajectory_count: int
    trajectory_density_gap: float | None
    readout_assignment_gap: float | None
    readout_sampling_gap: float | None
    accelerator_qualification: AcceleratorQualification | None
    pulse_control: PulseControlCertificate | None
    adaptive_jump_control: AdaptiveJumpCertificate | None
    circuit_level_qec: CircuitLevelQECCertificate | None
    lorentzian_memory: LorentzianMemoryCertificate | None
    toric_code: ToricCodeCertificate | None
    retyped_open_systems: RetypedOpenSystemsCertificate | None
    blocked_reason: str | None = None

    @property
    def passed(self) -> bool:
        return (
            self.blocked_reason is None
            and self.qubit_count >= 3
            and self.openqasm_version == "3.0"
            and len(self.source_sha256) == 64
            and self.backend_resolved is not None
            and self.statevector_norm_gap is not None
            and self.statevector_norm_gap < 1e-11
            and self.accelerator_numpy_state_gap is not None
            and self.accelerator_numpy_state_gap < 1e-11
            and self.ghz_support_leakage is not None
            and self.ghz_support_leakage < 1e-11
            and self.ghz_balance_gap is not None
            and self.ghz_balance_gap < 1e-11
            and self.arbitrary_control_target_gap is not None
            and self.arbitrary_control_target_gap < 1e-11
            and self.dynamic_measurement_count >= 2
            and self.dynamic_loop_iterations >= 1
            and self.dynamic_branch_count >= 1
            and self.dynamic_feedforward_gap is not None
            and self.dynamic_feedforward_gap < 1e-11
            and self.dynamic_max_clock_ns is not None
            and self.dynamic_max_clock_ns > 0.0
            and self.maximum_kraus_completeness_gap is not None
            and self.maximum_kraus_completeness_gap < 1e-11
            and self.trajectory_count >= 256
            and self.trajectory_density_gap is not None
            and self.trajectory_density_gap < 0.04
            and self.readout_assignment_gap is not None
            and self.readout_assignment_gap < 1e-12
            and self.readout_sampling_gap is not None
            and self.readout_sampling_gap < 0.035
            and self.accelerator_qualification is not None
            and self.accelerator_qualification.passed
            and self.pulse_control is not None
            and self.pulse_control.passed
            and self.adaptive_jump_control is not None
            and self.adaptive_jump_control.passed
            and self.circuit_level_qec is not None
            and self.circuit_level_qec.passed
            and self.lorentzian_memory is not None
            and self.lorentzian_memory.passed
            and self.toric_code is not None
            and self.toric_code.passed
            and self.retyped_open_systems is not None
            and self.retyped_open_systems.passed
        )

    def to_dict(self) -> dict:
        payload = asdict(self) | {"passed": self.passed}
        for name, value in (
            ("accelerator_qualification", self.accelerator_qualification),
            ("pulse_control", self.pulse_control),
            ("adaptive_jump_control", self.adaptive_jump_control),
            ("circuit_level_qec", self.circuit_level_qec),
            ("lorentzian_memory", self.lorentzian_memory),
            ("toric_code", self.toric_code),
            ("retyped_open_systems", self.retyped_open_systems),
        ):
            if value is not None:
                payload[name]["passed"] = value.passed
        return payload


class _ToricCodeMWPM:
    """Perfect-syndrome toric-code control with homology-aware MWPM recovery."""

    def __init__(self, lattice_size: int):
        if lattice_size < 3:
            raise ValueError("Toric-code lattice size must be at least three")
        self.size = int(lattice_size)
        self.edge_count = 2 * self.size * self.size

    def h(self, x: int, y: int) -> int:
        return (y % self.size) * self.size + (x % self.size)

    def v(self, x: int, y: int) -> int:
        return self.size * self.size + (y % self.size) * self.size + (x % self.size)

    def star_edges(self, x: int, y: int) -> tuple[int, int, int, int]:
        return (self.h(x, y), self.h(x - 1, y), self.v(x, y), self.v(x, y - 1))

    def plaquette_edges(self, x: int, y: int) -> tuple[int, int, int, int]:
        return (self.h(x, y), self.v(x + 1, y), self.h(x, y + 1), self.v(x, y))

    def star_syndrome(self, z_errors: np.ndarray) -> tuple[tuple[int, int], ...]:
        return tuple(
            (x, y)
            for y in range(self.size)
            for x in range(self.size)
            if sum(int(z_errors[index]) for index in self.star_edges(x, y)) % 2
        )

    def plaquette_syndrome(self, x_errors: np.ndarray) -> tuple[tuple[int, int], ...]:
        return tuple(
            (x, y)
            for y in range(self.size)
            for x in range(self.size)
            if sum(int(x_errors[index]) for index in self.plaquette_edges(x, y)) % 2
        )

    def _delta(self, first: int, second: int) -> tuple[int, int]:
        forward = (second - first) % self.size
        backward = forward - self.size
        chosen = forward if abs(forward) <= abs(backward) else backward
        return int(chosen), abs(int(chosen))

    def _matching(self, syndrome: Sequence[tuple[int, int]]) -> tuple[tuple[tuple[int, int], tuple[int, int]], ...]:
        if len(syndrome) % 2:
            raise ValueError("Toric-code syndrome parity must be even")
        graph = nx.Graph()
        graph.add_nodes_from(range(len(syndrome)))
        for left in range(len(syndrome)):
            for right in range(left + 1, len(syndrome)):
                _, dx = self._delta(syndrome[left][0], syndrome[right][0])
                _, dy = self._delta(syndrome[left][1], syndrome[right][1])
                # Deterministic lexical perturbation breaks equal-distance ties without changing
                # the integer minimum-distance objective.
                weight = (dx + dy) * 1_000_000 + left * len(syndrome) + right
                graph.add_edge(left, right, weight=weight)
        raw = nx.algorithms.matching.min_weight_matching(graph, weight="weight")
        if len(raw) * 2 != len(syndrome):
            raise RuntimeError("MWPM did not return a perfect syndrome matching")
        return tuple((syndrome[min(a, b)], syndrome[max(a, b)]) for a, b in raw)

    def _primal_path(self, start: tuple[int, int], end: tuple[int, int]) -> np.ndarray:
        correction = np.zeros(self.edge_count, dtype=np.uint8)
        x, y = start
        dx, _ = self._delta(x, end[0])
        step_x = 1 if dx >= 0 else -1
        for _ in range(abs(dx)):
            if step_x > 0:
                correction[self.h(x, y)] ^= 1
                x = (x + 1) % self.size
            else:
                correction[self.h(x - 1, y)] ^= 1
                x = (x - 1) % self.size
        dy, _ = self._delta(y, end[1])
        step_y = 1 if dy >= 0 else -1
        for _ in range(abs(dy)):
            if step_y > 0:
                correction[self.v(x, y)] ^= 1
                y = (y + 1) % self.size
            else:
                correction[self.v(x, y - 1)] ^= 1
                y = (y - 1) % self.size
        return correction

    def _dual_path(self, start: tuple[int, int], end: tuple[int, int]) -> np.ndarray:
        correction = np.zeros(self.edge_count, dtype=np.uint8)
        x, y = start
        dx, _ = self._delta(x, end[0])
        step_x = 1 if dx >= 0 else -1
        for _ in range(abs(dx)):
            if step_x > 0:
                x = (x + 1) % self.size
                correction[self.v(x, y)] ^= 1
            else:
                correction[self.v(x, y)] ^= 1
                x = (x - 1) % self.size
        dy, _ = self._delta(y, end[1])
        step_y = 1 if dy >= 0 else -1
        for _ in range(abs(dy)):
            if step_y > 0:
                y = (y + 1) % self.size
                correction[self.h(x, y)] ^= 1
            else:
                correction[self.h(x, y)] ^= 1
                y = (y - 1) % self.size
        return correction

    def decode_z(self, errors: np.ndarray) -> tuple[np.ndarray, tuple[int, int], int]:
        correction = np.zeros(self.edge_count, dtype=np.uint8)
        for start, end in self._matching(self.star_syndrome(errors)):
            correction ^= self._primal_path(start, end)
        residual = np.asarray(errors, dtype=np.uint8) ^ correction
        syndrome_gap = len(self.star_syndrome(residual))
        homology = (
            int(sum(residual[self.h(self.size - 1, y)] for y in range(self.size)) % 2),
            int(sum(residual[self.v(x, self.size - 1)] for x in range(self.size)) % 2),
        )
        return residual, homology, syndrome_gap

    def decode_x(self, errors: np.ndarray) -> tuple[np.ndarray, tuple[int, int], int]:
        correction = np.zeros(self.edge_count, dtype=np.uint8)
        for start, end in self._matching(self.plaquette_syndrome(errors)):
            correction ^= self._dual_path(start, end)
        residual = np.asarray(errors, dtype=np.uint8) ^ correction
        syndrome_gap = len(self.plaquette_syndrome(residual))
        homology = (
            int(sum(residual[self.v(0, y)] for y in range(self.size)) % 2),
            int(sum(residual[self.h(x, 0)] for x in range(self.size)) % 2),
        )
        return residual, homology, syndrome_gap

    def certify(self, error_probability: float, trials: int, seed: int) -> ToricCodeCertificate:
        if not (0.0 <= error_probability <= 1.0) or trials < 1:
            raise ValueError("Toric-code Monte Carlo contract is inadmissible")
        all_x = True
        all_z = True
        max_syndrome = 0
        for edge in range(self.edge_count):
            x_error = np.zeros(self.edge_count, dtype=np.uint8)
            x_error[edge] = 1
            _, homology_x, gap_x = self.decode_x(x_error)
            all_x = all_x and gap_x == 0 and homology_x == (0, 0)
            z_error = np.zeros(self.edge_count, dtype=np.uint8)
            z_error[edge] = 1
            _, homology_z, gap_z = self.decode_z(z_error)
            all_z = all_z and gap_z == 0 and homology_z == (0, 0)
            max_syndrome = max(max_syndrome, gap_x, gap_z)

        z_loop = np.zeros(self.edge_count, dtype=np.uint8)
        for x in range(self.size):
            z_loop[self.h(x, 0)] = 1
        _, z_homology, z_gap = self.decode_z(z_loop)
        x_loop = np.zeros(self.edge_count, dtype=np.uint8)
        for x in range(self.size):
            x_loop[self.v(x, 0)] = 1
        _, x_homology, x_gap = self.decode_x(x_loop)
        max_syndrome = max(max_syndrome, z_gap, x_gap)

        rng = np.random.default_rng(seed)
        failures = 0
        for _ in range(trials):
            x_errors = (rng.random(self.edge_count) < error_probability).astype(np.uint8)
            z_errors = (rng.random(self.edge_count) < error_probability).astype(np.uint8)
            _, hx, gx = self.decode_x(x_errors)
            _, hz, gz = self.decode_z(z_errors)
            failures += int(gx > 0 or gz > 0 or hx != (0, 0) or hz != (0, 0))
        return ToricCodeCertificate(
            lattice_size=self.size,
            physical_qubit_count=self.edge_count,
            all_single_x_errors_corrected=bool(all_x),
            all_single_z_errors_corrected=bool(all_z),
            residual_syndrome_gap=int(max_syndrome),
            noncontractible_x_loop_detected=bool(x_homology != (0, 0)),
            noncontractible_z_loop_detected=bool(z_homology != (0, 0)),
            monte_carlo_trials=int(trials),
            physical_error_probability=float(error_probability),
            logical_failure_rate=float(failures / trials),
        )


def _amplitude_damping_kraus(probability: float) -> tuple[np.ndarray, np.ndarray]:
    value = float(probability)
    if value < -1e-15 or value > 1.0 + 1e-15:
        raise ValueError("Amplitude-damping probability is outside [0,1]")
    value = float(np.clip(value, 0.0, 1.0))
    return (
        np.array([[1.0, 0.0], [0.0, np.sqrt(1.0 - value)]], dtype=complex),
        np.array([[0.0, np.sqrt(value)], [0.0, 0.0]], dtype=complex),
    )


def _phase_damping_kraus(probability: float) -> tuple[np.ndarray, np.ndarray]:
    value = float(probability)
    if value < -1e-15 or value > 1.0 + 1e-15:
        raise ValueError("Phase-damping probability is outside [0,1]")
    value = float(np.clip(value, 0.0, 1.0))
    return (
        np.array([[1.0, 0.0], [0.0, np.sqrt(1.0 - value)]], dtype=complex),
        np.array([[0.0, 0.0], [0.0, np.sqrt(value)]], dtype=complex),
    )


def _kraus_completeness_gap(kraus: Sequence[np.ndarray]) -> float:
    dimension = kraus[0].shape[0]
    total = np.zeros((dimension, dimension), dtype=complex)
    for operator in kraus:
        total += operator.conj().T @ operator
    return float(np.linalg.norm(total - np.eye(dimension), ord="fro"))


def _apply_local_kraus_density(
    density: np.ndarray,
    kraus: Sequence[np.ndarray],
    qubit: int,
    qubit_count: int,
) -> np.ndarray:
    result = np.zeros_like(density, dtype=complex)
    for local in kraus:
        full = np.array([[1.0 + 0.0j]])
        for site in range(qubit_count):
            full = np.kron(full, local if site == qubit else _PAULI["I"])
        result += full @ density @ full.conj().T
    return result


def _lorentzian_survival_amplitude(times: np.ndarray, linewidth: float, coupling_rate: float) -> np.ndarray:
    lam = float(linewidth)
    gamma = float(coupling_rate)
    if lam <= 0.0 or gamma <= 0.0:
        raise ValueError("Lorentzian reservoir parameters must be positive")
    delta = np.sqrt(complex(lam * lam - 2.0 * gamma * lam))
    time = np.asarray(times, dtype=float)
    if abs(delta) < 1e-14:
        return np.exp(-lam * time / 2.0) * (1.0 + lam * time / 2.0)
    return np.exp(-lam * time / 2.0) * (
        np.cosh(delta * time / 2.0) + (lam / delta) * np.sinh(delta * time / 2.0)
    )


def _lorentzian_memory_certificate(
    linewidth: float,
    coupling_rate: float,
    maximum_time: float = 30.0,
    samples: int = 2001,
) -> LorentzianMemoryCertificate:
    times = np.linspace(0.0, float(maximum_time), int(samples))
    amplitude = _lorentzian_survival_amplitude(times, linewidth, coupling_rate)
    survival = np.abs(amplitude) ** 2
    gaps = []
    for value in survival:
        gaps.append(_kraus_completeness_gap(_amplitude_damping_kraus(1.0 - float(value))))
    increments = np.diff(survival)
    backflow = float(np.sum(increments[increments > 0.0]))
    markov_amplitude = _lorentzian_survival_amplitude(times, linewidth=1.0, coupling_rate=0.05)
    markov_survival = np.abs(markov_amplitude) ** 2
    markov_increments = np.diff(markov_survival)
    markov_backflow = float(np.sum(markov_increments[markov_increments > 1e-14]))
    return LorentzianMemoryCertificate(
        linewidth=float(linewidth),
        coupling_rate=float(coupling_rate),
        maximum_kraus_completeness_gap=max(gaps),
        minimum_survival_probability=float(np.min(survival)),
        maximum_survival_probability=float(np.max(survival)),
        blp_backflow=backflow,
        markov_control_backflow=markov_backflow,
        backflow_detected=bool(backflow > 1e-5),
    )

class AdaptiveQuantumDynamics:
    """Single adaptive owner for exact, Krylov, MPS, contraction-tree and trajectory execution.

    The representation is selected from the formal resource contract.  It never silently
    materializes a state vector or Choi matrix beyond the configured limit and returns a blocked
    certificate when the requested accuracy cannot be sustained.
    """

    def __init__(
        self,
        hamiltonian: LocalPauliHamiltonian,
        policy: AdaptiveExecutionPolicy | None = None,
        workload_profile: QuantumWorkloadProfile | None = None,
    ):
        self.hamiltonian = hamiltonian
        self.policy = policy or AdaptiveExecutionPolicy()
        self.policy.validate()
        self.workload_profile = workload_profile
        if self.workload_profile is not None:
            self.workload_profile.validate()
            if self.workload_profile.qubit_count != self.hamiltonian.qubit_count:
                raise ValueError("Workload profile qubit count differs from Hamiltonian")
        # Terms acting on the same one- or two-site support are summed before exponentiation.
        # This is an exact algebraic consolidation for the local generator and avoids repeated
        # SVD factorizations for XX/YY/ZZ contributions on the same simplicial edge.
        grouped: dict[tuple[int, ...], np.ndarray] = {}
        for term in self.hamiltonian.terms:
            grouped.setdefault(term.sites, np.zeros_like(term.local_matrix))
            grouped[term.sites] += term.local_matrix
        self._local_generators = tuple((sites, matrix) for sites, matrix in grouped.items())
        self._gate_cache: dict[float, tuple[tuple[tuple[int, ...], np.ndarray], ...]] = {}

    @staticmethod
    def _product_bits(qubit_count: int) -> tuple[int, ...]:
        # Distributed excitations exercise the full graph without hard-coding a target answer.
        stride = max(2, qubit_count // 5)
        return tuple(1 if site % stride == 0 else 0 for site in range(qubit_count))

    def method_decision(self) -> QuantumMethodDecision:
        reasons: list[str] = []
        assumptions: list[str] = []
        profile = self.workload_profile
        unmet = tuple(profile.open_axes) if profile is not None else ()
        if self.policy.force_contraction_tree:
            representation = "GENERAL_GRAPH_CONTRACTION_TREE"
            reasons.append("forced by the explicit execution policy")
        elif self.policy.force_ttn:
            representation = "PERSISTENT_ADAPTIVE_TTN_PATH_UPDATE"
            reasons.append("forced by the explicit execution policy")
        elif self.policy.force_mps:
            representation = "ADAPTIVE_GRAPH_ORDERED_MPS_TEBD"
            reasons.append("forced by the explicit execution policy")
        else:
            workspace_bytes = self.hamiltonian.statevector_bytes * self.policy.statevector_workspace_factor
            if workspace_bytes <= self.policy.statevector_memory_limit_bytes:
                representation = "MATRIX_FREE_KRYLOV_STATEVECTOR"
                reasons.append("state-vector workspace fits the declared memory budget")
            else:
                bandwidth = self.hamiltonian.interaction_graph_bandwidth()
                treewidth = self.hamiltonian.interaction_treewidth_upper_bound()
                profile_requests_tree = (
                    profile is not None
                    and profile.tensor_network_geometry in {"tree", "ttn", "adaptive_tree", "hierarchical"}
                )
                entanglement_allows_compression = (
                    profile is None
                    or profile.entanglement_growth_rate in {"low", "moderate", "unknown"}
                )
                profile_treewidth = profile.estimated_treewidth if profile is not None else None
                effective_treewidth = treewidth if profile_treewidth is None else max(treewidth, profile_treewidth)
                if bandwidth <= self.policy.mps_max_interaction_span and not profile_requests_tree:
                    representation = "ADAPTIVE_GRAPH_ORDERED_MPS_TEBD"
                    reasons.append("interaction bandwidth lies inside the MPS span contract")
                elif (
                    self.policy.ttn_enabled
                    and profile_requests_tree
                    and entanglement_allows_compression
                    and effective_treewidth <= self.policy.ttn_treewidth_upper_bound
                ):
                    representation = "PERSISTENT_ADAPTIVE_TTN_PATH_UPDATE"
                    reasons.append("multidimensional workload requests a tree representation within the treewidth gate")
                    if profile is not None and profile.entanglement_growth_rate == "unknown":
                        assumptions.append("entanglement growth is unknown and must be monitored through bond/error gates")
                else:
                    representation = "GENERAL_GRAPH_CONTRACTION_TREE"
                    reasons.append("state-vector and one-dimensional MPS routes are outside their resource contracts")
                    if profile_requests_tree and effective_treewidth > self.policy.ttn_treewidth_upper_bound:
                        assumptions.append("TTN rejected because the declared/estimated treewidth exceeds the policy gate")
        payload = {
            "representation": representation,
            "reasons": tuple(reasons),
            "assumptions": tuple(assumptions),
            "unmet_axes": unmet,
            "axis_registry_digest": None if profile is None else profile.axis_registry_digest,
        }
        import hashlib as _hashlib, json as _json
        digest = _hashlib.sha256(_json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        return QuantumMethodDecision(**payload, digest=digest)

    def selected_representation(self) -> str:
        return self.method_decision().representation

    def _compiled_half_step_gates(
        self,
        step_size: float,
    ) -> tuple[tuple[tuple[int, ...], np.ndarray], ...]:
        key = float(step_size)
        if key not in self._gate_cache:
            self._gate_cache[key] = tuple(
                (sites, expm(-0.5j * key * generator))
                for sites, generator in self._local_generators
            )
        return self._gate_cache[key]

    def _compiled_symmetric_gate_sequence(
        self,
        elapsed_time: float,
        steps: int,
    ) -> tuple[tuple[tuple[int, ...], np.ndarray], ...]:
        if steps < 1:
            raise ValueError("Symmetric gate sequence requires at least one step")
        half_step = self._compiled_half_step_gates(float(elapsed_time) / steps)
        one_step = half_step + tuple(reversed(half_step))
        return one_step * steps

    @staticmethod
    def _statevector_one_site_densities(
        state: np.ndarray,
        qubit_count: int,
    ) -> tuple[np.ndarray, ...]:
        tensor = np.asarray(state, dtype=complex).reshape((2,) * qubit_count)
        densities: list[np.ndarray] = []
        for site in range(qubit_count):
            moved = np.moveaxis(tensor, site, 0).reshape(2, -1)
            rho = moved @ moved.conj().T
            rho = 0.5 * (rho + rho.conj().T)
            rho /= np.trace(rho)
            densities.append(rho)
        return tuple(densities)

    @staticmethod
    def _density_entropies(densities: Sequence[np.ndarray]) -> tuple[float, ...]:
        entropies: list[float] = []
        for rho in densities:
            eigenvalues = np.clip(np.linalg.eigvalsh(rho).real, 0.0, 1.0)
            values = eigenvalues[eigenvalues > 1e-15]
            entropies.append(float(-np.sum(values * np.log2(values))))
        return tuple(entropies)

    def _contraction_observable_state(
        self,
        bits: Sequence[int],
        elapsed_time: float,
        steps: int,
    ) -> tuple[
        tuple[np.ndarray, ...],
        float,
        float,
        ContractionTreePlanSummary,
    ]:
        sequence = self._compiled_symmetric_gate_sequence(elapsed_time, steps)
        engine = TensorNetworkContractionEngine(
            self.hamiltonian.qubit_count, bits, sequence, self.policy
        )
        required = 1 + 3 * self.hamiltonian.qubit_count + len(self.hamiltonian.terms)
        if required > self.policy.contraction_observable_max_count:
            raise RuntimeError(
                "BLOCKED_RESOURCE_INFEASIBLE:CONTRACTION_OBSERVABLE_BUDGET_EXCEEDED"
            )
        norm, first_summary, plan = engine.contract_expectation()
        norm_real = float(norm.real)
        if not np.isfinite(norm_real) or norm_real <= 0.0:
            raise RuntimeError("BLOCKED_RESOURCE_INFEASIBLE:INVALID_CONTRACTION_NORM")
        total_seconds = first_summary.contraction_seconds
        bloch: list[tuple[float, float, float]] = []
        for site in range(self.hamiltonian.qubit_count):
            values: list[float] = []
            for label in ("X", "Y", "Z"):
                expectation, summary, _ = engine.contract_expectation(
                    {site: _PAULI[label]}, plan=plan
                )
                total_seconds += summary.contraction_seconds
                values.append(float((expectation / norm).real))
            bloch.append(tuple(values))
        densities: list[np.ndarray] = []
        for x_value, y_value, z_value in bloch:
            rho = 0.5 * (
                _PAULI["I"]
                + x_value * _PAULI["X"]
                + y_value * _PAULI["Y"]
                + z_value * _PAULI["Z"]
            )
            densities.append(0.5 * (rho + rho.conj().T))
        energy = 0.0
        for term in self.hamiltonian.terms:
            operator_map = {
                site: _PAULI[pauli]
                for site, pauli in zip(term.sites, term.paulis, strict=True)
            }
            expectation, summary, _ = engine.contract_expectation(
                operator_map, plan=plan
            )
            total_seconds += summary.contraction_seconds
            energy += float(term.coefficient * (expectation / norm).real)
        aggregate = ContractionTreePlanSummary(
            optimizer=first_summary.optimizer,
            backend=first_summary.backend,
            parallel_mode=first_summary.parallel_mode,
            mpi_world_size=first_summary.mpi_world_size,
            gpu_available=first_summary.gpu_available,
            unsliced_peak_elements=first_summary.unsliced_peak_elements,
            peak_elements=first_summary.peak_elements,
            flop_estimate=first_summary.flop_estimate * required,
            sliced_index_count=first_summary.sliced_index_count,
            slice_count=first_summary.slice_count,
            planning_seconds=first_summary.planning_seconds,
            contraction_seconds=total_seconds,
        )
        return tuple(densities), energy, abs(norm_real - 1.0), aggregate

    def _apply_symmetric_step(
        self,
        state: MatrixProductState,
        step_size: float,
    ) -> tuple[float, int]:
        gates = self._compiled_half_step_gates(step_size)
        discarded_total = 0.0
        max_bond_used = state.max_bond
        for sites, gate in gates:
            if len(sites) == 1:
                state.apply_one_site_gate(sites[0], gate)
            else:
                discarded, rank = state.apply_two_site_gate(
                    sites[0],
                    sites[1],
                    gate,
                    max_bond=self.policy.mps_max_bond,
                    discarded_weight_budget=self.policy.mps_discarded_weight_budget,
                )
                discarded_total += discarded
                max_bond_used = max(max_bond_used, rank)
        for sites, gate in reversed(gates):
            if len(sites) == 1:
                state.apply_one_site_gate(sites[0], gate)
            else:
                discarded, rank = state.apply_two_site_gate(
                    sites[0],
                    sites[1],
                    gate,
                    max_bond=self.policy.mps_max_bond,
                    discarded_weight_budget=self.policy.mps_discarded_weight_budget,
                )
                discarded_total += discarded
                max_bond_used = max(max_bond_used, rank)
        state.normalize()
        return discarded_total, max_bond_used

    def _evolve_mps(self, bits: Sequence[int], elapsed_time: float, steps: int) -> tuple[MatrixProductState, float, int]:
        state = MatrixProductState.product_state(bits)
        total_discarded = 0.0
        max_bond_used = state.max_bond
        step_size = float(elapsed_time) / steps
        for _ in range(steps):
            discarded, rank = self._apply_symmetric_step(state, step_size)
            total_discarded += discarded
            max_bond_used = max(max_bond_used, rank)
        return state, total_discarded, max_bond_used

    def _ttn_energy(self, state: PersistentAdaptiveTTN) -> float:
        value = 0.0
        for term in self.hamiltonian.terms:
            operators = {
                site: _PAULI[pauli]
                for site, pauli in zip(term.sites, term.paulis, strict=True)
            }
            value += float(term.coefficient * state.expectation(operators).real)
        return value

    def _apply_ttn_symmetric_step(
        self,
        state: PersistentAdaptiveTTN,
        step_size: float,
    ) -> None:
        gates = self._compiled_half_step_gates(step_size)
        for sites, gate in gates:
            if len(sites) == 1:
                state.apply_one_site_gate(sites[0], gate)
            else:
                state.apply_two_site_gate(sites[0], sites[1], gate, adapt=True)
        for sites, gate in reversed(gates):
            if len(sites) == 1:
                state.apply_one_site_gate(sites[0], gate)
            else:
                state.apply_two_site_gate(sites[0], sites[1], gate, adapt=True)

    def _evolve_ttn(
        self,
        bits: Sequence[int],
        elapsed_time: float,
        steps: int,
    ) -> PersistentAdaptiveTTN:
        state = PersistentAdaptiveTTN.product_state(
            bits,
            max_bond=self.policy.ttn_max_bond,
            discarded_weight_budget=self.policy.ttn_discarded_weight_budget,
            interaction_graph=self.hamiltonian.interaction_graph(),
            maximum_refactor_qubits=max(14, min(20, self.hamiltonian.qubit_count)),
        )
        step_size = float(elapsed_time) / steps
        for _ in range(steps):
            self._apply_ttn_symmetric_step(state, step_size)
        return state

    def _execute_ttn(
        self,
        bits: Sequence[int],
        elapsed_time: float,
        degrees: Sequence[int],
    ) -> ScalableQuantumCertificate:
        coarse_steps = self.policy.trotter_steps
        refined_steps = 2 * coarse_steps
        initial = PersistentAdaptiveTTN.product_state(
            bits,
            max_bond=self.policy.ttn_max_bond,
            discarded_weight_budget=self.policy.ttn_discarded_weight_budget,
            interaction_graph=self.hamiltonian.interaction_graph(),
            maximum_refactor_qubits=max(14, min(20, self.hamiltonian.qubit_count)),
        )
        energy_initial = self._ttn_energy(initial)
        coarse = self._evolve_ttn(bits, elapsed_time, coarse_steps)
        refined = self._evolve_ttn(bits, elapsed_time, refined_steps)
        coarse_densities = coarse.one_site_density_matrices()
        refined_densities = refined.one_site_density_matrices()
        step_gap = float(
            max(
                np.linalg.norm(left - right, ord="fro")
                for left, right in zip(coarse_densities, refined_densities, strict=True)
            )
        )
        energy_final = self._ttn_energy(refined)
        relative_drift = abs(energy_final - energy_initial) / max(abs(energy_initial), 1.0)
        entropies = refined.single_site_entropies()
        exact_reference_gap: float | None = None
        if self.hamiltonian.qubit_count <= 12:
            exact_initial = LocalPauliHamiltonian.product_state(bits)
            exact = self.hamiltonian.evolve_krylov(exact_initial, elapsed_time)
            approximate = refined.to_statevector(maximum_qubits=12)
            phase = np.vdot(exact, approximate)
            if abs(phase) > 0.0:
                approximate *= np.exp(-1j * np.angle(phase))
            exact_reference_gap = float(np.linalg.norm(exact - approximate))
        total_discarded = coarse.total_discarded_weight + refined.total_discarded_weight
        norm_gap = abs(refined.norm_squared() - 1.0)
        blocked_reason: str | None = None
        if not np.isfinite(norm_gap) or norm_gap >= 1e-9:
            blocked_reason = "BLOCKED_RESOURCE_INFEASIBLE:INVALID_TTN_NORM"
        elif total_discarded >= 1e-5:
            blocked_reason = "BLOCKED_RESOURCE_INFEASIBLE:TTN_TRUNCATION_BUDGET_EXCEEDED"
        elif step_gap >= 5e-2:
            blocked_reason = "BLOCKED_RESOURCE_INFEASIBLE:TTN_TROTTER_REFINEMENT_BUDGET_EXCEEDED"
        elif exact_reference_gap is not None and exact_reference_gap >= 1e-7:
            blocked_reason = "BLOCKED_RESOURCE_INFEASIBLE:TTN_BOUNDED_REFERENCE_DISAGREEMENT"
        decision = self.method_decision()
        return ScalableQuantumCertificate(
            qubit_count=self.hamiltonian.qubit_count,
            representation="PERSISTENT_ADAPTIVE_TTN_PATH_UPDATE",
            elapsed_time=float(elapsed_time),
            trotter_steps=refined_steps,
            statevector_bytes_estimate=self.hamiltonian.statevector_bytes,
            statevector_workspace_bytes_estimate=(
                self.hamiltonian.statevector_bytes * self.policy.statevector_workspace_factor
            ),
            dense_choi_bytes_estimate=self.hamiltonian.dense_choi_bytes,
            interaction_term_count=len(self.hamiltonian.terms),
            compiled_local_generator_count=len(self._local_generators),
            minimum_interaction_degree=min(degrees),
            noncommuting_term_pairs=self.hamiltonian.noncommuting_pair_count(),
            max_bond_limit=self.policy.ttn_max_bond,
            max_bond_used=max(coarse.used_maximum_bond, refined.used_maximum_bond),
            total_discarded_weight=float(total_discarded),
            norm_gap=float(norm_gap),
            energy_initial=float(energy_initial),
            energy_final=float(energy_final),
            relative_energy_drift=float(relative_drift),
            trotter_step_doubling_gap=float(step_gap),
            exact_reference_gap=exact_reference_gap,
            entangled_site_count=sum(value > 1e-8 for value in entropies),
            maximum_single_site_entropy=max(entropies),
            interaction_graph_bandwidth=self.hamiltonian.interaction_graph_bandwidth(),
            interaction_treewidth_upper_bound=self.hamiltonian.interaction_treewidth_upper_bound(),
            ttn_tree_rotation_count=refined.tree_rotation_count,
            ttn_local_path_update_count=refined.local_path_update_count,
            ttn_topology_rebuild_count=refined.topology_rebuild_count,
            ttn_statevector_materialized=bool(refined._statevector_materialized),
            method_decision_digest=decision.digest,
            blocked_reason=blocked_reason,
        )

    def _execute_contraction_tree(
        self,
        bits: Sequence[int],
        elapsed_time: float,
        degrees: Sequence[int],
    ) -> ScalableQuantumCertificate:
        qubits = self.hamiltonian.qubit_count
        bandwidth = self.hamiltonian.interaction_graph_bandwidth()
        treewidth = self.hamiltonian.interaction_treewidth_upper_bound()
        coarse_steps = self.policy.trotter_steps
        refined_steps = 2 * coarse_steps
        energy_initial = MatrixProductState.product_state(bits).energy(self.hamiltonian)
        try:
            if qubits <= self.policy.contraction_statevector_max_qubits:
                coarse_engine = TensorNetworkContractionEngine(
                    qubits,
                    bits,
                    self._compiled_symmetric_gate_sequence(elapsed_time, coarse_steps),
                    self.policy,
                )
                refined_engine = TensorNetworkContractionEngine(
                    qubits,
                    bits,
                    self._compiled_symmetric_gate_sequence(elapsed_time, refined_steps),
                    self.policy,
                )
                coarse_state, coarse_state_summary = coarse_engine.contract_statevector()
                refined_state, refined_state_summary = refined_engine.contract_statevector()
                norm_scalar, norm_summary, _ = refined_engine.contract_expectation()
                coarse_norm = float(np.vdot(coarse_state, coarse_state).real)
                refined_norm = float(np.vdot(refined_state, refined_state).real)
                coarse_state /= np.sqrt(coarse_norm)
                refined_state /= np.sqrt(refined_norm)
                coarse_densities = self._statevector_one_site_densities(coarse_state, qubits)
                refined_densities = self._statevector_one_site_densities(refined_state, qubits)
                energy_final = self.hamiltonian.energy_statevector(refined_state)
                entropies = self._density_entropies(refined_densities)
                exact_initial = LocalPauliHamiltonian.product_state(bits)
                exact = self.hamiltonian.evolve_krylov(exact_initial, elapsed_time)
                phase = np.vdot(exact, refined_state)
                if abs(phase) > 0.0:
                    refined_for_gap = refined_state * np.exp(-1j * np.angle(phase))
                else:
                    refined_for_gap = refined_state
                exact_reference_gap = float(np.linalg.norm(exact - refined_for_gap))
                norm_gap = abs(refined_norm - 1.0)
                norm_crosscheck_gap = abs(complex(norm_scalar) - refined_norm)
                summary = ContractionTreePlanSummary(
                    optimizer=norm_summary.optimizer,
                    backend=norm_summary.backend,
                    parallel_mode=norm_summary.parallel_mode,
                    mpi_world_size=norm_summary.mpi_world_size,
                    gpu_available=norm_summary.gpu_available,
                    unsliced_peak_elements=max(
                        norm_summary.unsliced_peak_elements,
                        refined_state_summary.unsliced_peak_elements,
                    ),
                    peak_elements=max(
                        norm_summary.peak_elements,
                        refined_state_summary.peak_elements,
                    ),
                    flop_estimate=(
                        coarse_state_summary.flop_estimate
                        + refined_state_summary.flop_estimate
                        + norm_summary.flop_estimate
                    ),
                    sliced_index_count=norm_summary.sliced_index_count,
                    slice_count=norm_summary.slice_count,
                    planning_seconds=(
                        coarse_state_summary.planning_seconds
                        + refined_state_summary.planning_seconds
                        + norm_summary.planning_seconds
                    ),
                    contraction_seconds=(
                        coarse_state_summary.contraction_seconds
                        + refined_state_summary.contraction_seconds
                        + norm_summary.contraction_seconds
                    ),
                )
                representation = "GENERAL_GRAPH_CONTRACTION_TREE_STATEVECTOR"
            else:
                coarse_densities, _, coarse_norm_gap, coarse_summary = (
                    self._contraction_observable_state(bits, elapsed_time, coarse_steps)
                )
                refined_densities, energy_final, refined_norm_gap, refined_summary = (
                    self._contraction_observable_state(bits, elapsed_time, refined_steps)
                )
                entropies = self._density_entropies(refined_densities)
                exact_reference_gap = None
                norm_gap = refined_norm_gap
                norm_crosscheck_gap = max(coarse_norm_gap, refined_norm_gap)
                summary = ContractionTreePlanSummary(
                    optimizer=refined_summary.optimizer,
                    backend=refined_summary.backend,
                    parallel_mode=refined_summary.parallel_mode,
                    mpi_world_size=refined_summary.mpi_world_size,
                    gpu_available=refined_summary.gpu_available,
                    unsliced_peak_elements=max(
                        coarse_summary.unsliced_peak_elements,
                        refined_summary.unsliced_peak_elements,
                    ),
                    peak_elements=max(
                        coarse_summary.peak_elements,
                        refined_summary.peak_elements,
                    ),
                    flop_estimate=(
                        coarse_summary.flop_estimate + refined_summary.flop_estimate
                    ),
                    sliced_index_count=max(
                        coarse_summary.sliced_index_count,
                        refined_summary.sliced_index_count,
                    ),
                    slice_count=max(coarse_summary.slice_count, refined_summary.slice_count),
                    planning_seconds=(
                        coarse_summary.planning_seconds + refined_summary.planning_seconds
                    ),
                    contraction_seconds=(
                        coarse_summary.contraction_seconds + refined_summary.contraction_seconds
                    ),
                )
                representation = "GENERAL_GRAPH_CONTRACTION_TREE_OBSERVABLES"
            step_gap = float(
                max(
                    np.linalg.norm(left - right, ord="fro")
                    for left, right in zip(coarse_densities, refined_densities, strict=True)
                )
            )
            relative_drift = abs(energy_final - energy_initial) / max(abs(energy_initial), 1.0)
            blocked_reason: str | None = None
            if norm_gap >= 1e-9:
                blocked_reason = "BLOCKED_RESOURCE_INFEASIBLE:CONTRACTION_NORM_BUDGET_EXCEEDED"
            elif norm_crosscheck_gap >= 1e-10:
                blocked_reason = "BLOCKED_RESOURCE_INFEASIBLE:CONTRACTION_NORM_CROSSCHECK_FAILED"
            elif step_gap >= 5e-2:
                blocked_reason = "BLOCKED_RESOURCE_INFEASIBLE:CONTRACTION_TROTTER_BUDGET_EXCEEDED"
            elif exact_reference_gap is not None and exact_reference_gap >= 1e-7:
                blocked_reason = "BLOCKED_RESOURCE_INFEASIBLE:CONTRACTION_REFERENCE_DISAGREEMENT"
            return ScalableQuantumCertificate(
                qubit_count=qubits,
                representation=representation,
                elapsed_time=float(elapsed_time),
                trotter_steps=refined_steps,
                statevector_bytes_estimate=self.hamiltonian.statevector_bytes,
                statevector_workspace_bytes_estimate=(
                    self.hamiltonian.statevector_bytes * self.policy.statevector_workspace_factor
                ),
                dense_choi_bytes_estimate=self.hamiltonian.dense_choi_bytes,
                interaction_term_count=len(self.hamiltonian.terms),
                compiled_local_generator_count=len(self._local_generators),
                minimum_interaction_degree=min(degrees),
                noncommuting_term_pairs=self.hamiltonian.noncommuting_pair_count(),
                max_bond_limit=0,
                max_bond_used=0,
                total_discarded_weight=0.0,
                norm_gap=float(norm_gap),
                energy_initial=energy_initial,
                energy_final=energy_final,
                relative_energy_drift=relative_drift,
                trotter_step_doubling_gap=step_gap,
                exact_reference_gap=exact_reference_gap,
                entangled_site_count=sum(value > 1e-8 for value in entropies),
                maximum_single_site_entropy=max(entropies),
                interaction_graph_bandwidth=bandwidth,
                interaction_treewidth_upper_bound=treewidth,
                contraction_backend=summary.backend,
                contraction_optimizer=summary.optimizer,
                contraction_parallel_mode=summary.parallel_mode,
                contraction_mpi_world_size=summary.mpi_world_size,
                contraction_gpu_available=summary.gpu_available,
                contraction_slice_count=summary.slice_count,
                contraction_sliced_index_count=summary.sliced_index_count,
                contraction_unsliced_peak_elements=summary.unsliced_peak_elements,
                contraction_peak_elements=summary.peak_elements,
                contraction_flop_estimate=summary.flop_estimate,
                contraction_planning_seconds=summary.planning_seconds,
                contraction_seconds=summary.contraction_seconds,
                contraction_norm_crosscheck_gap=float(abs(norm_crosscheck_gap)),
                blocked_reason=blocked_reason,
            )
        except RuntimeError as error:
            reason = str(error)
            if not reason.startswith("BLOCKED_"):
                reason = f"BLOCKED_RESOURCE_INFEASIBLE:{reason}"
            return ScalableQuantumCertificate(
                qubit_count=qubits,
                representation="GENERAL_GRAPH_CONTRACTION_TREE_BLOCKED",
                elapsed_time=float(elapsed_time),
                trotter_steps=refined_steps,
                statevector_bytes_estimate=self.hamiltonian.statevector_bytes,
                statevector_workspace_bytes_estimate=(
                    self.hamiltonian.statevector_bytes * self.policy.statevector_workspace_factor
                ),
                dense_choi_bytes_estimate=self.hamiltonian.dense_choi_bytes,
                interaction_term_count=len(self.hamiltonian.terms),
                compiled_local_generator_count=len(self._local_generators),
                minimum_interaction_degree=min(degrees),
                noncommuting_term_pairs=self.hamiltonian.noncommuting_pair_count(),
                max_bond_limit=0,
                max_bond_used=0,
                total_discarded_weight=0.0,
                norm_gap=float("inf"),
                energy_initial=energy_initial,
                energy_final=float("nan"),
                relative_energy_drift=float("inf"),
                trotter_step_doubling_gap=float("inf"),
                exact_reference_gap=None,
                entangled_site_count=0,
                maximum_single_site_entropy=0.0,
                interaction_graph_bandwidth=bandwidth,
                interaction_treewidth_upper_bound=treewidth,
                blocked_reason=reason,
            )

    def execute_closed(self, elapsed_time: float) -> ScalableQuantumCertificate:
        elapsed_time = float(elapsed_time)
        if elapsed_time < 0.0:
            raise ValueError("Elapsed time must be non-negative")
        bits = self._product_bits(self.hamiltonian.qubit_count)
        degrees = self.hamiltonian.interaction_degrees()
        representation = self.selected_representation()

        if representation == "MATRIX_FREE_KRYLOV_STATEVECTOR":
            initial = LocalPauliHamiltonian.product_state(bits)
            final = self.hamiltonian.evolve_krylov(initial, elapsed_time)
            norm_gap = abs(float(np.vdot(final, final).real) - 1.0)
            energy_initial = self.hamiltonian.energy_statevector(initial)
            energy_final = self.hamiltonian.energy_statevector(final)
            relative_drift = abs(energy_final - energy_initial) / max(abs(energy_initial), 1.0)
            # Krylov action is the accepted exact finite-time path; no Trotter split is used.
            densities = []
            tensor = final.reshape((2,) * self.hamiltonian.qubit_count)
            for site in range(self.hamiltonian.qubit_count):
                moved = np.moveaxis(tensor, site, 0).reshape(2, -1)
                rho = moved @ moved.conj().T
                densities.append(rho / np.trace(rho))
            entropies = []
            for rho in densities:
                eigenvalues = np.clip(np.linalg.eigvalsh(rho).real, 0.0, 1.0)
                values = eigenvalues[eigenvalues > 1e-15]
                entropies.append(float(-np.sum(values * np.log2(values))))
            return ScalableQuantumCertificate(
                qubit_count=self.hamiltonian.qubit_count,
                representation=representation,
                elapsed_time=float(elapsed_time),
                trotter_steps=0,
                statevector_bytes_estimate=self.hamiltonian.statevector_bytes,
                statevector_workspace_bytes_estimate=(
                    self.hamiltonian.statevector_bytes * self.policy.statevector_workspace_factor
                ),
                dense_choi_bytes_estimate=self.hamiltonian.dense_choi_bytes,
                interaction_term_count=len(self.hamiltonian.terms),
                compiled_local_generator_count=len(self._local_generators),
                minimum_interaction_degree=min(degrees),
                noncommuting_term_pairs=self.hamiltonian.noncommuting_pair_count(),
                max_bond_limit=0,
                max_bond_used=0,
                total_discarded_weight=0.0,
                norm_gap=norm_gap,
                energy_initial=energy_initial,
                energy_final=energy_final,
                relative_energy_drift=relative_drift,
                trotter_step_doubling_gap=0.0,
                exact_reference_gap=0.0,
                entangled_site_count=sum(value > 1e-8 for value in entropies),
                maximum_single_site_entropy=max(entropies),
                interaction_graph_bandwidth=self.hamiltonian.interaction_graph_bandwidth(),
                interaction_treewidth_upper_bound=self.hamiltonian.interaction_treewidth_upper_bound(),
            )

        if representation == "GENERAL_GRAPH_CONTRACTION_TREE":
            return self._execute_contraction_tree(bits, elapsed_time, degrees)
        if representation == "PERSISTENT_ADAPTIVE_TTN_PATH_UPDATE":
            return self._execute_ttn(bits, elapsed_time, degrees)

        coarse_steps = self.policy.trotter_steps
        refined_steps = 2 * coarse_steps
        coarse, coarse_discarded, coarse_bond = self._evolve_mps(bits, elapsed_time, coarse_steps)
        refined, refined_discarded, refined_bond = self._evolve_mps(bits, elapsed_time, refined_steps)
        coarse_densities = coarse.one_site_density_matrices()
        refined_densities = refined.one_site_density_matrices()
        step_gap = float(
            max(
                np.linalg.norm(left - right, ord="fro")
                for left, right in zip(coarse_densities, refined_densities, strict=True)
            )
        )
        energy_initial = MatrixProductState.product_state(bits).energy(self.hamiltonian)
        energy_final = refined.energy(self.hamiltonian)
        relative_drift = abs(energy_final - energy_initial) / max(abs(energy_initial), 1.0)
        entropies = refined.single_site_entropies()

        exact_reference_gap: float | None = None
        if self.hamiltonian.qubit_count <= 12:
            exact_initial = LocalPauliHamiltonian.product_state(bits)
            exact = self.hamiltonian.evolve_krylov(exact_initial, elapsed_time)
            approximate = refined.to_statevector(maximum_qubits=12)
            phase = np.vdot(exact, approximate)
            if abs(phase) > 0.0:
                approximate *= np.exp(-1j * np.angle(phase))
            exact_reference_gap = float(np.linalg.norm(exact - approximate))

        blocked_reason: str | None = None
        if refined.norm_squared() <= 0.0 or not np.isfinite(refined.norm_squared()):
            blocked_reason = "BLOCKED_RESOURCE_INFEASIBLE:INVALID_MPS_NORM"
        elif coarse_discarded + refined_discarded >= 1e-5:
            blocked_reason = "BLOCKED_RESOURCE_INFEASIBLE:MPS_TRUNCATION_BUDGET_EXCEEDED"
        elif step_gap >= 5e-2:
            blocked_reason = "BLOCKED_RESOURCE_INFEASIBLE:TROTTER_REFINEMENT_BUDGET_EXCEEDED"
        elif exact_reference_gap is not None and exact_reference_gap >= 1e-7:
            blocked_reason = "BLOCKED_RESOURCE_INFEASIBLE:BOUNDED_REFERENCE_DISAGREEMENT"

        return ScalableQuantumCertificate(
            qubit_count=self.hamiltonian.qubit_count,
            representation=representation,
            elapsed_time=float(elapsed_time),
            trotter_steps=refined_steps,
            statevector_bytes_estimate=self.hamiltonian.statevector_bytes,
            statevector_workspace_bytes_estimate=(
                self.hamiltonian.statevector_bytes * self.policy.statevector_workspace_factor
            ),
            dense_choi_bytes_estimate=self.hamiltonian.dense_choi_bytes,
            interaction_term_count=len(self.hamiltonian.terms),
            compiled_local_generator_count=len(self._local_generators),
            minimum_interaction_degree=min(degrees),
            noncommuting_term_pairs=self.hamiltonian.noncommuting_pair_count(),
            max_bond_limit=self.policy.mps_max_bond,
            max_bond_used=max(coarse_bond, refined_bond),
            total_discarded_weight=float(coarse_discarded + refined_discarded),
            norm_gap=abs(refined.norm_squared() - 1.0),
            energy_initial=energy_initial,
            energy_final=energy_final,
            relative_energy_drift=relative_drift,
            trotter_step_doubling_gap=step_gap,
            exact_reference_gap=exact_reference_gap,
            entangled_site_count=sum(value > 1e-8 for value in entropies),
            maximum_single_site_entropy=max(entropies),
            interaction_graph_bandwidth=self.hamiltonian.interaction_graph_bandwidth(),
            interaction_treewidth_upper_bound=self.hamiltonian.interaction_treewidth_upper_bound(),
            blocked_reason=blocked_reason,
        )

    def execute_processor_emulator(
        self,
        qasm_source: str | None = None,
        requested_backend: str = "auto",
        processor_qubits: int = 8,
        noise: ProcessorNoiseSpec | None = None,
        trajectory_count: int = 2048,
        readout_shots: int = 8192,
        toric_lattice_size: int = 5,
        toric_trials: int = 256,
        toric_error_probability: float = 0.02,
        lorentzian_linewidth: float = 0.4,
        lorentzian_coupling_rate: float = 2.0,
    ) -> ProcessorEmulatorCertificate:
        """Execute the authoritative Atlas processor, pulse, noise and QEC controls.

        OpenQASM 3 AST execution, OpenPulse qutrit controls, accelerator routing, adaptive
        quantum jumps and repeated-syndrome QEC are all owned here.  OpenQASM 2 is accepted only
        by the parser's syntax-normalization compatibility projection; there is no second executor.
        """

        qubits = int(processor_qubits)
        if qubits < 3:
            raise ValueError("Processor control requires at least three qubits")
        if trajectory_count < 256 or readout_shots < 512:
            raise ValueError("Processor trajectory/readout sampling contracts are too small")
        active_noise = noise or ProcessorNoiseSpec()
        active_noise.validate()
        source = qasm_source or "\n".join(
            [
                "OPENQASM 3.0;",
                f"qubit[{qubits}] q;",
                f"bit[{qubits}] c;",
                "h q[0];",
                *(f"cx q[0], q[{site}];" for site in range(1, qubits)),
            ]
        )
        program = OpenQASM3Parser.parse(source)
        if program.version != "3.0" or program.qubit_count != qubits:
            raise ValueError("Processor-control program differs from the Atlas register contract")

        try:
            kernel = create_statevector_kernel(qubits, requested_backend)
            state = kernel.execute(program)
        except RuntimeError as exc:
            reason = str(exc)
            if not reason.startswith("BLOCKED_"):
                raise
            return ProcessorEmulatorCertificate(
                qubit_count=qubits,
                openqasm_version=program.version,
                source_sha256=program.source_sha256,
                backend_requested=str(requested_backend),
                backend_resolved=None,
                accelerator_runtime=None,
                circuit_instruction_count=len(program.instructions),
                statevector_norm_gap=None,
                accelerator_numpy_state_gap=None,
                ghz_support_leakage=None,
                ghz_balance_gap=None,
                arbitrary_control_target_gap=None,
                dynamic_measurement_count=0,
                dynamic_loop_iterations=0,
                dynamic_branch_count=0,
                dynamic_feedforward_gap=None,
                dynamic_max_clock_ns=None,
                maximum_kraus_completeness_gap=None,
                trajectory_count=int(trajectory_count),
                trajectory_density_gap=None,
                readout_assignment_gap=None,
                readout_sampling_gap=None,
                accelerator_qualification=None,
                pulse_control=None,
                adaptive_jump_control=None,
                circuit_level_qec=None,
                lorentzian_memory=None,
                toric_code=None,
                retyped_open_systems=None,
                blocked_reason=reason,
            )

        numpy_state = execute_numpy(program)
        overlap = np.vdot(numpy_state, state)
        if abs(overlap) > 0.0:
            state = state * np.exp(-1j * np.angle(overlap))
        state_gap = float(np.linalg.norm(state - numpy_state))
        probabilities = np.abs(state) ** 2
        support = float(probabilities[0] + probabilities[-1])
        balance = float(abs(probabilities[0] - probabilities[-1]))
        norm_gap = abs(float(np.vdot(state, state).real) - 1.0)

        arbitrary_program = OpenQASM3Parser.parse(
            """OPENQASM 3.0;
qubit[3] q;
x q[2];
cx q[2], q[0];
"""
        )
        arbitrary_kernel = create_statevector_kernel(3, requested_backend)
        arbitrary_state = arbitrary_kernel.execute(arbitrary_program)
        expected = np.zeros(8, dtype=complex)
        expected[5] = 1.0
        arbitrary_gap = float(np.linalg.norm(arbitrary_state - expected))

        dynamic_program = OpenQASM3Parser.parse(
            """OPENQASM 3.0;
qubit[2] q;
bit[2] c;
x q[1];
while (c[1] == 0) { c[1] = measure q[1]; }
reset q[1];
for int i in [0:1] { x q[i]; }
c[0] = measure q[0];
if (c[0] == 1) { x q[1]; } else { z q[1]; }
delay[10ns] q[0], q[1];
"""
        )
        dynamic_kernel = create_statevector_kernel(2, "native" if requested_backend == "auto" else requested_backend)
        dynamic_result = OpenQASM3Executor(
            dynamic_kernel, random_seed=self.policy.random_seed + 71
        ).execute(dynamic_program)
        dynamic_expected = np.zeros(4, dtype=complex)
        dynamic_expected[2] = 1.0
        dynamic_overlap = np.vdot(dynamic_expected, dynamic_result.statevector)
        dynamic_state = dynamic_result.statevector
        if abs(dynamic_overlap) > 0.0:
            dynamic_state = dynamic_state * np.exp(-1j * np.angle(dynamic_overlap))
        dynamic_gap = float(np.linalg.norm(dynamic_state - dynamic_expected))

        pulse_source = """OPENQASM 3.0;
defcalgrammar \"openpulse\";
qubit[2] q;
bit[2] c;
cal {
  extern port d0;
  extern port d1;
  frame f0 = newframe(d0, 5.0e9, 0.0);
  frame f1 = newframe(d1, 5.1e9, 0.0);
  waveform x_drag = drag(0.1469837, 40ns, 8.87155645ns, 1.63577546);
  waveform cr_square = constant(0.012, 65.44984694978736ns);
}
defcal x $0 { play(f0, x_drag); }
defcal cr $0, $1 { play(f1, cr_square); }
x q[0];
cr q[0], q[1];
"""
        pulse_program = OpenQASM3Parser.parse(pulse_source)
        if pulse_program.pulse_program is None:
            raise RuntimeError("BLOCKED_PHYSICAL_INVALID:OPENPULSE_PROGRAM_MISSING")
        pulse_certificate = TransmonPulseEngine().certify(pulse_program.pulse_program)
        accelerator_certificate = qualify_accelerators(qubits)

        bell_program = OpenQASM3Parser.parse(
            """OPENQASM 3.0;
qubit[2] q;
h q[0];
cx q[0], q[1];
"""
        )
        bell = execute_numpy(bell_program)
        bell_density = np.outer(bell, bell.conj())
        duration = active_noise.one_qubit_gate_time + active_noise.two_qubit_gate_time
        amplitude_probability, phase_probability = active_noise.kraus_parameters(duration)
        amplitude_kraus = _amplitude_damping_kraus(amplitude_probability)
        phase_kraus = _phase_damping_kraus(phase_probability)
        kraus_gap = max(
            _kraus_completeness_gap(amplitude_kraus),
            _kraus_completeness_gap(phase_kraus),
        )
        exact_density = bell_density.copy()
        for site in range(2):
            exact_density = _apply_local_kraus_density(exact_density, amplitude_kraus, site, 2)
            exact_density = _apply_local_kraus_density(exact_density, phase_kraus, site, 2)

        def sample_local_kraus(vector: np.ndarray, operators: Sequence[np.ndarray], site: int, rng: np.random.Generator) -> np.ndarray:
            branches = [apply_numpy_gate(vector, operator, (site,)) for operator in operators]
            branch_probabilities = np.array([float(np.vdot(branch, branch).real) for branch in branches])
            branch_probabilities = np.clip(branch_probabilities, 0.0, None)
            total = float(branch_probabilities.sum())
            if total <= 0.0 or not np.isfinite(total):
                raise RuntimeError("BLOCKED_PHYSICAL_INVALID:KRAUS_BRANCHES_NOT_NORMALIZABLE")
            branch_probabilities /= total
            index = int(rng.choice(len(branches), p=branch_probabilities))
            return branches[index] / np.sqrt(float(np.vdot(branches[index], branches[index]).real))

        rng = np.random.default_rng(self.policy.random_seed + 1009)
        empirical_density = np.zeros((4, 4), dtype=complex)
        for _ in range(int(trajectory_count)):
            trajectory = bell.copy()
            for site in range(2):
                trajectory = sample_local_kraus(trajectory, amplitude_kraus, site, rng)
                trajectory = sample_local_kraus(trajectory, phase_kraus, site, rng)
            empirical_density += np.outer(trajectory, trajectory.conj())
        empirical_density /= float(trajectory_count)
        trajectory_gap = float(np.linalg.norm(empirical_density - exact_density, ord="fro"))

        assignment = active_noise.readout_assignment
        assignment_gap = float(
            max(np.max(np.abs(assignment.sum(axis=1) - 1.0)), max(0.0, -float(np.min(assignment))))
        )
        full_assignment = np.kron(assignment, assignment)
        true_distribution = np.clip(np.real(np.diag(exact_density)), 0.0, None)
        true_distribution /= true_distribution.sum()
        expected_observed = true_distribution @ full_assignment
        observed_counts = np.zeros(4, dtype=int)
        for _ in range(int(readout_shots)):
            true_index = int(rng.choice(4, p=true_distribution))
            true_bits = ((true_index >> 1) & 1, true_index & 1)
            observed_bits = tuple(int(rng.choice(2, p=assignment[bit])) for bit in true_bits)
            observed_counts[2 * observed_bits[0] + observed_bits[1]] += 1
        observed_distribution = observed_counts / float(readout_shots)
        readout_sampling_gap = float(np.max(np.abs(observed_distribution - expected_observed)))

        adaptive_jump = certify_adaptive_quantum_jumps(
            trajectory_count=512, seed=self.policy.random_seed + 3031
        )
        circuit_qec = certify_circuit_level_qec(
            lattice_size=max(3, min(5, toric_lattice_size)),
            syndrome_rounds=5,
            trials=max(128, toric_trials),
            data_error_probability=min(0.004, toric_error_probability),
            measurement_error_probability=min(0.004, toric_error_probability),
            seed=self.policy.random_seed + 4049,
        )
        memory_certificate = _lorentzian_memory_certificate(
            linewidth=lorentzian_linewidth, coupling_rate=lorentzian_coupling_rate
        )
        toric_certificate = _ToricCodeMWPM(toric_lattice_size).certify(
            error_probability=toric_error_probability,
            trials=toric_trials,
            seed=self.policy.random_seed + 2027,
        )
        retyped_certificate = retyped_open_systems_control()

        blocked_reason: str | None = None
        if not np.isfinite(state).all():
            blocked_reason = "BLOCKED_NUMERICAL_INVALID:NONFINITE_PROCESSOR_STATE"
        elif norm_gap >= 1e-11 or state_gap >= 1e-11:
            blocked_reason = "BLOCKED_NUMERICAL_INVALID:ACCELERATOR_REFERENCE_DISAGREEMENT"
        elif 1.0 - support >= 1e-11 or balance >= 1e-11:
            blocked_reason = "BLOCKED_NUMERICAL_INVALID:GHZ_CONTROL_FAILED"
        elif arbitrary_gap >= 1e-11:
            blocked_reason = "BLOCKED_NUMERICAL_INVALID:CONTROL_TARGET_AXIS_FAILED"
        elif dynamic_gap >= 1e-11 or dynamic_result.measurement_count < 2:
            blocked_reason = "BLOCKED_DYNAMIC_CONTROL:FEEDBACK_OR_MEASUREMENT_FAILED"
        elif not pulse_certificate.passed:
            blocked_reason = "BLOCKED_PHYSICAL_INVALID:OPENPULSE_CONTROL_FAILED"
        elif not accelerator_certificate.passed:
            blocked_reason = "BLOCKED_NUMERICAL_INVALID:NATIVE_ACCELERATOR_QUALIFICATION_FAILED"
        elif kraus_gap >= 1e-11 or assignment_gap >= 1e-12:
            blocked_reason = "BLOCKED_PHYSICAL_INVALID:CHANNEL_OR_POVM_INCOMPLETE"
        elif trajectory_gap >= 0.04:
            blocked_reason = "BLOCKED_NUMERICAL_INVALID:TRAJECTORY_DENSITY_DISAGREEMENT"
        elif readout_sampling_gap >= 0.035:
            blocked_reason = "BLOCKED_NUMERICAL_INVALID:READOUT_SAMPLING_DISAGREEMENT"
        elif not adaptive_jump.passed:
            blocked_reason = "BLOCKED_PHYSICAL_INVALID:ADAPTIVE_JUMP_CONTROL_FAILED"
        elif not circuit_qec.passed:
            blocked_reason = "BLOCKED_PHYSICAL_INVALID:CIRCUIT_LEVEL_QEC_FAILED"
        elif not memory_certificate.passed:
            blocked_reason = "BLOCKED_PHYSICAL_INVALID:NONMARKOVIAN_CHANNEL_CONTROL_FAILED"
        elif not toric_certificate.passed:
            blocked_reason = "BLOCKED_PHYSICAL_INVALID:IDEAL_TORIC_REFERENCE_FAILED"
        elif not retyped_certificate.passed:
            blocked_reason = "BLOCKED_PHYSICAL_INVALID:RETYPE_OPEN_SYSTEM_CONTROLS_FAILED"

        runtime = accelerator_certificate.runtime
        return ProcessorEmulatorCertificate(
            qubit_count=qubits,
            openqasm_version=program.version,
            source_sha256=program.source_sha256,
            backend_requested=str(requested_backend),
            backend_resolved=kernel.backend_name,
            accelerator_runtime=runtime,
            circuit_instruction_count=len(program.instructions),
            statevector_norm_gap=float(norm_gap),
            accelerator_numpy_state_gap=state_gap,
            ghz_support_leakage=float(1.0 - support),
            ghz_balance_gap=balance,
            arbitrary_control_target_gap=arbitrary_gap,
            dynamic_measurement_count=dynamic_result.measurement_count,
            dynamic_loop_iterations=dynamic_result.loop_iterations,
            dynamic_branch_count=dynamic_result.branch_count,
            dynamic_feedforward_gap=dynamic_gap,
            dynamic_max_clock_ns=max(dynamic_result.qubit_clock_ns),
            maximum_kraus_completeness_gap=float(kraus_gap),
            trajectory_count=int(trajectory_count),
            trajectory_density_gap=trajectory_gap,
            readout_assignment_gap=assignment_gap,
            readout_sampling_gap=readout_sampling_gap,
            accelerator_qualification=accelerator_certificate,
            pulse_control=pulse_certificate,
            adaptive_jump_control=adaptive_jump,
            circuit_level_qec=circuit_qec,
            lorentzian_memory=memory_certificate,
            toric_code=toric_certificate,
            retyped_open_systems=retyped_certificate,
            blocked_reason=blocked_reason,
        )

    def _small_trajectory_density_validation(
        self,
        elapsed_time: float,
        dephasing_rate: float,
        validation_qubits: int = 3,
        trajectories: int = 512,
    ) -> float:
        n = min(validation_qubits, self.hamiltonian.qubit_count)
        retained_terms = tuple(
            term for term in self.hamiltonian.terms if all(site < n for site in term.sites)
        )
        small = LocalPauliHamiltonian(n, retained_terms)
        h_dense = small.dense_matrix(maximum_qubits=8)
        bits = self._product_bits(n)
        psi0 = LocalPauliHamiltonian.product_state(bits)
        collapse = []
        for site in range(n):
            operator = np.array([[1.0 + 0.0j]])
            for index in range(n):
                operator = np.kron(operator, _PAULI["Z"] if index == site else _PAULI["I"])
            collapse.append(np.sqrt(dephasing_rate) * operator)
        exact = FiniteQuantumDynamics(h_dense, collapse).evolve_density(
            np.outer(psi0, psi0.conj()), elapsed_time
        )

        rng = np.random.default_rng(self.policy.random_seed + 17)
        steps = max(2, self.policy.trotter_steps * 2)
        dt = elapsed_time / steps
        unitary = expm(-1j * dt * h_dense)
        z_operators = [operator / np.sqrt(dephasing_rate) for operator in collapse]
        flip_probability = 0.5 * (1.0 - np.exp(-2.0 * dephasing_rate * dt))
        empirical = np.zeros_like(exact)
        for _ in range(trajectories):
            state = psi0.copy()
            for _ in range(steps):
                state = unitary @ state
                for operator in z_operators:
                    if rng.random() < flip_probability:
                        state = operator @ state
            empirical += np.outer(state, state.conj())
        empirical /= trajectories
        return float(np.linalg.norm(empirical - exact, ord="fro"))

    def execute_dephasing_trajectories(
        self,
        elapsed_time: float,
        dephasing_rate: float,
    ) -> TrajectoryEnsembleCertificate:
        elapsed_time = float(elapsed_time)
        if elapsed_time < 0.0:
            raise ValueError("Elapsed time must be non-negative")
        if dephasing_rate < 0.0:
            raise ValueError("Dephasing rate must be non-negative")
        bits = self._product_bits(self.hamiltonian.qubit_count)
        rng = np.random.default_rng(self.policy.random_seed)
        steps = 2 * self.policy.trotter_steps
        dt = float(elapsed_time) / steps
        flip_probability = 0.5 * (1.0 - np.exp(-2.0 * dephasing_rate * dt))
        probability_samples: list[np.ndarray] = []
        x_samples: list[np.ndarray] = []
        total_discarded = 0.0
        maximum_norm_gap = 0.0
        max_bond_used = 1

        for _ in range(self.policy.trajectory_count):
            state = MatrixProductState.product_state(bits)
            for _ in range(steps):
                discarded, rank = self._apply_symmetric_step(state, dt)
                total_discarded += discarded
                max_bond_used = max(max_bond_used, rank)
                for site in range(self.hamiltonian.qubit_count):
                    if rng.random() < flip_probability:
                        state.apply_one_site_gate(site, _PAULI["Z"])
                state.normalize()
            maximum_norm_gap = max(maximum_norm_gap, abs(state.norm_squared() - 1.0))
            densities = state.one_site_density_matrices()
            probability_samples.append(np.array([float(rho[1, 1].real) for rho in densities]))
            x_samples.append(np.array([float(2.0 * rho[0, 1].real) for rho in densities]))

        probability_array = np.stack(probability_samples, axis=0)
        x_array = np.stack(x_samples, axis=0)
        means = np.clip(probability_array.mean(axis=0), 0.0, 1.0)
        mean_x = np.clip(x_array.mean(axis=0), -1.0, 1.0)
        probability_standard_error = probability_array.std(axis=0, ddof=1) / np.sqrt(probability_array.shape[0])
        x_standard_error = x_array.std(axis=0, ddof=1) / np.sqrt(x_array.shape[0])
        standard_error = max(float(np.max(probability_standard_error)), float(np.max(x_standard_error)))
        validation_gap = self._small_trajectory_density_validation(elapsed_time, dephasing_rate)
        trajectory_blocked_reason: str | None = None
        if maximum_norm_gap >= 1e-9:
            trajectory_blocked_reason = "BLOCKED_RESOURCE_INFEASIBLE:TRAJECTORY_NORM_BUDGET_EXCEEDED"
        elif total_discarded >= 1e-4:
            trajectory_blocked_reason = "BLOCKED_RESOURCE_INFEASIBLE:TRAJECTORY_TRUNCATION_BUDGET_EXCEEDED"
        elif standard_error >= 0.5:
            trajectory_blocked_reason = "BLOCKED_RESOURCE_INFEASIBLE:TRAJECTORY_SAMPLING_BUDGET_EXCEEDED"
        elif validation_gap >= 0.08:
            trajectory_blocked_reason = "BLOCKED_RESOURCE_INFEASIBLE:TRAJECTORY_REFERENCE_DISAGREEMENT"
        return TrajectoryEnsembleCertificate(
            qubit_count=self.hamiltonian.qubit_count,
            representation="MPS_LOCAL_DEPHASING_TRAJECTORY_ENSEMBLE",
            elapsed_time=float(elapsed_time),
            trotter_steps=steps,
            trajectory_count=self.policy.trajectory_count,
            dephasing_rate=float(dephasing_rate),
            random_seed=self.policy.random_seed,
            max_bond_used=max_bond_used,
            total_discarded_weight=float(total_discarded),
            maximum_norm_gap=float(maximum_norm_gap),
            mean_excitation_probability=tuple(float(value) for value in means),
            mean_x_expectation=tuple(float(value) for value in mean_x),
            maximum_sampling_standard_error=standard_error,
            small_system_density_gap=validation_gap,
            blocked_reason=trajectory_blocked_reason,
        )


def qualify_structured_50_qubit_ttn_hamiltonian_dynamics() -> ScalableQuantumCertificate:
    """Execute a statevector-free 50-qubit low-treewidth Hamiltonian TTN control.

    The workload is a forest of 25 disjoint XX-coupled pairs with local Z fields.
    The local and pair terms do not all commute, so the certificate exercises
    symmetric Trotter refinement, arbitrary-pair TTN path exposure, topology
    rebuilding, entanglement generation and the active error gates.  The graph
    remains low treewidth; this is not evidence for arbitrary volume-law or
    sustained high-treewidth dynamics.
    """

    qubit_count = 50
    terms = [
        LocalPauliTerm((site,), ("Z",), 0.11, f"z_{site}")
        for site in range(qubit_count)
    ]
    terms.extend(
        LocalPauliTerm((site, site + 1), ("X", "X"), 0.30, f"xx_{site}_{site + 1}")
        for site in range(0, qubit_count, 2)
    )
    hamiltonian = LocalPauliHamiltonian(qubit_count, terms)
    profile = QuantumWorkloadProfile(
        qubit_count=qubit_count,
        circuit_depth=2,
        circuit_geometry="pair_forest",
        tensor_network_geometry="adaptive_tree",
        entanglement_growth_rate="low",
        estimated_treewidth=1,
        t_gate_count=0,
        magic_monotone="low",
        open_system_regime="closed",
        observable_scope="energy_and_one_site_reduced_states",
        target_error=5e-2,
        axis_registry_digest="phi-qcm-70-axis-current-state-v3.3",
    )
    policy = AdaptiveExecutionPolicy(
        statevector_memory_limit_bytes=1024,
        statevector_workspace_factor=6,
        trotter_steps=1,
        ttn_enabled=True,
        ttn_max_bond=16,
        ttn_discarded_weight_budget=1e-18,
        ttn_treewidth_upper_bound=4,
        force_ttn=True,
    )
    return AdaptiveQuantumDynamics(hamiltonian, policy, profile).execute_closed(0.2)


def qualify_high_treewidth_contraction_fallback() -> ScalableQuantumCertificate:
    """Qualify the bounded fallback selected after statevector/MPS/TTN resource rejection.

    The eight-qubit complete interaction graph has treewidth seven. A deliberately small
    state-vector workspace gate forces the general contraction-tree owner, while the bounded
    register still permits an independent Krylov equality check. This is a routing and numerical
    correctness certificate, not a large-scale high-treewidth scalability claim.
    """

    qubit_count = 8
    terms = [
        LocalPauliTerm((site,), ("Z",), 0.07 + 0.005 * site, f"z_{site}")
        for site in range(qubit_count)
    ]
    terms.extend(
        LocalPauliTerm(
            (left, right),
            ("X", "X"),
            0.015 + 0.001 * ((left + right) % 3),
            f"xx_{left}_{right}",
        )
        for left in range(qubit_count)
        for right in range(left + 1, qubit_count)
    )
    hamiltonian = LocalPauliHamiltonian(qubit_count, terms)
    profile = QuantumWorkloadProfile(
        qubit_count=qubit_count,
        circuit_depth=4,
        circuit_geometry="complete_graph",
        tensor_network_geometry="general_graph",
        entanglement_growth_rate="high",
        estimated_treewidth=7,
        open_system_regime="closed",
        observable_scope="state_and_one_site_reduced_states",
        target_error=1e-6,
    )
    policy = AdaptiveExecutionPolicy(
        statevector_memory_limit_bytes=1024,
        statevector_workspace_factor=6,
        trotter_steps=2,
        trajectory_count=2,
        contraction_memory_limit_elements=4096,
        contraction_max_slices=64,
        contraction_parallel_workers=2,
        contraction_statevector_max_qubits=10,
        force_contraction_tree=True,
    )
    return AdaptiveQuantumDynamics(hamiltonian, policy, profile).execute_closed(0.08)
