from __future__ import annotations

from dataclasses import asdict, dataclass
import importlib.util
from typing import Sequence

import numpy as np

from .control import QuantumCircuitProgram, QuantumInstruction

_I = np.eye(2, dtype=complex)
_X = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=complex)
_Y = np.array([[0.0, -1j], [1j, 0.0]], dtype=complex)
_Z = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=complex)
_H = np.array([[1.0, 1.0], [1.0, -1.0]], dtype=complex) / np.sqrt(2.0)
_SWAP = np.array(
    [[1.0, 0.0, 0.0, 0.0], [0.0, 0.0, 1.0, 0.0], [0.0, 1.0, 0.0, 0.0], [0.0, 0.0, 0.0, 1.0]],
    dtype=complex,
)


def gate_matrix(instruction: QuantumInstruction) -> np.ndarray:
    name = instruction.name.lower()
    if name == "x":
        return _X
    if name == "y":
        return _Y
    if name == "z":
        return _Z
    if name == "h":
        return _H
    if name == "s":
        return np.diag([1.0, 1.0j]).astype(complex)
    if name == "sdg":
        return np.diag([1.0, -1.0j]).astype(complex)
    if name == "t":
        return np.diag([1.0, np.exp(1j * np.pi / 4.0)]).astype(complex)
    if name == "tdg":
        return np.diag([1.0, np.exp(-1j * np.pi / 4.0)]).astype(complex)
    if name in {"rx", "ry", "rz"}:
        if instruction.parameter is None:
            raise ValueError(f"Gate {name} requires one angle")
        pauli = {"rx": _X, "ry": _Y, "rz": _Z}[name]
        theta = float(instruction.parameter)
        return np.cos(theta / 2.0) * _I - 1j * np.sin(theta / 2.0) * pauli
    if name == "cx":
        return np.array(
            [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1], [0, 0, 1, 0]], dtype=complex
        )
    if name == "cz":
        return np.diag([1.0, 1.0, 1.0, -1.0]).astype(complex)
    if name == "swap":
        return _SWAP
    if name == "cr":
        # Gate-level calibrated cross-resonance primitive: ZX(pi/2).
        return np.cos(np.pi / 4.0) * np.eye(4, dtype=complex) - 1j * np.sin(np.pi / 4.0) * np.kron(_Z, _X)
    raise ValueError(f"Unsupported Atlas processor gate: {instruction.name}")


def apply_numpy_gate(state: np.ndarray, gate: np.ndarray, qubits: Sequence[int]) -> np.ndarray:
    vector = np.asarray(state, dtype=complex).reshape(-1)
    n = int(round(np.log2(vector.size)))
    if 2**n != vector.size:
        raise ValueError("State-vector size is not a power of two")
    axes = tuple(int(value) for value in qubits)
    if len(set(axes)) != len(axes) or any(value < 0 or value >= n for value in axes):
        raise ValueError("Gate axes are inadmissible")
    remaining = tuple(index for index in range(n) if index not in axes)
    permutation = axes + remaining
    inverse = np.argsort(permutation)
    tensor = vector.reshape((2,) * n).transpose(permutation).reshape(2 ** len(axes), -1)
    result = np.asarray(gate, dtype=complex) @ tensor
    return result.reshape((2,) * n).transpose(inverse).reshape(-1)


@dataclass(frozen=True, slots=True)
class AcceleratorQualification:
    requested_backend: str
    resolved_backend: str | None
    runtime: str | None
    native_openmp: bool
    native_max_threads: int
    native_reference_gap: float | None
    cuquantum_available: bool
    cuda_available: bool
    blocked_reason: str | None

    @property
    def passed(self) -> bool:
        return (
            self.blocked_reason is None
            and self.resolved_backend is not None
            and self.native_reference_gap is not None
            and self.native_reference_gap < 1e-12
        )

    def to_dict(self) -> dict:
        return asdict(self) | {"passed": self.passed}


class NativeStatevectorKernel:
    def __init__(self, qubit_count: int):
        if qubit_count < 1:
            raise ValueError("Native state-vector kernel requires a positive qubit count")
        try:
            from qpdtr import _native
        except Exception as exc:
            raise RuntimeError("BLOCKED_BACKEND_UNAVAILABLE:NATIVE_EXTENSION_NOT_BUILT") from exc
        self._native = _native
        self.qubit_count = int(qubit_count)
        build = dict(_native.build_info())
        self.backend_name = "NATIVE_CPP_OPENMP" if build.get("openmp") else "NATIVE_CPP"
        self.state = np.zeros(2**self.qubit_count, dtype=np.complex128)
        self.state[0] = 1.0

    @property
    def build_info(self) -> dict:
        return dict(self._native.build_info())

    def apply_instruction(self, instruction: QuantumInstruction) -> None:
        self.state = np.asarray(
            self._native.apply_gate(self.state, gate_matrix(instruction), tuple(instruction.qubits)),
            dtype=np.complex128,
        )

    def to_numpy(self) -> np.ndarray:
        return self.state.copy()

    def set_numpy(self, state: np.ndarray) -> None:
        value = np.asarray(state, dtype=np.complex128).reshape(-1)
        if value.size != self.state.size:
            raise ValueError("Replacement state dimension differs from the kernel dimension")
        self.state = np.ascontiguousarray(value)

    def execute(self, program: QuantumCircuitProgram) -> np.ndarray:
        for instruction in program.instructions:
            self.apply_instruction(instruction)
        return self.to_numpy()


class TorchStatevectorKernel:
    def __init__(self, qubit_count: int, requested_backend: str = "cpu", dtype: str = "complex128"):
        if qubit_count < 1:
            raise ValueError("Torch state-vector kernel requires a positive qubit count")
        try:
            import torch
        except Exception as exc:
            raise RuntimeError("BLOCKED_BACKEND_UNAVAILABLE:PYTORCH_NOT_INSTALLED") from exc
        policy = str(requested_backend).lower()
        if policy not in {"cpu", "cuda", "mps", "auto"}:
            raise ValueError("Torch backend must be cpu, cuda, mps or auto")
        if policy == "cuda":
            if not torch.cuda.is_available():
                raise RuntimeError("BLOCKED_BACKEND_UNAVAILABLE:TORCH_CUDA_DEVICE_NOT_AVAILABLE")
            device = torch.device("cuda")
            backend = "TORCH_CUDA"
        elif policy == "mps":
            available = bool(hasattr(torch.backends, "mps") and torch.backends.mps.is_available())
            if not available:
                raise RuntimeError("BLOCKED_BACKEND_UNAVAILABLE:TORCH_MPS_DEVICE_NOT_AVAILABLE")
            device = torch.device("mps")
            backend = "TORCH_MPS"
        elif policy == "auto" and torch.cuda.is_available():
            device = torch.device("cuda")
            backend = "TORCH_CUDA"
        elif policy == "auto" and hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            device = torch.device("mps")
            backend = "TORCH_MPS"
        else:
            device = torch.device("cpu")
            backend = "TORCH_CPU"
        if dtype not in {"complex64", "complex128"}:
            raise ValueError("Torch state-vector dtype must be complex64 or complex128")
        if device.type == "mps" and dtype == "complex128":
            dtype = "complex64"
        self._torch = torch
        self.qubit_count = int(qubit_count)
        self.device = device
        self.backend_name = backend
        self.dtype_name = dtype
        self.dtype = getattr(torch, dtype)
        self.state = torch.zeros(2**self.qubit_count, dtype=self.dtype, device=self.device)
        self.state[0] = 1.0 + 0.0j

    def _apply_to(self, state, gate: np.ndarray, qubits: Sequence[int]):
        axes = tuple(int(value) for value in qubits)
        remaining = tuple(index for index in range(self.qubit_count) if index not in axes)
        permutation = axes + remaining
        inverse = tuple(int(value) for value in np.argsort(permutation))
        tensor = state.reshape((2,) * self.qubit_count).permute(permutation).reshape(2 ** len(axes), -1)
        operand = self._torch.as_tensor(gate, dtype=self.dtype, device=self.device)
        result = operand @ tensor
        return result.reshape((2,) * self.qubit_count).permute(inverse).reshape(-1)

    def apply_instruction(self, instruction: QuantumInstruction) -> None:
        self.state = self._apply_to(self.state, gate_matrix(instruction), instruction.qubits)

    def to_numpy(self) -> np.ndarray:
        return np.asarray(self.state.detach().cpu().numpy(), dtype=complex)

    def set_numpy(self, state: np.ndarray) -> None:
        value = np.asarray(state, dtype=complex).reshape(-1)
        if value.size != self.state.numel():
            raise ValueError("Replacement state dimension differs from the kernel dimension")
        self.state = self._torch.as_tensor(value, dtype=self.dtype, device=self.device).clone()

    def execute(self, program: QuantumCircuitProgram) -> np.ndarray:
        for instruction in program.instructions:
            self.apply_instruction(instruction)
        return self.to_numpy()

    def sample_kraus(self, state, kraus: Sequence[np.ndarray], qubit: int, rng: np.random.Generator):
        branches = [self._apply_to(state, operator, (qubit,)) for operator in kraus]
        probabilities = np.array(
            [float(self._torch.real(self._torch.vdot(branch, branch)).detach().cpu()) for branch in branches]
        )
        probabilities = np.clip(probabilities, 0.0, None)
        total = float(probabilities.sum())
        if not np.isfinite(total) or total <= 0.0:
            raise RuntimeError("Kraus branch probabilities are not normalizable")
        probabilities /= total
        selected = int(rng.choice(len(branches), p=probabilities))
        return branches[selected] / np.sqrt(probabilities[selected] * total)


class CuQuantumStatevectorKernel:
    """cuTensorNet NetworkState adapter using the documented high-level state API.

    This is a real backend implementation, not a surrogate.  It is admitted only when both
    cuQuantum and a CUDA device are present.  Dynamic mid-circuit state replacement is not
    supported by NetworkState and therefore fails explicitly rather than falling back silently.
    """

    def __init__(self, qubit_count: int, *, mps_max_extent: int | None = None):
        if qubit_count < 1:
            raise ValueError("cuQuantum state requires a positive qubit count")
        try:
            import torch
            from cuquantum.tensornet.experimental import MPSConfig, NetworkState, TNConfig
        except Exception as exc:
            raise RuntimeError("BLOCKED_BACKEND_UNAVAILABLE:CUQUANTUM_NOT_INSTALLED") from exc
        if not torch.cuda.is_available():
            raise RuntimeError("BLOCKED_BACKEND_UNAVAILABLE:CUDA_DEVICE_NOT_AVAILABLE")
        self.qubit_count = int(qubit_count)
        self.backend_name = "CUQUANTUM_CUTENSORNET"
        config = TNConfig() if mps_max_extent is None else MPSConfig(max_extent=int(mps_max_extent))
        self._state = NetworkState((2,) * self.qubit_count, dtype="complex128", config=config)
        self._operations: list[tuple[tuple[int, ...], np.ndarray]] = []

    def apply_instruction(self, instruction: QuantumInstruction) -> None:
        matrix = gate_matrix(instruction)
        tensor = matrix.reshape((2,) * (2 * len(instruction.qubits)))
        self._state.apply_tensor_operator(instruction.qubits, tensor, immutable=True, unitary=True)
        self._operations.append((instruction.qubits, matrix))

    def to_numpy(self) -> np.ndarray:
        value = self._state.compute_state_vector()
        try:
            return np.asarray(value.get(), dtype=complex).reshape(-1)
        except AttributeError:
            try:
                return np.asarray(value.detach().cpu().numpy(), dtype=complex).reshape(-1)
            except AttributeError:
                return np.asarray(value, dtype=complex).reshape(-1)

    def set_numpy(self, state: np.ndarray) -> None:
        raise RuntimeError("BLOCKED_DYNAMIC_CONTROL:CUQUANTUM_NETWORKSTATE_CANNOT_REPLACE_STATE")

    def execute(self, program: QuantumCircuitProgram) -> np.ndarray:
        for instruction in program.instructions:
            self.apply_instruction(instruction)
        return self.to_numpy()

    def free(self) -> None:
        self._state.free()


def execute_numpy(program: QuantumCircuitProgram) -> np.ndarray:
    state = np.zeros(2**program.qubit_count, dtype=complex)
    state[0] = 1.0
    for instruction in program.instructions:
        state = apply_numpy_gate(state, gate_matrix(instruction), instruction.qubits)
    return state


def create_statevector_kernel(qubit_count: int, requested_backend: str):
    policy = str(requested_backend).lower()
    if policy == "native":
        return NativeStatevectorKernel(qubit_count)
    if policy == "cuquantum":
        return CuQuantumStatevectorKernel(qubit_count)
    if policy in {"torch_cpu", "cpu"}:
        return TorchStatevectorKernel(qubit_count, "cpu")
    if policy in {"torch_cuda", "cuda"}:
        return TorchStatevectorKernel(qubit_count, "cuda")
    if policy == "mps":
        return TorchStatevectorKernel(qubit_count, "mps")
    if policy != "auto":
        raise ValueError("Backend must be auto, native, cuquantum, torch_cpu, torch_cuda or mps")
    # Prefer the vendor accelerator, then the compiled native owner, then Torch CPU.
    cuquantum_failure: RuntimeError | None = None
    if importlib.util.find_spec("cuquantum") is not None:
        try:
            return CuQuantumStatevectorKernel(qubit_count)
        except RuntimeError as exc:
            cuquantum_failure = exc
    try:
        return NativeStatevectorKernel(qubit_count)
    except RuntimeError as native_failure:
        try:
            return TorchStatevectorKernel(qubit_count, "auto")
        except RuntimeError as torch_failure:
            reasons = [str(value) for value in (cuquantum_failure, native_failure, torch_failure) if value is not None]
            raise RuntimeError("BLOCKED_BACKEND_UNAVAILABLE:" + "|".join(reasons)) from torch_failure


def qualify_accelerators(qubit_count: int = 8) -> AcceleratorQualification:
    reference_program = QuantumCircuitProgram(
        version="3.0",
        qubit_count=qubit_count,
        classical_bit_count=0,
        statements=(),
        pulse_program=None,
        source_sha256="native-qualification",
    )
    # Bypass the empty-program compatibility projection and exercise arbitrary axes directly.
    instructions = [QuantumInstruction("h", (0,))]
    instructions.extend(QuantumInstruction("cx", (0, site)) for site in range(1, qubit_count))
    reference = np.zeros(2**qubit_count, dtype=complex)
    reference[0] = 1.0
    for instruction in instructions:
        reference = apply_numpy_gate(reference, gate_matrix(instruction), instruction.qubits)
    try:
        native = NativeStatevectorKernel(qubit_count)
        for instruction in instructions:
            native.apply_instruction(instruction)
        gap = float(np.linalg.norm(reference - native.to_numpy()))
        info = native.build_info
        resolved = native.backend_name
        reason = None if gap < 1e-12 else "BLOCKED_NUMERICAL_INVALID:NATIVE_REFERENCE_DISAGREEMENT"
    except RuntimeError as exc:
        gap = None
        info = {"openmp": False, "max_threads": 0}
        resolved = None
        reason = str(exc)
    try:
        import torch
        cuda = bool(torch.cuda.is_available())
        runtime = f"torch-{torch.__version__}"
    except Exception:
        cuda = False
        runtime = None
    return AcceleratorQualification(
        requested_backend="auto",
        resolved_backend=resolved,
        runtime=runtime,
        native_openmp=bool(info.get("openmp", False)),
        native_max_threads=int(info.get("max_threads", 0)),
        native_reference_gap=gap,
        cuquantum_available=importlib.util.find_spec("cuquantum") is not None,
        cuda_available=cuda,
        blocked_reason=reason,
    )
