from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Sequence

import numpy as np


@dataclass(frozen=True, slots=True)
class SVDCoarseGrainingCertificate:
    original_shape: tuple[int, ...]
    left_axes: tuple[int, ...]
    right_axes: tuple[int, ...]
    matrix_shape: tuple[int, int]
    retained_bond_dimension: int
    singular_values: tuple[float, ...]
    discarded_weight: float
    relative_frobenius_error: float
    certified_bound_gap: float

    def to_dict(self) -> dict:
        return asdict(self)


def _validated_partition(ndim: int, left_axes: Sequence[int]) -> tuple[tuple[int, ...], tuple[int, ...]]:
    left = tuple(int(axis) for axis in left_axes)
    if not left or len(set(left)) != len(left):
        raise ValueError("The tensor bipartition requires unique non-empty left axes")
    if any(axis < 0 or axis >= ndim for axis in left):
        raise ValueError("Tensor bipartition axis is outside the tensor rank")
    right = tuple(axis for axis in range(ndim) if axis not in left)
    if not right:
        raise ValueError("The tensor bipartition requires at least one right axis")
    return left, right


def svd_coarse_grain_tensor(
    tensor: np.ndarray,
    max_bond: int,
    *,
    left_axes: Sequence[int] | None = None,
) -> tuple[np.ndarray, SVDCoarseGrainingCertificate]:
    """Apply the sole active SVD coarse-graining algorithm to an N-dimensional tensor.

    The tensor is permuted into one declared bipartition, reshaped to a matrix, truncated
    by the optimal rank-chi SVD approximation, and restored to the original axis order.
    The discarded singular values certify the relative Frobenius error.
    """

    data = np.asarray(tensor)
    if data.ndim < 2:
        raise ValueError("SVD coarse-graining requires a tensor of rank at least two")
    if not np.issubdtype(data.dtype, np.number):
        raise TypeError("SVD coarse-graining requires a numerical tensor")
    if not np.all(np.isfinite(data)):
        raise ValueError("SVD coarse-graining rejects non-finite tensor entries")
    if max_bond <= 0:
        raise ValueError("Bond dimension must be positive")

    if left_axes is None:
        split = max(1, data.ndim // 2)
        left_axes = tuple(range(split))
    left, right = _validated_partition(data.ndim, left_axes)
    permutation = left + right
    inverse_permutation = tuple(int(axis) for axis in np.argsort(permutation))
    permuted = np.transpose(data, permutation)
    left_size = int(np.prod([data.shape[axis] for axis in left], dtype=np.int64))
    right_size = int(np.prod([data.shape[axis] for axis in right], dtype=np.int64))
    matrix = permuted.reshape(left_size, right_size)

    u, singular_values, vh = np.linalg.svd(matrix, full_matrices=False)
    chi = min(int(max_bond), int(singular_values.size))
    approximation_matrix = (u[:, :chi] * singular_values[:chi]) @ vh[:chi]
    approximation_permuted = approximation_matrix.reshape(permuted.shape)
    approximation = np.transpose(approximation_permuted, inverse_permutation)

    discarded_sq = float(np.sum(singular_values[chi:] ** 2))
    total_sq = float(np.sum(singular_values**2))
    predicted = np.sqrt(discarded_sq / total_sq) if total_sq else 0.0
    norm = float(np.linalg.norm(data))
    observed = float(np.linalg.norm(data - approximation) / norm) if norm else 0.0
    certificate = SVDCoarseGrainingCertificate(
        original_shape=tuple(int(value) for value in data.shape),
        left_axes=left,
        right_axes=right,
        matrix_shape=(left_size, right_size),
        retained_bond_dimension=chi,
        singular_values=tuple(float(value) for value in singular_values),
        discarded_weight=discarded_sq / total_sq if total_sq else 0.0,
        relative_frobenius_error=observed,
        certified_bound_gap=abs(observed - predicted),
    )
    return approximation, certificate


def svd_coarse_grain(matrix: np.ndarray, max_bond: int) -> tuple[np.ndarray, SVDCoarseGrainingCertificate]:
    """Compatibility entry point delegating to the single N-dimensional owner algorithm."""

    data = np.asarray(matrix)
    if data.ndim != 2:
        raise ValueError("Matrix entry point accepts exactly two dimensions")
    return svd_coarse_grain_tensor(data, max_bond, left_axes=(0,))
