from __future__ import annotations

from dataclasses import asdict, dataclass
from functools import lru_cache
from itertools import product
import json
from math import isfinite, sqrt
from pathlib import Path
from typing import Sequence

import numpy as np
from scipy.linalg import expm

from .error_budget import (
    QuantumErrorAllocation,
    build_unified_quantum_error_budget,
)


@dataclass(frozen=True, slots=True)
class ProcessTensorDigitalTwinCertificate:
    backend_name: str
    backend_version: str
    calibration_timestamp: str
    calibration_source_status: str
    calibrated_qubits: tuple[int, ...]
    mean_t1_us: float
    mean_t2_us: float
    two_qubit_gate_error: float
    two_qubit_gate_length_ns: float
    static_zz_coupling_ghz: float
    one_step_choi_minimum_eigenvalue: float
    trace_preservation_gap: float
    markov_process_tensor_bond_dimension: int
    non_markovian_identifiability_status: str
    holdout_validation_status: str
    status: str
    claim_scope: str

    @property
    def passed(self) -> bool:
        return self.status.startswith("PASS")

    def to_dict(self) -> dict:
        return asdict(self) | {"passed": self.passed}


@dataclass(frozen=True, slots=True)
class ProcessTensorMemoryCertificate:
    time_step: float
    intervention_steps: int
    system_dimension: int
    environment_dimension: int
    exact_tensor_entry_count: int
    temporal_bond_dimensions: tuple[int, ...]
    process_tensor_bond_dimension: int
    compression_relative_frobenius_error: float
    maximum_intervention_prediction_gap: float
    maximum_cptp_trace_gap: float
    minimum_cptp_output_eigenvalue: float
    conditional_probability_gap: float
    conditional_state_trace_distance: float
    causal_break_memory_witness: float
    markov_reset_memory_witness: float
    memory_witness_separation: float
    validated_sequence_count: int
    spatial_qubit_count: int
    spatial_temporal_intervention_steps: int
    spatial_temporal_exact_tensor_entry_count: int
    spatial_temporal_leg_dimensions: tuple[int, ...]
    spatial_temporal_bond_dimensions: tuple[int, ...]
    spatial_temporal_bond_dimension: int
    spatial_temporal_compression_relative_frobenius_error: float
    spatial_temporal_prediction_gap: float
    spatial_temporal_selected_ordering: str
    spatial_temporal_reference_sequences: int
    unified_error_bound: float
    unified_error_budget: float
    unified_error_budget_status: str
    digital_twin_backend: str
    digital_twin_calibration_timestamp: str
    digital_twin_status: str
    digital_twin_non_markovian_status: str
    status: str
    claim_scope: str

    @property
    def passed(self) -> bool:
        return self.status.startswith("PASS")

    def to_dict(self) -> dict:
        return asdict(self) | {"passed": self.passed}


# Thin compatibility views. The active memory owner is ProcessTensorMemoryCertificate.
@dataclass(frozen=True, slots=True)
class TransferTensorMemoryCertificate:
    time_step: float
    training_steps: int
    holdout_steps: int
    selected_memory_length: int
    maximum_memory_length: int
    transfer_tensor_tail_norm: float
    training_reconstruction_gap: float
    holdout_prediction_gap: float
    maximum_trace_preservation_gap: float
    minimum_dephasing_cp_margin: float
    temporal_bond_proxy: int
    status: str
    claim_scope: str

    @property
    def passed(self) -> bool:
        return self.status.startswith("PASS")

    def to_dict(self) -> dict:
        return asdict(self) | {"passed": self.passed}


@dataclass(frozen=True, slots=True)
class TemporalKernelCompressionCertificate:
    time_points: int
    temporal_bond_dimension: int
    relative_reconstruction_error: float
    retained_singular_values: tuple[float, ...]
    status: str
    claim_scope: str

    def to_dict(self) -> dict:
        return asdict(self)


def _vec(matrix: np.ndarray) -> np.ndarray:
    return np.asarray(matrix, dtype=complex).reshape(-1, order="F")


def _unvec(vector: np.ndarray, dimension: int) -> np.ndarray:
    return np.asarray(vector, dtype=complex).reshape((dimension, dimension), order="F")


def _partial_trace_environment(
    joint: np.ndarray,
    system_dimension: int,
    environment_dimension: int,
) -> np.ndarray:
    tensor = np.asarray(joint, dtype=complex).reshape(
        system_dimension,
        environment_dimension,
        system_dimension,
        environment_dimension,
    )
    return np.einsum("aebe->ab", tensor, optimize=True)


def _superoperator_from_kraus(kraus: Sequence[np.ndarray]) -> np.ndarray:
    if not kraus:
        raise ValueError("at least one Kraus operator is required")
    operators = tuple(np.asarray(item, dtype=complex) for item in kraus)
    dimension = operators[0].shape[0]
    if any(item.shape != (dimension, dimension) for item in operators):
        raise ValueError("Kraus operators must be square and share one dimension")
    return sum(np.kron(item.conj(), item) for item in operators)


def _apply_system_superoperator(
    joint: np.ndarray,
    superoperator: np.ndarray,
    system_dimension: int,
    environment_dimension: int,
) -> np.ndarray:
    superoperator = np.asarray(superoperator, dtype=complex)
    liouville_dimension = system_dimension * system_dimension
    if superoperator.shape != (liouville_dimension, liouville_dimension):
        raise ValueError("system superoperator has an incompatible Liouville dimension")
    super_tensor = superoperator.reshape(
        system_dimension,
        system_dimension,
        system_dimension,
        system_dimension,
        order="F",
    )
    joint_tensor = np.asarray(joint, dtype=complex).reshape(
        system_dimension,
        environment_dimension,
        system_dimension,
        environment_dimension,
    )
    result = np.einsum("abst,setf->aebf", super_tensor, joint_tensor, optimize=True)
    return result.reshape(
        system_dimension * environment_dimension,
        system_dimension * environment_dimension,
    )


def _paulis() -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    identity = np.eye(2, dtype=complex)
    x = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=complex)
    y = np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=complex)
    z = np.diag([1.0, -1.0]).astype(complex)
    return identity, x, y, z


def _single_memory_unitary(time_step: float, detuning: float, coupling_rate: float) -> np.ndarray:
    identity, x, y, z = _paulis()
    hamiltonian = (
        0.5 * float(detuning) * (np.kron(z, identity) - np.kron(identity, z))
        + 0.5 * float(coupling_rate) * (np.kron(x, x) + np.kron(y, y))
    )
    return expm(-1.0j * float(time_step) * hamiltonian)


def _two_qubit_memory_unitary(time_step: float) -> np.ndarray:
    identity, x, y, z = _paulis()

    def operator(first: np.ndarray, second: np.ndarray, environment: np.ndarray) -> np.ndarray:
        return np.kron(np.kron(first, second), environment)

    hamiltonian = (
        0.23 * operator(z, identity, identity)
        - 0.17 * operator(identity, z, identity)
        + 0.11 * operator(z, z, identity)
        + 0.37 * (operator(x, identity, x) + operator(y, identity, y))
        + 0.29 * (operator(identity, x, x) + operator(identity, y, y))
    )
    return expm(-1.0j * float(time_step) * hamiltonian)


def _ground_joint_state(system_qubits: int, environment_qubits: int = 1) -> np.ndarray:
    ground = np.array([1.0, 0.0], dtype=complex)
    state = ground
    for _ in range(system_qubits + environment_qubits - 1):
        state = np.kron(state, ground)
    return np.outer(state, state.conj())


def _propagate_sequence(
    sequence: Sequence[np.ndarray],
    unitary: np.ndarray,
    *,
    system_dimension: int = 2,
    environment_dimension: int = 2,
    reset_environment_after_step: bool = False,
) -> np.ndarray:
    system_qubits = int(round(np.log2(system_dimension)))
    if 2**system_qubits != system_dimension or environment_dimension != 2:
        raise ValueError("bounded owner currently requires qubit system and one memory qubit")
    joint = _ground_joint_state(system_qubits)
    environment_reference = np.diag([1.0, 0.0]).astype(complex)
    for superoperator in sequence:
        joint = _apply_system_superoperator(
            joint,
            superoperator,
            system_dimension,
            environment_dimension,
        )
        joint = unitary @ joint @ unitary.conj().T
        if reset_environment_after_step:
            system = _partial_trace_environment(joint, system_dimension, environment_dimension)
            joint = np.kron(system, environment_reference)
    return _partial_trace_environment(joint, system_dimension, environment_dimension)


def _basis_superoperators(dimension: int) -> tuple[np.ndarray, ...]:
    liouville_dimension = dimension * dimension
    result = []
    for row in range(liouville_dimension):
        for column in range(liouville_dimension):
            basis = np.zeros((liouville_dimension, liouville_dimension), dtype=complex)
            basis[row, column] = 1.0
            result.append(basis)
    return tuple(result)


def build_operational_process_tensor(
    unitary: np.ndarray,
    intervention_steps: int,
    *,
    system_dimension: int = 2,
    environment_dimension: int = 2,
) -> np.ndarray:
    """Build an exact multilinear process tensor in a matrix-unit basis."""

    if intervention_steps < 1:
        raise ValueError("at least one intervention step is required")
    basis = _basis_superoperators(system_dimension)
    output_dimension = system_dimension * system_dimension
    tensor = np.zeros((len(basis),) * intervention_steps + (output_dimension,), dtype=complex)

    if intervention_steps == 2:
        # The two-step spatial-temporal certificate is performance critical. Reuse
        # the first evolved joint state without changing the mathematical owner.
        system_qubits = int(round(np.log2(system_dimension)))
        initial_joint = _ground_joint_state(system_qubits)
        first_states = []
        for first in basis:
            joint = _apply_system_superoperator(
                initial_joint,
                first,
                system_dimension,
                environment_dimension,
            )
            first_states.append(unitary @ joint @ unitary.conj().T)
        for first_index, joint in enumerate(first_states):
            for second_index, second in enumerate(basis):
                evolved = _apply_system_superoperator(
                    joint,
                    second,
                    system_dimension,
                    environment_dimension,
                )
                evolved = unitary @ evolved @ unitary.conj().T
                tensor[first_index, second_index] = _vec(
                    _partial_trace_environment(
                        evolved,
                        system_dimension,
                        environment_dimension,
                    )
                )
        return tensor

    for indices in product(range(len(basis)), repeat=intervention_steps):
        output = _propagate_sequence(
            tuple(basis[index] for index in indices),
            unitary,
            system_dimension=system_dimension,
            environment_dimension=environment_dimension,
        )
        tensor[indices] = _vec(output)
    return tensor


def contract_process_tensor(
    process_tensor: np.ndarray,
    sequence: Sequence[np.ndarray],
) -> np.ndarray:
    value = np.asarray(process_tensor, dtype=complex)
    output_dimension = int(round(sqrt(value.shape[-1])))
    if output_dimension * output_dimension != value.shape[-1]:
        raise ValueError("process tensor output leg is not a square density-vector dimension")
    if value.ndim != len(sequence) + 1:
        raise ValueError("process tensor and intervention sequence have incompatible orders")
    for superoperator in sequence:
        coefficients = np.asarray(superoperator, dtype=complex).reshape(-1)
        if coefficients.size != value.shape[0]:
            raise ValueError("intervention superoperator has an incompatible dimension")
        value = np.tensordot(coefficients, value, axes=(0, 0))
    return _unvec(value, output_dimension)


def _tensor_train_svd(
    tensor: np.ndarray,
    *,
    relative_tolerance: float,
    maximum_bond: int,
) -> tuple[tuple[np.ndarray, ...], tuple[int, ...], float, np.ndarray]:
    dimensions = tuple(int(value) for value in tensor.shape)
    if len(dimensions) < 2:
        raise ValueError("tensor-train compression requires at least two tensor legs")
    if relative_tolerance <= 0.0 or maximum_bond < 1:
        raise ValueError("invalid tensor-train compression policy")
    norm = float(np.linalg.norm(tensor.reshape(-1)))
    if norm <= 0.0:
        raise ValueError("cannot compress a zero process tensor")

    cores: list[np.ndarray] = []
    ranks = [1]
    unfolding = np.asarray(tensor, dtype=complex)
    left_rank = 1
    local_budget = (relative_tolerance * norm) ** 2 / max(1, len(dimensions) - 1)
    for dimension in dimensions[:-1]:
        matrix = unfolding.reshape(left_rank * dimension, -1)
        u, singular_values, vh = np.linalg.svd(matrix, full_matrices=False)
        squared = singular_values**2
        rank = min(len(singular_values), maximum_bond)
        for candidate in range(1, rank + 1):
            discarded = float(np.sum(squared[candidate:]))
            if discarded <= local_budget:
                rank = candidate
                break
        cores.append(u[:, :rank].reshape(left_rank, dimension, rank))
        unfolding = singular_values[:rank, None] * vh[:rank, :]
        left_rank = rank
        ranks.append(rank)
    cores.append(unfolding.reshape(left_rank, dimensions[-1], 1))
    ranks.append(1)

    reconstructed = cores[0]
    for core in cores[1:]:
        reconstructed = np.tensordot(reconstructed, core, axes=(-1, 0))
    reconstructed = np.squeeze(reconstructed, axis=(0, -1))
    relative_error = float(np.linalg.norm(reconstructed - tensor) / norm)
    return tuple(cores), tuple(ranks), relative_error, reconstructed


def _trace_distance(first: np.ndarray, second: np.ndarray) -> float:
    difference = np.asarray(first, dtype=complex) - np.asarray(second, dtype=complex)
    eigenvalues = np.linalg.eigvalsh(0.5 * (difference + difference.conj().T))
    return 0.5 * float(np.sum(np.abs(eigenvalues)))


def _single_qubit_interventions() -> dict[str, np.ndarray]:
    identity, x, _, _ = _paulis()
    h = np.array([[1.0, 1.0], [1.0, -1.0]], dtype=complex) / np.sqrt(2.0)
    p0 = np.diag([1.0, 0.0]).astype(complex)
    p1 = np.diag([0.0, 1.0]).astype(complex)
    reset0 = (
        np.array([[1.0, 0.0], [0.0, 0.0]], dtype=complex),
        np.array([[0.0, 1.0], [0.0, 0.0]], dtype=complex),
    )
    damping = 0.23
    amplitude = (
        np.diag([1.0, np.sqrt(1.0 - damping)]).astype(complex),
        np.array([[0.0, np.sqrt(damping)], [0.0, 0.0]], dtype=complex),
    )
    return {
        "identity": _superoperator_from_kraus((identity,)),
        "x": _superoperator_from_kraus((x,)),
        "h": _superoperator_from_kraus((h,)),
        "dephase_z": _superoperator_from_kraus((p0, p1)),
        "project_0": _superoperator_from_kraus((p0,)),
        "project_1": _superoperator_from_kraus((p1,)),
        "reset_0": _superoperator_from_kraus(reset0),
        "amplitude_damping": _superoperator_from_kraus(amplitude),
    }


def _two_qubit_interventions() -> dict[str, np.ndarray]:
    identity, x, _, z = _paulis()
    h = np.array([[1.0, 1.0], [1.0, -1.0]], dtype=complex) / np.sqrt(2.0)
    cnot = np.array(
        [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1], [0, 0, 1, 0]],
        dtype=complex,
    )
    p0 = np.diag([1.0, 0.0]).astype(complex)
    p1 = np.diag([0.0, 1.0]).astype(complex)
    dephase_first = tuple(np.kron(item, identity) for item in (p0, p1))
    return {
        "identity": _superoperator_from_kraus((np.kron(identity, identity),)),
        "x_first": _superoperator_from_kraus((np.kron(x, identity),)),
        "h_second": _superoperator_from_kraus((np.kron(identity, h),)),
        "zz": _superoperator_from_kraus((np.kron(z, z),)),
        "cnot": _superoperator_from_kraus((cnot,)),
        "dephase_first": _superoperator_from_kraus(dephase_first),
    }


def _space_time_factorization_maps() -> tuple[np.ndarray, np.ndarray]:
    """Map a two-qubit superoperator basis into per-site Liouville legs."""

    system_dimension = 4
    liouville_dimension = 16
    local_first: list[int] = []
    local_second: list[int] = []
    for basis_index in range(256):
        super_row, super_column = divmod(basis_index, liouville_dimension)
        output_ket, output_bra = super_row % system_dimension, super_row // system_dimension
        input_ket, input_bra = super_column % system_dimension, super_column // system_dimension
        ok0, ok1 = divmod(output_ket, 2)
        ob0, ob1 = divmod(output_bra, 2)
        ik0, ik1 = divmod(input_ket, 2)
        ib0, ib1 = divmod(input_bra, 2)
        output_vec0, output_vec1 = ok0 + 2 * ob0, ok1 + 2 * ob1
        input_vec0, input_vec1 = ik0 + 2 * ib0, ik1 + 2 * ib1
        local_first.append(output_vec0 * 4 + input_vec0)
        local_second.append(output_vec1 * 4 + input_vec1)

    basis_inverse = np.empty(256, dtype=int)
    for original, (first, second) in enumerate(zip(local_first, local_second)):
        basis_inverse[first * 16 + second] = original

    output_first: list[int] = []
    output_second: list[int] = []
    for vector_index in range(16):
        ket, bra = vector_index % system_dimension, vector_index // system_dimension
        ket0, ket1 = divmod(ket, 2)
        bra0, bra1 = divmod(bra, 2)
        output_first.append(ket0 + 2 * bra0)
        output_second.append(ket1 + 2 * bra1)

    output_inverse = np.empty(16, dtype=int)
    for original, (first, second) in enumerate(zip(output_first, output_second)):
        output_inverse[first * 4 + second] = original
    return basis_inverse, output_inverse


def _factor_space_time_process_tensor(process_tensor: np.ndarray) -> np.ndarray:
    basis_inverse, output_inverse = _space_time_factorization_maps()
    reordered = process_tensor[np.ix_(basis_inverse, basis_inverse, output_inverse)]
    return reordered.reshape(16, 16, 16, 16, 4, 4)


def _restore_space_time_process_tensor(factorized: np.ndarray) -> np.ndarray:
    basis_inverse, output_inverse = _space_time_factorization_maps()
    reordered = np.asarray(factorized, dtype=complex).reshape(256, 256, 16)
    original = np.empty_like(reordered)
    original[np.ix_(basis_inverse, basis_inverse, output_inverse)] = reordered
    return original


def _calibration_path() -> Path:
    return Path(__file__).resolve().parents[2] / "data" / "calibration" / "ibmq_manila_2024-05-27_subset.json"


def _amplitude_phase_kraus(t1_us: float, t2_us: float, duration_ns: float) -> tuple[np.ndarray, ...]:
    duration_us = float(duration_ns) / 1000.0
    gamma = 1.0 - np.exp(-duration_us / float(t1_us))
    inverse_tphi = max(0.0, 1.0 / float(t2_us) - 0.5 / float(t1_us))
    coherence = np.exp(-duration_us * inverse_tphi)
    phase_probability = 0.5 * (1.0 - coherence)
    identity, _, _, z = _paulis()
    amplitude = (
        np.diag([1.0, np.sqrt(max(0.0, 1.0 - gamma))]).astype(complex),
        np.array([[0.0, np.sqrt(max(0.0, gamma))], [0.0, 0.0]], dtype=complex),
    )
    phase = (
        np.sqrt(max(0.0, 1.0 - phase_probability)) * identity,
        np.sqrt(max(0.0, phase_probability)) * z,
    )
    return tuple(phase_operator @ amplitude_operator for phase_operator in phase for amplitude_operator in amplitude)


def _depolarizing_kraus(dimension_qubits: int, average_gate_error: float) -> tuple[np.ndarray, ...]:
    identity, x, y, z = _paulis()
    paulis = (identity, x, y, z)
    dimension = 2**dimension_qubits
    depolarizing_probability = min(1.0, float(average_gate_error) * dimension / (dimension - 1.0))
    operators = [np.sqrt(max(0.0, 1.0 - depolarizing_probability)) * np.eye(dimension, dtype=complex)]
    non_identity = []
    for labels in product(range(4), repeat=dimension_qubits):
        if all(label == 0 for label in labels):
            continue
        operator = paulis[labels[0]]
        for label in labels[1:]:
            operator = np.kron(operator, paulis[label])
        non_identity.append(operator)
    scale = np.sqrt(depolarizing_probability / len(non_identity))
    operators.extend(scale * operator for operator in non_identity)
    return tuple(operators)


def _choi_from_kraus(kraus: Sequence[np.ndarray]) -> np.ndarray:
    dimension = kraus[0].shape[0]
    choi = np.zeros((dimension * dimension, dimension * dimension), dtype=complex)
    for row in range(dimension):
        for column in range(dimension):
            basis = np.zeros((dimension, dimension), dtype=complex)
            basis[row, column] = 1.0
            output = sum(operator @ basis @ operator.conj().T for operator in kraus)
            choi += np.kron(basis, output)
    return choi


@lru_cache(maxsize=4)
def qualify_process_tensor_digital_twin(
    calibration_file: str | None = None,
) -> ProcessTensorDigitalTwinCertificate:
    """Build a real-device-derived Markov process-tensor baseline.

    The public IBM Manila snapshot supplies T1, T2, readout, gate error, gate
    duration and static ZZ coupling.  These data determine a CPTP Markov baseline
    but do not identify a non-Markovian process tensor, because no multitime
    intervention/outcome counts or covariance are present.  The latter remains
    explicitly blocked rather than inferred from T1/T2.
    """

    path = Path(calibration_file) if calibration_file is not None else _calibration_path()
    data = json.loads(path.read_text(encoding="utf-8"))
    qubit0 = data["qubits"]["0"]
    qubit1 = data["qubits"]["1"]
    gate = data["two_qubit_gate"]
    duration_ns = float(gate["gate_length_ns"])

    local0 = _amplitude_phase_kraus(qubit0["T1_us"], qubit0["T2_us"], duration_ns)
    local1 = _amplitude_phase_kraus(qubit1["T1_us"], qubit1["T2_us"], duration_ns)
    local = tuple(np.kron(first, second) for first in local0 for second in local1)

    _, _, _, z = _paulis()
    zz_ghz = float(data["static_coupling"]["zz_01_GHz"])
    angle = 2.0 * np.pi * zz_ghz * duration_ns
    coherent = expm(-1.0j * angle * np.kron(z, z))
    coherent_local = tuple(coherent @ operator for operator in local)

    depolarizing = _depolarizing_kraus(2, float(gate["gate_error"]))
    combined = tuple(depolarizing_operator @ local_operator for depolarizing_operator in depolarizing for local_operator in coherent_local)

    choi = _choi_from_kraus(combined)
    minimum_eigenvalue = float(np.min(np.linalg.eigvalsh(0.5 * (choi + choi.conj().T))))
    completeness = sum(operator.conj().T @ operator for operator in combined)
    trace_gap = float(np.linalg.norm(completeness - np.eye(4), ord="fro"))

    if minimum_eigenvalue < -1e-10 or trace_gap > 1e-10:
        status = "FAIL_REAL_CALIBRATION_MARKOV_BASELINE_NOT_CPTP"
    else:
        status = "PASS_REAL_CALIBRATION_SNAPSHOT_MARKOV_PROCESS_TENSOR_BASELINE"

    return ProcessTensorDigitalTwinCertificate(
        backend_name=str(data["backend_name"]),
        backend_version=str(data["backend_version"]),
        calibration_timestamp=str(data["last_update_date"]),
        calibration_source_status=str(data["source_status"]),
        calibrated_qubits=(0, 1),
        mean_t1_us=float((qubit0["T1_us"] + qubit1["T1_us"]) / 2.0),
        mean_t2_us=float((qubit0["T2_us"] + qubit1["T2_us"]) / 2.0),
        two_qubit_gate_error=float(gate["gate_error"]),
        two_qubit_gate_length_ns=duration_ns,
        static_zz_coupling_ghz=zz_ghz,
        one_step_choi_minimum_eigenvalue=minimum_eigenvalue,
        trace_preservation_gap=trace_gap,
        markov_process_tensor_bond_dimension=1,
        non_markovian_identifiability_status="BLOCKED_MULTITIME_CALIBRATION_DATA_REQUIRED",
        holdout_validation_status="BLOCKED_REAL_SHOT_COUNTS_AND_COVARIANCE_REQUIRED",
        status=status,
        claim_scope=(
            "Two-qubit Markov digital-twin baseline from the public IBM Manila calibration snapshot dated "
            "2024-05-27. The snapshot is real-device-derived but not live. T1/T2, gate error, duration, "
            "readout and static ZZ determine a CPTP baseline only; non-Markovian process-tensor memory "
            "and predictive holdout validation are not claimed without multitime intervention counts."
        ),
    )


@lru_cache(maxsize=8)
def qualify_process_tensor_memory(
    *,
    time_step: float = 0.37,
    detuning: float = 0.41,
    coupling_rate: float = 0.93,
    intervention_steps: int = 3,
    compression_tolerance: float = 1e-12,
    maximum_bond: int = 256,
) -> ProcessTensorMemoryCertificate:
    """Qualify the active spatial-temporal process-tensor tensor-network owner.

    The owner first validates intervention-complete single-qubit memory, including
    conditional measurements and causal breaks.  It then constructs an exact
    two-qubit/two-time process tensor with one persistent shared memory qubit,
    factors every intervention and output leg by spatial site, and compresses the
    resulting six-leg object as a space-time tensor train (an MPS/chain-TTN).
    One unified error ledger covers temporal compression, space-time compression
    and intervention prediction.  Finally, a public real-device calibration
    snapshot is attached as a fail-closed Markov digital-twin baseline.
    """

    if time_step <= 0.0 or coupling_rate <= 0.0 or intervention_steps != 3:
        raise ValueError("bounded qualification requires positive parameters and three single-qubit intervention steps")

    # Temporal intervention-complete control.
    unitary = _single_memory_unitary(time_step, detuning, coupling_rate)
    process_tensor = build_operational_process_tensor(unitary, intervention_steps)
    _, temporal_ranks, temporal_compression_error, compressed_temporal = _tensor_train_svd(
        process_tensor,
        relative_tolerance=compression_tolerance,
        maximum_bond=maximum_bond,
    )

    operations = _single_qubit_interventions()
    validation_sequences = (
        (operations["identity"], operations["identity"], operations["identity"]),
        (operations["x"], operations["identity"], operations["h"]),
        (operations["h"], operations["dephase_z"], operations["amplitude_damping"]),
        (operations["amplitude_damping"], operations["x"], operations["identity"]),
        (operations["x"], operations["reset_0"], operations["identity"]),
        (operations["identity"], operations["reset_0"], operations["identity"]),
    )
    prediction_gaps = []
    trace_gaps = []
    minimum_eigenvalue = np.inf
    for sequence in validation_sequences:
        exact = _propagate_sequence(sequence, unitary)
        predicted = contract_process_tensor(compressed_temporal, sequence)
        prediction_gaps.append(float(np.linalg.norm(predicted - exact, ord="fro")))
        trace_gaps.append(abs(float(np.trace(predicted).real) - 1.0))
        minimum_eigenvalue = min(
            minimum_eigenvalue,
            float(np.min(np.linalg.eigvalsh(0.5 * (predicted + predicted.conj().T)))),
        )

    conditional_sequence = (operations["h"], operations["project_0"], operations["identity"])
    conditional_exact = _propagate_sequence(conditional_sequence, unitary)
    conditional_predicted = contract_process_tensor(compressed_temporal, conditional_sequence)
    exact_probability = float(np.trace(conditional_exact).real)
    predicted_probability = float(np.trace(conditional_predicted).real)
    probability_gap = abs(exact_probability - predicted_probability)
    if exact_probability <= 1e-14 or predicted_probability <= 1e-14:
        conditional_state_gap = np.inf
    else:
        conditional_state_gap = _trace_distance(
            conditional_exact / exact_probability,
            conditional_predicted / predicted_probability,
        )

    history_excited = (operations["x"], operations["reset_0"], operations["identity"])
    history_ground = (operations["identity"], operations["reset_0"], operations["identity"])
    memory_excited = contract_process_tensor(compressed_temporal, history_excited)
    memory_ground = contract_process_tensor(compressed_temporal, history_ground)
    memory_witness = _trace_distance(memory_excited, memory_ground)
    markov_excited = _propagate_sequence(history_excited, unitary, reset_environment_after_step=True)
    markov_ground = _propagate_sequence(history_ground, unitary, reset_environment_after_step=True)
    markov_witness = _trace_distance(markov_excited, markov_ground)
    witness_separation = memory_witness - markov_witness

    # Spatial-temporal tensor-network owner: two system qubits + one shared memory.
    spatial_time_step = max(0.05, min(0.25, float(time_step) * 0.4594594594594595))
    spatial_unitary = _two_qubit_memory_unitary(spatial_time_step)
    spatial_process_tensor = build_operational_process_tensor(
        spatial_unitary,
        2,
        system_dimension=4,
        environment_dimension=2,
    )
    factorized = _factor_space_time_process_tensor(spatial_process_tensor)
    _, time_major_ranks, time_major_error, time_major_reconstructed = _tensor_train_svd(
        factorized,
        relative_tolerance=compression_tolerance,
        maximum_bond=maximum_bond,
    )
    space_major = np.transpose(factorized, (0, 2, 4, 1, 3, 5))
    _, space_major_ranks, space_major_error, space_major_reconstructed = _tensor_train_svd(
        space_major,
        relative_tolerance=compression_tolerance,
        maximum_bond=maximum_bond,
    )
    if max(time_major_ranks) <= max(space_major_ranks):
        selected_ordering = "TIME_MAJOR_SITE_FACTORED_TT_MPS"
        selected_ranks = time_major_ranks
        selected_error = time_major_error
        selected_factorized = time_major_reconstructed
    else:
        selected_ordering = "SPACE_MAJOR_SITE_FACTORED_TT_MPS"
        selected_ranks = space_major_ranks
        selected_error = space_major_error
        selected_factorized = np.transpose(space_major_reconstructed, (0, 3, 1, 4, 2, 5))
    compressed_spatial_process = _restore_space_time_process_tensor(selected_factorized)

    spatial_operations = _two_qubit_interventions()
    spatial_sequences = (
        (spatial_operations["identity"], spatial_operations["identity"]),
        (spatial_operations["x_first"], spatial_operations["h_second"]),
        (spatial_operations["h_second"], spatial_operations["cnot"]),
        (spatial_operations["dephase_first"], spatial_operations["zz"]),
        (spatial_operations["cnot"], spatial_operations["x_first"]),
    )
    spatial_prediction_gaps = []
    for sequence in spatial_sequences:
        exact = _propagate_sequence(
            sequence,
            spatial_unitary,
            system_dimension=4,
            environment_dimension=2,
        )
        predicted = contract_process_tensor(compressed_spatial_process, sequence)
        spatial_prediction_gaps.append(float(np.linalg.norm(predicted - exact, ord="fro")))
    spatial_prediction_gap = float(max(spatial_prediction_gaps))

    budget_allocation = 1e-10
    unified_budget = build_unified_quantum_error_budget(
        (
            QuantumErrorAllocation(
                "temporal_process_tensor_compression",
                "ProcessTensorMemory",
                "relative_frobenius",
                float(temporal_compression_error),
                budget_allocation,
                "RSS",
                "spacetime_process_frobenius",
                "PASS",
            ),
            QuantumErrorAllocation(
                "temporal_intervention_prediction",
                "ProcessTensorMemory",
                "frobenius",
                float(max(prediction_gaps)),
                budget_allocation,
                "RSS",
                "spacetime_process_frobenius",
                "PASS",
            ),
            QuantumErrorAllocation(
                "space_time_tensor_network_compression",
                "ProcessTensorMemory",
                "relative_frobenius",
                float(selected_error),
                budget_allocation,
                "RSS",
                "spacetime_process_frobenius",
                "PASS",
            ),
            QuantumErrorAllocation(
                "space_time_intervention_prediction",
                "ProcessTensorMemory",
                "frobenius",
                spatial_prediction_gap,
                budget_allocation,
                "RSS",
                "spacetime_process_frobenius",
                "PASS",
            ),
        )
    )
    group_bounds = dict(unified_budget.compatible_group_bounds)
    group_budgets = dict(unified_budget.compatible_group_budgets)
    joint_error_bound = float(group_bounds["spacetime_process_frobenius"])
    joint_error_budget = float(group_budgets["spacetime_process_frobenius"])

    digital_twin = qualify_process_tensor_digital_twin()

    numbers = (
        temporal_compression_error,
        *prediction_gaps,
        *trace_gaps,
        minimum_eigenvalue,
        probability_gap,
        conditional_state_gap,
        memory_witness,
        markov_witness,
        witness_separation,
        selected_error,
        spatial_prediction_gap,
        joint_error_bound,
        digital_twin.one_step_choi_minimum_eigenvalue,
        digital_twin.trace_preservation_gap,
    )
    if not all(isfinite(float(value)) for value in numbers):
        status = "FAIL_NONFINITE_SPATIAL_TEMPORAL_PROCESS_TENSOR_CERTIFICATE"
    elif temporal_compression_error > 1e-10 or selected_error > 1e-10:
        status = "FAIL_SPATIAL_TEMPORAL_PROCESS_TENSOR_COMPRESSION"
    elif max(prediction_gaps) > 1e-10 or spatial_prediction_gap > 1e-10:
        status = "FAIL_SPATIAL_TEMPORAL_INTERVENTION_PREDICTION"
    elif max(trace_gaps) > 1e-10 or minimum_eigenvalue < -1e-10:
        status = "FAIL_CPTP_INTERVENTION_CONTROL"
    elif probability_gap > 1e-10 or conditional_state_gap > 1e-10:
        status = "FAIL_CONDITIONAL_MEASUREMENT_CONTROL"
    elif memory_witness < 1e-3 or markov_witness > 1e-10 or witness_separation < 1e-3:
        status = "FAIL_CAUSAL_BREAK_MEMORY_WITNESS"
    elif not unified_budget.status.startswith("PASS"):
        status = "FAIL_UNIFIED_SPATIAL_TEMPORAL_ERROR_BUDGET"
    elif not digital_twin.passed:
        status = "FAIL_REAL_CALIBRATION_DIGITAL_TWIN_BASELINE"
    else:
        status = "PASS_BOUNDED_SPATIAL_TEMPORAL_PROCESS_TENSOR_TTN"

    return ProcessTensorMemoryCertificate(
        time_step=float(time_step),
        intervention_steps=int(intervention_steps),
        system_dimension=2,
        environment_dimension=2,
        exact_tensor_entry_count=int(process_tensor.size),
        temporal_bond_dimensions=tuple(int(value) for value in temporal_ranks),
        process_tensor_bond_dimension=int(max(temporal_ranks)),
        compression_relative_frobenius_error=float(temporal_compression_error),
        maximum_intervention_prediction_gap=float(max(prediction_gaps)),
        maximum_cptp_trace_gap=float(max(trace_gaps)),
        minimum_cptp_output_eigenvalue=float(minimum_eigenvalue),
        conditional_probability_gap=float(probability_gap),
        conditional_state_trace_distance=float(conditional_state_gap),
        causal_break_memory_witness=float(memory_witness),
        markov_reset_memory_witness=float(markov_witness),
        memory_witness_separation=float(witness_separation),
        validated_sequence_count=len(validation_sequences) + 1,
        spatial_qubit_count=2,
        spatial_temporal_intervention_steps=2,
        spatial_temporal_exact_tensor_entry_count=int(spatial_process_tensor.size),
        spatial_temporal_leg_dimensions=tuple(int(value) for value in factorized.shape),
        spatial_temporal_bond_dimensions=tuple(int(value) for value in selected_ranks),
        spatial_temporal_bond_dimension=int(max(selected_ranks)),
        spatial_temporal_compression_relative_frobenius_error=float(selected_error),
        spatial_temporal_prediction_gap=spatial_prediction_gap,
        spatial_temporal_selected_ordering=selected_ordering,
        spatial_temporal_reference_sequences=len(spatial_sequences),
        unified_error_bound=joint_error_bound,
        unified_error_budget=joint_error_budget,
        unified_error_budget_status=unified_budget.status,
        digital_twin_backend=digital_twin.backend_name,
        digital_twin_calibration_timestamp=digital_twin.calibration_timestamp,
        digital_twin_status=digital_twin.status,
        digital_twin_non_markovian_status=digital_twin.non_markovian_identifiability_status,
        status=status,
        claim_scope=(
            "Active bounded memory owner: intervention-complete single-qubit process tensor plus an exact "
            "two-system-qubit/two-time tensor with a persistent shared memory qubit. The latter is factorized "
            "by spatial site and compressed as one space-time TT/MPS (a chain tree tensor network), with one "
            "enforced error ledger and direct dense dilation controls. A public IBM Manila snapshot supplies "
            "a real-device-derived Markov digital-twin baseline. The result is not an unbounded many-qubit "
            "continuum-bath solver, and non-Markovian hardware memory remains blocked until multitime real-QPU "
            "intervention counts and covariance are supplied."
        ),
    )


def qualify_transfer_tensor_memory(
    *,
    linewidth: float = 0.7,
    coupling_rate: float = 1.3,
    time_step: float = 0.08,
    training_steps: int = 28,
    holdout_steps: int = 20,
    tail_tolerance: float = 1e-11,
) -> TransferTensorMemoryCertificate:
    """Thin compatibility view over the active spatial-temporal process tensor."""

    del linewidth, training_steps, holdout_steps
    certificate = qualify_process_tensor_memory(
        time_step=max(0.1, float(time_step) * 4.625),
        coupling_rate=max(0.1, float(coupling_rate) * 0.7153846153846154),
        compression_tolerance=max(1e-14, float(tail_tolerance)),
    )
    cp_margin = max(0.0, certificate.minimum_cptp_output_eigenvalue)
    return TransferTensorMemoryCertificate(
        time_step=certificate.time_step,
        training_steps=certificate.intervention_steps,
        holdout_steps=certificate.validated_sequence_count + certificate.spatial_temporal_reference_sequences,
        selected_memory_length=certificate.process_tensor_bond_dimension,
        maximum_memory_length=certificate.spatial_temporal_bond_dimension,
        transfer_tensor_tail_norm=certificate.spatial_temporal_compression_relative_frobenius_error,
        training_reconstruction_gap=certificate.compression_relative_frobenius_error,
        holdout_prediction_gap=max(
            certificate.maximum_intervention_prediction_gap,
            certificate.spatial_temporal_prediction_gap,
        ),
        maximum_trace_preservation_gap=certificate.maximum_cptp_trace_gap,
        minimum_dephasing_cp_margin=cp_margin,
        temporal_bond_proxy=certificate.process_tensor_bond_dimension,
        status=certificate.status,
        claim_scope=certificate.claim_scope,
    )


def qualify_temporal_kernel_compression(
    linewidth: float = 0.7,
    coupling_rate: float = 1.3,
    time_points: int = 96,
    cutoff: float = 1e-10,
) -> TemporalKernelCompressionCertificate:
    """Thin compatibility view backed by the active spatial-temporal owner."""

    certificate = qualify_process_tensor_memory(
        time_step=0.37,
        detuning=max(0.05, float(linewidth)),
        coupling_rate=max(0.05, float(coupling_rate)),
        compression_tolerance=max(1e-14, float(cutoff)),
    )
    return TemporalKernelCompressionCertificate(
        time_points=int(time_points),
        temporal_bond_dimension=certificate.spatial_temporal_bond_dimension,
        relative_reconstruction_error=max(
            certificate.compression_relative_frobenius_error,
            certificate.spatial_temporal_compression_relative_frobenius_error,
            certificate.maximum_intervention_prediction_gap,
            certificate.spatial_temporal_prediction_gap,
        ),
        retained_singular_values=(),
        status=certificate.status,
        claim_scope=certificate.claim_scope,
    )
