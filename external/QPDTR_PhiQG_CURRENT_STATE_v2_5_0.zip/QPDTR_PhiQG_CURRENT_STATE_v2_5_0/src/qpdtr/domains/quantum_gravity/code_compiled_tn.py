from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from typing import Any, Mapping, Sequence

import numpy as np

from .quantum import MatrixProductState


_H = np.array([[1.0, 1.0], [1.0, -1.0]], dtype=np.complex128) / np.sqrt(2.0)
_CNOT = np.array(
    [[1.0, 0.0, 0.0, 0.0],
     [0.0, 1.0, 0.0, 0.0],
     [0.0, 0.0, 0.0, 1.0],
     [0.0, 0.0, 1.0, 0.0]],
    dtype=np.complex128,
)


def _digest(payload: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ).hexdigest()


@dataclass(frozen=True, slots=True)
class CompiledLayer:
    phase_exponents_mod_8: tuple[int, ...]
    permutation: tuple[int, ...]

    def validate(self, qubit_count: int) -> None:
        if len(self.phase_exponents_mod_8) != qubit_count:
            raise ValueError("compiled phase layer has the wrong qubit count")
        if sorted(self.permutation) != list(range(qubit_count)):
            raise ValueError("compiled permutation must be a qubit-label permutation")


@dataclass(frozen=True, slots=True)
class CodeCompilationCertificate:
    schema: str
    compiler_id: str
    code_family: str
    encoder_digest: str
    admitted_physical_layer_types: tuple[str, ...]
    logical_gate_library: tuple[str, ...]
    verified: bool
    digest: str

    @classmethod
    def issue(
        cls,
        *,
        compiler_id: str,
        code_family: str,
        encoder_digest: str,
        logical_gate_library: Sequence[str],
        verified: bool,
    ) -> "CodeCompilationCertificate":
        semantic = {
            "schema": "qpdtr-code-compilation-certificate/v1",
            "compiler_id": str(compiler_id),
            "code_family": str(code_family),
            "encoder_digest": str(encoder_digest),
            "admitted_physical_layer_types": ("single_qubit_diagonal_mod8", "classical_qubit_permutation"),
            "logical_gate_library": tuple(str(v) for v in logical_gate_library),
            "verified": bool(verified),
        }
        return cls(**semantic, digest=_digest(semantic))


@dataclass(frozen=True, slots=True)
class CodeCompiledTNCertificate:
    schema: str
    status: str
    exact_reference_gap: float
    small_qubit_count: int
    small_depth: int
    small_peak_bond: int
    large_qubit_count: int
    large_depth: int
    large_peak_bond: int
    encoder_peak_bond: int
    permutation_layers: int
    diagonal_layers: int
    statevector_materialized_large: bool
    compilation_certificate_digest: str
    claim_boundary: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_BOUNDED_CODE_COMPILED_TN_OWNER"

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["passed"] = self.passed
        return payload


class PermutationTrackedMPS:
    """MPS runtime for a prevalidated diagonal-plus-permutation physical schedule.

    The owner does not discover a CSS code or prove that a logical gate compiles to
    the schedule.  It consumes a verified compilation certificate.  Once admitted,
    onsite diagonal gates leave every MPS bond unchanged, while permutations are
    represented by a classical wire-to-site map rather than SWAP gates.
    """

    def __init__(self, state: MatrixProductState, compilation: CodeCompilationCertificate) -> None:
        if not compilation.verified:
            raise ValueError("code-compiled runtime requires a verified compilation certificate")
        self.state = state.copy()
        self.compilation = compilation
        self.logical_to_site = list(range(state.qubit_count))
        self.initial_peak_bond = state.max_bond
        self.peak_bond = state.max_bond
        self.applied_layers = 0
        self.applied_permutations = 0
        self.applied_diagonal_layers = 0

    @property
    def qubit_count(self) -> int:
        return self.state.qubit_count

    def apply_layer(self, layer: CompiledLayer) -> None:
        layer.validate(self.qubit_count)
        for logical_qubit, exponent in enumerate(layer.phase_exponents_mod_8):
            k = int(exponent) % 8
            if k:
                phase = np.exp(1.0j * np.pi * k / 4.0)
                self.state.apply_one_site_gate(
                    self.logical_to_site[logical_qubit],
                    np.diag([1.0, phase]).astype(np.complex128),
                )
        if any(int(v) % 8 for v in layer.phase_exponents_mod_8):
            self.applied_diagonal_layers += 1

        old_mapping = tuple(self.logical_to_site)
        new_mapping = [0] * self.qubit_count
        # permutation[q] is the new logical label carrying the old logical wire q.
        for old_label, new_label in enumerate(layer.permutation):
            new_mapping[int(new_label)] = old_mapping[old_label]
        self.logical_to_site = new_mapping
        if tuple(layer.permutation) != tuple(range(self.qubit_count)):
            self.applied_permutations += 1
        self.applied_layers += 1
        self.peak_bond = max(self.peak_bond, self.state.max_bond)
        if self.state.max_bond != self.initial_peak_bond:
            raise RuntimeError("code-compiled diagonal/permutation layer changed the MPS bond dimension")

    def logical_statevector(self, *, maximum_qubits: int = 20) -> np.ndarray:
        site_state = self.state.to_statevector(maximum_qubits=maximum_qubits)
        tensor = site_state.reshape((2,) * self.qubit_count)
        logical_tensor = np.transpose(tensor, axes=tuple(self.logical_to_site))
        return logical_tensor.reshape(-1)

    def norm_gap(self) -> float:
        return abs(self.state.norm_squared() - 1.0)


def ghz_encoder_mps(qubit_count: int) -> MatrixProductState:
    n = int(qubit_count)
    if n < 2:
        raise ValueError("GHZ encoder fixture requires at least two qubits")
    state = MatrixProductState.product_state([0] * n)
    state.apply_one_site_gate(0, _H)
    for left in range(n - 1):
        state.apply_adjacent_two_site_gate(left, _CNOT, max_bond=2, discarded_weight_budget=0.0)
    state.normalize()
    return state


def _dense_apply_layer(state: np.ndarray, layer: CompiledLayer, qubit_count: int) -> np.ndarray:
    tensor = np.asarray(state, dtype=np.complex128).reshape((2,) * qubit_count)
    for logical_qubit, exponent in enumerate(layer.phase_exponents_mod_8):
        k = int(exponent) % 8
        if k:
            phase = np.exp(1.0j * np.pi * k / 4.0)
            slicer = [slice(None)] * qubit_count
            slicer[logical_qubit] = 1
            tensor[tuple(slicer)] *= phase
    inverse = np.empty(qubit_count, dtype=int)
    for old_label, new_label in enumerate(layer.permutation):
        inverse[int(new_label)] = old_label
    tensor = np.transpose(tensor, axes=tuple(int(v) for v in inverse))
    return tensor.reshape(-1)


def deterministic_compiled_layers(qubit_count: int, depth: int, *, seed: int) -> tuple[CompiledLayer, ...]:
    rng = np.random.default_rng(int(seed))
    layers: list[CompiledLayer] = []
    n = int(qubit_count)
    for step in range(int(depth)):
        phases = tuple(int(v) for v in rng.integers(0, 8, size=n))
        if step % 3 == 0:
            shift = 1 + (step % max(1, n - 1))
            permutation = tuple((q + shift) % n for q in range(n))
        elif step % 3 == 1:
            permutation = tuple(reversed(range(n)))
        else:
            permutation = tuple(range(n))
        layers.append(CompiledLayer(phases, permutation))
    return tuple(layers)


def qualify_code_compiled_tensor_network() -> CodeCompiledTNCertificate:
    compilation = CodeCompilationCertificate.issue(
        compiler_id="QPDTR-BOUNDED-CODE-COMPILED-SCHEDULE",
        code_family="PREVALIDATED_DIAGONAL_PERMUTATION_FIXTURE",
        encoder_digest=hashlib.sha256(b"GHZ-MPS-ENCODER-v1").hexdigest(),
        logical_gate_library=("nonlocal_Clifford_via_automorphism", "controlled_phase_hierarchy"),
        verified=True,
    )

    small_n = 10
    small_layers = deterministic_compiled_layers(small_n, 96, seed=260708396)
    small_mps = ghz_encoder_mps(small_n)
    runtime = PermutationTrackedMPS(small_mps, compilation)
    dense = small_mps.to_statevector(maximum_qubits=small_n)
    for layer in small_layers:
        runtime.apply_layer(layer)
        dense = _dense_apply_layer(dense, layer, small_n)
    mps_vector = runtime.logical_statevector(maximum_qubits=small_n)
    phase = np.vdot(dense, mps_vector)
    if abs(phase) > 0.0:
        mps_vector = mps_vector * np.exp(-1.0j * np.angle(phase))
    exact_gap = float(np.linalg.norm(mps_vector - dense))

    large_n = 256
    large_layers = deterministic_compiled_layers(large_n, 512, seed=260708397)
    large_runtime = PermutationTrackedMPS(ghz_encoder_mps(large_n), compilation)
    for layer in large_layers:
        large_runtime.apply_layer(layer)

    passed = bool(
        exact_gap < 1e-11
        and runtime.peak_bond == runtime.initial_peak_bond == 2
        and large_runtime.peak_bond == large_runtime.initial_peak_bond == 2
        and large_runtime.norm_gap() < 1e-10
        and sorted(large_runtime.logical_to_site) == list(range(large_n))
    )
    semantic = {
        "schema": "qpdtr-code-compiled-tensor-network/v1",
        "status": "PASS_BOUNDED_CODE_COMPILED_TN_OWNER" if passed else "FAIL_BOUNDED_CODE_COMPILED_TN_OWNER",
        "exact_reference_gap": exact_gap,
        "small_qubit_count": small_n,
        "small_depth": len(small_layers),
        "small_peak_bond": runtime.peak_bond,
        "large_qubit_count": large_n,
        "large_depth": len(large_layers),
        "large_peak_bond": large_runtime.peak_bond,
        "encoder_peak_bond": large_runtime.initial_peak_bond,
        "permutation_layers": large_runtime.applied_permutations,
        "diagonal_layers": large_runtime.applied_diagonal_layers,
        "statevector_materialized_large": False,
        "compilation_certificate_digest": compilation.digest,
        "claim_boundary": (
            "The owner is exact for an already verified physical schedule containing only onsite "
            "Z_8 diagonal gates and classical wire permutations. It does not discover CSS encoders, "
            "prove code automorphisms, or admit arbitrary logical circuits."
        ),
    }
    return CodeCompiledTNCertificate(**semantic, digest=_digest(semantic))
