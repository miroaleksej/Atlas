from __future__ import annotations

from dataclasses import asdict, dataclass
from math import acos, cos, pi, sqrt
from typing import Iterable

import mpmath as mp
import numpy as np
import sympy as sp
from sympy.physics.wigner import wigner_6j


def _j(twice: int) -> sp.Rational:
    if twice < 0:
        raise ValueError("Spin must be non-negative")
    return sp.Rational(int(twice), 2)


def _triangle_admissible(a2: int, b2: int, c2: int) -> bool:
    return (a2 + b2 + c2) % 2 == 0 and abs(a2 - b2) <= c2 <= a2 + b2


def admissible_6j(spins2: tuple[int, int, int, int, int, int]) -> bool:
    a, b, c, d, e, f = spins2
    return all(_triangle_admissible(*triad) for triad in ((a, b, c), (a, e, f), (d, b, f), (d, e, c)))


def wigner_6j_exact(spins2: tuple[int, int, int, int, int, int]) -> sp.Expr:
    if not admissible_6j(spins2):
        return sp.Integer(0)
    return sp.simplify(wigner_6j(*(_j(v) for v in spins2)))


def _delta_mp(a2: int, b2: int, c2: int) -> mp.mpf:
    x = (a2 + b2 - c2) // 2
    y = (a2 - b2 + c2) // 2
    z = (-a2 + b2 + c2) // 2
    w = (a2 + b2 + c2) // 2 + 1
    return mp.sqrt(mp.factorial(x) * mp.factorial(y) * mp.factorial(z) / mp.factorial(w))


def wigner_6j_racah(spins2: tuple[int, int, int, int, int, int], dps: int = 80) -> mp.mpf:
    if not admissible_6j(spins2):
        return mp.mpf("0")
    mp.mp.dps = dps
    a, b, c, d, e, f = spins2
    aa = [(a + b + c) // 2, (a + e + f) // 2, (d + b + f) // 2, (d + e + c) // 2]
    bb = [(a + b + d + e) // 2, (a + c + d + f) // 2, (b + c + e + f) // 2]
    total = mp.mpf("0")
    for z in range(max(aa), min(bb) + 1):
        denom = mp.mpf("1")
        for x in aa:
            denom *= mp.factorial(z - x)
        for x in bb:
            denom *= mp.factorial(x - z)
        total += (-1) ** z * mp.factorial(z + 1) / denom
    return (
        _delta_mp(a, b, c)
        * _delta_mp(a, e, f)
        * _delta_mp(d, b, f)
        * _delta_mp(d, e, c)
        * total
    )


@dataclass(frozen=True, slots=True)
class OrthogonalityCertificate:
    cases: int
    exact_pass: bool
    max_absolute_residual: float

    def to_dict(self) -> dict:
        return asdict(self)


def orthogonality_certificate(j2: int = 4) -> OrthogonalityCertificate:
    allowed = tuple(range(0, 2 * j2 + 1, 2))
    residuals: list[float] = []
    cases = 0
    for p2 in allowed:
        for q2 in allowed:
            lhs = sp.Integer(0)
            for x2 in allowed:
                lhs += (x2 + 1) * wigner_6j_exact((j2, j2, x2, j2, j2, p2)) * wigner_6j_exact((j2, j2, x2, j2, j2, q2))
            rhs = sp.Rational(1, p2 + 1) if p2 == q2 else sp.Integer(0)
            residual = sp.simplify(lhs - rhs)
            residuals.append(abs(float(sp.N(residual, 50))))
            cases += 1
    maximum = max(residuals, default=0.0)
    return OrthogonalityCertificate(cases, maximum == 0.0, maximum)


@dataclass(frozen=True, slots=True)
class AsymptoticCertificate:
    spin: int
    exact_value: float
    asymptotic_value: float
    absolute_error: float
    relative_error: float

    def to_dict(self) -> dict:
        return asdict(self)


def equilateral_asymptotic(spin: int = 50) -> AsymptoticCertificate:
    if spin < 1:
        raise ValueError("Positive integer spin required")
    exact = float(sp.N(wigner_6j(spin, spin, spin, spin, spin, spin), 60))
    length = spin + 0.5
    volume = length**3 / (6.0 * sqrt(2.0))
    exterior_dihedral = acos(-1.0 / 3.0)
    asymptotic = cos(6.0 * length * exterior_dihedral + pi / 4.0) / sqrt(12.0 * pi * volume)
    absolute = abs(exact - asymptotic)
    relative = absolute / abs(exact) if exact else float("inf")
    return AsymptoticCertificate(spin, exact, asymptotic, absolute, relative)


@dataclass(frozen=True, slots=True)
class CrossBackendCertificate:
    cases: int
    max_absolute_disagreement: float

    def to_dict(self) -> dict:
        return asdict(self)


def cross_backend_certificate(cases: Iterable[tuple[int, int, int, int, int, int]]) -> CrossBackendCertificate:
    mp.mp.dps = 80
    disagreements: list[float] = []
    count = 0
    for spins in cases:
        exact = mp.mpf(str(sp.N(wigner_6j_exact(spins), 80)))
        racah = wigner_6j_racah(spins, dps=80)
        disagreements.append(float(abs(exact - racah)))
        count += 1
    return CrossBackendCertificate(count, max(disagreements, default=0.0))


def recoupling_amplitude_matrix(j2: int = 6, damping: float = 0.06) -> tuple[np.ndarray, tuple[int, ...]]:
    allowed = tuple(range(0, 2 * j2 + 1, 2))
    matrix = np.zeros((len(allowed), len(allowed)), dtype=float)
    j = j2 / 2.0
    for ix, x2 in enumerate(allowed):
        x = x2 / 2.0
        for ip, p2 in enumerate(allowed):
            p = p2 / 2.0
            sixj = float(sp.N(wigner_6j_exact((j2, j2, x2, j2, j2, p2)), 50))
            weight = np.exp(-damping * (x * (x + 1.0) + p * (p + 1.0)))
            matrix[ix, ip] = sqrt((x2 + 1) * (p2 + 1)) * sixj * weight
    return matrix, allowed
