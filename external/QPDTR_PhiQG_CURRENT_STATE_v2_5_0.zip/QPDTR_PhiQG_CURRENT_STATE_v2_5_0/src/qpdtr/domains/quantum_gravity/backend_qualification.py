"""Real backend qualification for the current host.

Unavailable CUDA/MPI backends are reported as blocked; they are never emulated.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import platform
import time
from typing import Any

import numpy as np
from scipy.linalg import expm
from scipy.sparse import csc_array
from scipy.sparse.linalg import expm_multiply


@dataclass(frozen=True, slots=True)
class BackendResult:
    backend: str
    available: bool
    executed: bool
    equality_gap: float | None
    elapsed_seconds: float | None
    device_or_world: str
    status: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class BackendQualification:
    cpu: BackendResult
    cuda: BackendResult
    mpi: BackendResult
    status: str
    claim_scope: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "cpu": self.cpu.to_dict(),
            "cuda": self.cuda.to_dict(),
            "mpi": self.mpi.to_dict(),
            "status": self.status,
            "claim_scope": self.claim_scope,
        }


def qualify_real_backends(seed: int = 11) -> BackendQualification:
    rng = np.random.default_rng(seed)
    a = rng.normal(size=(32, 32)) + 1j * rng.normal(size=(32, 32))
    h = 0.5 * (a + a.conj().T)
    v = rng.normal(size=32) + 1j * rng.normal(size=32)
    v /= np.linalg.norm(v)
    started = time.perf_counter()
    cpu_value = expm_multiply(csc_array(-1j * 0.07 * h), v)
    cpu_reference = expm(-1j * 0.07 * h) @ v
    cpu_elapsed = time.perf_counter() - started
    cpu_gap = float(np.linalg.norm(cpu_value - cpu_reference))
    cpu = BackendResult(
        "CPU_NUMPY_SCIPY", True, True, cpu_gap, cpu_elapsed,
        f"{platform.machine()} / {platform.processor() or 'processor-unreported'}",
        "PASS" if cpu_gap < 1e-11 else "FAIL_NUMERICAL_EQUALITY",
        "real host execution",
    )

    try:
        import cupy as cp  # type: ignore
        count = int(cp.cuda.runtime.getDeviceCount())
        if count < 1:
            raise RuntimeError("no CUDA device")
        device = cp.cuda.Device(0)
        with device:
            started = time.perf_counter()
            ch = cp.asarray(h)
            cv = cp.asarray(v)
            # Hermitian eigendecomposition is a direct device-level equality control.
            w, u = cp.linalg.eigh(ch)
            cuda_value = u @ (cp.exp(-1j * 0.07 * w) * (u.conj().T @ cv))
            cp.cuda.Stream.null.synchronize()
            elapsed = time.perf_counter() - started
            gap = float(np.linalg.norm(cp.asnumpy(cuda_value) - cpu_reference))
            props = cp.cuda.runtime.getDeviceProperties(0)
            name = props.get("name", b"CUDA device")
            if isinstance(name, bytes):
                name = name.decode(errors="replace")
        cuda = BackendResult("CUDA_CUPY", True, True, gap, elapsed, str(name), "PASS" if gap < 1e-10 else "FAIL_NUMERICAL_EQUALITY", "real CUDA device execution")
    except Exception as error:
        cuda = BackendResult("CUDA_CUPY", False, False, None, None, "NONE", "BLOCKED_BACKEND_UNAVAILABLE", str(error))

    try:
        from mpi4py import MPI  # type: ignore
        comm = MPI.COMM_WORLD
        size = int(comm.Get_size())
        if size <= 1:
            raise RuntimeError("MPI world size is one; multi-rank qualification requires mpiexec -n >=2")
        rank = int(comm.Get_rank())
        local = np.array([rank + 1.0], dtype=float)
        started = time.perf_counter()
        total = np.zeros_like(local)
        comm.Allreduce(local, total)
        elapsed = time.perf_counter() - started
        expected = size * (size + 1) / 2
        gap = abs(float(total[0]) - expected)
        mpi = BackendResult("MPI4PY_ALLREDUCE", True, True, gap, elapsed, f"world_size={size}", "PASS" if gap == 0.0 else "FAIL_NUMERICAL_EQUALITY", "real multi-rank MPI execution")
    except Exception as error:
        mpi = BackendResult("MPI4PY_ALLREDUCE", False, False, None, None, "world_size<=1 or unavailable", "BLOCKED_BACKEND_UNAVAILABLE", str(error))

    status = "PASS_CPU_EXTERNAL_ACCELERATORS_BLOCKED"
    if cpu.status != "PASS":
        status = "FAIL_CPU"
    elif cuda.status == "PASS" and mpi.status == "PASS":
        status = "PASS_CPU_CUDA_MPI"
    elif cuda.status == "PASS":
        status = "PASS_CPU_CUDA_MPI_BLOCKED"
    elif mpi.status == "PASS":
        status = "PASS_CPU_MPI_CUDA_BLOCKED"
    return BackendQualification(
        cpu, cuda, mpi, status,
        "only actually executed backends are qualified; unavailable backends remain blocked",
    )
