"""Current interacting spinful SIAM Cayley-TTN owner.

The active owner combines one exact bath-geometry mapping with an interacting
fermionic tensor-network runtime.  It certifies finite star/chain/tree equivalence,
projected imaginary-time TTN ground-state convergence, second-order real-time TTN
TEBD, interacting impurity Green functions and spectral sum rules, and a structured
statevector-free holdout.  The quadratic mapping remains a required subroutine; it
is not an alternative active impurity solver.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Sequence
from functools import lru_cache
import hashlib
import itertools
import json
import math

import networkx as nx
import numpy as np
from scipy.linalg import eigh, expm
from scipy.sparse import csr_matrix, dok_matrix
from scipy.sparse.linalg import expm_multiply

from .adaptive_ttn import PersistentAdaptiveTTN


def _digest(payload: Any) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), default=lambda x: x.item() if isinstance(x, np.generic) else x).encode("utf-8")
    ).hexdigest()


def _phase_fixed(vector: np.ndarray, tolerance: float = 1e-14) -> np.ndarray:
    out = np.asarray(vector, dtype=complex).copy()
    nz = np.flatnonzero(np.abs(out) > tolerance)
    if nz.size:
        phase = out[nz[0]] / abs(out[nz[0]])
        out /= phase
    return out


def _orthonormal_frame(first: np.ndarray, tolerance: float = 1e-13) -> np.ndarray:
    """Deterministic modified Gram-Schmidt frame with ``first`` as column zero."""
    vector = np.asarray(first, dtype=complex).reshape(-1)
    norm = float(np.linalg.norm(vector))
    if not np.isfinite(norm) or norm <= tolerance:
        raise ValueError("Frame root must be finite and nonzero")
    vector = _phase_fixed(vector / norm)
    n = vector.size
    columns: list[np.ndarray] = [vector]
    for index in range(n):
        candidate = np.zeros(n, dtype=complex)
        candidate[index] = 1.0
        for column in columns:
            candidate -= column * np.vdot(column, candidate)
        length = float(np.linalg.norm(candidate))
        if length > tolerance:
            candidate = _phase_fixed(candidate / length)
            # one reorthogonalization pass
            for column in columns:
                candidate -= column * np.vdot(column, candidate)
            candidate /= np.linalg.norm(candidate)
            columns.append(_phase_fixed(candidate))
        if len(columns) == n:
            break
    if len(columns) != n:
        raise ArithmeticError("Failed to complete deterministic orthonormal frame")
    return np.column_stack(columns)


def _balanced_partition(weights: np.ndarray) -> tuple[tuple[int, ...], tuple[int, ...], float]:
    """Deterministic near-balanced two-way partition of nonnegative weights."""
    values = np.asarray(weights, dtype=float).reshape(-1)
    if values.size < 2:
        raise ValueError("A binary partition requires at least two states")
    if np.any(values < 0.0) or not np.all(np.isfinite(values)):
        raise ValueError("Partition weights must be finite and nonnegative")
    order = sorted(range(values.size), key=lambda i: (-values[i], i))
    groups: list[list[int]] = [[], []]
    sums = [0.0, 0.0]
    for index in order:
        target = 0 if sums[0] <= sums[1] else 1
        groups[target].append(index)
        sums[target] += float(values[index])
    if not groups[0] or not groups[1]:
        donor = 0 if len(groups[0]) > 1 else 1
        receiver = 1 - donor
        moved = min(groups[donor], key=lambda i: (values[i], i))
        groups[donor].remove(moved)
        groups[receiver].append(moved)
        sums[donor] -= float(values[moved])
        sums[receiver] += float(values[moved])

    # Deterministic single-item local improvement.
    improved = True
    while improved:
        improved = False
        current = abs(sums[0] - sums[1])
        best: tuple[float, int, int] | None = None
        for source in (0, 1):
            target = 1 - source
            if len(groups[source]) <= 1:
                continue
            for index in groups[source]:
                new_s = sums[source] - values[index]
                new_t = sums[target] + values[index]
                gap = abs(new_s - new_t)
                candidate = (float(gap), source, index)
                if gap + 1e-15 < current and (best is None or candidate < best):
                    best = candidate
        if best is not None:
            _, source, index = best
            target = 1 - source
            groups[source].remove(index)
            groups[target].append(index)
            sums[source] -= float(values[index])
            sums[target] += float(values[index])
            improved = True
    total = sums[0] + sums[1]
    relative_gap = 0.0 if total == 0.0 else abs(sums[0] - sums[1]) / total
    return tuple(sorted(groups[0])), tuple(sorted(groups[1])), float(relative_gap)


@dataclass(frozen=True, slots=True)
class CayleyNode:
    index: int
    parent: int | None
    depth: int
    subspace_dimension: int
    onsite_energy: float
    parent_coupling_real: float
    parent_coupling_imag: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class CayleyMappingCertificate:
    bath_mode_count: int
    branching_factor: int
    tree_depth: int
    maximum_degree: int
    unitary_gap: float
    bath_reconstruction_gap: float
    tree_nonedge_residual: float
    spectrum_gap: float
    star_chain_hybridization_gap: float
    star_tree_hybridization_gap: float
    moment_gap: float
    maximum_partition_relative_weight_gap: float
    node_count: int
    edge_count: int
    status: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_EXACT_FINITE_CAYLEY_BATH_MAPPING"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"passed": self.passed}


@dataclass(frozen=True, slots=True)
class BathDiscretizationCertificate:
    coarse_order: int
    fine_order: int
    coarse_continuum_hybridization_gap: float
    fine_continuum_hybridization_gap: float
    refinement_gap: float
    status: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_GAUSS_LEGENDRE_BATH_REFINEMENT_CONTROL"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"passed": self.passed}




@dataclass(frozen=True, slots=True)
class SIAMRepresentationCertificate:
    bath_mode_count_per_spin: int
    spin_orbital_count: int
    sector_dimension: int
    interaction_u: float
    star_tree_spectrum_gap: float
    star_chain_spectrum_gap: float
    star_tree_ground_energy_gap: float
    star_chain_ground_energy_gap: float
    impurity_occupation_gap: float
    double_occupation_gap: float
    status: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_EXACT_INTERACTING_SIAM_STAR_CHAIN_TREE_EQUIVALENCE"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"passed": self.passed}


@dataclass(frozen=True, slots=True)
class SIAMGroundStateCertificate:
    bath_mode_count_per_spin: int
    spin_orbital_count: int
    interaction_u: float
    imaginary_time_beta: float
    imaginary_time_step: float
    imaginary_time_steps: int
    initialization: str
    exact_ground_energy: float
    ttn_ground_energy: float
    energy_gap: float
    ground_state_fidelity: float
    particle_sector_leakage: float
    maximum_bond: int
    used_maximum_bond: int
    discarded_weight: float
    bond_dimension_sequence: tuple[int, ...]
    bond_energy_gap_sequence: tuple[float, ...]
    bond_fidelity_sequence: tuple[float, ...]
    bond_discarded_weight_sequence: tuple[float, ...]
    status: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_IMAGINARY_TIME_INTERACTING_CAYLEY_TTN_GROUND_STATE"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"passed": self.passed}


@dataclass(frozen=True, slots=True)
class SIAMRealTimeCertificate:
    bath_mode_count_per_spin: int
    spin_orbital_count: int
    final_time: float
    coarse_time_step: float
    fine_time_step: float
    coarse_state_gap: float
    fine_state_gap: float
    step_doubling_gap: float
    fine_state_fidelity: float
    maximum_impurity_occupation_gap: float
    particle_sector_leakage: float
    norm_gap: float
    maximum_bond: int
    used_maximum_bond: int
    discarded_weight: float
    status: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_SECOND_ORDER_INTERACTING_CAYLEY_TTN_TEBD"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"passed": self.passed}


@dataclass(frozen=True, slots=True)
class SIAMGreenFunctionCertificate:
    bath_mode_count_per_spin: int
    time_point_count: int
    maximum_star_tree_green_gap: float
    maximum_star_chain_green_gap: float
    equal_time_anticommutator_gap: float
    spectral_zeroth_moment: float
    spectral_zeroth_moment_gap: float
    spectral_first_moment: float
    spectral_first_moment_reference: float
    spectral_first_moment_gap: float
    status: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_INTERACTING_IMPURITY_GREEN_FUNCTION_AND_SUM_RULES"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"passed": self.passed}


@dataclass(frozen=True, slots=True)
class SIAMScalableHoldoutCertificate:
    bath_mode_count_per_spin: int
    active_bath_modes_per_spin: int
    spectator_bath_modes_per_spin: int
    spin_orbital_count: int
    interaction_u: float
    imaginary_time_steps: int
    real_time_steps: int
    maximum_bond: int
    used_maximum_bond: int
    discarded_weight: float
    particle_number_gap: float
    maximum_spectator_occupation: float
    norm_gap: float
    impurity_up_occupation: float
    impurity_down_occupation: float
    impurity_double_occupation: float
    statevector_materialized: bool
    status: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_STRUCTURED_26_QUBIT_INTERACTING_CAYLEY_TTN_HOLDOUT"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"passed": self.passed}


@dataclass(frozen=True, slots=True)
class CayleyImpurityQualification:
    mapping: CayleyMappingCertificate
    representation_equivalence: SIAMRepresentationCertificate
    ground_state: SIAMGroundStateCertificate
    real_time_tebd: SIAMRealTimeCertificate
    green_function: SIAMGreenFunctionCertificate
    scalable_holdout: SIAMScalableHoldoutCertificate
    bath_discretization: BathDiscretizationCertificate
    unqualified_regions: tuple[str, ...]
    status: str
    digest: str

    @property
    def passed(self) -> bool:
        return self.status == "PASS_BOUNDED_INTERACTING_SPINFUL_SIAM_CAYLEY_TTN_RUNTIME"

    def to_dict(self) -> dict[str, Any]:
        return {
            "mapping": self.mapping.to_dict(),
            "representation_equivalence": self.representation_equivalence.to_dict(),
            "ground_state": self.ground_state.to_dict(),
            "real_time_tebd": self.real_time_tebd.to_dict(),
            "green_function": self.green_function.to_dict(),
            "scalable_holdout": self.scalable_holdout.to_dict(),
            "bath_discretization": self.bath_discretization.to_dict(),
            "unqualified_regions": list(self.unqualified_regions),
            "status": self.status,
            "digest": self.digest,
            "passed": self.passed,
        }


class CayleyBathMapping:
    """Exact recursive binary Cayley representation of a finite quadratic bath."""

    def __init__(self, bath_hamiltonian: np.ndarray, hybridizations: Sequence[complex]):
        h = np.asarray(bath_hamiltonian, dtype=complex)
        v = np.asarray(hybridizations, dtype=complex).reshape(-1)
        if h.ndim != 2 or h.shape[0] != h.shape[1] or h.shape[0] != v.size:
            raise ValueError("Bath Hamiltonian and hybridization dimensions disagree")
        if h.shape[0] < 2:
            raise ValueError("Cayley mapping requires at least two bath modes")
        if not np.allclose(h, h.conj().T, atol=1e-12, rtol=0.0):
            raise ValueError("Bath Hamiltonian must be Hermitian")
        coupling_norm = float(np.linalg.norm(v))
        if not np.isfinite(coupling_norm) or coupling_norm <= 0.0:
            raise ValueError("At least one impurity-bath hybridization must be nonzero")
        self.bath_hamiltonian = h
        self.hybridizations = v
        self.coupling_norm = coupling_norm
        self._nodes: list[CayleyNode] = []
        self._parent_pairs: list[tuple[int, int]] = []
        self._partition_gaps: list[float] = []
        original_basis = np.eye(v.size, dtype=complex)
        root_coordinates = np.conj(v) / coupling_norm
        basis, _ = self._recurse(original_basis, root_coordinates, parent=None, depth=0)
        self.unitary = basis
        self.tree_hamiltonian = basis.conj().T @ h @ basis

    @property
    def nodes(self) -> tuple[CayleyNode, ...]:
        return tuple(self._nodes)

    @property
    def edges(self) -> tuple[tuple[int, int], ...]:
        return tuple(self._parent_pairs)

    def _recurse(
        self,
        subspace_basis: np.ndarray,
        root_coordinates: np.ndarray,
        *,
        parent: int | None,
        depth: int,
    ) -> tuple[np.ndarray, int]:
        m = subspace_basis.shape[1]
        frame = _orthonormal_frame(root_coordinates)
        local_basis = subspace_basis @ frame
        local_h = local_basis.conj().T @ self.bath_hamiltonian @ local_basis
        node_index = len(self._nodes)
        coupling = 0.0 + 0.0j
        self._nodes.append(
            CayleyNode(
                index=node_index,
                parent=parent,
                depth=depth,
                subspace_dimension=m,
                onsite_energy=float(np.real(local_h[0, 0])),
                parent_coupling_real=0.0,
                parent_coupling_imag=0.0,
            )
        )
        if parent is not None:
            self._parent_pairs.append((parent, node_index))
        if m == 1:
            return local_basis[:, :1], node_index

        eigenvalues, eigenvectors = eigh(local_h[1:, 1:])
        eigenbasis = local_basis[:, 1:] @ eigenvectors
        alpha = local_h[0, 1:] @ eigenvectors
        weights = np.square(np.abs(alpha))
        if weights.size == 1:
            partitions = ((0,),)
            relative_gap = 0.0
        else:
            left_indices, right_indices, relative_gap = _balanced_partition(weights)
            partitions = (left_indices, right_indices)
        self._partition_gaps.append(relative_gap)
        child_bases: list[np.ndarray] = []
        for indices in partitions:
            idx = np.asarray(indices, dtype=int)
            branch_basis = eigenbasis[:, idx]
            branch_alpha = alpha[idx]
            branch_norm = float(np.linalg.norm(branch_alpha))
            if branch_norm > 1e-14:
                branch_root_coordinates = np.conj(branch_alpha) / branch_norm
            else:
                branch_root_coordinates = np.zeros(idx.size, dtype=complex)
                branch_root_coordinates[0] = 1.0
            child_basis, child_index = self._recurse(
                branch_basis,
                branch_root_coordinates,
                parent=node_index,
                depth=depth + 1,
            )
            child_bases.append(child_basis)
            # Replace immutable node with the exact parent coupling now known.
            child = self._nodes[child_index]
            self._nodes[child_index] = CayleyNode(
                index=child.index,
                parent=child.parent,
                depth=child.depth,
                subspace_dimension=child.subspace_dimension,
                onsite_energy=child.onsite_energy,
                parent_coupling_real=float(branch_norm),
                parent_coupling_imag=0.0,
            )
        return np.column_stack([local_basis[:, 0], *child_bases]), node_index

    def chain_basis(self) -> np.ndarray:
        """Independent full-reorthogonalized Lanczos basis rooted at the impurity channel."""
        n = self.bath_hamiltonian.shape[0]
        root = np.conj(self.hybridizations) / self.coupling_norm
        columns: list[np.ndarray] = [_phase_fixed(root)]
        beta_previous = 0.0
        previous = np.zeros(n, dtype=complex)
        for _ in range(1, n):
            current = columns[-1]
            alpha = np.vdot(current, self.bath_hamiltonian @ current)
            candidate = self.bath_hamiltonian @ current - alpha * current - beta_previous * previous
            for column in columns:
                candidate -= column * np.vdot(column, candidate)
            beta = float(np.linalg.norm(candidate))
            if beta <= 1e-13:
                # Deterministically complete the basis if the Krylov space closes early.
                for index in range(n):
                    candidate = np.zeros(n, dtype=complex)
                    candidate[index] = 1.0
                    for column in columns:
                        candidate -= column * np.vdot(column, candidate)
                    beta = float(np.linalg.norm(candidate))
                    if beta > 1e-13:
                        break
            if beta <= 1e-13:
                raise ArithmeticError("Lanczos basis completion failed")
            previous = current
            columns.append(_phase_fixed(candidate / beta))
            beta_previous = beta
        return np.column_stack(columns)

    def hybridization(self, z: complex, representation: str = "star") -> complex:
        if representation == "star":
            inverse = np.linalg.solve(z * np.eye(self.bath_hamiltonian.shape[0]) - self.bath_hamiltonian, self.hybridizations)
            return complex(np.vdot(self.hybridizations, inverse))
        if representation == "tree":
            matrix = self.tree_hamiltonian
        elif representation == "chain":
            q = self.chain_basis()
            matrix = q.conj().T @ self.bath_hamiltonian @ q
        else:
            raise ValueError("Unknown bath representation")
        root = np.zeros(matrix.shape[0], dtype=complex)
        root[0] = 1.0
        inverse = np.linalg.solve(z * np.eye(matrix.shape[0]) - matrix, root)
        return complex((self.coupling_norm**2) * inverse[0])

    def certificate(self) -> CayleyMappingCertificate:
        n = self.bath_hamiltonian.shape[0]
        identity = np.eye(n, dtype=complex)
        unitary_gap = float(np.linalg.norm(self.unitary.conj().T @ self.unitary - identity, ord=2))
        reconstruction = self.unitary @ self.tree_hamiltonian @ self.unitary.conj().T
        reconstruction_gap = float(np.linalg.norm(reconstruction - self.bath_hamiltonian, ord=2))
        allowed = {(i, i) for i in range(n)}
        allowed.update(self.edges)
        allowed.update((b, a) for a, b in self.edges)
        nonedge = [abs(self.tree_hamiltonian[i, j]) for i in range(n) for j in range(n) if (i, j) not in allowed]
        nonedge_residual = float(max(nonedge, default=0.0))
        spectrum_gap = float(np.max(np.abs(np.sort(eigh(self.bath_hamiltonian, eigvals_only=True)) - np.sort(eigh(self.tree_hamiltonian, eigvals_only=True)))))
        z_grid = [complex(x, eta) for eta in (0.15, 0.4, 1.0) for x in np.linspace(-1.8, 1.8, 9)]
        star_tree = max(abs(self.hybridization(z, "star") - self.hybridization(z, "tree")) for z in z_grid)
        star_chain = max(abs(self.hybridization(z, "star") - self.hybridization(z, "chain")) for z in z_grid)
        root = np.conj(self.hybridizations) / self.coupling_norm
        moment_gap = 0.0
        for power in range(7):
            star_moment = self.coupling_norm**2 * np.vdot(root, np.linalg.matrix_power(self.bath_hamiltonian, power) @ root)
            tree_root = np.zeros(n, dtype=complex)
            tree_root[0] = 1.0
            tree_moment = self.coupling_norm**2 * np.vdot(tree_root, np.linalg.matrix_power(self.tree_hamiltonian, power) @ tree_root)
            moment_gap = max(moment_gap, abs(star_moment - tree_moment))
        degrees = [0] * n
        for parent, child in self.edges:
            degrees[parent] += 1
            degrees[child] += 1
        status = (
            "PASS_EXACT_FINITE_CAYLEY_BATH_MAPPING"
            if max(unitary_gap, reconstruction_gap, nonedge_residual, spectrum_gap, star_tree, star_chain, moment_gap) < 2e-10
            else "FAIL_CAYLEY_BATH_MAPPING"
        )
        payload = {
            "bath_mode_count": n,
            "branching_factor": 2,
            "tree_depth": max(node.depth for node in self.nodes),
            "maximum_degree": max(degrees),
            "unitary_gap": unitary_gap,
            "bath_reconstruction_gap": reconstruction_gap,
            "tree_nonedge_residual": nonedge_residual,
            "spectrum_gap": spectrum_gap,
            "star_chain_hybridization_gap": float(star_chain),
            "star_tree_hybridization_gap": float(star_tree),
            "moment_gap": float(moment_gap),
            "maximum_partition_relative_weight_gap": max(self._partition_gaps, default=0.0),
            "node_count": len(self.nodes),
            "edge_count": len(self.edges),
            "status": status,
        }
        return CayleyMappingCertificate(**payload, digest=_digest(payload))



@dataclass(slots=True)
class _SectorHamiltonian:
    matrix: csr_matrix
    basis: tuple[int, ...]
    index: dict[int, int]
    spin_orbital_count: int
    bath_mode_count_per_spin: int
    n_up: int
    n_down: int


def _mode_layout(n_bath: int) -> tuple[tuple[int, ...], tuple[int, ...]]:
    return (0, *range(2, 2 + n_bath)), (1, *range(2 + n_bath, 2 + 2 * n_bath))


def _sector_basis(n_bath: int, n_up: int, n_down: int) -> tuple[int, ...]:
    up_modes, down_modes = _mode_layout(n_bath)
    states: list[int] = []
    for occupied_up in itertools.combinations(up_modes, n_up):
        up_state = sum(1 << mode for mode in occupied_up)
        for occupied_down in itertools.combinations(down_modes, n_down):
            states.append(up_state + sum(1 << mode for mode in occupied_down))
    return tuple(states)


def _annihilate(state: int, mode: int) -> tuple[int, int] | None:
    if not ((state >> mode) & 1):
        return None
    sign = -1 if (state & ((1 << mode) - 1)).bit_count() % 2 else 1
    return state ^ (1 << mode), sign


def _create(state: int, mode: int) -> tuple[int, int] | None:
    if (state >> mode) & 1:
        return None
    sign = -1 if (state & ((1 << mode) - 1)).bit_count() % 2 else 1
    return state ^ (1 << mode), sign


def _apply_cdag_c(state: int, create_mode: int, annihilate_mode: int) -> tuple[int, int] | None:
    removed = _annihilate(state, annihilate_mode)
    if removed is None:
        return None
    created = _create(removed[0], create_mode)
    if created is None:
        return None
    return created[0], removed[1] * created[1]


def _build_siam_sector(
    bath_hamiltonian: np.ndarray,
    hybridizations: np.ndarray,
    *,
    impurity_energy: float,
    interaction_u: float,
    n_up: int,
    n_down: int,
) -> _SectorHamiltonian:
    bath_h = np.asarray(bath_hamiltonian, dtype=complex)
    coupling = np.asarray(hybridizations, dtype=complex).reshape(-1)
    n_bath = coupling.size
    if bath_h.shape != (n_bath, n_bath):
        raise ValueError("SIAM bath dimensions disagree")
    q = 2 + 2 * n_bath
    up_modes, down_modes = _mode_layout(n_bath)
    one_body = np.zeros((q, q), dtype=complex)
    one_body[0, 0] = impurity_energy
    one_body[1, 1] = impurity_energy
    one_body[np.ix_(up_modes[1:], up_modes[1:])] = bath_h
    one_body[np.ix_(down_modes[1:], down_modes[1:])] = bath_h
    one_body[0, up_modes[1:]] = coupling
    one_body[up_modes[1:], 0] = np.conj(coupling)
    one_body[1, down_modes[1:]] = coupling
    one_body[down_modes[1:], 1] = np.conj(coupling)
    basis = _sector_basis(n_bath, n_up, n_down)
    index = {state: position for position, state in enumerate(basis)}
    matrix = dok_matrix((len(basis), len(basis)), dtype=complex)
    for column, state in enumerate(basis):
        if ((state >> 0) & 1) and ((state >> 1) & 1):
            matrix[column, column] += interaction_u
        for i in range(q):
            for j in range(q):
                coefficient = one_body[i, j]
                if abs(coefficient) <= 1e-14:
                    continue
                result = _apply_cdag_c(state, i, j)
                if result is not None and result[0] in index:
                    matrix[index[result[0]], column] += coefficient * result[1]
    return _SectorHamiltonian(matrix.tocsr(), basis, index, q, n_bath, n_up, n_down)


def _ttn_index(state: int, qubit_count: int) -> int:
    return sum(((state >> mode) & 1) << (qubit_count - 1 - mode) for mode in range(qubit_count))


def _embed_sector(vector: np.ndarray, sector: _SectorHamiltonian) -> np.ndarray:
    full = np.zeros(1 << sector.spin_orbital_count, dtype=complex)
    full[[_ttn_index(state, sector.spin_orbital_count) for state in sector.basis]] = vector
    return full


def _extract_sector(vector: np.ndarray, sector: _SectorHamiltonian) -> tuple[np.ndarray, float]:
    indices = [_ttn_index(state, sector.spin_orbital_count) for state in sector.basis]
    projected = np.asarray(vector, dtype=complex)[indices]
    leakage = max(0.0, 1.0 - float(np.square(np.abs(projected)).sum()))
    norm = float(np.linalg.norm(projected))
    if norm <= 0.0:
        raise ArithmeticError("TTN state has zero weight in the target SIAM sector")
    return projected / norm, leakage


def _phase_aligned_gap(reference: np.ndarray, observed: np.ndarray) -> float:
    overlap = np.vdot(reference, observed)
    phase = 1.0 + 0.0j if abs(overlap) == 0.0 else overlap / abs(overlap)
    return float(np.linalg.norm(observed - phase * reference))


def _impurity_observables(vector: np.ndarray, sector: _SectorHamiltonian) -> tuple[float, float, float]:
    probabilities = np.square(np.abs(vector))
    n_up = sum(weight * ((state >> 0) & 1) for weight, state in zip(probabilities, sector.basis, strict=True))
    n_down = sum(weight * ((state >> 1) & 1) for weight, state in zip(probabilities, sector.basis, strict=True))
    double = sum(weight * ((state >> 0) & 1) * ((state >> 1) & 1) for weight, state in zip(probabilities, sector.basis, strict=True))
    return float(n_up), float(n_down), float(double)


def _small_siam_representations() -> tuple[CayleyBathMapping, dict[str, tuple[np.ndarray, np.ndarray]]]:
    energies = np.array([-1.2, 0.0, 1.2], dtype=float)
    couplings = np.array([0.28, 0.24, 0.28], dtype=complex)
    mapping = CayleyBathMapping(np.diag(energies), couplings)
    chain_basis = mapping.chain_basis()
    chain_h = chain_basis.conj().T @ np.diag(energies) @ chain_basis
    root_coupling = np.zeros(energies.size, dtype=complex)
    root_coupling[0] = mapping.coupling_norm
    return mapping, {
        "star": (np.diag(energies), couplings),
        "tree": (mapping.tree_hamiltonian, root_coupling),
        "chain": (chain_h, root_coupling),
    }


def _representation_certificate() -> SIAMRepresentationCertificate:
    mapping, representations = _small_siam_representations()
    interaction_u = 1.6
    impurity_energy = -interaction_u / 2.0
    spectra: dict[str, np.ndarray] = {}
    energies: dict[str, float] = {}
    observables: dict[str, tuple[float, float, float]] = {}
    dimension = 0
    for name, (bath_h, coupling) in representations.items():
        sector = _build_siam_sector(bath_h, coupling, impurity_energy=impurity_energy, interaction_u=interaction_u, n_up=2, n_down=2)
        values, vectors = eigh(sector.matrix.toarray())
        spectra[name] = values
        energies[name] = float(values[0])
        observables[name] = _impurity_observables(vectors[:, 0], sector)
        dimension = len(sector.basis)
    spectrum_tree = float(np.max(np.abs(spectra["star"] - spectra["tree"])))
    spectrum_chain = float(np.max(np.abs(spectra["star"] - spectra["chain"])))
    energy_tree = abs(energies["star"] - energies["tree"])
    energy_chain = abs(energies["star"] - energies["chain"])
    occupation_gap = max(
        abs(sum(observables["star"][:2]) - sum(observables["tree"][:2])),
        abs(sum(observables["star"][:2]) - sum(observables["chain"][:2])),
    )
    double_gap = max(
        abs(observables["star"][2] - observables["tree"][2]),
        abs(observables["star"][2] - observables["chain"][2]),
    )
    passed = max(spectrum_tree, spectrum_chain, energy_tree, energy_chain, occupation_gap, double_gap) < 2e-10
    payload = {
        "bath_mode_count_per_spin": mapping.bath_hamiltonian.shape[0],
        "spin_orbital_count": 2 + 2 * mapping.bath_hamiltonian.shape[0],
        "sector_dimension": dimension,
        "interaction_u": interaction_u,
        "star_tree_spectrum_gap": spectrum_tree,
        "star_chain_spectrum_gap": spectrum_chain,
        "star_tree_ground_energy_gap": energy_tree,
        "star_chain_ground_energy_gap": energy_chain,
        "impurity_occupation_gap": occupation_gap,
        "double_occupation_gap": double_gap,
        "status": "PASS_EXACT_INTERACTING_SIAM_STAR_CHAIN_TREE_EQUIVALENCE" if passed else "FAIL_INTERACTING_SIAM_REPRESENTATION_EQUIVALENCE",
    }
    return SIAMRepresentationCertificate(**payload, digest=_digest(payload))


_HADAMARD = np.array([[1.0, 1.0], [1.0, -1.0]], dtype=complex) / math.sqrt(2.0)
_PHASE = np.diag([1.0, 1.0j]).astype(complex)
_PHASE_DAGGER = _PHASE.conj().T
_NUMBER = np.diag([0.0, 1.0]).astype(complex)
_CNOT = np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1], [0, 0, 1, 0]], dtype=complex)


class _FermionicCayleyTTN:
    def __init__(self, state: PersistentAdaptiveTTN):
        self.state = state

    @classmethod
    def product_state(cls, bits: Sequence[int], graph: nx.Graph, *, max_bond: int, budget: float) -> "_FermionicCayleyTTN":
        return cls(PersistentAdaptiveTTN.product_state(bits, max_bond=max_bond, discarded_weight_budget=budget, interaction_graph=graph, maximum_refactor_qubits=14))

    @classmethod
    def from_statevector(cls, vector: np.ndarray, graph: nx.Graph, *, max_bond: int, budget: float) -> "_FermionicCayleyTTN":
        qubits = int(round(math.log2(np.asarray(vector).size)))
        return cls(PersistentAdaptiveTTN(vector, qubit_count=qubits, max_bond=max_bond, discarded_weight_budget=budget, interaction_graph=graph, maximum_refactor_qubits=14))

    def _pauli_string_exponential(self, operators: dict[int, str], alpha: complex) -> None:
        sites = sorted(operators)
        for site in sites:
            if operators[site] == "X":
                self.state.apply_one_site_gate(site, _HADAMARD)
            elif operators[site] == "Y":
                self.state.apply_one_site_gate(site, _HADAMARD @ _PHASE_DAGGER)
        target = sites[-1]
        for site in sites[:-1]:
            self.state.apply_two_site_gate(site, target, _CNOT, adapt=True)
        self.state.apply_one_site_gate(target, np.diag([np.exp(-alpha), np.exp(alpha)]))
        for site in reversed(sites[:-1]):
            self.state.apply_two_site_gate(site, target, _CNOT, adapt=True)
        for site in reversed(sites):
            if operators[site] == "X":
                self.state.apply_one_site_gate(site, _HADAMARD)
            elif operators[site] == "Y":
                self.state.apply_one_site_gate(site, _PHASE @ _HADAMARD)

    def _hopping(self, first: int, second: int, coefficient: complex, scale: complex) -> None:
        if abs(np.imag(coefficient)) > 2e-12:
            raise ValueError("Current Cayley SIAM TEBD requires a real phase-fixed hopping graph")
        if first > second:
            first, second = second, first
        parity = {site: "Z" for site in range(first + 1, second)}
        alpha = scale * float(np.real(coefficient)) / 2.0
        self._pauli_string_exponential({first: "X", **parity, second: "X"}, alpha)
        self._pauli_string_exponential({first: "Y", **parity, second: "Y"}, alpha)

    def strang_step(
        self,
        onsite: dict[int, float],
        hoppings: Sequence[tuple[int, int, complex]],
        interaction: tuple[int, int, float],
        step: float,
        *,
        imaginary_time: bool,
    ) -> None:
        scale = (step if imaginary_time else 1.0j * step) / 2.0
        terms: list[tuple[Any, ...]] = [("onsite", mode, energy) for mode, energy in sorted(onsite.items())]
        terms.append(("interaction", *interaction))
        terms.extend(("hopping", first, second, coefficient) for first, second, coefficient in hoppings)
        for sequence in (terms, list(reversed(terms))):
            for term in sequence:
                if term[0] == "onsite":
                    self.state.apply_one_site_gate(term[1], np.diag([1.0, np.exp(-scale * term[2])]))
                elif term[0] == "interaction":
                    self.state.apply_two_site_gate(term[1], term[2], np.diag([1.0, 1.0, 1.0, np.exp(-scale * term[3])]), adapt=True)
                else:
                    self._hopping(term[1], term[2], term[3], scale)


def _tree_terms(mapping: CayleyBathMapping, impurity_energy: float, interaction_u: float) -> tuple[dict[int, float], list[tuple[int, int, complex]], tuple[int, int, float], nx.Graph]:
    n_bath = mapping.bath_hamiltonian.shape[0]
    up_modes, down_modes = _mode_layout(n_bath)
    onsite = {0: float(impurity_energy), 1: float(impurity_energy)}
    for index in range(n_bath):
        onsite[up_modes[index + 1]] = float(np.real(mapping.tree_hamiltonian[index, index]))
        onsite[down_modes[index + 1]] = float(np.real(mapping.tree_hamiltonian[index, index]))
    hoppings: list[tuple[int, int, complex]] = []
    for left in range(n_bath):
        for right in range(left + 1, n_bath):
            coefficient = mapping.tree_hamiltonian[left, right]
            if abs(coefficient) > 1e-12:
                hoppings.append((up_modes[left + 1], up_modes[right + 1], coefficient))
                hoppings.append((down_modes[left + 1], down_modes[right + 1], coefficient))
    hoppings.append((0, up_modes[1], mapping.coupling_norm))
    hoppings.append((1, down_modes[1], mapping.coupling_norm))
    graph = nx.Graph()
    graph.add_nodes_from(range(2 + 2 * n_bath))
    graph.add_edges_from((first, second, {"weight": float(abs(coefficient))}) for first, second, coefficient in hoppings)
    graph.add_edge(0, 1, weight=float(abs(interaction_u)))
    return onsite, hoppings, (0, 1, float(interaction_u)), graph


def _ground_state_certificate() -> SIAMGroundStateCertificate:
    mapping, representations = _small_siam_representations()
    interaction_u = 1.6
    impurity_energy = -interaction_u / 2.0
    bath_h, coupling = representations["tree"]
    sector = _build_siam_sector(bath_h, coupling, impurity_energy=impurity_energy, interaction_u=interaction_u, n_up=2, n_down=2)
    eigenvalues, eigenvectors = eigh(sector.matrix.toarray())
    exact_energy = float(eigenvalues[0])
    exact_state = eigenvectors[:, 0]
    exact_full = _embed_sector(exact_state, sector)
    onsite, hoppings, interaction, graph = _tree_terms(mapping, impurity_energy, interaction_u)
    warm_sector = _build_siam_sector(bath_h, coupling, impurity_energy=impurity_energy, interaction_u=0.0, n_up=2, n_down=2)
    _, warm_vectors = eigh(warm_sector.matrix.toarray())
    warm_full = _embed_sector(warm_vectors[:, 0], warm_sector)
    step = 0.15
    steps = 36
    solver = _FermionicCayleyTTN.from_statevector(warm_full, graph, max_bond=16, budget=1e-12)
    for _ in range(steps):
        solver.strang_step(onsite, hoppings, interaction, step, imaginary_time=True)
    observed_full = solver.state.to_statevector(maximum_qubits=14)
    observed, leakage = _extract_sector(observed_full, sector)
    observed_energy = float(np.real(np.vdot(observed, sector.matrix @ observed)))
    fidelity = float(abs(np.vdot(exact_state, observed)) ** 2)
    bond_dimensions = (2, 4, 8)
    bond_energy_gaps: list[float] = []
    bond_fidelities: list[float] = []
    bond_discarded: list[float] = []
    for bond in bond_dimensions:
        reference = PersistentAdaptiveTTN(exact_full, qubit_count=sector.spin_orbital_count, max_bond=bond, discarded_weight_budget=0.0, interaction_graph=graph, maximum_refactor_qubits=14)
        approximation, _ = _extract_sector(reference.to_statevector(maximum_qubits=14), sector)
        bond_energy_gaps.append(abs(float(np.real(np.vdot(approximation, sector.matrix @ approximation))) - exact_energy))
        bond_fidelities.append(float(abs(np.vdot(exact_state, approximation)) ** 2))
        bond_discarded.append(float(reference.total_discarded_weight))
    monotone = all(bond_energy_gaps[i + 1] <= bond_energy_gaps[i] + 1e-12 for i in range(len(bond_energy_gaps) - 1))
    passed = (
        abs(observed_energy - exact_energy) < 1e-4
        and fidelity > 0.9998
        and leakage < 1e-10
        and monotone
        and bond_energy_gaps[-1] < 1e-6
        and bond_fidelities[-1] > 0.9999999
    )
    payload = {
        "bath_mode_count_per_spin": mapping.bath_hamiltonian.shape[0],
        "spin_orbital_count": sector.spin_orbital_count,
        "interaction_u": interaction_u,
        "imaginary_time_beta": steps * step,
        "imaginary_time_step": step,
        "imaginary_time_steps": steps,
        "initialization": "noninteracting_reference_ground_state_continuation",
        "exact_ground_energy": exact_energy,
        "ttn_ground_energy": observed_energy,
        "energy_gap": abs(observed_energy - exact_energy),
        "ground_state_fidelity": fidelity,
        "particle_sector_leakage": leakage,
        "maximum_bond": 16,
        "used_maximum_bond": solver.state.used_maximum_bond,
        "discarded_weight": solver.state.total_discarded_weight,
        "bond_dimension_sequence": bond_dimensions,
        "bond_energy_gap_sequence": tuple(float(x) for x in bond_energy_gaps),
        "bond_fidelity_sequence": tuple(float(x) for x in bond_fidelities),
        "bond_discarded_weight_sequence": tuple(float(x) for x in bond_discarded),
        "status": "PASS_IMAGINARY_TIME_INTERACTING_CAYLEY_TTN_GROUND_STATE" if passed else "FAIL_INTERACTING_CAYLEY_TTN_GROUND_STATE",
    }
    return SIAMGroundStateCertificate(**payload, digest=_digest(payload))


def _real_time_certificate() -> SIAMRealTimeCertificate:
    mapping, representations = _small_siam_representations()
    interaction_u = 1.6
    impurity_energy = -interaction_u / 2.0
    bath_h, coupling = representations["tree"]
    initial_sector = _build_siam_sector(bath_h, coupling, impurity_energy=impurity_energy, interaction_u=interaction_u, n_up=2, n_down=2)
    values, vectors = eigh(initial_sector.matrix.toarray())
    initial = vectors[:, 0]
    full_initial = _embed_sector(initial, initial_sector)
    post_energy = impurity_energy + 0.25
    post_sector = _build_siam_sector(bath_h, coupling, impurity_energy=post_energy, interaction_u=interaction_u, n_up=2, n_down=2)
    onsite, hoppings, interaction, graph = _tree_terms(mapping, post_energy, interaction_u)
    final_time = 0.24
    trajectories: dict[float, tuple[np.ndarray, float, float, float, int, float]] = {}
    for dt in (0.08, 0.04):
        solver = _FermionicCayleyTTN.from_statevector(full_initial, graph, max_bond=16, budget=1e-10)
        maximum_occupation_gap = 0.0
        for step_index in range(int(round(final_time / dt))):
            solver.strang_step(onsite, hoppings, interaction, dt, imaginary_time=False)
            observed, _ = _extract_sector(solver.state.to_statevector(maximum_qubits=14), post_sector)
            exact = expm_multiply(-1.0j * post_sector.matrix * ((step_index + 1) * dt), initial)
            exact /= np.linalg.norm(exact)
            obs_n = sum(_impurity_observables(observed, post_sector)[:2])
            exact_n = sum(_impurity_observables(exact, post_sector)[:2])
            maximum_occupation_gap = max(maximum_occupation_gap, abs(obs_n - exact_n))
        full_final = solver.state.to_statevector(maximum_qubits=14)
        observed, leakage = _extract_sector(full_final, post_sector)
        exact = expm_multiply(-1.0j * post_sector.matrix * final_time, initial)
        exact /= np.linalg.norm(exact)
        trajectories[dt] = (observed, _phase_aligned_gap(exact, observed), maximum_occupation_gap, leakage, solver.state.used_maximum_bond, solver.state.total_discarded_weight)
    coarse, fine = trajectories[0.08], trajectories[0.04]
    step_gap = _phase_aligned_gap(coarse[0], fine[0])
    fidelity = float(abs(np.vdot(expm_multiply(-1.0j * post_sector.matrix * final_time, initial), fine[0])) ** 2)
    norm_gap = abs(float(np.linalg.norm(fine[0])) - 1.0)
    passed = coarse[1] < 7e-4 and fine[1] < 2e-4 and step_gap < 5e-4 and fine[2] < 3e-4 and fine[3] < 1e-9
    payload = {
        "bath_mode_count_per_spin": mapping.bath_hamiltonian.shape[0],
        "spin_orbital_count": initial_sector.spin_orbital_count,
        "final_time": final_time,
        "coarse_time_step": 0.08,
        "fine_time_step": 0.04,
        "coarse_state_gap": coarse[1],
        "fine_state_gap": fine[1],
        "step_doubling_gap": step_gap,
        "fine_state_fidelity": fidelity,
        "maximum_impurity_occupation_gap": fine[2],
        "particle_sector_leakage": fine[3],
        "norm_gap": norm_gap,
        "maximum_bond": 16,
        "used_maximum_bond": fine[4],
        "discarded_weight": fine[5],
        "status": "PASS_SECOND_ORDER_INTERACTING_CAYLEY_TTN_TEBD" if passed else "FAIL_INTERACTING_CAYLEY_TTN_TEBD",
    }
    return SIAMRealTimeCertificate(**payload, digest=_digest(payload))


def _apply_mode_between_sectors(vector: np.ndarray, source: _SectorHamiltonian, target: _SectorHamiltonian, mode: int, *, creation: bool) -> np.ndarray:
    result = np.zeros(len(target.basis), dtype=complex)
    for column, state in enumerate(source.basis):
        transformed = _create(state, mode) if creation else _annihilate(state, mode)
        if transformed is not None and transformed[0] in target.index:
            result[target.index[transformed[0]]] += transformed[1] * vector[column]
    return result


def _green_data(bath_h: np.ndarray, coupling: np.ndarray) -> tuple[np.ndarray, float, float, float]:
    interaction_u = 1.6
    impurity_energy = -interaction_u / 2.0
    ground_sector = _build_siam_sector(bath_h, coupling, impurity_energy=impurity_energy, interaction_u=interaction_u, n_up=2, n_down=2)
    addition_sector = _build_siam_sector(bath_h, coupling, impurity_energy=impurity_energy, interaction_u=interaction_u, n_up=3, n_down=2)
    removal_sector = _build_siam_sector(bath_h, coupling, impurity_energy=impurity_energy, interaction_u=interaction_u, n_up=1, n_down=2)
    e0, v0 = eigh(ground_sector.matrix.toarray())
    ep, vp = eigh(addition_sector.matrix.toarray())
    em, vm = eigh(removal_sector.matrix.toarray())
    ground = v0[:, 0]
    plus = _apply_mode_between_sectors(ground, ground_sector, addition_sector, 0, creation=True)
    minus = _apply_mode_between_sectors(ground, ground_sector, removal_sector, 0, creation=False)
    amplitudes_plus = vp.conj().T @ plus
    amplitudes_minus = vm.conj().T @ minus
    weights_plus = np.square(np.abs(amplitudes_plus))
    weights_minus = np.square(np.abs(amplitudes_minus))
    omega_plus = ep - e0[0]
    omega_minus = e0[0] - em
    times = np.linspace(0.0, 5.0, 51)
    green = np.array([
        -1.0j * (
            np.sum(weights_plus * np.exp(-1.0j * omega_plus * time))
            + np.sum(weights_minus * np.exp(-1.0j * omega_minus * time))
        )
        for time in times
    ])
    zeroth = float(np.sum(weights_plus) + np.sum(weights_minus))
    first = float(np.sum(weights_plus * omega_plus) + np.sum(weights_minus * omega_minus))
    n_down = _impurity_observables(ground, ground_sector)[1]
    first_reference = impurity_energy + interaction_u * n_down
    return green, zeroth, first, float(first_reference)


def _green_certificate() -> SIAMGreenFunctionCertificate:
    mapping, representations = _small_siam_representations()
    data = {name: _green_data(bath_h, coupling) for name, (bath_h, coupling) in representations.items()}
    star_green, zeroth, first, first_reference = data["star"]
    tree_green = data["tree"][0]
    chain_green = data["chain"][0]
    tree_gap = float(np.max(np.abs(star_green - tree_green)))
    chain_gap = float(np.max(np.abs(star_green - chain_green)))
    equal_time_gap = abs(star_green[0] + 1.0j)
    zeroth_gap = abs(zeroth - 1.0)
    first_gap = abs(first - first_reference)
    passed = max(tree_gap, chain_gap, equal_time_gap, zeroth_gap, first_gap) < 2e-10
    payload = {
        "bath_mode_count_per_spin": mapping.bath_hamiltonian.shape[0],
        "time_point_count": len(star_green),
        "maximum_star_tree_green_gap": tree_gap,
        "maximum_star_chain_green_gap": chain_gap,
        "equal_time_anticommutator_gap": equal_time_gap,
        "spectral_zeroth_moment": zeroth,
        "spectral_zeroth_moment_gap": zeroth_gap,
        "spectral_first_moment": first,
        "spectral_first_moment_reference": first_reference,
        "spectral_first_moment_gap": first_gap,
        "status": "PASS_INTERACTING_IMPURITY_GREEN_FUNCTION_AND_SUM_RULES" if passed else "FAIL_INTERACTING_IMPURITY_GREEN_FUNCTION_OR_SUM_RULES",
    }
    return SIAMGreenFunctionCertificate(**payload, digest=_digest(payload))


def _scalable_holdout_certificate() -> SIAMScalableHoldoutCertificate:
    n_bath = 12
    active = 3
    interaction_u = 1.4
    impurity_energy = -interaction_u / 2.0
    energies = np.array([-1.2, 0.0, 1.2] + [5.0] * (n_bath - active), dtype=float)
    couplings = np.array([0.25, 0.20, 0.25] + [0.0] * (n_bath - active), dtype=complex)
    mapping = CayleyBathMapping(np.diag(energies), couplings)
    onsite, hoppings, interaction, graph = _tree_terms(mapping, impurity_energy, interaction_u)
    qubits = 2 + 2 * n_bath
    bits = [0] * qubits
    bits[0] = 1
    bits[2] = 1
    bits[2 + n_bath] = 1
    solver = _FermionicCayleyTTN.product_state(bits, graph, max_bond=16, budget=1e-10)
    for _ in range(2):
        solver.strang_step(onsite, hoppings, interaction, 0.08, imaginary_time=True)
    for _ in range(1):
        solver.strang_step(onsite, hoppings, interaction, 0.04, imaginary_time=False)
    occupations = [float(np.real(solver.state.expectation({mode: _NUMBER}))) for mode in range(qubits)]
    # Cayley mapping rotates the original bath basis.  Spectators therefore cannot be
    # identified by original mode indices.  They are the tree nodes outside the
    # nonzero connected component of the impurity-coupled root node.
    bath_graph = nx.Graph()
    bath_graph.add_nodes_from(range(n_bath))
    for left in range(n_bath):
        for right in range(left + 1, n_bath):
            if abs(mapping.tree_hamiltonian[left, right]) > 1e-12:
                bath_graph.add_edge(left, right)
    active_tree_nodes = nx.node_connected_component(bath_graph, 0)
    up_modes, down_modes = _mode_layout(n_bath)
    spectator_modes = [
        mode
        for node in range(n_bath)
        if node not in active_tree_nodes
        for mode in (up_modes[node + 1], down_modes[node + 1])
    ]
    maximum_spectator = max((occupations[mode] for mode in spectator_modes), default=0.0)
    number_gap = abs(sum(occupations) - sum(bits))
    norm_gap = abs(solver.state.norm_squared() - 1.0)
    double = float(np.real(solver.state.expectation({0: _NUMBER, 1: _NUMBER})))
    statevector_materialized = bool(solver.state._statevector_materialized)
    passed = (
        not statevector_materialized
        and number_gap < 1e-8
        and maximum_spectator < 1e-10
        and norm_gap < 1e-10
        and solver.state.total_discarded_weight <= 1.01e-10
    )
    payload = {
        "bath_mode_count_per_spin": n_bath,
        "active_bath_modes_per_spin": active,
        "spectator_bath_modes_per_spin": n_bath - active,
        "spin_orbital_count": qubits,
        "interaction_u": interaction_u,
        "imaginary_time_steps": 2,
        "real_time_steps": 1,
        "maximum_bond": 16,
        "used_maximum_bond": solver.state.used_maximum_bond,
        "discarded_weight": solver.state.total_discarded_weight,
        "particle_number_gap": number_gap,
        "maximum_spectator_occupation": maximum_spectator,
        "norm_gap": norm_gap,
        "impurity_up_occupation": occupations[0],
        "impurity_down_occupation": occupations[1],
        "impurity_double_occupation": double,
        "statevector_materialized": statevector_materialized,
        "status": "PASS_STRUCTURED_26_QUBIT_INTERACTING_CAYLEY_TTN_HOLDOUT" if passed else "FAIL_STRUCTURED_INTERACTING_CAYLEY_TTN_HOLDOUT",
    }
    return SIAMScalableHoldoutCertificate(**payload, digest=_digest(payload))


def _flat_bath(order: int, half_bandwidth: float = 2.0, gamma: float = 0.35) -> tuple[np.ndarray, np.ndarray]:
    nodes, weights = np.polynomial.legendre.leggauss(int(order))
    energies = half_bandwidth * nodes
    quadrature_weights = half_bandwidth * weights
    coupling_squared = (gamma / math.pi) * quadrature_weights
    return energies.astype(float), np.sqrt(coupling_squared).astype(complex)


def _continuum_flat_hybridization(z: complex, half_bandwidth: float = 2.0, gamma: float = 0.35) -> complex:
    return complex((gamma / math.pi) * (np.log(z + half_bandwidth) - np.log(z - half_bandwidth)))


def _discretization_certificate() -> BathDiscretizationCertificate:
    coarse_order, fine_order = 15, 63
    grid = [complex(x, eta) for eta in (0.2, 0.5, 1.0) for x in np.linspace(-1.5, 1.5, 13)]
    gaps: dict[int, float] = {}
    values: dict[int, list[complex]] = {}
    for order in (coarse_order, fine_order):
        energies, couplings = _flat_bath(order)
        observed = [np.sum(np.abs(couplings) ** 2 / (z - energies)) for z in grid]
        exact = [_continuum_flat_hybridization(z) for z in grid]
        values[order] = observed
        gaps[order] = float(max(abs(a - b) for a, b in zip(observed, exact, strict=True)))
    refinement = float(max(abs(a - b) for a, b in zip(values[coarse_order], values[fine_order], strict=True)))
    status = "PASS_GAUSS_LEGENDRE_BATH_REFINEMENT_CONTROL" if gaps[fine_order] < gaps[coarse_order] and gaps[fine_order] < 5e-6 else "FAIL_BATH_REFINEMENT_CONTROL"
    payload = {
        "coarse_order": coarse_order,
        "fine_order": fine_order,
        "coarse_continuum_hybridization_gap": gaps[coarse_order],
        "fine_continuum_hybridization_gap": gaps[fine_order],
        "refinement_gap": refinement,
        "status": status,
    }
    return BathDiscretizationCertificate(**payload, digest=_digest(payload))


@lru_cache(maxsize=1)
def qualify_cayley_impurity_runtime() -> CayleyImpurityQualification:
    """Execute the current bounded interacting spinful SIAM Cayley-TTN qualification."""
    energies, couplings = _flat_bath(31)
    mapping = CayleyBathMapping(np.diag(energies), couplings).certificate()
    representation = _representation_certificate()
    ground = _ground_state_certificate()
    real_time = _real_time_certificate()
    green = _green_certificate()
    holdout = _scalable_holdout_certificate()
    bath = _discretization_certificate()
    passed = all((mapping.passed, representation.passed, ground.passed, real_time.passed, green.passed, holdout.passed, bath.passed))
    unqualified = (
        "arbitrary continuum baths without an explicit discretization certificate",
        "generic 26-qubit interacting baths beyond the structured three-active-mode holdout",
        "long-time or volume-law interacting dynamics outside the measured bond and time envelopes",
        "finite-temperature, multiorbital, DMFT self-consistency and physical-device qualification",
        "linear-prediction extrapolation beyond the exact bounded Lehmann and time-domain controls",
    )
    payload = {
        "mapping_digest": mapping.digest,
        "representation_digest": representation.digest,
        "ground_state_digest": ground.digest,
        "real_time_digest": real_time.digest,
        "green_function_digest": green.digest,
        "scalable_holdout_digest": holdout.digest,
        "bath_discretization_digest": bath.digest,
        "unqualified_regions": unqualified,
        "status": "PASS_BOUNDED_INTERACTING_SPINFUL_SIAM_CAYLEY_TTN_RUNTIME" if passed else "FAIL_BOUNDED_INTERACTING_SPINFUL_SIAM_CAYLEY_TTN_RUNTIME",
    }
    return CayleyImpurityQualification(mapping, representation, ground, real_time, green, holdout, bath, unqualified, payload["status"], _digest(payload))
