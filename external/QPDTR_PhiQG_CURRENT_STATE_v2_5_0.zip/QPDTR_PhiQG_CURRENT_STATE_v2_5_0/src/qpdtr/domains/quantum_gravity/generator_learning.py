from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np
from scipy.linalg import expm, logm


@dataclass(frozen=True, slots=True)
class LearnedAffineBlochGenerator:
    matrix: tuple[tuple[float, ...], ...]
    drift: tuple[float, ...]
    discrete_map: tuple[tuple[float, ...], ...]
    discrete_offset: tuple[float, ...]
    regression_residual_rms: float
    design_condition_number: float

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class GeneratorLearningCertificate:
    sample_count: int
    trajectory_count: int
    time_step: float
    noise_standard_deviation: float
    generator_matrix_gap: float
    generator_drift_gap: float
    holdout_bloch_rmse: float
    holdout_maximum_gap: float
    confidence_coverage_rate: float
    learned: LearnedAffineBlochGenerator
    status: str
    claim_scope: str

    @property
    def passed(self) -> bool:
        return self.status.startswith('PASS')

    def to_dict(self) -> dict:
        return asdict(self) | {'passed': self.passed}


def _augmented_generator(matrix: np.ndarray, drift: np.ndarray) -> np.ndarray:
    augmented = np.zeros((4, 4), dtype=float)
    augmented[:3, :3] = np.asarray(matrix, dtype=float)
    augmented[:3, 3] = np.asarray(drift, dtype=float)
    return augmented


def _propagate(matrix: np.ndarray, drift: np.ndarray, state: np.ndarray, times: np.ndarray) -> np.ndarray:
    generator = _augmented_generator(matrix, drift)
    initial = np.concatenate([np.asarray(state, dtype=float), [1.0]])
    rows = []
    for time in times:
        rows.append((expm(generator * float(time)) @ initial)[:3])
    return np.asarray(rows)


def learn_affine_bloch_generator(
    trajectories: np.ndarray,
    *,
    time_step: float,
) -> tuple[LearnedAffineBlochGenerator, np.ndarray, np.ndarray]:
    """Learn r_{k+1}=M r_k+c and lower it to dr/dt=A r+b."""

    data = np.asarray(trajectories, dtype=float)
    if data.ndim != 3 or data.shape[2] != 3 or data.shape[1] < 3:
        raise ValueError('trajectories must have shape (trajectory,time,3)')
    if time_step <= 0.0:
        raise ValueError('time_step must be positive')
    x = data[:, :-1, :].reshape(-1, 3)
    y = data[:, 1:, :].reshape(-1, 3)
    design = np.column_stack([x, np.ones(len(x))])
    coefficients, _, _, _ = np.linalg.lstsq(design, y, rcond=None)
    # y = design @ coefficients, so M = coefficients[:3,:]^T and c = coefficients[3,:]
    discrete_matrix = coefficients[:3, :].T
    discrete_offset = coefficients[3, :]
    residual = y - (design @ coefficients)
    dof = max(1, len(y) - design.shape[1])
    residual_covariance = residual.T @ residual / dof
    input_covariance = np.linalg.pinv(design.T @ design)

    affine_map = np.eye(4, dtype=float)
    affine_map[:3, :3] = discrete_matrix
    affine_map[:3, 3] = discrete_offset
    generator = np.real_if_close(logm(affine_map) / float(time_step), tol=1000)
    if np.iscomplexobj(generator):
        raise ValueError('learned affine map has no numerically real logarithm')
    generator = np.asarray(generator, dtype=float)
    learned = LearnedAffineBlochGenerator(
        matrix=tuple(tuple(float(value) for value in row) for row in generator[:3, :3]),
        drift=tuple(float(value) for value in generator[:3, 3]),
        discrete_map=tuple(tuple(float(value) for value in row) for row in discrete_matrix),
        discrete_offset=tuple(float(value) for value in discrete_offset),
        regression_residual_rms=float(np.sqrt(np.mean(residual * residual))),
        design_condition_number=float(np.linalg.cond(design)),
    )
    return learned, residual_covariance, input_covariance


def _sample_affine_maps(
    learned: LearnedAffineBlochGenerator,
    residual_covariance: np.ndarray,
    input_covariance: np.ndarray,
    *,
    sample_count: int,
    seed: int,
) -> tuple[np.ndarray, ...]:
    rng = np.random.default_rng(seed)
    mean = np.vstack(
        [
            np.asarray(learned.discrete_map, dtype=float).T,
            np.asarray(learned.discrete_offset, dtype=float),
        ]
    )
    # Matrix-normal regression covariance: Cov(vec(B)) = Sigma_y \otimes (X^T X)^-1.
    covariance = np.kron(residual_covariance, input_covariance)
    covariance = (covariance + covariance.T) / 2.0
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    factor = eigenvectors @ np.diag(np.sqrt(np.clip(eigenvalues, 0.0, None)))
    mean_vec = mean.reshape(-1, order='F')
    outputs = []
    for _ in range(sample_count):
        draw = mean_vec + factor @ rng.normal(size=len(mean_vec))
        coefficient = draw.reshape(4, 3, order='F')
        affine = np.eye(4, dtype=float)
        affine[:3, :3] = coefficient[:3, :].T
        affine[:3, 3] = coefficient[3, :]
        outputs.append(affine)
    return tuple(outputs)


def qualify_bounded_generator_learning(
    *,
    seed: int = 90421,
    time_step: float = 0.04,
    training_steps: int = 55,
    uncertainty_samples: int = 240,
    noise_standard_deviation: float = 2.0e-4,
) -> GeneratorLearningCertificate:
    """Blind synthetic single-qubit Hamiltonian/Lindbladian learning control."""

    gamma_one = 0.23
    gamma_phi = 0.08
    omega = 1.17
    equilibrium_z = 0.31
    gamma_two = gamma_one / 2.0 + gamma_phi
    true_matrix = np.asarray(
        [
            [-gamma_two, -omega, 0.0],
            [omega, -gamma_two, 0.0],
            [0.0, 0.0, -gamma_one],
        ],
        dtype=float,
    )
    true_drift = np.asarray([0.0, 0.0, gamma_one * equilibrium_z], dtype=float)
    initial_states = np.asarray(
        [
            [1.0, 0.0, 0.0], [-1.0, 0.0, 0.0],
            [0.0, 1.0, 0.0], [0.0, -1.0, 0.0],
            [0.0, 0.0, 1.0], [0.0, 0.0, -1.0],
        ],
        dtype=float,
    )
    times = np.arange(training_steps + 1, dtype=float) * float(time_step)
    rng = np.random.default_rng(seed)
    exact = np.asarray([_propagate(true_matrix, true_drift, state, times) for state in initial_states])
    observed = exact + rng.normal(scale=noise_standard_deviation, size=exact.shape)
    learned, residual_covariance, input_covariance = learn_affine_bloch_generator(
        observed,
        time_step=time_step,
    )
    estimated_matrix = np.asarray(learned.matrix, dtype=float)
    estimated_drift = np.asarray(learned.drift, dtype=float)

    holdout_states = np.asarray(
        [
            [1.0, 1.0, 1.0] / np.sqrt(3.0),
            [-1.0, 2.0, 0.5] / np.sqrt(5.25),
            [0.3, -0.4, 0.5] / np.sqrt(0.5),
        ],
        dtype=float,
    )
    holdout_times = np.arange(1, 81, dtype=float) * float(time_step)
    exact_holdout = np.asarray(
        [_propagate(true_matrix, true_drift, state, holdout_times) for state in holdout_states]
    )
    learned_holdout = np.asarray(
        [_propagate(estimated_matrix, estimated_drift, state, holdout_times) for state in holdout_states]
    )
    gaps = np.linalg.norm(exact_holdout - learned_holdout, axis=2)

    sampled_maps = _sample_affine_maps(
        learned,
        residual_covariance,
        input_covariance,
        sample_count=uncertainty_samples,
        seed=seed + 1,
    )
    coverage_numerator = 0
    coverage_denominator = 0
    for initial_index, initial in enumerate(holdout_states):
        augmented = np.concatenate([initial, [1.0]])
        samples = np.empty((len(sampled_maps), len(holdout_times), 3), dtype=float)
        for sample_index, affine in enumerate(sampled_maps):
            state = augmented.copy()
            for time_index in range(len(holdout_times)):
                state = affine @ state
                samples[sample_index, time_index] = state[:3]
        mean = np.mean(samples, axis=0)
        std = np.std(samples, axis=0, ddof=1)
        lower = mean - 2.2 * std - 2.0 * noise_standard_deviation
        upper = mean + 2.2 * std + 2.0 * noise_standard_deviation
        target = exact_holdout[initial_index]
        coverage_numerator += int(np.sum((target >= lower) & (target <= upper)))
        coverage_denominator += int(target.size)

    matrix_gap = float(np.linalg.norm(estimated_matrix - true_matrix, ord='fro'))
    drift_gap = float(np.linalg.norm(estimated_drift - true_drift))
    rmse = float(np.sqrt(np.mean((learned_holdout - exact_holdout) ** 2)))
    maximum_gap = float(np.max(gaps))
    coverage = float(coverage_numerator / max(1, coverage_denominator))

    if matrix_gap >= 0.03 or drift_gap >= 0.01:
        status = 'FAIL_GENERATOR_RECOVERY'
    elif maximum_gap >= 0.03:
        status = 'FAIL_HOLDOUT_PREDICTION'
    elif coverage < 0.90:
        status = 'FAIL_UNCERTAINTY_COVERAGE'
    else:
        status = 'PASS_SYNTHETIC_SINGLE_QUBIT_GENERATOR_LEARNING_WITH_UNCERTAINTY'

    return GeneratorLearningCertificate(
        sample_count=int(observed[:, :-1, :].shape[0] * observed[:, :-1, :].shape[1]),
        trajectory_count=len(initial_states),
        time_step=float(time_step),
        noise_standard_deviation=float(noise_standard_deviation),
        generator_matrix_gap=matrix_gap,
        generator_drift_gap=drift_gap,
        holdout_bloch_rmse=rmse,
        holdout_maximum_gap=maximum_gap,
        confidence_coverage_rate=coverage,
        learned=learned,
        status=status,
        claim_scope=(
            'Blind synthetic affine-Bloch learning for one qubit with a fixed time step; '
            'not ansatz-free many-qubit Lindbladian learning and not experimental qualification.'
        ),
    )
