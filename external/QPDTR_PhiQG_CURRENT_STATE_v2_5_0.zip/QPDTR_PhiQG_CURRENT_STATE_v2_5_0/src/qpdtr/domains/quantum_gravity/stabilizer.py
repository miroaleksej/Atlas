from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from typing import Any, Iterable, Sequence

import numpy as np


_CLIFFORD_GATES = frozenset({"H", "S", "SDG", "X", "Y", "Z", "CNOT", "CZ", "SWAP"})


def _as_qubit(qubit: int, qubit_count: int) -> int:
    q = int(qubit)
    if q < 0 or q >= qubit_count:
        raise IndexError(f"qubit {q} is outside [0, {qubit_count})")
    return q


def _phase_aligned_gap(reference: np.ndarray, candidate: np.ndarray) -> float:
    overlap = np.vdot(reference, candidate)
    if abs(overlap) > 0.0:
        candidate = candidate * np.exp(-1j * np.angle(overlap))
    return float(np.linalg.norm(reference - candidate))


def _rowsum_phase_term(x1: int, z1: int, x2: int, z2: int) -> int:
    """Aaronson-Gottesman CHP phase contribution for multiplying Pauli rows."""
    if x1 == 0 and z1 == 0:
        return 0
    if x1 == 1 and z1 == 1:
        return z2 - x2
    if x1 == 1 and z1 == 0:
        return z2 * (2 * x2 - 1)
    return x2 * (1 - 2 * z2)


def _parse_pauli(pauli: str | Sequence[str], qubit_count: int) -> tuple[np.ndarray, np.ndarray]:
    if isinstance(pauli, str):
        symbols = tuple(pauli)
    else:
        symbols = tuple(str(item) for item in pauli)
    if len(symbols) != qubit_count:
        raise ValueError(f"Pauli length {len(symbols)} does not equal qubit_count={qubit_count}")
    x = np.zeros(qubit_count, dtype=np.uint8)
    z = np.zeros(qubit_count, dtype=np.uint8)
    for q, symbol in enumerate(symbols):
        p = symbol.upper()
        if p == "I":
            continue
        if p == "X":
            x[q] = 1
        elif p == "Y":
            x[q] = 1
            z[q] = 1
        elif p == "Z":
            z[q] = 1
        else:
            raise ValueError(f"Unsupported Pauli symbol {symbol!r}")
    return x, z


@dataclass(frozen=True, slots=True)
class StabilizerMeasurement:
    qubit: int
    outcome: int
    deterministic: bool

    def to_dict(self) -> dict[str, Any]:
        return {
            "qubit": int(self.qubit),
            "outcome": int(self.outcome),
            "deterministic": bool(self.deterministic),
        }


class StabilizerTableau:
    """Exact Aaronson-Gottesman tableau for Clifford circuits.

    Rows 0..n-1 are destabilizers, rows n..2n-1 are stabilizers, and row 2n is
    scratch space.  The representation is exact Boolean algebra; it does not
    allocate a 2**n state vector.
    """

    def __init__(self, qubit_count: int) -> None:
        n = int(qubit_count)
        if n < 1:
            raise ValueError("qubit_count must be positive")
        self.qubit_count = n
        self.x = np.zeros((2 * n + 1, n), dtype=np.uint8)
        self.z = np.zeros((2 * n + 1, n), dtype=np.uint8)
        self.r = np.zeros(2 * n + 1, dtype=np.uint8)
        indices = np.arange(n)
        self.x[indices, indices] = 1
        self.z[n + indices, indices] = 1
        self.gate_count = 0
        self.measurement_count = 0

    @classmethod
    def zero_state(cls, qubit_count: int) -> "StabilizerTableau":
        return cls(qubit_count)

    def copy(self) -> "StabilizerTableau":
        other = object.__new__(StabilizerTableau)
        other.qubit_count = self.qubit_count
        other.x = self.x.copy()
        other.z = self.z.copy()
        other.r = self.r.copy()
        other.gate_count = self.gate_count
        other.measurement_count = self.measurement_count
        return other

    @property
    def memory_bytes(self) -> int:
        return int(self.x.nbytes + self.z.nbytes + self.r.nbytes)

    def _rowsum(self, target: int, source: int) -> None:
        phase = 2 * int(self.r[target]) + 2 * int(self.r[source])
        for q in range(self.qubit_count):
            phase += _rowsum_phase_term(
                int(self.x[source, q]),
                int(self.z[source, q]),
                int(self.x[target, q]),
                int(self.z[target, q]),
            )
        phase %= 4
        if phase not in (0, 2):
            raise ArithmeticError("commuting stabilizer-row product acquired a non-Hermitian phase")
        self.r[target] = np.uint8(phase // 2)
        self.x[target] ^= self.x[source]
        self.z[target] ^= self.z[source]

    def h(self, qubit: int) -> None:
        q = _as_qubit(qubit, self.qubit_count)
        self.r ^= self.x[:, q] & self.z[:, q]
        xq = self.x[:, q].copy()
        self.x[:, q] = self.z[:, q]
        self.z[:, q] = xq
        self.gate_count += 1

    def s(self, qubit: int) -> None:
        q = _as_qubit(qubit, self.qubit_count)
        self.r ^= self.x[:, q] & self.z[:, q]
        self.z[:, q] ^= self.x[:, q]
        self.gate_count += 1

    def sdg(self, qubit: int) -> None:
        for _ in range(3):
            self.s(qubit)

    def x_gate(self, qubit: int) -> None:
        q = _as_qubit(qubit, self.qubit_count)
        self.r ^= self.z[:, q]
        self.gate_count += 1

    def z_gate(self, qubit: int) -> None:
        q = _as_qubit(qubit, self.qubit_count)
        self.r ^= self.x[:, q]
        self.gate_count += 1

    def y_gate(self, qubit: int) -> None:
        q = _as_qubit(qubit, self.qubit_count)
        self.r ^= self.x[:, q] ^ self.z[:, q]
        self.gate_count += 1

    def cnot(self, control: int, target: int) -> None:
        c = _as_qubit(control, self.qubit_count)
        t = _as_qubit(target, self.qubit_count)
        if c == t:
            raise ValueError("CNOT control and target must differ")
        self.r ^= self.x[:, c] & self.z[:, t] & (self.x[:, t] ^ self.z[:, c] ^ np.uint8(1))
        self.x[:, t] ^= self.x[:, c]
        self.z[:, c] ^= self.z[:, t]
        self.gate_count += 1

    def cz(self, first: int, second: int) -> None:
        a = _as_qubit(first, self.qubit_count)
        b = _as_qubit(second, self.qubit_count)
        if a == b:
            raise ValueError("CZ qubits must differ")
        self.h(b)
        self.cnot(a, b)
        self.h(b)

    def swap(self, first: int, second: int) -> None:
        a = _as_qubit(first, self.qubit_count)
        b = _as_qubit(second, self.qubit_count)
        if a == b:
            return
        self.cnot(a, b)
        self.cnot(b, a)
        self.cnot(a, b)

    def apply(self, gate: str, *qubits: int) -> None:
        name = gate.upper()
        if name not in _CLIFFORD_GATES:
            raise ValueError(f"Unsupported Clifford gate {gate!r}")
        if name == "H":
            self.h(qubits[0])
        elif name == "S":
            self.s(qubits[0])
        elif name == "SDG":
            self.sdg(qubits[0])
        elif name == "X":
            self.x_gate(qubits[0])
        elif name == "Y":
            self.y_gate(qubits[0])
        elif name == "Z":
            self.z_gate(qubits[0])
        elif name == "CNOT":
            self.cnot(qubits[0], qubits[1])
        elif name == "CZ":
            self.cz(qubits[0], qubits[1])
        else:
            self.swap(qubits[0], qubits[1])

    def measure_z(
        self,
        qubit: int,
        *,
        rng: np.random.Generator | None = None,
        forced_outcome: int | None = None,
    ) -> StabilizerMeasurement:
        q = _as_qubit(qubit, self.qubit_count)
        n = self.qubit_count
        pivot = next((row for row in range(n, 2 * n) if self.x[row, q]), None)
        if pivot is None:
            scratch = 2 * n
            self.x[scratch].fill(0)
            self.z[scratch].fill(0)
            self.r[scratch] = 0
            for row in range(n):
                if self.x[row, q]:
                    self._rowsum(scratch, row + n)
            outcome = int(self.r[scratch])
            deterministic = True
        else:
            if forced_outcome is None:
                generator = rng if rng is not None else np.random.default_rng()
                outcome = int(generator.integers(0, 2))
            else:
                outcome = int(forced_outcome)
                if outcome not in (0, 1):
                    raise ValueError("forced_outcome must be 0 or 1")
            for row in range(2 * n):
                if row != pivot and self.x[row, q]:
                    self._rowsum(row, pivot)
            self.x[pivot - n] = self.x[pivot]
            self.z[pivot - n] = self.z[pivot]
            self.r[pivot - n] = self.r[pivot]
            self.x[pivot].fill(0)
            self.z[pivot].fill(0)
            self.z[pivot, q] = 1
            self.r[pivot] = np.uint8(outcome)
            deterministic = False
        self.measurement_count += 1
        return StabilizerMeasurement(q, outcome, deterministic)

    def expectation_pauli(self, pauli: str | Sequence[str]) -> int:
        px, pz = _parse_pauli(pauli, self.qubit_count)
        n = self.qubit_count
        stabilizer_x = self.x[n : 2 * n]
        stabilizer_z = self.z[n : 2 * n]
        anti = (stabilizer_x @ pz + stabilizer_z @ px) & np.uint8(1)
        if bool(np.any(anti)):
            return 0

        scratch = 2 * n
        self.x[scratch].fill(0)
        self.z[scratch].fill(0)
        self.r[scratch] = 0
        destabilizer_x = self.x[:n]
        destabilizer_z = self.z[:n]
        coefficients = (destabilizer_x @ pz + destabilizer_z @ px) & np.uint8(1)
        for row in np.flatnonzero(coefficients):
            self._rowsum(scratch, int(row) + n)
        if not np.array_equal(self.x[scratch], px) or not np.array_equal(self.z[scratch], pz):
            raise ArithmeticError("tableau canonical-pair invariant failed during Pauli expectation")
        return -1 if int(self.r[scratch]) else 1

    def canonical_pair_sample_gap(self, sample_count: int = 64, seed: int = 0) -> int:
        rng = np.random.default_rng(seed)
        n = self.qubit_count
        gap = 0
        for _ in range(max(1, int(sample_count))):
            i = int(rng.integers(0, n))
            j = int(rng.integers(0, n))
            di_x, di_z = self.x[i], self.z[i]
            sj_x, sj_z = self.x[n + j], self.z[n + j]
            comm = int((np.dot(di_x, sj_z) + np.dot(di_z, sj_x)) & 1)
            gap = max(gap, abs(comm - int(i == j)))
            si_x, si_z = self.x[n + i], self.z[n + i]
            sj_x, sj_z = self.x[n + j], self.z[n + j]
            stab_comm = int((np.dot(si_x, sj_z) + np.dot(si_z, sj_x)) & 1)
            gap = max(gap, stab_comm)
        return int(gap)

    def digest(self) -> str:
        payload = hashlib.sha256()
        payload.update(self.qubit_count.to_bytes(8, "big"))
        payload.update(self.x.tobytes(order="C"))
        payload.update(self.z.tobytes(order="C"))
        payload.update(self.r.tobytes(order="C"))
        return payload.hexdigest()


@dataclass(slots=True)
class _MagicBranch:
    coefficient: complex
    tableau: StabilizerTableau
    clifford_operations: list[tuple[str, tuple[int, ...]]]


class BoundedMagicInjectionRuntime:
    """Exact T = alpha I + beta Z branch decomposition under an explicit bound.

    The scalable component is the Clifford tableau.  Materialization of each
    stabilizer branch is allowed only for the declared small-qubit validation
    region, so the implementation does not silently promote 2**t branching to
    a large-qubit claim.
    """

    def __init__(
        self,
        qubit_count: int,
        *,
        maximum_t_gates: int,
        maximum_branches: int,
        materialization_qubit_limit: int,
    ) -> None:
        n = int(qubit_count)
        if n < 1 or n > int(materialization_qubit_limit):
            raise ValueError("bounded magic runtime requires a positive qubit count within materialization limit")
        if maximum_t_gates < 0 or maximum_branches < 1:
            raise ValueError("magic resource bounds are inadmissible")
        self.qubit_count = n
        self.maximum_t_gates = int(maximum_t_gates)
        self.maximum_branches = int(maximum_branches)
        self.materialization_qubit_limit = int(materialization_qubit_limit)
        self.t_gate_count = 0
        self.branches = [_MagicBranch(1.0 + 0.0j, StabilizerTableau.zero_state(n), [])]
        self.direct_operations: list[tuple[str, tuple[int, ...]]] = []

    def apply_clifford(self, gate: str, *qubits: int) -> None:
        name = gate.upper()
        if name not in _CLIFFORD_GATES:
            raise ValueError(f"Unsupported Clifford gate {gate!r}")
        normalized = tuple(int(q) for q in qubits)
        for branch in self.branches:
            branch.tableau.apply(name, *normalized)
            branch.clifford_operations.append((name, normalized))
        self.direct_operations.append((name, normalized))

    def apply_t(self, qubit: int) -> None:
        q = _as_qubit(qubit, self.qubit_count)
        if self.t_gate_count >= self.maximum_t_gates:
            raise RuntimeError("T-gate bound exceeded")
        if len(self.branches) * 2 > self.maximum_branches:
            raise RuntimeError("magic branch bound exceeded")
        omega = np.exp(1j * np.pi / 4.0)
        alpha = (1.0 + omega) / 2.0
        beta = (1.0 - omega) / 2.0
        next_branches: list[_MagicBranch] = []
        for branch in self.branches:
            keep = _MagicBranch(
                branch.coefficient * alpha,
                branch.tableau.copy(),
                list(branch.clifford_operations),
            )
            flipped_tableau = branch.tableau.copy()
            flipped_tableau.z_gate(q)
            flipped_operations = list(branch.clifford_operations)
            flipped_operations.append(("Z", (q,)))
            flip = _MagicBranch(branch.coefficient * beta, flipped_tableau, flipped_operations)
            next_branches.extend((keep, flip))
        self.branches = next_branches
        self.t_gate_count += 1
        self.direct_operations.append(("T", (q,)))

    def materialize_branch_sum(self) -> np.ndarray:
        dimension = 1 << self.qubit_count
        result = np.zeros(dimension, dtype=np.complex128)
        for branch in self.branches:
            state = np.zeros(dimension, dtype=np.complex128)
            state[0] = 1.0
            for gate, qubits in branch.clifford_operations:
                _apply_statevector_gate(state, gate, qubits)
            result += branch.coefficient * state
        return result

    def materialize_direct_reference(self) -> np.ndarray:
        dimension = 1 << self.qubit_count
        state = np.zeros(dimension, dtype=np.complex128)
        state[0] = 1.0
        for gate, qubits in self.direct_operations:
            _apply_statevector_gate(state, gate, qubits)
        return state


def _apply_single_qubit_statevector(state: np.ndarray, matrix: np.ndarray, qubit: int) -> None:
    stride = 1 << qubit
    block = stride << 1
    for start in range(0, state.size, block):
        lower = slice(start, start + stride)
        upper = slice(start + stride, start + block)
        a = state[lower].copy()
        b = state[upper].copy()
        state[lower] = matrix[0, 0] * a + matrix[0, 1] * b
        state[upper] = matrix[1, 0] * a + matrix[1, 1] * b


def _apply_cnot_statevector(state: np.ndarray, control: int, target: int) -> None:
    indices = np.arange(state.size, dtype=np.int64)
    selected = ((indices >> control) & 1).astype(bool) & ~((indices >> target) & 1).astype(bool)
    source = indices[selected]
    destination = source | (1 << target)
    temporary = state[source].copy()
    state[source] = state[destination]
    state[destination] = temporary


def _apply_statevector_gate(state: np.ndarray, gate: str, qubits: Sequence[int]) -> None:
    name = gate.upper()
    if name == "H":
        _apply_single_qubit_statevector(
            state,
            np.array([[1.0, 1.0], [1.0, -1.0]], dtype=np.complex128) / np.sqrt(2.0),
            qubits[0],
        )
    elif name == "S":
        _apply_single_qubit_statevector(state, np.diag([1.0, 1.0j]), qubits[0])
    elif name == "SDG":
        _apply_single_qubit_statevector(state, np.diag([1.0, -1.0j]), qubits[0])
    elif name == "T":
        _apply_single_qubit_statevector(state, np.diag([1.0, np.exp(1j * np.pi / 4.0)]), qubits[0])
    elif name == "X":
        _apply_single_qubit_statevector(state, np.array([[0.0, 1.0], [1.0, 0.0]], dtype=np.complex128), qubits[0])
    elif name == "Y":
        _apply_single_qubit_statevector(state, np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=np.complex128), qubits[0])
    elif name == "Z":
        _apply_single_qubit_statevector(state, np.diag([1.0, -1.0]), qubits[0])
    elif name == "CNOT":
        _apply_cnot_statevector(state, qubits[0], qubits[1])
    elif name == "CZ":
        indices = np.arange(state.size, dtype=np.int64)
        selected = (((indices >> qubits[0]) & 1) & ((indices >> qubits[1]) & 1)).astype(bool)
        state[selected] *= -1.0
    elif name == "SWAP":
        a, b = int(qubits[0]), int(qubits[1])
        if a != b:
            _apply_cnot_statevector(state, a, b)
            _apply_cnot_statevector(state, b, a)
            _apply_cnot_statevector(state, a, b)
    else:
        raise ValueError(f"Unsupported state-vector gate {gate!r}")


def _pauli_expectation_statevector(state: np.ndarray, pauli: str) -> complex:
    candidate = state.copy()
    matrices = {
        "I": np.eye(2, dtype=np.complex128),
        "X": np.array([[0.0, 1.0], [1.0, 0.0]], dtype=np.complex128),
        "Y": np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=np.complex128),
        "Z": np.diag([1.0, -1.0]).astype(np.complex128),
    }
    for q, symbol in enumerate(pauli):
        if symbol != "I":
            _apply_single_qubit_statevector(candidate, matrices[symbol], q)
    return np.vdot(state, candidate)


@dataclass(frozen=True, slots=True)
class LargeCliffordCertificate:
    qubit_count: int
    gate_count: int
    measurement_count: int
    tableau_memory_bytes: int
    canonical_pair_sample_gap: int
    global_x_expectation: int
    sampled_zz_expectations: tuple[int, ...]
    first_measurement: StabilizerMeasurement
    last_measurement: StabilizerMeasurement
    statevector_materialized: bool
    status: str
    claim_scope: str

    @property
    def passed(self) -> bool:
        return self.status.startswith("PASS")

    def to_dict(self) -> dict[str, Any]:
        return {
            "qubit_count": self.qubit_count,
            "gate_count": self.gate_count,
            "measurement_count": self.measurement_count,
            "tableau_memory_bytes": self.tableau_memory_bytes,
            "canonical_pair_sample_gap": self.canonical_pair_sample_gap,
            "global_x_expectation": self.global_x_expectation,
            "sampled_zz_expectations": list(self.sampled_zz_expectations),
            "first_measurement": self.first_measurement.to_dict(),
            "last_measurement": self.last_measurement.to_dict(),
            "statevector_materialized": self.statevector_materialized,
            "status": self.status,
            "claim_scope": self.claim_scope,
        }


@dataclass(frozen=True, slots=True)
class BoundedMagicCertificate:
    qubit_count: int
    t_gate_count: int
    branch_count: int
    maximum_branches: int
    branch_state_norm_gap: float
    direct_reference_norm_gap: float
    phase_aligned_state_gap: float
    z0_expectation_gap: float
    global_x_expectation_gap: float
    maximum_tableau_memory_bytes: int
    status: str
    claim_scope: str

    @property
    def passed(self) -> bool:
        return self.status.startswith("PASS")

    def to_dict(self) -> dict[str, Any]:
        return {
            "qubit_count": self.qubit_count,
            "t_gate_count": self.t_gate_count,
            "branch_count": self.branch_count,
            "maximum_branches": self.maximum_branches,
            "branch_state_norm_gap": self.branch_state_norm_gap,
            "direct_reference_norm_gap": self.direct_reference_norm_gap,
            "phase_aligned_state_gap": self.phase_aligned_state_gap,
            "z0_expectation_gap": self.z0_expectation_gap,
            "global_x_expectation_gap": self.global_x_expectation_gap,
            "maximum_tableau_memory_bytes": self.maximum_tableau_memory_bytes,
            "status": self.status,
            "claim_scope": self.claim_scope,
        }


@dataclass(frozen=True, slots=True)
class StabilizerMagicRuntimeCertificate:
    large_clifford: LargeCliffordCertificate
    bounded_magic: BoundedMagicCertificate
    status: str
    claim_scope: str
    source_method: str = "Aaronson-Gottesman tableau plus exact bounded T=(alpha I+beta Z) branch decomposition"

    @property
    def passed(self) -> bool:
        return self.status.startswith("PASS")

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "large_clifford": self.large_clifford.to_dict(),
            "bounded_magic": self.bounded_magic.to_dict(),
            "status": self.status,
            "claim_scope": self.claim_scope,
            "source_method": self.source_method,
        }
        payload["sha256"] = hashlib.sha256(
            json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        return payload


def qualify_large_clifford_stabilizer(
    *,
    qubit_count: int = 1000,
    seed: int = 20260801,
) -> LargeCliffordCertificate:
    n = int(qubit_count)
    state = StabilizerTableau.zero_state(n)
    state.h(0)
    for target in range(1, n):
        state.cnot(0, target)

    global_x = state.expectation_pauli("X" * n)
    sample_sites = tuple(sorted({1, max(1, n // 4), max(1, n // 2), max(1, 3 * n // 4), n - 1}))
    zz_values = []
    for site in sample_sites:
        pauli = ["I"] * n
        pauli[0] = "Z"
        pauli[site] = "Z"
        zz_values.append(state.expectation_pauli(pauli))

    measured = state.copy()
    rng = np.random.default_rng(seed)
    first = measured.measure_z(0, rng=rng)
    last = measured.measure_z(n - 1, rng=rng)
    pair_gap = state.canonical_pair_sample_gap(sample_count=128, seed=seed + 1)
    passed = (
        global_x == 1
        and all(value == 1 for value in zz_values)
        and pair_gap == 0
        and not first.deterministic
        and last.deterministic
        and first.outcome == last.outcome
    )
    return LargeCliffordCertificate(
        qubit_count=n,
        gate_count=state.gate_count,
        measurement_count=measured.measurement_count,
        tableau_memory_bytes=state.memory_bytes,
        canonical_pair_sample_gap=pair_gap,
        global_x_expectation=global_x,
        sampled_zz_expectations=tuple(zz_values),
        first_measurement=first,
        last_measurement=last,
        statevector_materialized=False,
        status="PASS_CLIFFORD_1000_TABLEAU_EXACT" if passed else "FAIL_CLIFFORD_TABLEAU_CONTROL",
        claim_scope=(
            "Exact Clifford H/S/CNOT/Pauli/measurement tableau control at the declared qubit count; "
            "not a non-Clifford, noisy-device, or arbitrary Hamiltonian simulation certificate."
        ),
    )


def qualify_bounded_magic_injection(
    *,
    qubit_count: int = 10,
    t_gate_count: int = 5,
    tolerance: float = 1e-12,
) -> BoundedMagicCertificate:
    n = int(qubit_count)
    t_count = int(t_gate_count)
    maximum_branches = 1 << t_count
    runtime = BoundedMagicInjectionRuntime(
        n,
        maximum_t_gates=t_count,
        maximum_branches=maximum_branches,
        materialization_qubit_limit=n,
    )
    for q in range(min(5, n)):
        runtime.apply_clifford("H", q)
    for q in range(min(5, n)):
        target = q + 5
        if target < n:
            runtime.apply_clifford("CNOT", q, target)
    for q in range(min(t_count, n)):
        runtime.apply_t((2 * q) % n)
        runtime.apply_clifford("S", (2 * q + 1) % n)
    for q in range(n - 1):
        if q % 2 == 0:
            runtime.apply_clifford("CZ", q, q + 1)
    runtime.apply_clifford("H", n - 1)

    branch_state = runtime.materialize_branch_sum()
    direct_state = runtime.materialize_direct_reference()
    branch_norm_gap = abs(float(np.vdot(branch_state, branch_state).real) - 1.0)
    direct_norm_gap = abs(float(np.vdot(direct_state, direct_state).real) - 1.0)
    state_gap = _phase_aligned_gap(direct_state, branch_state)
    z0 = "Z" + "I" * (n - 1)
    global_x = "X" * n
    z_gap = abs(_pauli_expectation_statevector(direct_state, z0) - _pauli_expectation_statevector(branch_state, z0))
    x_gap = abs(
        _pauli_expectation_statevector(direct_state, global_x)
        - _pauli_expectation_statevector(branch_state, global_x)
    )
    max_tableau_memory = max(branch.tableau.memory_bytes for branch in runtime.branches)
    passed = (
        len(runtime.branches) == maximum_branches
        and branch_norm_gap <= tolerance
        and direct_norm_gap <= tolerance
        and state_gap <= tolerance
        and float(z_gap) <= tolerance
        and float(x_gap) <= tolerance
    )
    return BoundedMagicCertificate(
        qubit_count=n,
        t_gate_count=t_count,
        branch_count=len(runtime.branches),
        maximum_branches=maximum_branches,
        branch_state_norm_gap=branch_norm_gap,
        direct_reference_norm_gap=direct_norm_gap,
        phase_aligned_state_gap=state_gap,
        z0_expectation_gap=float(z_gap),
        global_x_expectation_gap=float(x_gap),
        maximum_tableau_memory_bytes=max_tableau_memory,
        status="PASS_BOUNDED_EXACT_MAGIC_INJECTION" if passed else "FAIL_BOUNDED_MAGIC_INJECTION_CONTROL",
        claim_scope=(
            "Exact bounded T-gate branch decomposition checked against an independent state-vector reference; "
            "branch cost remains exponential in T count and no 200-qubit moderate-magic claim is made."
        ),
    )


def qualify_stabilizer_magic_runtime(
    *,
    clifford_qubit_count: int = 1000,
    magic_qubit_count: int = 10,
    magic_t_gate_count: int = 5,
    tolerance: float = 1e-12,
    seed: int = 20260801,
) -> StabilizerMagicRuntimeCertificate:
    large = qualify_large_clifford_stabilizer(qubit_count=clifford_qubit_count, seed=seed)
    magic = qualify_bounded_magic_injection(
        qubit_count=magic_qubit_count,
        t_gate_count=magic_t_gate_count,
        tolerance=tolerance,
    )
    passed = large.passed and magic.passed
    return StabilizerMagicRuntimeCertificate(
        large_clifford=large,
        bounded_magic=magic,
        status=(
            "PASS_CLIFFORD_1000_AND_BOUNDED_MAGIC_INJECTION"
            if passed
            else "FAIL_STABILIZER_MAGIC_RUNTIME_CONTROL"
        ),
        claim_scope=(
            "The pure-Clifford tableau scales to the declared 1000-qubit control. Magic injection is qualified "
            "only for the explicit small-n, small-T branch envelope; STN/CAMPS large-magic scalability remains open."
        ),
    )
