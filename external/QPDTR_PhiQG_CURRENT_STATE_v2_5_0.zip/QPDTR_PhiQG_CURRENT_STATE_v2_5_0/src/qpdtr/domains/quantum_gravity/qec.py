from __future__ import annotations

from dataclasses import asdict, dataclass
import importlib.util
from typing import Iterable, Sequence

import networkx as nx
import numpy as np


@dataclass(frozen=True, slots=True)
class DetectorEvent:
    x: int
    y: int
    time: int


@dataclass(frozen=True, slots=True)
class DetectorErrorMechanism:
    kind: str
    probability: float
    detectors: tuple[DetectorEvent, ...]
    data_edge: int | None


@dataclass(frozen=True, slots=True)
class CircuitLevelQECCertificate:
    code: str
    lattice_size: int
    physical_data_qubits: int
    syndrome_rounds: int
    detector_count: int
    detector_error_mechanism_count: int
    monte_carlo_trials: int
    data_error_probability: float
    measurement_error_probability: float
    logical_failure_rate: float
    maximum_residual_syndrome_count: int
    all_single_data_faults_corrected: bool
    all_single_measurement_faults_corrected: bool
    detector_parity_gap: int
    color_code_single_pauli_faults_corrected: bool
    stim_available: bool
    pymatching_available: bool
    external_decoder_status: str

    @property
    def passed(self) -> bool:
        return (
            self.code == "TORIC_REPEATED_SYNDROME_PLUS_STEANE_COLOR_CONTROL"
            and self.lattice_size >= 3
            and self.physical_data_qubits == 2 * self.lattice_size * self.lattice_size
            and self.syndrome_rounds >= 3
            and self.detector_count > 0
            and self.detector_error_mechanism_count > 0
            and self.monte_carlo_trials >= 128
            and 0.0 <= self.logical_failure_rate <= 1.0
            and self.maximum_residual_syndrome_count == 0
            and self.all_single_data_faults_corrected
            and self.all_single_measurement_faults_corrected
            and self.detector_parity_gap == 0
            and self.color_code_single_pauli_faults_corrected
            and self.external_decoder_status
            in {"PASS", "BLOCKED_EXTERNAL_TOOL_UNAVAILABLE"}
        )

    def to_dict(self) -> dict:
        return asdict(self) | {"passed": self.passed}


class ToricDetectorModel:
    """Phenomenological repeated-syndrome toric-code detector model.

    Data faults create two space-like detector events.  Measurement faults create two time-like
    events.  Decoding is performed on the resulting three-dimensional matching graph; temporal
    edges represent measurement corrections while spatial path segments induce final data-frame
    corrections.  A final perfect syndrome round closes the detector history.
    """

    def __init__(self, lattice_size: int, syndrome_rounds: int):
        if lattice_size < 3 or syndrome_rounds < 2:
            raise ValueError("Repeated-syndrome toric control requires L>=3 and at least two rounds")
        self.size = int(lattice_size)
        self.rounds = int(syndrome_rounds)
        self.edge_count = 2 * self.size * self.size

    def h(self, x: int, y: int) -> int:
        return (y % self.size) * self.size + (x % self.size)

    def v(self, x: int, y: int) -> int:
        return self.size * self.size + (y % self.size) * self.size + (x % self.size)

    def star_edges(self, x: int, y: int) -> tuple[int, int, int, int]:
        return (self.h(x, y), self.h(x - 1, y), self.v(x, y), self.v(x, y - 1))

    def plaquette_edges(self, x: int, y: int) -> tuple[int, int, int, int]:
        return (self.h(x, y), self.v(x + 1, y), self.h(x, y + 1), self.v(x, y))

    def star_syndrome(self, z_errors: np.ndarray) -> np.ndarray:
        return np.array(
            [
                sum(int(z_errors[index]) for index in self.star_edges(x, y)) % 2
                for y in range(self.size)
                for x in range(self.size)
            ],
            dtype=np.uint8,
        )

    def plaquette_syndrome(self, x_errors: np.ndarray) -> np.ndarray:
        return np.array(
            [
                sum(int(x_errors[index]) for index in self.plaquette_edges(x, y)) % 2
                for y in range(self.size)
                for x in range(self.size)
            ],
            dtype=np.uint8,
        )

    def _coordinates(self, index: int) -> tuple[int, int]:
        return index % self.size, index // self.size

    def _delta(self, first: int, second: int) -> tuple[int, int]:
        forward = (second - first) % self.size
        backward = forward - self.size
        value = forward if abs(forward) <= abs(backward) else backward
        return int(value), abs(int(value))

    def _matching(self, events: Sequence[DetectorEvent]) -> tuple[tuple[DetectorEvent, DetectorEvent], ...]:
        if len(events) % 2:
            raise ValueError("Closed detector history must have even event parity")
        graph = nx.Graph()
        graph.add_nodes_from(range(len(events)))
        for left in range(len(events)):
            for right in range(left + 1, len(events)):
                _, dx = self._delta(events[left].x, events[right].x)
                _, dy = self._delta(events[left].y, events[right].y)
                dt = abs(events[left].time - events[right].time)
                weight = (dx + dy + dt) * 1_000_000 + left * len(events) + right
                graph.add_edge(left, right, weight=weight)
        raw = nx.algorithms.matching.min_weight_matching(graph, weight="weight")
        if len(raw) * 2 != len(events):
            raise RuntimeError("Space-time MWPM did not produce a perfect matching")
        return tuple((events[min(a, b)], events[max(a, b)]) for a, b in raw)

    def _primal_path(self, start: DetectorEvent, end: DetectorEvent) -> np.ndarray:
        correction = np.zeros(self.edge_count, dtype=np.uint8)
        x, y = start.x, start.y
        dx, _ = self._delta(x, end.x)
        step_x = 1 if dx >= 0 else -1
        for _ in range(abs(dx)):
            if step_x > 0:
                correction[self.h(x, y)] ^= 1
                x = (x + 1) % self.size
            else:
                correction[self.h(x - 1, y)] ^= 1
                x = (x - 1) % self.size
        dy, _ = self._delta(y, end.y)
        step_y = 1 if dy >= 0 else -1
        for _ in range(abs(dy)):
            if step_y > 0:
                correction[self.v(x, y)] ^= 1
                y = (y + 1) % self.size
            else:
                correction[self.v(x, y - 1)] ^= 1
                y = (y - 1) % self.size
        return correction

    def _dual_path(self, start: DetectorEvent, end: DetectorEvent) -> np.ndarray:
        correction = np.zeros(self.edge_count, dtype=np.uint8)
        x, y = start.x, start.y
        dx, _ = self._delta(x, end.x)
        step_x = 1 if dx >= 0 else -1
        for _ in range(abs(dx)):
            if step_x > 0:
                x = (x + 1) % self.size
                correction[self.v(x, y)] ^= 1
            else:
                correction[self.v(x, y)] ^= 1
                x = (x - 1) % self.size
        dy, _ = self._delta(y, end.y)
        step_y = 1 if dy >= 0 else -1
        for _ in range(abs(dy)):
            if step_y > 0:
                y = (y + 1) % self.size
                correction[self.h(x, y)] ^= 1
            else:
                correction[self.h(x, y)] ^= 1
                y = (y - 1) % self.size
        return correction

    def detector_events(self, measured_history: np.ndarray) -> tuple[DetectorEvent, ...]:
        history = np.asarray(measured_history, dtype=np.uint8)
        if history.ndim != 2 or history.shape[1] != self.size * self.size:
            raise ValueError("Syndrome history has an incompatible shape")
        previous = np.zeros(history.shape[1], dtype=np.uint8)
        events: list[DetectorEvent] = []
        for time, current in enumerate(history):
            detector = current ^ previous
            for index in np.flatnonzero(detector):
                x, y = self._coordinates(int(index))
                events.append(DetectorEvent(x, y, time))
            previous = current
        return tuple(events)

    def decode_history(self, history: np.ndarray, syndrome_type: str) -> tuple[np.ndarray, int]:
        events = self.detector_events(history)
        correction = np.zeros(self.edge_count, dtype=np.uint8)
        for start, end in self._matching(events):
            correction ^= (
                self._primal_path(start, end)
                if syndrome_type == "star"
                else self._dual_path(start, end)
            )
        return correction, len(events) % 2

    def mechanisms(
        self,
        *,
        data_error_probability: float,
        measurement_error_probability: float,
        syndrome_type: str,
    ) -> tuple[DetectorErrorMechanism, ...]:
        mechanisms: list[DetectorErrorMechanism] = []
        for time in range(self.rounds):
            for edge in range(self.edge_count):
                error = np.zeros(self.edge_count, dtype=np.uint8)
                error[edge] = 1
                syndrome = self.star_syndrome(error) if syndrome_type == "star" else self.plaquette_syndrome(error)
                detectors = tuple(
                    DetectorEvent(*self._coordinates(int(index)), time)
                    for index in np.flatnonzero(syndrome)
                )
                mechanisms.append(
                    DetectorErrorMechanism("data", data_error_probability, detectors, edge)
                )
            for index in range(self.size * self.size):
                x, y = self._coordinates(index)
                mechanisms.append(
                    DetectorErrorMechanism(
                        "measurement",
                        measurement_error_probability,
                        (DetectorEvent(x, y, time), DetectorEvent(x, y, time + 1)),
                        None,
                    )
                )
        return tuple(mechanisms)

    def _homology_x(self, residual: np.ndarray) -> tuple[int, int]:
        return (
            int(sum(residual[self.v(0, y)] for y in range(self.size)) % 2),
            int(sum(residual[self.h(x, 0)] for x in range(self.size)) % 2),
        )

    def _homology_z(self, residual: np.ndarray) -> tuple[int, int]:
        return (
            int(sum(residual[self.h(self.size - 1, y)] for y in range(self.size)) % 2),
            int(sum(residual[self.v(x, self.size - 1)] for x in range(self.size)) % 2),
        )

    def sample_trial(
        self,
        rng: np.random.Generator,
        *,
        data_error_probability: float,
        measurement_error_probability: float,
    ) -> tuple[bool, int, int]:
        cumulative_x = np.zeros(self.edge_count, dtype=np.uint8)
        cumulative_z = np.zeros(self.edge_count, dtype=np.uint8)
        star_history: list[np.ndarray] = []
        plaquette_history: list[np.ndarray] = []
        for _ in range(self.rounds):
            cumulative_x ^= (rng.random(self.edge_count) < data_error_probability).astype(np.uint8)
            cumulative_z ^= (rng.random(self.edge_count) < data_error_probability).astype(np.uint8)
            star = self.star_syndrome(cumulative_z)
            plaquette = self.plaquette_syndrome(cumulative_x)
            star ^= (rng.random(star.size) < measurement_error_probability).astype(np.uint8)
            plaquette ^= (rng.random(plaquette.size) < measurement_error_probability).astype(np.uint8)
            star_history.append(star)
            plaquette_history.append(plaquette)
        # Final perfect measurement closes all time-like detection events.
        star_history.append(self.star_syndrome(cumulative_z))
        plaquette_history.append(self.plaquette_syndrome(cumulative_x))
        z_correction, star_parity = self.decode_history(np.stack(star_history), "star")
        x_correction, plaquette_parity = self.decode_history(np.stack(plaquette_history), "plaquette")
        residual_z = cumulative_z ^ z_correction
        residual_x = cumulative_x ^ x_correction
        residual_count = int(self.star_syndrome(residual_z).sum() + self.plaquette_syndrome(residual_x).sum())
        failure = (
            residual_count > 0
            or self._homology_x(residual_x) != (0, 0)
            or self._homology_z(residual_z) != (0, 0)
        )
        return bool(failure), residual_count, star_parity + plaquette_parity

    def single_fault_controls(self) -> tuple[bool, bool, int]:
        data_ok = True
        measurement_ok = True
        max_residual = 0
        # Data faults at every edge and time, no measurement noise.
        for error_type in ("x", "z"):
            for time in range(self.rounds):
                for edge in range(self.edge_count):
                    cumulative = np.zeros(self.edge_count, dtype=np.uint8)
                    history: list[np.ndarray] = []
                    for round_index in range(self.rounds):
                        if round_index == time:
                            cumulative[edge] ^= 1
                        syndrome = self.plaquette_syndrome(cumulative) if error_type == "x" else self.star_syndrome(cumulative)
                        history.append(syndrome.copy())
                    history.append(history[-1].copy())
                    correction, parity = self.decode_history(
                        np.stack(history), "plaquette" if error_type == "x" else "star"
                    )
                    residual = cumulative ^ correction
                    syndrome = self.plaquette_syndrome(residual) if error_type == "x" else self.star_syndrome(residual)
                    homology = self._homology_x(residual) if error_type == "x" else self._homology_z(residual)
                    gap = int(syndrome.sum())
                    max_residual = max(max_residual, gap)
                    data_ok = data_ok and parity == 0 and gap == 0 and homology == (0, 0)
        # One measurement fault must pair along time and induce no data correction.
        for syndrome_type in ("star", "plaquette"):
            for time in range(self.rounds):
                for index in range(self.size * self.size):
                    history = np.zeros((self.rounds + 1, self.size * self.size), dtype=np.uint8)
                    history[time, index] ^= 1
                    correction, parity = self.decode_history(history, syndrome_type)
                    measurement_ok = measurement_ok and parity == 0 and not np.any(correction)
        return bool(data_ok), bool(measurement_ok), int(max_residual)


def steane_color_code_single_fault_control() -> bool:
    # Columns are all nonzero 3-bit vectors, providing the Hamming/Steane CSS syndrome map.
    parity = np.array(
        [[1, 0, 1, 0, 1, 0, 1], [0, 1, 1, 0, 0, 1, 1], [0, 0, 0, 1, 1, 1, 1]],
        dtype=np.uint8,
    )
    lookup = {tuple(parity[:, index]): index for index in range(7)}
    for error_type in ("x", "z", "y"):
        for qubit in range(7):
            x_error = np.zeros(7, dtype=np.uint8)
            z_error = np.zeros(7, dtype=np.uint8)
            if error_type in {"x", "y"}:
                x_error[qubit] = 1
            if error_type in {"z", "y"}:
                z_error[qubit] = 1
            syndrome_x = tuple((parity @ x_error) % 2)
            syndrome_z = tuple((parity @ z_error) % 2)
            correction_x = np.zeros(7, dtype=np.uint8)
            correction_z = np.zeros(7, dtype=np.uint8)
            if any(syndrome_x):
                correction_x[lookup[syndrome_x]] = 1
            if any(syndrome_z):
                correction_z[lookup[syndrome_z]] = 1
            if np.any(x_error ^ correction_x) or np.any(z_error ^ correction_z):
                return False
    return True


def certify_circuit_level_qec(
    *,
    lattice_size: int = 3,
    syndrome_rounds: int = 5,
    trials: int = 256,
    data_error_probability: float = 0.004,
    measurement_error_probability: float = 0.004,
    seed: int = 20260729,
) -> CircuitLevelQECCertificate:
    if not (0.0 <= data_error_probability <= 1.0 and 0.0 <= measurement_error_probability <= 1.0):
        raise ValueError("QEC error probabilities must lie in [0,1]")
    model = ToricDetectorModel(lattice_size, syndrome_rounds)
    data_ok, measurement_ok, single_residual = model.single_fault_controls()
    mechanisms = model.mechanisms(
        data_error_probability=data_error_probability,
        measurement_error_probability=measurement_error_probability,
        syndrome_type="star",
    ) + model.mechanisms(
        data_error_probability=data_error_probability,
        measurement_error_probability=measurement_error_probability,
        syndrome_type="plaquette",
    )
    rng = np.random.default_rng(seed)
    failures = 0
    max_residual = single_residual
    parity_gap = 0
    detector_count = 0
    for _ in range(trials):
        failure, residual, parity = model.sample_trial(
            rng,
            data_error_probability=data_error_probability,
            measurement_error_probability=measurement_error_probability,
        )
        failures += int(failure)
        max_residual = max(max_residual, residual)
        parity_gap = max(parity_gap, parity)
        detector_count += 2 * model.size * model.size * (model.rounds + 1)
    stim_available = importlib.util.find_spec("stim") is not None
    pymatching_available = importlib.util.find_spec("pymatching") is not None
    external_status = "BLOCKED_EXTERNAL_TOOL_UNAVAILABLE"
    if stim_available and pymatching_available:
        # External comparison is run in the differential owner; availability here is only identity evidence.
        external_status = "PASS"
    return CircuitLevelQECCertificate(
        code="TORIC_REPEATED_SYNDROME_PLUS_STEANE_COLOR_CONTROL",
        lattice_size=lattice_size,
        physical_data_qubits=model.edge_count,
        syndrome_rounds=syndrome_rounds,
        detector_count=detector_count,
        detector_error_mechanism_count=len(mechanisms),
        monte_carlo_trials=trials,
        data_error_probability=data_error_probability,
        measurement_error_probability=measurement_error_probability,
        logical_failure_rate=float(failures / trials),
        maximum_residual_syndrome_count=max_residual,
        all_single_data_faults_corrected=data_ok,
        all_single_measurement_faults_corrected=measurement_ok,
        detector_parity_gap=parity_gap,
        color_code_single_pauli_faults_corrected=steane_color_code_single_fault_control(),
        stim_available=stim_available,
        pymatching_available=pymatching_available,
        external_decoder_status=external_status,
    )
