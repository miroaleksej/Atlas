"""Scientific domains owned by QPDTR."""
