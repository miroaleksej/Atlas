"""Current-state physical-law registry bundled with the PhiQG runtime."""
