"""Quantum Physical Digital Twin Runtime — PhiQG domain."""

__version__ = "2.5.0"
