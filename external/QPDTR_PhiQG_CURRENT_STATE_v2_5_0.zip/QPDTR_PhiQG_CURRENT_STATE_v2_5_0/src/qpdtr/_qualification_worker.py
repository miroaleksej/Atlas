from __future__ import annotations

import importlib
import pickle
from pathlib import Path
import sys
import traceback
from typing import Any

from threadpoolctl import threadpool_limits


def _execute_entry(entry: tuple[str, str, tuple[Any, ...], dict[str, Any]]) -> Any:
    module_name, function_name, args, kwargs = entry
    function = getattr(importlib.import_module(module_name), function_name)
    return function(*tuple(args), **dict(kwargs))


def execute_request(request_path: str | Path) -> None:
    """Execute registered owners and atomically persist their certificates.

    This module is process-isolation infrastructure only. It contains no scientific
    algorithm; every result is produced by the authoritative module/function named in
    the request prepared by :mod:`qpdtr.owner`.
    """

    path = Path(request_path)
    with path.open("rb") as stream:
        entries, result_name = pickle.load(stream)
    try:
        with threadpool_limits(limits=1):
            results = [_execute_entry(entry) for entry in entries]
        payload: tuple[str, Any] = ("PASS", results)
    except BaseException:
        payload = ("FAIL", traceback.format_exc())
    result_path = Path(result_name)
    temporary_path = Path(str(result_path) + ".tmp")
    with temporary_path.open("wb") as stream:
        pickle.dump(payload, stream, protocol=pickle.HIGHEST_PROTOCOL)
        stream.flush()
    temporary_path.replace(result_path)


def main() -> int:
    if len(sys.argv) != 2:
        return 2
    execute_request(sys.argv[1])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
