#define PY_SSIZE_T_CLEAN
#include <Python.h>
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <numpy/arrayobject.h>
#include <complex>
#include <vector>
#include <cmath>
#include <cstdint>
#include <algorithm>
#ifdef _OPENMP
#include <omp.h>
#endif

namespace {

bool is_power_of_two(npy_intp value) {
    return value > 0 && (value & (value - 1)) == 0;
}

int integer_log2(npy_intp value) {
    int result = 0;
    while (value > 1) {
        value >>= 1;
        ++result;
    }
    return result;
}

PyObject* apply_gate(PyObject*, PyObject* args) {
    PyObject* state_obj = nullptr;
    PyObject* gate_obj = nullptr;
    PyObject* targets_obj = nullptr;
    if (!PyArg_ParseTuple(args, "OOO", &state_obj, &gate_obj, &targets_obj)) {
        return nullptr;
    }

    PyArrayObject* state = reinterpret_cast<PyArrayObject*>(
        PyArray_FROM_OTF(state_obj, NPY_COMPLEX128, NPY_ARRAY_IN_ARRAY)
    );
    PyArrayObject* gate = reinterpret_cast<PyArrayObject*>(
        PyArray_FROM_OTF(gate_obj, NPY_COMPLEX128, NPY_ARRAY_IN_ARRAY)
    );
    if (!state || !gate) {
        Py_XDECREF(state);
        Py_XDECREF(gate);
        return nullptr;
    }
    if (PyArray_NDIM(state) != 1 || !is_power_of_two(PyArray_DIM(state, 0))) {
        Py_DECREF(state);
        Py_DECREF(gate);
        PyErr_SetString(PyExc_ValueError, "state must be a one-dimensional power-of-two complex128 array");
        return nullptr;
    }
    if (PyArray_NDIM(gate) != 2 || PyArray_DIM(gate, 0) != PyArray_DIM(gate, 1) ||
        !is_power_of_two(PyArray_DIM(gate, 0))) {
        Py_DECREF(state);
        Py_DECREF(gate);
        PyErr_SetString(PyExc_ValueError, "gate must be a square power-of-two complex128 array");
        return nullptr;
    }

    PyObject* target_sequence = PySequence_Fast(targets_obj, "targets must be a sequence of integers");
    if (!target_sequence) {
        Py_DECREF(state);
        Py_DECREF(gate);
        return nullptr;
    }
    const Py_ssize_t target_count = PySequence_Fast_GET_SIZE(target_sequence);
    const npy_intp gate_dimension = PyArray_DIM(gate, 0);
    if (target_count < 1 || target_count > 4 || (static_cast<npy_intp>(1) << target_count) != gate_dimension) {
        Py_DECREF(target_sequence);
        Py_DECREF(state);
        Py_DECREF(gate);
        PyErr_SetString(PyExc_ValueError, "target count must match the gate dimension and be between one and four");
        return nullptr;
    }

    const int qubit_count = integer_log2(PyArray_DIM(state, 0));
    std::vector<int> targets(static_cast<size_t>(target_count));
    std::vector<bool> used(static_cast<size_t>(qubit_count), false);
    for (Py_ssize_t i = 0; i < target_count; ++i) {
        long value = PyLong_AsLong(PySequence_Fast_GET_ITEM(target_sequence, i));
        if (PyErr_Occurred() || value < 0 || value >= qubit_count || used[static_cast<size_t>(value)]) {
            Py_DECREF(target_sequence);
            Py_DECREF(state);
            Py_DECREF(gate);
            if (!PyErr_Occurred()) {
                PyErr_SetString(PyExc_ValueError, "targets must be distinct in-range qubit indices");
            }
            return nullptr;
        }
        targets[static_cast<size_t>(i)] = static_cast<int>(value);
        used[static_cast<size_t>(value)] = true;
    }
    Py_DECREF(target_sequence);

    std::vector<int> remaining;
    remaining.reserve(static_cast<size_t>(qubit_count - target_count));
    for (int q = 0; q < qubit_count; ++q) {
        if (!used[static_cast<size_t>(q)]) {
            remaining.push_back(q);
        }
    }

    npy_intp output_dims[1] = {PyArray_DIM(state, 0)};
    PyArrayObject* output = reinterpret_cast<PyArrayObject*>(PyArray_SimpleNew(1, output_dims, NPY_COMPLEX128));
    if (!output) {
        Py_DECREF(state);
        Py_DECREF(gate);
        return nullptr;
    }

    const auto* state_data = reinterpret_cast<const std::complex<double>*>(PyArray_DATA(state));
    const auto* gate_data = reinterpret_cast<const std::complex<double>*>(PyArray_DATA(gate));
    auto* output_data = reinterpret_cast<std::complex<double>*>(PyArray_DATA(output));
    const uint64_t block_count = uint64_t{1} << remaining.size();
    const int local_dimension = static_cast<int>(gate_dimension);

    Py_BEGIN_ALLOW_THREADS
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (int64_t block = 0; block < static_cast<int64_t>(block_count); ++block) {
        uint64_t base = 0;
        for (size_t r = 0; r < remaining.size(); ++r) {
            const uint64_t bit = (static_cast<uint64_t>(block) >> (remaining.size() - 1 - r)) & 1ULL;
            const int physical_bit = qubit_count - 1 - remaining[r];
            base |= bit << physical_bit;
        }
        std::complex<double> local_in[16]{};
        std::complex<double> local_out[16]{};
        uint64_t indices[16]{};
        for (int local = 0; local < local_dimension; ++local) {
            uint64_t index = base;
            for (Py_ssize_t t = 0; t < target_count; ++t) {
                const uint64_t bit = (static_cast<uint64_t>(local) >> (target_count - 1 - t)) & 1ULL;
                const int physical_bit = qubit_count - 1 - targets[static_cast<size_t>(t)];
                index |= bit << physical_bit;
            }
            indices[local] = index;
            local_in[local] = state_data[index];
        }
        for (int row = 0; row < local_dimension; ++row) {
            std::complex<double> sum = 0.0;
            for (int col = 0; col < local_dimension; ++col) {
                sum += gate_data[row * local_dimension + col] * local_in[col];
            }
            local_out[row] = sum;
        }
        for (int local = 0; local < local_dimension; ++local) {
            output_data[indices[local]] = local_out[local];
        }
    }
    Py_END_ALLOW_THREADS

    Py_DECREF(state);
    Py_DECREF(gate);
    return reinterpret_cast<PyObject*>(output);
}

PyObject* build_info(PyObject*, PyObject*) {
    PyObject* result = PyDict_New();
    if (!result) return nullptr;
#ifdef _OPENMP
    PyDict_SetItemString(result, "openmp", Py_True);
    PyDict_SetItemString(result, "max_threads", PyLong_FromLong(omp_get_max_threads()));
#else
    PyDict_SetItemString(result, "openmp", Py_False);
    PyDict_SetItemString(result, "max_threads", PyLong_FromLong(1));
#endif
#if defined(__AVX512F__)
    PyDict_SetItemString(result, "simd", PyUnicode_FromString("AVX512F"));
#elif defined(__AVX2__)
    PyDict_SetItemString(result, "simd", PyUnicode_FromString("AVX2"));
#elif defined(__SSE2__)
    PyDict_SetItemString(result, "simd", PyUnicode_FromString("SSE2"));
#else
    PyDict_SetItemString(result, "simd", PyUnicode_FromString("SCALAR"));
#endif
    PyDict_SetItemString(result, "complex_precision", PyUnicode_FromString("complex128"));
    return result;
}

PyMethodDef methods[] = {
    {"apply_gate", apply_gate, METH_VARARGS, "Apply a one- to four-qubit dense gate to a complex128 state vector."},
    {"build_info", build_info, METH_NOARGS, "Return native-kernel build information."},
    {nullptr, nullptr, 0, nullptr},
};

PyModuleDef module = {
    PyModuleDef_HEAD_INIT,
    "_native",
    "ΦQG Atlas native OpenMP state-vector kernels.",
    -1,
    methods,
};

} // namespace

PyMODINIT_FUNC PyInit__native(void) {
    import_array();
    return PyModule_Create(&module);
}
