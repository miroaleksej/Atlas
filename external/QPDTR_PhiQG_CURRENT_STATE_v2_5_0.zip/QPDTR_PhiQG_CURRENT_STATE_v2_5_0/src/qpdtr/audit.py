from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Any


# These values measure host/runtime performance, not the mathematical result.
# Model-time quantities such as ``elapsed_time`` are deliberately not listed here.
_PERFORMANCE_KEYS = frozenset(
    {
        "contraction_planning_seconds",
        "contraction_seconds",
        "native_max_threads",
    }
)


@dataclass(frozen=True, slots=True)
class SemanticTelemetrySplit:
    semantic_payload: dict[str, Any]
    performance_metrics: dict[str, Any]


def split_semantic_payload(payload: dict[str, Any]) -> SemanticTelemetrySplit:
    """Remove non-deterministic performance measurements from a result payload.

    The returned semantic payload preserves every physical input, output, error bound,
    representation choice and admission decision.  Only explicitly enumerated wall-clock
    measurements are moved into a path-addressed telemetry map.  The input is not mutated.
    """

    telemetry: dict[str, Any] = {}

    def visit(value: Any, path: str) -> Any:
        if isinstance(value, dict):
            result: dict[str, Any] = {}
            for key in sorted(value):
                item_path = f"{path}.{key}" if path else key
                if key in _PERFORMANCE_KEYS:
                    telemetry[item_path] = deepcopy(value[key])
                    continue
                result[key] = visit(value[key], item_path)
            return result
        if isinstance(value, list):
            return [visit(item, f"{path}[{index}]") for index, item in enumerate(value)]
        if isinstance(value, tuple):
            return tuple(visit(item, f"{path}[{index}]") for index, item in enumerate(value))
        return deepcopy(value)

    semantic = visit(payload, "")
    if not isinstance(semantic, dict):  # defensive; the public contract accepts a dict only
        raise TypeError("Semantic payload root must remain a mapping")
    return SemanticTelemetrySplit(semantic_payload=semantic, performance_metrics=telemetry)
