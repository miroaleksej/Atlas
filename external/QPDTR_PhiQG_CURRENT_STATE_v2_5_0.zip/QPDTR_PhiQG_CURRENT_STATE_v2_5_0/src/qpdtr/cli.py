from __future__ import annotations

import argparse
import json
from pathlib import Path

from .owner import QuantumGravityDynamicsOwner


def main() -> int:
    parser = argparse.ArgumentParser(description="Execute the authoritative current PhiQG research bundle")
    parser.add_argument("--report-dir", default="reports/current")
    args = parser.parse_args()
    result = QuantumGravityDynamicsOwner().execute(Path(args.report_dir))
    print(
        json.dumps(
            {
                "verdict": result["verdict"],
                "evidence_grade": result["evidence_grade"],
                "control_summary": result["control_summary"],
                "target_summary": result["target_summary"],
                "source_digest": result["source_digest"],
                "execution_digest": result["execution_digest"],
            },
            indent=2,
            ensure_ascii=False,
        )
    )
    return 0 if not result["control_summary"]["failed"] and not result["target_summary"]["failed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
