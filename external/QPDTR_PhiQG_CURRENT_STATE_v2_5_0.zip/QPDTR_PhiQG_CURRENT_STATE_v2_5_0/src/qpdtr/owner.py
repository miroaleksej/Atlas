from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import importlib
import pickle
import tempfile
import os
import subprocess
import sys
import time
import traceback
import json
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
from threadpoolctl import threadpool_limits

from .model import PhiQGModelSpec
from .audit import split_semantic_payload
from .domains.quantum_gravity.boundary import isotropic_livine_speziale_boundary_family
from .domains.quantum_gravity.eprl_adapter import (
    AdmittedVertexAmplitudeCache,
    SL2CfoamAdapter,
    load_raw_tensor,
)
from .domains.quantum_gravity.error_budget import (
    ErrorComponent, QuantumErrorAllocation, build_error_budget,
    build_unified_quantum_error_budget, qualify_error_interference_control,
)
from .domains.quantum_gravity.differential import run_differential_benchmarks
from .domains.quantum_gravity.frg import beta_newton_r2, beta_newton_r5, positive_fixed_point
from .domains.quantum_gravity.lorentzian import causal_lorentzian_bisimplex
from .domains.quantum_gravity.law_validation import PhysicalLawQualificationOwner
from .domains.quantum_gravity.matter import simplicial_qubit_matter_control
from .domains.quantum_gravity.quantum import (
    AdaptiveExecutionPolicy,
    qualify_structured_50_qubit_ttn_hamiltonian_dynamics,
    qualify_high_treewidth_contraction_fallback,
)
from .domains.quantum_gravity.adaptive_ttn import (
    qualify_persistent_adaptive_ttn,
    qualify_scalable_adaptive_ttn,
)
from .domains.quantum_gravity.backend_qualification import qualify_real_backends
from .domains.quantum_gravity.tempo import qualify_process_tensor_memory
from .domains.quantum_gravity.generator_learning import qualify_bounded_generator_learning
from .domains.quantum_gravity.stabilizer import qualify_stabilizer_magic_runtime
from .domains.quantum_gravity.camps import qualify_camps_runtime
from .domains.quantum_gravity.cayley_impurity import qualify_cayley_impurity_runtime
from .domains.quantum_gravity.portfolio import qualify_method_route
from .domains.quantum_gravity.cptp_tensor_train import qualify_cptp_tensor_train_runtime
from .domains.quantum_gravity.basis_adaptive_sparse import qualify_basis_adaptive_sparse_runtime
from .domains.quantum_gravity.adversarial_representation import qualify_representation_adversarial_benchmark
from .domains.quantum_gravity.fermionic_gaussian import qualify_fermionic_gaussian_runtime
from .domains.quantum_gravity.schwarzschild_4d import qualify_schwarzschild_4d_radial_modes
from .domains.quantum_gravity.decision_diagram import qualify_phase_polynomial_decision_diagram
from .domains.quantum_gravity.code_compiled_tn import qualify_code_compiled_tensor_network
from .domains.quantum_gravity.structural_router import qualify_phi_q1000_arfe
from .domains.quantum_gravity.measure import RegularizedMeasureSpec, regularized_measure_certificate
from .domains.quantum_gravity.ponzano_regge import (
    cross_backend_certificate,
    equilateral_asymptotic,
    orthogonality_certificate,
    recoupling_amplitude_matrix,
)
from .domains.quantum_gravity.refinement import canonical_refinement_suite
from .domains.quantum_gravity.regge import (
    boundary_of_five_simplex,
    regge_equation_certificate,
    scaling_certificate,
)
from .domains.quantum_gravity.relational import finite_relational_observable_control
from .domains.quantum_gravity.simplicial import SimplicialComplex, simplicial_map_certificate
from .domains.quantum_gravity.spectral import estimate_spectral_dimension, periodic_grid_graph, plateau_estimate
from .domains.quantum_gravity.tensor_rg import svd_coarse_grain, svd_coarse_grain_tensor




def _run_isolated_qualifications(
    requests: tuple[tuple[Any, tuple[Any, ...], dict[str, Any]], ...],
    *,
    timeout_seconds: float = 600.0,
) -> tuple[Any, ...]:
    """Run a bounded group of independent owners in one fresh interpreter.

    Grouping limits process-launch/runtime conflicts while preserving owner isolation:
    the worker imports each authoritative function, executes it once, and returns only
    atomically committed certificates. No scientific method is implemented here.
    """

    descriptor, request_name = tempfile.mkstemp(
        prefix="qpdtr-qualification-request-", suffix=".pkl"
    )
    os.close(descriptor)
    descriptor, result_name = tempfile.mkstemp(
        prefix="qpdtr-qualification-result-", suffix=".pkl"
    )
    os.close(descriptor)
    descriptor, stderr_name = tempfile.mkstemp(
        prefix="qpdtr-qualification-stderr-", suffix=".log"
    )
    os.close(descriptor)
    request_path = Path(request_name)
    result_path = Path(result_name)
    stderr_path = Path(stderr_name)
    result_path.unlink(missing_ok=True)
    temporary_path = Path(result_name + ".tmp")
    entries = [
        (function.__module__, function.__name__, tuple(args), dict(kwargs))
        for function, args, kwargs in requests
    ]
    with request_path.open("wb") as stream:
        pickle.dump((entries, result_name), stream, protocol=pickle.HIGHEST_PROTOCOL)
        stream.flush()

    environment = dict(os.environ)
    environment["OPENBLAS_NUM_THREADS"] = "1"
    environment["OMP_NUM_THREADS"] = "1"
    environment["MKL_NUM_THREADS"] = "1"
    stderr_stream = stderr_path.open("wb")
    process = subprocess.Popen(
        [sys.executable, "-m", "qpdtr._qualification_worker", request_name],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=stderr_stream,
        env=environment,
    )
    stderr_stream.close()
    try:
        deadline = time.monotonic() + timeout_seconds
        while not result_path.is_file():
            exit_code = process.poll()
            if exit_code is not None:
                stderr = stderr_path.read_text(encoding="utf-8", errors="replace")
                names = ", ".join(entry[1] for entry in entries)
                raise RuntimeError(
                    f"isolated qualification group [{names}] terminated with exit code "
                    f"{exit_code} without a certificate: {stderr}"
                )
            if time.monotonic() >= deadline:
                process.kill()
                process.wait()
                names = ", ".join(entry[1] for entry in entries)
                raise TimeoutError(
                    f"isolated qualification group [{names}] exceeded "
                    f"{timeout_seconds} seconds before certificate commit"
                )
            time.sleep(0.02)

        with result_path.open("rb") as stream:
            status, payload = pickle.load(stream)
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5.0)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        if status != "PASS":
            names = ", ".join(entry[1] for entry in entries)
            raise RuntimeError(f"isolated qualification group [{names}] failed: {payload}")
        return tuple(payload)
    finally:
        if process.poll() is None:
            process.kill()
            process.wait()
        request_path.unlink(missing_ok=True)
        result_path.unlink(missing_ok=True)
        temporary_path.unlink(missing_ok=True)
        stderr_path.unlink(missing_ok=True)


def _run_isolated_qualification(
    function: Any,
    *args: Any,
    timeout_seconds: float = 240.0,
    **kwargs: Any,
) -> Any:
    """Thin single-owner delegate to the isolated group executor."""

    return _run_isolated_qualifications(
        ((function, tuple(args), dict(kwargs)),),
        timeout_seconds=timeout_seconds,
    )[0]


def _json_default(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")


def _digest(payload: Any) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), default=_json_default).encode("utf-8")
    ).hexdigest()


def _source_digest() -> str:
    root = Path(__file__).resolve().parent
    digest = hashlib.sha256()
    source_files = [
        path for path in root.rglob("*") if path.is_file() and path.suffix in {".py", ".jl", ".cpp", ".json", ".gz"}
    ]
    for file_path in sorted(source_files, key=lambda item: item.relative_to(root).as_posix()):
        relative = file_path.relative_to(root).as_posix().encode("utf-8")
        data = file_path.read_bytes()
        digest.update(len(relative).to_bytes(4, "big"))
        digest.update(relative)
        digest.update(len(data).to_bytes(8, "big"))
        digest.update(data)
    return digest.hexdigest()


def _requirement(status: str, statement: str, evidence: str) -> dict[str, str]:
    return {"status": status, "requirement": statement, "evidence": evidence}


def _probe_requirement_status(status: str) -> str:
    if status == "PASS":
        return "PASS"
    if status.startswith("PARTIAL"):
        return "PARTIAL"
    if status.startswith("BLOCKED"):
        return "BLOCKED_EXTERNAL_BACKEND"
    return status


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _normal_angles(vector: list[float] | tuple[float, ...]) -> list[float]:
    x, y, z = (float(value) for value in vector)
    radius = float(np.sqrt(x * x + y * y + z * z))
    if radius <= 0.0:
        raise ValueError("Coherent-state normal must be non-zero")
    theta = float(np.arccos(np.clip(z / radius, -1.0, 1.0)))
    phi = float(np.arctan2(y, x))
    return [theta, phi]


def _single_vertex_node_data(boundary_payload: dict[str, Any]) -> list[dict[str, Any]]:
    face_order = [tuple(int(value) for value in face) for face in boundary_payload["face_order"]]
    index_by_face = {tuple(sorted(face)): index for index, face in enumerate(face_order)}
    node_data: list[dict[str, Any]] = []
    normals = boundary_payload["node_normals"]
    for node in range(5):
        node_normals = normals.get(node, normals.get(str(node)))
        neighbours = sorted(int(value) for value in node_normals)
        node_data.append(
            {
                "node_index": node,
                "neighbours": neighbours,
                "face_indices": [index_by_face[tuple(sorted((node, neighbour)))] for neighbour in neighbours],
                "angles": [_normal_angles(node_normals.get(neighbour, node_normals.get(str(neighbour)))) for neighbour in neighbours],
            }
        )
    return node_data


def _target_tensor_coarse_graining(probe: Any, report_path: Path, max_bond: int) -> dict[str, Any]:
    if probe.status != "PASS":
        return {
            "status": probe.status,
            "reason": "No target tensor is admitted until the provenance-bound EPRL contract passes.",
            "certificates": [],
        }
    output_dir = report_path / "target_tensor_coarse_graining"
    output_dir.mkdir(parents=True, exist_ok=True)
    certificates: list[dict[str, Any]] = []
    for artifact in probe.tensor_artifacts:
        tensor = load_raw_tensor(Path(probe.workdir), artifact)
        left_axes = tuple(range(max(1, tensor.ndim // 2)))
        approximation, certificate = svd_coarse_grain_tensor(
            tensor, max_bond=max_bond, left_axes=left_axes
        )
        output_name = Path(str(artifact["relative_path"])).stem + "_coarse.f64"
        output_file = output_dir / output_name
        np.asarray(approximation, dtype="<f8").ravel(order="F").tofile(output_file)
        certificates.append(
            {
                "source_artifact": artifact,
                "coarse_artifact": {
                    "relative_path": output_file.relative_to(report_path).as_posix(),
                    "sha256": _sha256_file(output_file),
                    "shape": list(approximation.shape),
                    "dtype": "float64_le",
                    "storage": "raw_column_major",
                    "element_count": int(approximation.size),
                },
                "certificate": certificate.to_dict(),
            }
        )
    return {
        "status": "PASS",
        "owner": "qpdtr.domains.quantum_gravity.tensor_rg.svd_coarse_grain_tensor",
        "max_bond": int(max_bond),
        "certificates": certificates,
    }


class QuantumGravityDynamicsOwner:
    """Single authoritative owner of the current PhiQG quantum-emulator runtime."""

    def __init__(self, spec: PhiQGModelSpec | None = None):
        self.spec = spec or PhiQGModelSpec()
        self.spec.validate()

    def execute(self, report_dir: str | Path) -> dict[str, Any]:
        # Independent numerical owners execute in disposable one-thread processes.
        # This preserves deterministic reduction contracts without retaining their
        # temporary tensor heaps in the authoritative orchestration process.
        return self._execute_current(report_dir)

    def _execute_current(self, report_dir: str | Path) -> dict[str, Any]:
        report_path = Path(report_dir)
        report_path.mkdir(parents=True, exist_ok=True)
        started = datetime.now(timezone.utc).isoformat()
        thresholds = self.spec.thresholds
        law_table = PhysicalLawQualificationOwner(
            random_seed=self.spec.quantum_random_seed + 29
        ).execute()
        # Execute the independent radial-mode owner before large tensor-network caches
        # are populated. The mathematics is unchanged; this prevents cumulative allocator
        # pressure from distorting the authoritative replay runtime.
        (
            schwarzschild_4d,
            cayley_impurity_runtime,
            process_tensor_memory,
            phi_q1000_arfe,
        ) = _run_isolated_qualifications(
            (
                (qualify_schwarzschild_4d_radial_modes, (), {}),
                (qualify_cayley_impurity_runtime, (), {}),
                (qualify_process_tensor_memory, (), {
                    "detuning": self.spec.quantum_lorentzian_linewidth,
                    "coupling_rate": self.spec.quantum_lorentzian_coupling_rate,
                }),
                (qualify_phi_q1000_arfe, (), {}),
            ),
            timeout_seconds=600.0,
        )

        # Current bounded quantum emulator core and finite simplicial matter sector.
        matter_policy = AdaptiveExecutionPolicy(
            exact_choi_max_qubits=self.spec.quantum_exact_choi_max_qubits,
            statevector_memory_limit_bytes=self.spec.quantum_statevector_memory_limit_bytes,
            statevector_workspace_factor=self.spec.quantum_statevector_workspace_factor,
            mps_max_bond=self.spec.quantum_mps_max_bond,
            mps_discarded_weight_budget=self.spec.quantum_mps_discarded_weight_budget,
            mps_max_interaction_span=self.spec.quantum_mps_max_interaction_span,
            trotter_steps=self.spec.quantum_trotter_steps,
            trajectory_count=self.spec.quantum_trajectory_count,
            random_seed=self.spec.quantum_random_seed,
            contraction_optimizer=self.spec.quantum_contraction_optimizer,
            contraction_memory_limit_elements=(
                self.spec.quantum_contraction_memory_limit_elements
            ),
            contraction_max_slices=self.spec.quantum_contraction_max_slices,
            contraction_parallel_workers=self.spec.quantum_contraction_parallel_workers,
            contraction_statevector_max_qubits=(
                self.spec.quantum_contraction_statevector_max_qubits
            ),
            contraction_observable_max_count=(
                self.spec.quantum_contraction_observable_max_count
            ),
            contraction_backend=self.spec.quantum_contraction_backend,
            contraction_enable_mpi=self.spec.quantum_contraction_enable_mpi,
        )
        general_graph_policy = AdaptiveExecutionPolicy(
            exact_choi_max_qubits=self.spec.quantum_exact_choi_max_qubits,
            statevector_memory_limit_bytes=1024,
            statevector_workspace_factor=self.spec.quantum_statevector_workspace_factor,
            mps_max_bond=self.spec.quantum_mps_max_bond,
            mps_discarded_weight_budget=self.spec.quantum_mps_discarded_weight_budget,
            mps_max_interaction_span=self.spec.quantum_mps_max_interaction_span,
            trotter_steps=self.spec.quantum_trotter_steps,
            trajectory_count=2,
            random_seed=self.spec.quantum_random_seed + 1,
            contraction_optimizer=self.spec.quantum_contraction_optimizer,
            contraction_memory_limit_elements=(
                self.spec.quantum_contraction_memory_limit_elements
            ),
            contraction_max_slices=self.spec.quantum_contraction_max_slices,
            contraction_parallel_workers=self.spec.quantum_contraction_parallel_workers,
            contraction_statevector_max_qubits=(
                self.spec.quantum_contraction_statevector_max_qubits
            ),
            contraction_observable_max_count=(
                self.spec.quantum_contraction_observable_max_count
            ),
            contraction_backend=self.spec.quantum_contraction_backend,
            contraction_enable_mpi=self.spec.quantum_contraction_enable_mpi,
            force_contraction_tree=True,
        )

        (
            adaptive_ttn,
            scalable_adaptive_ttn,
            structured_ttn_hamiltonian,
            generator_learning,
        ) = _run_isolated_qualifications(
            (
                (qualify_persistent_adaptive_ttn, (), {"seed": self.spec.quantum_random_seed + 71}),
                (qualify_scalable_adaptive_ttn, (), {"qubit_count": self.spec.quantum_qubit_count}),
                (qualify_structured_50_qubit_ttn_hamiltonian_dynamics, (), {}),
                (qualify_bounded_generator_learning, (), {"seed": self.spec.quantum_random_seed + 72}),
            ),
            timeout_seconds=600.0,
        )
        (stabilizer_magic, camps_runtime) = _run_isolated_qualifications(
            (
                (qualify_stabilizer_magic_runtime, (), {
                    "clifford_qubit_count": self.spec.quantum_stabilizer_clifford_qubit_count,
                    "magic_qubit_count": self.spec.quantum_magic_materialization_qubit_limit,
                    "magic_t_gate_count": self.spec.quantum_magic_t_gate_limit,
                    "tolerance": self.spec.quantum_magic_reference_tolerance,
                    "seed": self.spec.quantum_random_seed + 74,
                }),
                (qualify_camps_runtime, (), {}),
            ),
            timeout_seconds=600.0,
        )
        high_treewidth_fallback = _run_isolated_qualification(
            qualify_high_treewidth_contraction_fallback, timeout_seconds=600.0
        )
        (cptp_tensor_train_runtime, basis_adaptive_sparse_runtime) = (
            _run_isolated_qualifications(
                (
                    (qualify_cptp_tensor_train_runtime, (), {}),
                    (qualify_basis_adaptive_sparse_runtime, (), {}),
                ),
                timeout_seconds=600.0,
            )
        )
        error_interference = qualify_error_interference_control()
        backend_qualification = qualify_real_backends(seed=self.spec.quantum_random_seed + 73)
        (
            adversarial_representation,
            fermionic_gaussian_runtime,
            phase_decision_diagram,
        ) = _run_isolated_qualifications(
            (
                (qualify_representation_adversarial_benchmark, (), {}),
                (qualify_fermionic_gaussian_runtime, (), {}),
                (qualify_phase_polynomial_decision_diagram, (), {}),
            ),
            timeout_seconds=600.0,
        )
        code_compiled_tn = _run_isolated_qualification(
            qualify_code_compiled_tensor_network, timeout_seconds=600.0
        )
        matter = _run_isolated_qualification(
            simplicial_qubit_matter_control,
            timeout_seconds=900.0,
            qubit_count=self.spec.quantum_qubit_count,
            policy=matter_policy,
            general_graph_policy=general_graph_policy,
            processor_qubits=self.spec.quantum_processor_qubit_count,
            processor_backend=self.spec.quantum_processor_backend,
            processor_trajectory_count=self.spec.quantum_processor_trajectory_count,
            processor_readout_shots=self.spec.quantum_processor_readout_shots,
            processor_t1=self.spec.quantum_processor_t1,
            processor_t2=self.spec.quantum_processor_t2,
            processor_one_qubit_gate_time=self.spec.quantum_processor_one_qubit_gate_time,
            processor_two_qubit_gate_time=self.spec.quantum_processor_two_qubit_gate_time,
            processor_readout_0_to_1=self.spec.quantum_processor_readout_0_to_1,
            processor_readout_1_to_0=self.spec.quantum_processor_readout_1_to_0,
            toric_lattice_size=self.spec.quantum_toric_lattice_size,
            toric_trials=self.spec.quantum_toric_trials,
            toric_error_probability=self.spec.quantum_toric_error_probability,
            lorentzian_linewidth=self.spec.quantum_lorentzian_linewidth,
            lorentzian_coupling_rate=self.spec.quantum_lorentzian_coupling_rate,
        )
        portfolio_methods = (
            "QCM-EXACT-SV", "QCM-EXACT-DM", "QCM-MPS-TEBD", "QCM-TTN",
            "QCM-ADAPTIVE-TTN", "QCM-GENERAL-TN", "QCM-CONTRACTION-OPT",
            "QCM-SLICING", "QCM-TEMPO", "QCM-TRAJECTORIES", "QCM-STABILIZER",
            "QCM-STN-MAGIC", "QCM-CPTP-TT-LINDBLAD", "QCM-BASS", "QCM-FERMION-GAUSSIAN",
            "QCM-FEYNMAN-DD-LRW", "QCM-CODE-COMPILED-TN", "QCM-CAUSAL-CONE", "QCM-PAULI-OBS", "QCM-GTN-BP", "QCM-PHI-Q1000-ARFE", "QCM-MULTIGPU",
        )
        portfolio_evidence = {
            "QCM-EXACT-SV": matter.exact_reference.passed,
            "QCM-EXACT-DM": matter.bounded_four_level_reference.open_passed,
            "QCM-MPS-TEBD": matter.scalable_closed_dynamics.passed,
            "QCM-TTN": structured_ttn_hamiltonian.passed,
            "QCM-ADAPTIVE-TTN": adaptive_ttn.status.startswith("PASS") and scalable_adaptive_ttn.passed,
            "QCM-GENERAL-TN": high_treewidth_fallback.passed,
            "QCM-CONTRACTION-OPT": high_treewidth_fallback.passed,
            "QCM-SLICING": high_treewidth_fallback.passed,
            "QCM-TEMPO": process_tensor_memory.passed,
            "QCM-TRAJECTORIES": matter.scalable_open_dynamics.passed,
            "QCM-STABILIZER": stabilizer_magic.large_clifford.passed,
            "QCM-STN-MAGIC": camps_runtime.passed,
            "QCM-CPTP-TT-LINDBLAD": cptp_tensor_train_runtime.passed,
            "QCM-BASS": basis_adaptive_sparse_runtime.passed,
            "QCM-FERMION-GAUSSIAN": fermionic_gaussian_runtime.passed,
            "QCM-FEYNMAN-DD-LRW": phase_decision_diagram.passed,
            "QCM-CODE-COMPILED-TN": code_compiled_tn.passed,
            "QCM-CAUSAL-CONE": phi_q1000_arfe.causal_cone.passed,
            "QCM-PAULI-OBS": phi_q1000_arfe.pauli_observable.passed,
            "QCM-GTN-BP": phi_q1000_arfe.graph_tensor_bp.passed,
            "QCM-PHI-Q1000-ARFE": phi_q1000_arfe.passed,
            "QCM-MULTIGPU": (
                "PASS" if backend_qualification.cuda.status == "PASS" and backend_qualification.mpi.status == "PASS"
                else "BLOCKED_EXTERNAL_BACKEND"
            ),
        }
        quantum_portfolio = qualify_method_route(
            "QPDTR-CORE-PORTFOLIO-v2.5", portfolio_methods, portfolio_evidence
        )

        # Current metric-causal Lorentzian geometry control.
        lorentzian = causal_lorentzian_bisimplex()
        fine = SimplicialComplex(lorentzian.four_simplices)
        coarse = SimplicialComplex([(0, 1, 2, 3, 4)])
        topology = simplicial_map_certificate(
            fine,
            coarse,
            {0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 0},
        )
        refinement = canonical_refinement_suite(max_refined_dimension=3)

        # Current boundary state and finite regularized microscopic measure.
        boundary = isotropic_livine_speziale_boundary_family(
            center_twice_spin=self.spec.boundary_center_twice_spin,
            width_twice_spin=self.spec.boundary_width_twice_spin,
            extrinsic_phase_per_face=self.spec.boundary_extrinsic_phase,
        )
        measure_spec = RegularizedMeasureSpec(
            face_dimension_power=self.spec.measure_face_dimension_power,
            edge_intertwiner_power=self.spec.measure_edge_intertwiner_power,
            heat_kernel_epsilon=self.spec.measure_heat_kernel_epsilon,
            twice_spin_cutoff=self.spec.measure_twice_spin_cutoff,
        )
        measure = regularized_measure_certificate(measure_spec)

        # Finite relational measurement channel.
        relational = finite_relational_observable_control()

        # Spectral estimator validation on exact dimensional controls.
        sigmas = self.spec.spectral_sigmas
        ds1 = estimate_spectral_dimension(periodic_grid_graph((96,)), sigmas)
        ds2 = estimate_spectral_dimension(periodic_grid_graph((24, 24)), sigmas)
        plateau_1d = plateau_estimate(ds1, 0.2, 8.0)
        plateau_2d = plateau_estimate(ds2, 0.2, 8.0)

        # Exact 2+1 recoupling controls; never used as a four-dimensional target amplitude.
        orthogonality = orthogonality_certificate(j2=4)
        asymptotic = equilateral_asymptotic(spin=50)
        cross6j = cross_backend_certificate(
            [
                (2, 2, 0, 2, 2, 0),
                (2, 2, 2, 2, 2, 2),
                (4, 4, 2, 4, 4, 2),
                (4, 4, 4, 4, 4, 4),
                (6, 4, 2, 4, 6, 4),
            ]
        )
        amplitude_matrix, spin_labels = recoupling_amplitude_matrix(j2=6, damping=0.06)
        _, tensor_cert = svd_coarse_grain(amplitude_matrix, max_bond=3)

        # Published finite FRG controls; no full-flow or regulator-independent claim.
        frg_r2 = positive_fixed_point(
            beta_newton_r2,
            "proper_time_MES_O(R^2)",
            "arXiv:2411.00938v2 Eq.(5.17), d=4",
        )
        frg_r5 = positive_fixed_point(
            beta_newton_r5,
            "proper_time_MES_O(R^5)",
            "arXiv:2411.00938v2 Eq.(6.14), d=4",
        )
        frg_selected_order_spread = abs(frg_r2.critical_exponent - frg_r5.critical_exponent)

        # General edge-length Regge action, equations of motion and dimensional scaling.
        regge = boundary_of_five_simplex(1.0)
        regge_scaling = scaling_certificate(1.0, 2.0)
        regge_equations = regge_equation_certificate()

        # Provenance-bound target requests use the official sl2cfoam-next API only.
        boundary_payload = boundary.to_dict()
        request_configurations = []
        for index, configuration in enumerate(boundary_payload["configurations"]):
            request_configurations.append(
                {
                    "configuration_id": f"isotropic_scale_{index:02d}",
                    "twice_spins": configuration["twice_spins"],
                    "coefficient": {
                        "real": configuration["coefficient_real"],
                        "imag": configuration["coefficient_imag"],
                    },
                    "probability": configuration["probability"],
                }
            )
        single_node_data = _single_vertex_node_data(boundary_payload)
        boundary_family = {
            "family": boundary.family,
            "face_order": boundary_payload["face_order"],
            "configurations": request_configurations,
            "node_normals": boundary_payload["node_normals"],
            "closure_residuals": boundary_payload["closure_residuals"],
            "extrinsic_phase_per_face": boundary.extrinsic_phase_per_face,
            "shape_matching_status": boundary.shape_matching_status,
        }
        boundary_family["family_digest"] = _digest(boundary_family)
        single_contract = {
            "id": "single_4simplex_vertex",
            "vertex_count": 1,
            "face_order": boundary_payload["face_order"],
            "node_data": single_node_data,
            "coherent_contraction_order": [4, 3, 2, 1, 0],
        }
        shell_policy = asdict(self.spec.eprl_shell_policy)
        shell_policy_digest = _digest(shell_policy)
        maximum_shell = int(self.spec.eprl_shell_policy.maximum_shell)
        single_request = {
            "task": "single_vertex_coherent_family",
            "model": self.spec.vertex_model,
            "gauge_group": self.spec.gauge_group,
            "signature": self.spec.signature,
            "boundary_family": boundary_family,
            "amplitude_configurations": request_configurations,
            "complex_contract": single_contract,
            "complex_contract_digest": _digest(single_contract),
            "microscopic_measure": measure_spec.to_dict(),
            "shell_policy": shell_policy,
            "shell_policy_digest": shell_policy_digest,
            "immirzi": self.spec.immirzi,
            "y_map": self.spec.eprl_y_map,
            "backend_config": {
                "accuracy": self.spec.eprl_backend_accuracy,
                "max_MB_mem_per_thread": self.spec.eprl_backend_max_MB_mem_per_thread,
                "max_twice_spin": max(
                    max(configuration["twice_spins"]) for configuration in request_configurations
                ) + 2 * maximum_shell,
            },
            "causal_semantics": {
                "metric_boundary_control": "passed" if lorentzian.passed else "failed",
                "target_vertex": "standard_Lorentzian_EPRL",
                "causal_Toller_vertex": self.spec.causal_vertex_status,
            },
            "required_outputs": [
                "configuration_amplitudes",
                "contracted_amplitude",
                "immutable_backend_identity_and_request_bindings",
                "adaptive_shell_stability_certificate",
                "last_two_shell_rank_5_tensor_artifacts",
                "tensor_shell_stability_certificates",
            ],
        }

        delta3_node_angles = [single_node_data[index % len(single_node_data)]["angles"] for index in range(9)]
        delta3_family = {
            "family": "delta3_nine_node_equal_spin_coherent_probe",
            "boundary_twice_spin": self.spec.delta3_boundary_twice_spin,
            "node_angles": delta3_node_angles,
            "shape_matching_status": "OPEN_NOT_ASSERTED_BY_BOUNDED_DELTA3_PROBE",
        }
        delta3_family["family_digest"] = _digest(delta3_family)
        delta3_configurations = []
        for q in self.spec.delta3_internal_twice_spins:
            j = q / 2.0
            delta3_configurations.append(
                {
                    "configuration_id": f"delta3_internal_q{q:02d}",
                    "internal_twice_spin": q,
                    "weight": float(np.exp(-self.spec.measure_heat_kernel_epsilon * j * (j + 1.0))),
                }
            )
        delta3_contract = {
            "id": "delta3_three_vertex_one_internal_face",
            "definition": "three equal EPRL vertex tensors; nine partial coherent states; cyclic contraction over three internal intertwiners",
            "vertex_count": 3,
            "internal_face_count": 1,
            "boundary_twice_spin": self.spec.delta3_boundary_twice_spin,
            "internal_twice_spins": list(self.spec.delta3_internal_twice_spins),
            "node_angles": delta3_node_angles,
            "phase_and_face_weight": "(-1)^x(2x+1) sum_{k1,k2,k3}(-1)^(k1+k2+k3) tA[k2,k1]tB[k1,k3]tC[k3,k2]",
            "reference": "arXiv:2107.13952 Delta3 listing",
        }
        delta3_request = {
            "task": "delta3_three_vertex_one_internal_face",
            "model": self.spec.vertex_model,
            "gauge_group": self.spec.gauge_group,
            "signature": self.spec.signature,
            "boundary_family": delta3_family,
            "amplitude_configurations": delta3_configurations,
            "complex_contract": delta3_contract,
            "complex_contract_digest": _digest(delta3_contract),
            "microscopic_measure": measure_spec.to_dict(),
            "shell_policy": shell_policy,
            "shell_policy_digest": shell_policy_digest,
            "immirzi": self.spec.immirzi,
            "y_map": self.spec.eprl_y_map,
            "backend_config": {
                "accuracy": self.spec.eprl_backend_accuracy,
                "max_MB_mem_per_thread": self.spec.eprl_backend_max_MB_mem_per_thread,
                "max_twice_spin": max(
                    self.spec.delta3_boundary_twice_spin,
                    max(self.spec.delta3_internal_twice_spins),
                ) + 2 * maximum_shell,
            },
            "causal_semantics": {
                "target_vertex": "standard_Lorentzian_EPRL",
                "causal_Toller_vertex": self.spec.causal_vertex_status,
            },
            "required_outputs": [
                "internal_face_amplitudes",
                "contracted_delta3_amplitude",
                "immutable_graph_backend_identity_and_request_bindings",
                "adaptive_shell_stability_certificate",
                "last_two_shell_delta3_constituent_vertex_tensors",
                "tensor_shell_stability_certificates",
            ],
        }

        adapter = SL2CfoamAdapter()
        eprl_single = adapter.probe(single_request, report_path / "external_eprl_single")
        eprl_three = adapter.probe(delta3_request, report_path / "external_eprl_delta3")
        cache = AdmittedVertexAmplitudeCache(report_path / "admitted_vertex_cache")
        cache_entries: list[dict[str, Any]] = []
        for probe in (eprl_single, eprl_three):
            if probe.status == "PASS":
                entry = cache.admit(probe)
                cache_entries.append(
                    {
                        "cache_key": entry["cache_key"],
                        "request_digest": entry["request_digest"],
                        "backend_identity_digest": entry["backend_identity_digest"],
                        "tensor_artifact_count": len(entry["tensor_artifacts"]),
                        "status": "PASS",
                    }
                )
        vertex_cache_evidence = {
            "schema": "qpdtr-admitted-eprl-vertex-cache-evidence-current",
            "status": "PASS" if cache_entries else "EMPTY_NO_ADMITTED_ARTIFACTS",
            "entry_count": len(cache_entries),
            "entries": cache_entries,
            "surrogate_allowed": False,
        }
        target_tensor_single = _target_tensor_coarse_graining(
            eprl_single, report_path / "single_vertex_target", self.spec.eprl_target_max_bond
        )
        target_tensor_delta3 = _target_tensor_coarse_graining(
            eprl_three, report_path / "delta3_target", self.spec.eprl_target_max_bond
        )
        differential_benchmarks = run_differential_benchmarks(
            eprl_statuses=(eprl_single.status, eprl_three.status)
        )

        error_budget = build_error_budget(
            [
                ErrorComponent(
                    "physical_law_table",
                    "registry_uncovered_owner_count",
                    float(len(law_table.registry.uncovered_qualification_owners)),
                    "PASS" if law_table.registry.passed else "FAIL",
                    "all 9,383 current-state cells bound to theorem or existing-law owners",
                    "integer count",
                ),
                ErrorComponent(
                    "physical_law_table",
                    "strong_subadditivity_negative_gap",
                    max(0.0, -law_table.quantum_laws.strong_subadditivity_min_gap_bits),
                    "PASS" if law_table.quantum_laws.passed else "FAIL",
                    "QTM-30 on deterministic independent three-qubit density corpus",
                    "bits",
                ),
                ErrorComponent(
                    "physical_law_table",
                    "holevo_bound_violation",
                    max(0.0, -law_table.quantum_laws.holevo_bound_gap_bits),
                    "PASS" if law_table.quantum_laws.passed else "FAIL",
                    "QTM-32 binary nonorthogonal ensemble and Helstrom measurement",
                    "bits",
                ),
                ErrorComponent(
                    "physical_law_table",
                    "chern_integer_gap",
                    law_table.quantum_laws.chern_integer_gap,
                    "PASS" if law_table.quantum_laws.passed else "FAIL",
                    "MAT-11 gauge-invariant Fukui lattice Chern-number control",
                    "absolute distance to nearest integer",
                ),
                ErrorComponent(
                    "physical_law_table",
                    "diffusive_sme_ensemble_gap",
                    law_table.quantum_laws.diffusive_sme_ensemble_gap,
                    "PASS" if law_table.quantum_laws.passed else "FAIL",
                    "QTM-46 diffusive stochastic pure-state ensemble against exact dephasing",
                    "trace distance",
                ),
                ErrorComponent(
                    "quantum_emulator",
                    "bounded_reference_unitary_gap",
                    matter.bounded_four_level_reference.unitary_gap,
                    "PASS" if matter.bounded_four_level_reference.closed_passed else "FAIL",
                    "exact dense reference with Krylov action",
                    "operator 2-norm",
                ),
                ErrorComponent(
                    "quantum_emulator",
                    "bounded_reference_trace_preservation_gap",
                    matter.bounded_four_level_reference.trace_preservation_gap,
                    "PASS" if matter.bounded_four_level_reference.open_passed else "FAIL",
                    "single cached GKSL channel and exact Choi reshuffle",
                    "operator 2-norm",
                ),
                ErrorComponent(
                    "quantum_emulator",
                    "bounded_reference_complete_positivity_negativity",
                    max(0.0, -matter.bounded_four_level_reference.choi_min_eigenvalue),
                    "PASS" if matter.bounded_four_level_reference.open_passed else "FAIL",
                    "minimum Choi eigenvalue",
                    "absolute negative eigenvalue",
                ),
                ErrorComponent(
                    "quantum_emulator",
                    "general_graph_contraction_reference_gap",
                    matter.general_graph_contraction_control.exact_reference_gap or 0.0,
                    "PASS" if matter.general_graph_contraction_control.passed else "FAIL",
                    "general-graph contraction-tree state against matrix-free Krylov reference",
                    "state-vector 2-norm after global-phase alignment",
                ),
                ErrorComponent(
                    "quantum_emulator",
                    "general_graph_contraction_norm_crosscheck_gap",
                    matter.general_graph_contraction_control.contraction_norm_crosscheck_gap or 0.0,
                    "PASS" if matter.general_graph_contraction_control.passed else "FAIL",
                    "independent doubled-network scalar norm against contracted ket state",
                    "absolute scalar difference",
                ),
                ErrorComponent(
                    "quantum_emulator",
                    "fifty_qubit_total_discarded_weight",
                    matter.scalable_closed_dynamics.total_discarded_weight,
                    "PASS" if matter.scalable_closed_dynamics.passed else "FAIL",
                    "adaptive graph-ordered MPS/TEBD",
                    "sum of discarded squared singular values",
                ),
                ErrorComponent(
                    "quantum_emulator",
                    "fifty_qubit_trotter_step_doubling_gap",
                    matter.scalable_closed_dynamics.trotter_step_doubling_gap,
                    "PASS" if matter.scalable_closed_dynamics.passed else "FAIL",
                    "symmetric local-product evolution",
                    "maximum one-site reduced-density Frobenius difference",
                ),
                ErrorComponent(
                    "quantum_emulator",
                    "trajectory_small_system_density_gap",
                    matter.scalable_open_dynamics.small_system_density_gap,
                    "PASS" if matter.scalable_open_dynamics.passed else "FAIL",
                    "MPS dephasing trajectory ensemble against exact GKSL reference",
                    "Frobenius norm",
                ),
                ErrorComponent(
                    "quantum_processor",
                    "accelerator_numpy_state_gap",
                    matter.processor_emulator.accelerator_numpy_state_gap,
                    "PASS" if matter.processor_emulator.passed else "FAIL",
                    "accelerator tensor-axis circuit state against independent NumPy reference",
                    "state-vector 2-norm after phase alignment",
                ),
                ErrorComponent(
                    "quantum_processor",
                    "dynamic_feedforward_gap",
                    matter.processor_emulator.dynamic_feedforward_gap,
                    "PASS" if matter.processor_emulator.passed else "FAIL",
                    "OpenQASM 3 mid-circuit measurement, while/for control and classical feed-forward",
                    "state-vector 2-norm against deterministic branch target",
                ),
                ErrorComponent(
                    "quantum_processor",
                    "openpulse_single_transmon_step_gap",
                    (
                        matter.processor_emulator.pulse_control.single_transmon_step_doubling_gap
                        if matter.processor_emulator.pulse_control is not None
                        else None
                    ),
                    "PASS" if matter.processor_emulator.pulse_control is not None and matter.processor_emulator.pulse_control.passed else "FAIL",
                    "qutrit transmon DRAG pulse evolution",
                    "operator 2-norm under time-step doubling",
                ),
                ErrorComponent(
                    "quantum_open_system",
                    "adaptive_jump_trace_distance",
                    (
                        matter.processor_emulator.adaptive_jump_control.exact_trace_distance
                        if matter.processor_emulator.adaptive_jump_control is not None
                        else None
                    ),
                    "PASS" if matter.processor_emulator.adaptive_jump_control is not None and matter.processor_emulator.adaptive_jump_control.passed else "FAIL",
                    "event-resolved Monte-Carlo wave-function ensemble against exact GKSL density evolution",
                    "trace distance",
                ),
                ErrorComponent(
                    "quantum_qec",
                    "circuit_level_residual_syndrome_count",
                    (
                        float(matter.processor_emulator.circuit_level_qec.maximum_residual_syndrome_count)
                        if matter.processor_emulator.circuit_level_qec is not None
                        else None
                    ),
                    "PASS" if matter.processor_emulator.circuit_level_qec is not None and matter.processor_emulator.circuit_level_qec.passed else "FAIL",
                    "repeated noisy syndrome rounds with space-time MWPM and homology check",
                    "integer residual detector count",
                ),
                ErrorComponent(
                    "quantum_processor",
                    "kraus_completeness_gap",
                    matter.processor_emulator.maximum_kraus_completeness_gap,
                    "PASS" if matter.processor_emulator.passed else "FAIL",
                    "T1 amplitude damping and pure T2 phase damping channels",
                    "Frobenius norm of sum(K_dagger K)-I",
                ),
                ErrorComponent(
                    "quantum_processor",
                    "noise_trajectory_density_gap",
                    matter.processor_emulator.trajectory_density_gap,
                    "PASS" if matter.processor_emulator.passed else "FAIL",
                    "Kraus-branch trajectory ensemble against exact two-qubit density channel",
                    "Frobenius norm",
                ),
                ErrorComponent(
                    "quantum_processor",
                    "readout_sampling_gap",
                    matter.processor_emulator.readout_sampling_gap,
                    "PASS" if matter.processor_emulator.passed else "FAIL",
                    "asymmetric assignment-matrix sampling against exact noisy distribution",
                    "maximum absolute probability difference",
                ),
                ErrorComponent(
                    "quantum_processor",
                    "toric_residual_syndrome_gap",
                    float(matter.processor_emulator.toric_code.residual_syndrome_gap)
                    if matter.processor_emulator.toric_code is not None
                    else None,
                    "PASS" if matter.processor_emulator.passed else "FAIL",
                    "perfect-syndrome homology-aware MWPM recovery",
                    "integer residual defect count",
                ),
                ErrorComponent(
                    "quantum_open_retype",
                    "mollow_population_gap",
                    (
                        matter.processor_emulator.retyped_open_systems.mollow_population_gap
                        if matter.processor_emulator.retyped_open_systems is not None
                        else None
                    ),
                    (
                        "PASS"
                        if matter.processor_emulator.retyped_open_systems is not None
                        and matter.processor_emulator.retyped_open_systems.passed
                        else "FAIL"
                    ),
                    "driven two-level GKSL steady state against optical-Bloch analytic result",
                    "absolute excited-state population gap",
                ),
                ErrorComponent(
                    "quantum_open_retype",
                    "kerr_steady_state_residual",
                    (
                        matter.processor_emulator.retyped_open_systems.kerr_steady_residual
                        if matter.processor_emulator.retyped_open_systems is not None
                        else None
                    ),
                    (
                        "PASS"
                        if matter.processor_emulator.retyped_open_systems is not None
                        and matter.processor_emulator.retyped_open_systems.passed
                        else "FAIL"
                    ),
                    "finite-Fock driven-dissipative Kerr GKSL stationary state",
                    "Liouvillian state-vector 2-norm",
                ),
                ErrorComponent(
                    "quantum_open_retype",
                    "spatial_coherence_formula_gap",
                    (
                        matter.processor_emulator.retyped_open_systems.spatial_coherence_formula_gap
                        if matter.processor_emulator.retyped_open_systems is not None
                        else None
                    ),
                    (
                        "PASS"
                        if matter.processor_emulator.retyped_open_systems is not None
                        and matter.processor_emulator.retyped_open_systems.passed
                        else "FAIL"
                    ),
                    "positive-semidefinite spatial correlation kernel against exact two-site GKSL channel",
                    "absolute coherence-amplitude gap",
                ),
                ErrorComponent(
                    "quantum_open_retype",
                    "open_eft_number_derivative_gap",
                    (
                        matter.processor_emulator.retyped_open_systems.eft_number_derivative_gap
                        if matter.processor_emulator.retyped_open_systems is not None
                        else None
                    ),
                    (
                        "PASS"
                        if matter.processor_emulator.retyped_open_systems is not None
                        and matter.processor_emulator.retyped_open_systems.passed
                        else "FAIL"
                    ),
                    "one- and two-quantum loss EFT generator against exact number-moment identity",
                    "absolute derivative gap",
                ),
                ErrorComponent(
                    "quantum_open_retype",
                    "rg_scaling_exponent_gap",
                    (
                        matter.processor_emulator.retyped_open_systems.rg_scaling_exponent_gap
                        if matter.processor_emulator.retyped_open_systems is not None
                        else None
                    ),
                    (
                        "PASS"
                        if matter.processor_emulator.retyped_open_systems is not None
                        and matter.processor_emulator.retyped_open_systems.passed
                        else "FAIL"
                    ),
                    "bounded driven-dissipative linearized RG control",
                    "absolute fitted critical-exponent gap",
                ),
                ErrorComponent(
                    "boundary_state",
                    "normalization_gap",
                    boundary.normalization_gap,
                    "PASS" if boundary.passed else "FAIL",
                    "finite coherent-family norm",
                    "absolute probability gap",
                ),
                ErrorComponent(
                    "boundary_state",
                    "maximum_closure_residual",
                    max(boundary.closure_residuals),
                    "PASS" if boundary.passed else "FAIL",
                    "Livine-Speziale closure",
                    "relative vector norm",
                ),
                ErrorComponent(
                    "microscopic_measure",
                    "cutoff_tail_fraction",
                    measure.cutoff_tail_fraction,
                    "BOUNDED" if measure.passed else "FAIL",
                    "regulated face-weight tail",
                    "relative partition weight",
                ),
                ErrorComponent(
                    "relational_observable",
                    "relabel_covariance_gap",
                    relational.relabel_covariance_gap,
                    "PASS" if relational.passed else "FAIL",
                    "finite POVM permutation covariance",
                    "absolute observable gap",
                ),
                ErrorComponent(
                    "spectral",
                    "cycle_heat_trace_backend_gap",
                    ds1.backend_disagreement,
                    "PASS",
                    "eigenspectrum versus matrix exponential",
                    "absolute probability gap",
                ),
                ErrorComponent(
                    "spectral",
                    "torus_heat_trace_backend_gap",
                    ds2.backend_disagreement,
                    "PASS",
                    "eigenspectrum versus matrix exponential",
                    "absolute probability gap",
                ),
                ErrorComponent(
                    "ponzano_regge",
                    "orthogonality_residual",
                    orthogonality.max_absolute_residual,
                    "PASS" if orthogonality.exact_pass else "FAIL",
                    "exact symbolic identity",
                    "absolute algebraic residual",
                ),
                ErrorComponent(
                    "ponzano_regge",
                    "racah_backend_gap",
                    cross6j.max_absolute_disagreement,
                    "PASS",
                    "SymPy versus independent Racah sum",
                    "absolute amplitude gap",
                ),
                ErrorComponent(
                    "tensor_control",
                    "svd_relative_frobenius_error",
                    tensor_cert.relative_frobenius_error,
                    "BOUNDED",
                    "discarded singular values",
                    "relative Frobenius norm",
                ),
                ErrorComponent(
                    "frg_control",
                    "r2_beta_residual",
                    frg_r2.beta_residual,
                    "PASS",
                    "Brent root of cited polynomial",
                    "absolute beta-function residual",
                ),
                ErrorComponent(
                    "frg_control",
                    "r5_beta_residual",
                    frg_r5.beta_residual,
                    "PASS",
                    "Brent root of cited polynomial",
                    "absolute beta-function residual",
                ),
                ErrorComponent(
                    "regge_control",
                    "equation_of_motion_residual",
                    regge_equations.equilateral_gradient_norm,
                    "PASS" if regge_equations.passed else "FAIL",
                    "central finite difference of full edge-length action",
                    "Euclidean gradient norm",
                ),
                ErrorComponent(
                    "regge_control",
                    "scale_invariant_gap",
                    regge_scaling.invariant_r_sqrt_v_gap,
                    "PASS",
                    "analytic regular-simplex geometry",
                    "absolute dimensionless gap",
                ),
                ErrorComponent(
                    "eprl_target",
                    "single_vertex_successive_shell_estimator",
                    (
                        float(eprl_single.shell_certificate["successive_shell_estimator"])
                        if eprl_single.shell_certificate is not None
                        else None
                    ),
                    eprl_single.status,
                    "recomputed adaptive shell certificate",
                    "absolute successive-shell amplitude difference; not an infinite-tail bound",
                ),
                ErrorComponent(
                    "eprl_target",
                    "single_vertex_max_tensor_shell_difference",
                    (
                        max(item["relative_frobenius_difference"] for item in eprl_single.tensor_shell_certificates)
                        if eprl_single.tensor_shell_certificates
                        else None
                    ),
                    eprl_single.status,
                    "last-two-shell rank-5 artifact comparison",
                    "relative Frobenius difference",
                ),
                ErrorComponent(
                    "eprl_target",
                    "delta3_successive_shell_estimator",
                    (
                        float(eprl_three.shell_certificate["successive_shell_estimator"])
                        if eprl_three.shell_certificate is not None
                        else None
                    ),
                    eprl_three.status,
                    "recomputed adaptive shell certificate",
                    "absolute successive-shell amplitude difference; not an infinite-tail bound",
                ),
                ErrorComponent(
                    "eprl_target",
                    "delta3_max_tensor_shell_difference",
                    (
                        max(item["relative_frobenius_difference"] for item in eprl_three.tensor_shell_certificates)
                        if eprl_three.tensor_shell_certificates
                        else None
                    ),
                    eprl_three.status,
                    "last-two-shell constituent-vertex artifact comparison",
                    "relative Frobenius difference",
                ),
                ErrorComponent(
                    "eprl_target_tensor",
                    "single_vertex_max_relative_frobenius_error",
                    (
                        max(
                            item["certificate"]["relative_frobenius_error"]
                            for item in target_tensor_single["certificates"]
                        )
                        if target_tensor_single["status"] == "PASS"
                        and target_tensor_single["certificates"]
                        else None
                    ),
                    target_tensor_single["status"],
                    "authoritative N-dimensional SVD owner on admitted single-vertex tensors",
                    "relative Frobenius norm",
                ),
                ErrorComponent(
                    "eprl_target_tensor",
                    "delta3_max_relative_frobenius_error",
                    (
                        max(
                            item["certificate"]["relative_frobenius_error"]
                            for item in target_tensor_delta3["certificates"]
                        )
                        if target_tensor_delta3["status"] == "PASS"
                        and target_tensor_delta3["certificates"]
                        else None
                    ),
                    target_tensor_delta3["status"],
                    "authoritative N-dimensional SVD owner on admitted Delta3 vertex tensors",
                    "relative Frobenius norm",
                ),
            ]
        )

        refinement_pass = all(item["passed"] for item in refinement.values())
        unified_quantum_error_budget = build_unified_quantum_error_budget(
            (
                QuantumErrorAllocation(
                    "ttn_truncation", "PersistentAdaptiveTTN", "discarded squared singular-value weight",
                    adaptive_ttn.total_discarded_weight, 1e-8, "SUM", "state_representation", "PASS" if adaptive_ttn.status.startswith("PASS") else "FAIL",
                ),
                QuantumErrorAllocation(
                    "ttn_reference_gap", "PersistentAdaptiveTTN", "state-vector 2-norm after phase alignment",
                    adaptive_ttn.reconstruction_error, 1e-8, "RSS", "state_reference", "PASS" if adaptive_ttn.reconstruction_error is not None and adaptive_ttn.reconstruction_error < 1e-8 else "FAIL",
                ),
                QuantumErrorAllocation(
                    "ttn_scalable_path_truncation", "PersistentAdaptiveTTN", "discarded squared singular-value weight",
                    scalable_adaptive_ttn.total_discarded_weight, 1e-8, "SUM", "state_representation", "PASS" if scalable_adaptive_ttn.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "ttn_scalable_norm", "PersistentAdaptiveTTN", "absolute norm-squared gap",
                    scalable_adaptive_ttn.norm_gap, 1e-10, "MAX", "state_normalization", "PASS" if scalable_adaptive_ttn.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "ttn_hamiltonian_truncation", "AdaptiveQuantumDynamics", "discarded squared singular-value weight",
                    structured_ttn_hamiltonian.total_discarded_weight, 1e-8, "SUM", "state_representation", "PASS" if structured_ttn_hamiltonian.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "ttn_hamiltonian_norm", "AdaptiveQuantumDynamics", "absolute norm-squared gap",
                    structured_ttn_hamiltonian.norm_gap, 1e-9, "MAX", "state_normalization", "PASS" if structured_ttn_hamiltonian.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "ttn_hamiltonian_trotter_refinement", "AdaptiveQuantumDynamics", "maximum one-site reduced-density Frobenius difference",
                    structured_ttn_hamiltonian.trotter_step_doubling_gap, 5e-2, "RSS", "time_discretization", "PASS" if structured_ttn_hamiltonian.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "high_treewidth_contraction_reference", "AdaptiveQuantumDynamics", "state-vector 2-norm after phase alignment",
                    high_treewidth_fallback.exact_reference_gap, 1e-7, "RSS", "general_graph_contraction",
                    "PASS" if high_treewidth_fallback.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "schwarzschild_4d_reduced_population_rank", "Schwarzschild4DRadialModes", "maximum population difference between 33- and 65-node spectral discretizations",
                    schwarzschild_4d.reduced_population_rank_gap_33_65, 5e-4, "RSS", "curved_spacetime_environment",
                    "PASS" if schwarzschild_4d.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "process_tensor_intervention_prediction", "ProcessTensorMemory", "maximum multitime intervention output Frobenius gap",
                    process_tensor_memory.maximum_intervention_prediction_gap, 1e-10, "RSS", "environment_memory", "PASS" if process_tensor_memory.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "process_tensor_temporal_compression", "ProcessTensorMemory", "relative process-tensor Frobenius compression error",
                    process_tensor_memory.compression_relative_frobenius_error, 1e-10, "RSS", "environment_memory", "PASS" if process_tensor_memory.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "process_tensor_spatial_temporal_compression", "ProcessTensorMemory", "relative site-factorized space-time tensor-network Frobenius error",
                    process_tensor_memory.spatial_temporal_compression_relative_frobenius_error, 1e-10, "RSS", "environment_memory", "PASS" if process_tensor_memory.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "process_tensor_spatial_temporal_prediction", "ProcessTensorMemory", "maximum two-qubit multitime intervention Frobenius gap",
                    process_tensor_memory.spatial_temporal_prediction_gap, 1e-10, "RSS", "environment_memory", "PASS" if process_tensor_memory.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "real_calibration_markov_cptp", "ProcessTensorDigitalTwin", "Kraus completeness Frobenius gap from the real-device-derived calibration snapshot",
                    0.0 if process_tensor_memory.digital_twin_status.startswith("PASS") else None, 1e-10, "MAX", "calibration_cptp", "PASS" if process_tensor_memory.digital_twin_status.startswith("PASS") else "FAIL",
                ),
                QuantumErrorAllocation(
                    "bounded_magic_state_reference", "BoundedMagicInjectionRuntime", "state-vector 2-norm after phase alignment",
                    stabilizer_magic.bounded_magic.phase_aligned_state_gap, self.spec.quantum_magic_reference_tolerance,
                    "RSS", "state_reference", "PASS" if stabilizer_magic.bounded_magic.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "camps_bounded_state_reference", "CliffordAugmentedMPS", "state-vector 2-norm after phase alignment",
                    camps_runtime.bounded_exact.phase_aligned_state_gap, 1e-10,
                    "RSS", "state_reference", "PASS" if camps_runtime.bounded_exact.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "camps_structured_200_truncation", "CliffordAugmentedMPS", "maximum holdout discarded squared singular-value weight",
                    max(item.camps_discarded_weight for item in camps_runtime.scalable_holdouts), 1e-10,
                    "SUM", "state_representation", "PASS" if all(item.passed for item in camps_runtime.scalable_holdouts) else "FAIL",
                ),
                QuantumErrorAllocation(
                    "cayley_bath_mapping_hybridization", "CayleyBathMapping", "maximum star/tree hybridization-function absolute gap",
                    cayley_impurity_runtime.mapping.star_tree_hybridization_gap, 2e-10,
                    "MAX", "bath_mapping", "PASS" if cayley_impurity_runtime.mapping.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "interacting_siam_ground_state_reference", "InteractingSIAMCayleyTTN", "absolute ground-state energy gap against exact diagonalization",
                    cayley_impurity_runtime.ground_state.energy_gap, 1e-4,
                    "RSS", "state_reference", "PASS" if cayley_impurity_runtime.ground_state.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "interacting_siam_real_time_reference", "InteractingSIAMCayleyTTN", "phase-aligned state-vector 2-norm at the refined second-order time step",
                    cayley_impurity_runtime.real_time_tebd.fine_state_gap, 2e-4,
                    "RSS", "time_discretization", "PASS" if cayley_impurity_runtime.real_time_tebd.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "interacting_siam_green_sum_rule", "InteractingSIAMGreenFunction", "absolute first spectral-moment sum-rule gap",
                    cayley_impurity_runtime.green_function.spectral_first_moment_gap, 2e-10,
                    "MAX", "spectral_sum_rule", "PASS" if cayley_impurity_runtime.green_function.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "cayley_bath_continuum_discretization", "CayleyBathDiscretization", "fine-grid continuum hybridization absolute gap",
                    cayley_impurity_runtime.bath_discretization.fine_continuum_hybridization_gap, 5e-6,
                    "SEPARATE", "bath_discretization", "PASS" if cayley_impurity_runtime.bath_discretization.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "trajectory_sampling", "QuantumTrajectories", "maximum standard error",
                    matter.scalable_open_dynamics.maximum_sampling_standard_error, 0.5, "RSS", "sampling", "PASS" if matter.scalable_open_dynamics.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "trajectory_density_reference", "QuantumTrajectories", "Frobenius norm",
                    matter.scalable_open_dynamics.small_system_density_gap, 0.08, "RSS", "state_reference", "PASS" if matter.scalable_open_dynamics.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "slicing_norm_crosscheck", "TensorNetworkContractionEngine", "absolute scalar difference",
                    matter.general_graph_contraction_control.contraction_norm_crosscheck_gap, 1e-10, "MAX", "slicing_exactness", "PASS" if matter.general_graph_contraction_control.passed else "FAIL",
                ),
                QuantumErrorAllocation(
                    "trotter_step_doubling", "AdaptiveQuantumDynamics", "one-site reduced-density Frobenius difference",
                    matter.scalable_closed_dynamics.trotter_step_doubling_gap, 5e-2, "RSS", "time_discretization", "PASS" if matter.scalable_closed_dynamics.passed else "FAIL",
                ),
            )
        )

        control_gates = {
            "model_identity": True,
            "physical_law_table_registry_and_theorem_qualification": law_table.passed,
            "finite_quantum_unitarity": matter.bounded_four_level_reference.closed_passed,
            "finite_quantum_CPTP": matter.bounded_four_level_reference.open_passed,
            "fifty_qubit_simplicial_mps_dynamics": matter.scalable_closed_dynamics.passed,
            "fifty_qubit_open_trajectory_dynamics": matter.scalable_open_dynamics.passed,
            "processor_circuit_noise_readout_memory_and_toric_qec": matter.processor_emulator.passed,
            "openqasm3_dynamic_classical_feedback_and_timing": (
                matter.processor_emulator.dynamic_feedforward_gap is not None
                and matter.processor_emulator.dynamic_feedforward_gap < 1e-11
                and matter.processor_emulator.dynamic_measurement_count >= 2
                and matter.processor_emulator.dynamic_loop_iterations >= 1
                and matter.processor_emulator.dynamic_branch_count >= 1
            ),
            "openpulse_qutrit_transmon_and_cross_resonance": (
                matter.processor_emulator.pulse_control is not None
                and matter.processor_emulator.pulse_control.passed
            ),
            "native_cpp_openmp_statevector_accelerator": (
                matter.processor_emulator.accelerator_qualification is not None
                and matter.processor_emulator.accelerator_qualification.passed
            ),
            "adaptive_general_quantum_jump_unravelling": (
                matter.processor_emulator.adaptive_jump_control is not None
                and matter.processor_emulator.adaptive_jump_control.passed
            ),
            "circuit_level_repeated_syndrome_qec": (
                matter.processor_emulator.circuit_level_qec is not None
                and matter.processor_emulator.circuit_level_qec.passed
            ),
            "retyped_driven_open_quantum_cells": (
                matter.processor_emulator.retyped_open_systems is not None
                and matter.processor_emulator.retyped_open_systems.passed
            ),
            "bounded_mps_vs_krylov_reference": matter.exact_reference.passed,
            "general_graph_contraction_tree_and_exact_slicing": (
                matter.general_graph_contraction_control.passed
            ),
            "simplicial_matter_propagation": matter.passed,
            "regularized_measure_normalization": measure.passed
            and measure.cutoff_tail_fraction < thresholds.measure_tail_fraction,
            "coherent_boundary_normalization_and_closure": boundary.passed
            and boundary.normalization_gap < thresholds.boundary_normalization_gap
            and max(boundary.closure_residuals) < thresholds.boundary_closure_gap,
            "lorentzian_metric_causality": lorentzian.passed,
            "topology_chain_map_identity": topology.chain_map_valid,
            "topology_H0_preservation": bool(
                topology.induced_homology_ranks and topology.induced_homology_ranks[0] == 1
            ),
            "topology_H1_to_H4_coverage": refinement["S4_exact_topology"]["passed"],
            "barycentric_refinement_topology_preservation": refinement_pass,
            "relational_POVM_covariance": relational.passed
            and relational.relabel_covariance_gap < thresholds.relational_covariance_gap,
            "ponzano_regge_exact_identity": orthogonality.exact_pass,
            "spectral_estimator_cross_backend": (
                max(ds1.backend_disagreement, ds2.backend_disagreement)
                < thresholds.heat_kernel_backend_gap
            ),
            "tensor_svd_error_identity": tensor_cert.certified_bound_gap < thresholds.tensor_identity_gap,
            "frg_R2_polynomial_reproduction": (
                frg_r2.beta_residual < thresholds.fixed_point_residual and frg_r2.fixed_point > 0
            ),
            "frg_selected_order_comparison": (
                frg_selected_order_spread < thresholds.selected_frg_order_spread
            ),
            "regge_dimensional_scaling_identity": (
                abs(regge_scaling.action_ratio - regge_scaling.expected_action_ratio)
                < thresholds.regge_scaling_gap
                and abs(regge_scaling.curvature_ratio - regge_scaling.expected_curvature_ratio)
                < thresholds.regge_scaling_gap
                and regge_scaling.invariant_r_sqrt_v_gap < thresholds.regge_scaling_gap
            ),
            "regge_equations_of_motion_control": (
                regge_equations.passed
                and regge_equations.equilateral_gradient_norm < thresholds.regge_equation_residual
            ),
            "persistent_adaptive_ttn_bounded_reference": adaptive_ttn.status.startswith("PASS"),
            "persistent_adaptive_ttn_structured_50_qubit_path_update": scalable_adaptive_ttn.passed,
            "persistent_adaptive_ttn_structured_50_qubit_hamiltonian_dynamics": structured_ttn_hamiltonian.passed,
            "high_treewidth_general_graph_contraction_fallback": high_treewidth_fallback.passed,
            "cptp_tensor_train_one_dimensional_open_dynamics": cptp_tensor_train_runtime.passed,
            "basis_adaptive_sparse_pure_state_dynamics": basis_adaptive_sparse_runtime.passed,
            "adversarial_representation_portfolio": adversarial_representation["status"] == "PASS_BOUNDED_ADVERSARIAL_REPRESENTATION_BENCHMARK",
            "fermionic_gaussian_covariance_dynamics": fermionic_gaussian_runtime.passed,
            "schwarzschild_4d_radial_modes_and_finite_time_reduced_dynamics": schwarzschild_4d.passed,
            "phase_polynomial_decision_diagram_low_linear_rank_width": phase_decision_diagram.passed,
            "code_compiled_diagonal_permutation_tensor_network": code_compiled_tn.passed,
            "phi_q1000_adaptive_resource_factorized_owner": phi_q1000_arfe.passed,
            "compiler_method_portfolio_owner_binding": quantum_portfolio.passed,
            "intervention_complete_process_tensor_memory": process_tensor_memory.passed,
            "single_qubit_generator_learning_control": generator_learning.passed,
            "large_clifford_stabilizer_tableau_control": stabilizer_magic.large_clifford.passed,
            "bounded_exact_magic_injection_control": stabilizer_magic.bounded_magic.passed,
            "clifford_augmented_mps_bounded_and_structured_200_control": camps_runtime.passed,
            "bounded_interacting_spinful_siam_cayley_ttn_runtime": cayley_impurity_runtime.passed,
            "certified_error_interference_control": error_interference.status == "PASS_CERTIFIED_INTERFERENCE_BOUND",
            "unified_quantum_error_budget": unified_quantum_error_budget.status.startswith("PASS"),
            "real_cpu_backend_qualification": backend_qualification.cpu.status == "PASS",
        }
        control_failed = [name for name, passed in control_gates.items() if not passed]

        target_requirements = {
            "lorentzian_eprl_single_vertex_coherent_family": _requirement(
                _probe_requirement_status(eprl_single.status),
                "Execute the normalized coherent boundary family on a real Lorentzian EPRL vertex.",
                f"backend_status={eprl_single.status}; {eprl_single.reason}",
            ),
            "lorentzian_eprl_delta3_three_vertex": _requirement(
                _probe_requirement_status(eprl_three.status),
                "Execute the published Delta3 three-vertex, one-internal-face Lorentzian EPRL contraction.",
                f"backend_status={eprl_three.status}; {eprl_three.reason}",
            ),
            "microscopic_measure_derivation": _requirement(
                "PARTIAL",
                "Derive or uniquely fix the active regularized measure and remove regulator dependence.",
                (
                    f"Finite measure is executable; cutoff tail fraction={measure.cutoff_tail_fraction:.6g}; "
                    f"scheme log-partition spread={measure.scheme_partition_spread:.6g}; "
                    f"derivation={self.spec.measure_derivation_status}."
                ),
            ),
            "physical_boundary_state_family": _requirement(
                "PARTIAL",
                "Extend the normalized LS scale family to shape-matched Lorentzian semiclassical and relational states.",
                (
                    f"Normalization and node closure pass; shape matching remains {boundary.shape_matching_status}."
                ),
            ),
            "causal_vertex_amplitude": _requirement(
                "OPEN",
                "Implement and validate a causal Lorentzian vertex rather than infer target causality from boundary geometry.",
                self.spec.causal_vertex_status,
            ),
            "matter_sector": _requirement(
                "PARTIAL",
                "Construct anomaly-consistent quantum fields and determine whether Standard-Model gauge and matter data are derived.",
                self.spec.matter_derivation_status,
            ),
            "relational_observables": _requirement(
                "PARTIAL",
                "Lift the finite covariant POVM control to physical spin-foam/GFT relational observables and measurement channels.",
                self.spec.relational_qg_status,
            ),
            "regge_to_GR": _requirement(
                "PARTIAL",
                "Establish shape-regular refinement convergence of Regge solutions and physical correlators to GR.",
                (
                    f"Full edge-length EOM control residual={regge_equations.equilateral_gradient_norm:.6g}; "
                    "continuum convergence remains open."
                ),
            ),
            "eprl_target_tensor_coarse_graining": _requirement(
                (
                    "PASS"
                    if target_tensor_single["status"] == "PASS" and target_tensor_delta3["status"] == "PASS"
                    else (
                        "FAIL_TARGET_TENSOR_PIPELINE"
                        if str(target_tensor_single["status"]).startswith("FAIL")
                        or str(target_tensor_delta3["status"]).startswith("FAIL")
                        else (
                            "PARTIAL"
                            if str(target_tensor_single["status"]).startswith("PARTIAL")
                            or str(target_tensor_delta3["status"]).startswith("PARTIAL")
                            else "BLOCKED_EXTERNAL_BACKEND"
                        )
                    )
                ),
                "Feed only shell-stable, provenance-admitted official Lorentzian EPRL tensors into the sole N-dimensional SVD owner.",
                (
                    f"single={target_tensor_single['status']}; delta3={target_tensor_delta3['status']}; "
                    "Delta3 artifacts are constituent vertex tensors, while the graph amplitude is certified separately."
                ),
            ),
            "multi_complex_renormalization": _requirement(
                "PARTIAL" if target_tensor_delta3["status"] == "PASS" else "OPEN",
                "Iterate physical EPRL coarse-graining over multiple inequivalent refinement families.",
                (
                    "Shell-stable Delta3 constituent vertex tensors entered the authoritative SVD owner; graph-level repeated RG/refinement remains open."
                    if target_tensor_delta3["status"] == "PASS"
                    else "The target tensor pipeline remains unavailable until official EPRL artifacts pass provenance and shell-stability admission."
                ),
            ),
            "discretization_independence": _requirement(
                "OPEN",
                "Demonstrate agreement of physical target observables across inequivalent triangulations and refinement paths.",
                "Topology is preserved under bounded barycentric controls; target amplitudes are not yet compared.",
            ),
            "continuum_limit": _requirement(
                "OPEN",
                "Construct a physical distributional/refinement continuum limit without collapsing the dynamics to a topological theory.",
                self.spec.continuum_status,
            ),
            "physical_inner_product_and_unitarity": _requirement(
                "OPEN",
                "Construct a positive physical inner product and prove target composition/unitarity.",
                self.spec.physical_inner_product_status,
            ),
            "frg_full_flow_and_matching": _requirement(
                "OPEN",
                "Execute coupled regulator/gauge/parametrization/matter flows and match them to microscopic spin-foam coarse-graining.",
                "Only two cited finite essential-coupling polynomials are reproduced.",
            ),
            "distinctive_experimental_prediction": _requirement(
                "OPEN",
                "Derive an observable discriminant against GR+EFT, CDT, asymptotic safety and other spin-foam models.",
                "No unique experiment-facing prediction is produced.",
            ),
        }
        target_failed = [name for name, item in target_requirements.items() if item["status"].startswith("FAIL")]
        target_blocked = [name for name, item in target_requirements.items() if item["status"].startswith("BLOCKED")]
        target_open = [name for name, item in target_requirements.items() if item["status"] == "OPEN"]
        target_partial = [name for name, item in target_requirements.items() if item["status"] == "PARTIAL"]
        target_passed = [name for name, item in target_requirements.items() if item["status"] == "PASS"]

        if control_failed:
            verdict = "QUANTUM_EMULATOR_CONTROL_FAIL"
            evidence_grade = "INVALID"
        elif target_failed:
            verdict = "TARGET_BACKEND_OR_CONTRACT_FAIL"
            evidence_grade = "EVIDENCE_TABLE_BOUND_ATLAS_BOUNDED_OPENQASM3_PULSE_QEC_50_QUBIT_QG_CONTROL_VALIDATION"
        elif target_blocked:
            verdict = "QUANTUM_EMULATOR_CONTROL_PASS_TARGET_EPRL_BLOCKED"
            evidence_grade = "EVIDENCE_TABLE_BOUND_ATLAS_BOUNDED_OPENQASM3_PULSE_QEC_50_QUBIT_QG_CONTROL_VALIDATION"
        elif (
            target_requirements["lorentzian_eprl_single_vertex_coherent_family"]["status"] == "PARTIAL"
            or target_requirements["lorentzian_eprl_delta3_three_vertex"]["status"] == "PARTIAL"
        ):
            verdict = "TARGET_EPRL_EXECUTED_SHELL_STABILITY_INCOMPLETE"
            evidence_grade = "MICROSCOPIC_TARGET_EXECUTION_PARTIAL"
        else:
            verdict = "TARGET_MICROSCOPIC_COHERENT_AMPLITUDES_EXECUTED_CONTINUUM_OPEN"
            evidence_grade = "MICROSCOPIC_TARGET_EXECUTION"

        result: dict[str, Any] = {
            "schema": "qpdtr-phiqg-execution-bundle-current",
            "release": "2.5.0",
            "source_digest": _source_digest(),
            "started_utc": started,
            "completed_utc": datetime.now(timezone.utc).isoformat(),
            "system_description": {
                "purpose": (
                    "A fail-closed bounded quantum emulator and quantum-gravity research runtime. "
                    "It evolves finite quantum states, validates current geometric/mathematical owners, "
                    "and admits Lorentzian EPRL target evidence only through a provenance-bound backend."
                ),
                "solved_tasks": [
                    "execute bounded exact unitary/GKSL references with a single cached channel and Choi reshuffle",
                    "contract intervention-complete temporal memory with a site-factorized two-qubit space-time TT/MPS process tensor under one enforced error ledger",
                    "execute PHI-Q1000-ARFE exact causal-cone reduction, sparse Heisenberg Pauli propagation and exact 1000-node tree graph-TN belief propagation under typed boundary contracts",
                    "build a CPTP Markov process-tensor baseline from a public real-device IBM Manila calibration snapshot while blocking non-Markovian identification without multitime counts",
                    "execute a 50-local-qubit simplicial matter sector with matrix-free routing, MPS/TEBD and dephasing trajectories",
                    "cross-check the MPS path against an independent Krylov state-vector reference on bounded registers",
                    "execute a bounded general-graph contraction-tree control with explicit path planning, exact index slicing, threaded slice reduction and independent Krylov agreement",
                    "expose one contraction owner for NumPy CPU and optional real-device CuPy/MPI execution without emulating unavailable accelerators",
                    "validate a non-degenerate metric Lorentzian bi-simplex and time orientation",
                    "execute a normalized isotropic Livine-Speziale coherent boundary family",
                    "normalize a regularized finite EPRL candidate measure and estimate cutoff tail",
                    "compute exact GF(2) homology, induced maps and topology through H4",
                    "validate topology preservation under barycentric refinement through S3",
                    "execute a finite relational POVM observable with relabel covariance",
                    "verify exact Ponzano-Regge/Wigner-6j controls",
                    "validate a spectral-dimension estimator on known lattices",
                    "certify the finite SVD truncation identity",
                    "reproduce cited finite FRG beta polynomials and roots",
                    "execute general edge-length Regge equations and dimensional scaling",
                    "enforce immutable commit/source/binary/module/table/build provenance for sl2cfoam-next",
                    "execute adaptive shell windows and distinguish finite stability estimators from rigorous tail bounds",
                    "admit target SVD only after amplitude and last-two-shell tensor stability",
                    "encode the published Delta3 three-vertex cyclic contraction without an amplitude surrogate",
                    "feed admitted rank-5 EPRL tensors into the existing N-dimensional SVD owner",
                    "publish typed, non-aggregated error evidence",
                    "execute a persistent adaptive TTN bounded reference with graph-driven topology rebuilding and controlled hierarchical SVD truncation",
                    "execute a statevector-free structured 50-qubit persistent TTN with arbitrary two-site path exposure, local tree rotations, controlled truncation and global GHZ correlation certificates",
                    "execute statevector-free 50-qubit noncommuting low-treewidth Hamiltonian dynamics on a pair-forest interaction graph with Trotter-refinement, energy, entropy and truncation certificates",
                    "route an eight-qubit complete-graph high-treewidth control through the general contraction-tree fallback and cross-check it against independent Krylov evolution",
                    "execute a locally purified nearest-neighbour one-dimensional GKSL tensor-train owner with exact dense reference, time-step/rank refinement, constructive positivity, trace control and statevector-free scalable controls",
                    "execute a basis-adaptive top-k sparse-state owner with an exact bounded reference, fixed-basis adversary, participation-ratio guard and statevector-free scalable control",
                    "route adversarial structural classes through the certified owner portfolio without treating one width measure as universal",
                    "execute an exact quasi-free fermionic Gaussian covariance owner with dense Jordan-Wigner equality, Wick reconstruction, Lyapunov steady-state and 128-mode statevector-free controls",
                    "execute a bounded multi-terminal phase-polynomial decision-diagram owner on a 64-variable complete interaction graph with treewidth 63 and linear cut-rank 1",
                    "execute a verified diagonal-plus-permutation code-compiled MPS schedule for 256 qubits and 512 layers without bond growth after encoding",
                    "select among code-compiled, decision-diagram, stabilizer, Gaussian, locally purified GKSL, basis-adaptive sparse, TEMPO, TTN and general-TN owners using constructive certificates and multiple structural indicators",
                    "execute bounded 3+1D Schwarzschild scalar Regge-Wheeler radial mode sums with adaptive angular cutoff, greybody flux checks and nested 17/33/65 finite-time reduced-dynamics refinement",
                    "bind compiler-selected computational-method identifiers to the single current QPDTR owner portfolio without silently qualifying unavailable accelerators",
                    "execute a bounded intervention-complete process-tensor tensor train with reusable controls, projective conditioning, resets, causal-break memory witness and temporal compression certificate",
                    "execute blind synthetic single-qubit Hamiltonian/Lindbladian generator learning with uncertainty propagation to held-out observables",
                    "execute an exact 1000-qubit Clifford tableau with H/S/CNOT/Pauli gates and computational-basis measurements without state-vector materialization",
                    "execute an exact bounded T-gate injection decomposition T=(alpha I+beta Z) and compare the branch sum to an independent state-vector reference",
                    "execute a symplectic Clifford-frame plus residual-MPS CAMPS owner, with exact bounded equality and three statevector-free 200-qubit structured holdouts against ordinary MPS",
                    "execute a bounded interacting spinful SIAM Cayley-TTN owner with exact star/chain/tree equivalence, imaginary-time ground-state preparation, second-order real-time evolution, Green-function sum rules, a structured 26-qubit statevector-free holdout and bath-discretization refinement",
                    "execute a certified common-norm error-interference control while retaining the triangle bound whenever cross-error geometry is not certified",
                    "bind TTN, process-tensor temporal compression, intervention prediction, trajectory and slicing errors to one typed budget",
                    "qualify the real CPU backend and fail closed for unavailable CUDA/MPI backends",
                    "run optional external differential qualification against Qiskit Aer, QuTiP, ITensorMPS.jl, Stim/PyMatching and provenance-bound sl2cfoam-next without substituting unavailable tools",
                    "separate host performance telemetry from the deterministic semantic execution digest",
                    "bind all 9,383 table cells to the v3.0 proof ladder and canonical theorem-owner contracts",
                    "execute theorem-backed quantum-information, topology and stochastic-measurement certificates mapped to exact table Cell IDs",
                    "reject simulation-only promotion and expose deterministic nonlinear ensemble dependence as a no-signalling counterexample",
                ],
                "not_solved": [
                    "the full PhiQG sum over complexes and a unique microscopic measure",
                    "a causal Toller-matrix EPRL backend",
                    "shape-matched physical Lorentzian boundary-state completeness",
                    "execution of the immutable-provenance official EPRL backend in this environment",
                    "an iterated EPRL refinement/renormalization flow beyond admitted single/Delta3 tensors",
                    "a regulator-independent physical continuum limit",
                    "target physical inner product and unitarity",
                    "derivation of the Standard Model",
                    "arbitrary exact strongly entangled 50-qubit evolution on commodity hardware",
                    "qualification and performance evidence on real CUDA multi-GPU or MPI cluster hardware",
                    "device-level fault-tolerance qualification with noisy gates, measurements, leakage and an asymptotic threshold study",
                    "efficient arbitrary volume-law or sustained high-treewidth TTN dynamics beyond the qualified low-Schmidt-rank structured workload",
                    "general many-qubit ansatz-free Lindbladian learning from physical experimental data",
                    "two-dimensional, long-range or nonlocal-jump locally purified GKSL tensor-train evolution beyond the qualified one-dimensional local owner",
                    "basis-adaptive sparse simulation for mixed states, generic volume-law states or states delocalized in every local product basis",
                    "fermionic Gaussian pairing/Bogoliubov dynamics, interactions and non-Gaussian jumps beyond the qualified number-conserving quasi-free owner",
                    "continuum-bath and many-qubit process-tensor MPO scaling beyond the qualified bounded qubit-memory intervention-complete control",
                    "arbitrary-placement or two-dimensional moderate-magic CAMPS scaling outside the qualified structured one-dimensional holdout family",
                    "generic interacting SIAM Cayley-TTN scaling beyond the qualified finite-bath exact-control and structured 26-qubit holdout, including long-time volume-law growth, finite temperature, multiorbital models, DMFT self-consistency and linear-prediction spectral reconstruction",
                    "full stabilizer-tensor-network magic injection beyond the bounded exact branch runtime",
                    "full 4D Wightman reconstruction, generic process-tensor tomography and regulator-free convergence of arbitrary reduced dynamics",
                    "arbitrary sustained high-treewidth or volume-law tensor-network scaling",
                    "generic decision-diagram simulation without a verified phase-polynomial lowering or bounded diagram size",
                    "automatic discovery or proof of CSS code automorphisms for code-compiled tensor-network schedules",
                    "a distinctive experimentally confirmed prediction",
                    "complete external differential qualification when Qiskit Aer, QuTiP, Julia/ITensorMPS.jl or the pinned sl2cfoam-next runtime are unavailable",
                    "promote any table cell from computational self-consistency to a new physical law without independent held-out experimental evidence",
                ],
            },
            "model_spec": self.spec.to_dict(),
            "control_evidence": {
                "physical_law_table_v3": law_table.to_dict(),
                "quantum_matter_emulator": matter.to_dict(),
                "persistent_adaptive_ttn_bounded_reference": adaptive_ttn.to_dict(),
                "persistent_adaptive_ttn_structured_50_qubit": scalable_adaptive_ttn.to_dict(),
                "persistent_adaptive_ttn_structured_50_qubit_hamiltonian_dynamics": structured_ttn_hamiltonian.to_dict(),
                "high_treewidth_general_graph_contraction_fallback": high_treewidth_fallback.to_dict(),
                "cptp_tensor_train_runtime": cptp_tensor_train_runtime.to_dict(),
                "basis_adaptive_sparse_runtime": basis_adaptive_sparse_runtime.to_dict(),
                "adversarial_representation_benchmark": adversarial_representation,
                "fermionic_gaussian_runtime": fermionic_gaussian_runtime.to_dict(),
                "schwarzschild_4d_radial_modes": schwarzschild_4d.to_dict(),
                "phase_polynomial_decision_diagram": phase_decision_diagram.to_dict(),
                "code_compiled_tensor_network": code_compiled_tn.to_dict(),
                "phi_q1000_adaptive_resource_factorized_emulator": phi_q1000_arfe.to_dict(),
                "quantum_method_portfolio": quantum_portfolio.to_dict(),
                "process_tensor_memory": process_tensor_memory.to_dict(),
                "bounded_generator_learning": generator_learning.to_dict(),
                "stabilizer_magic_runtime": stabilizer_magic.to_dict(),
                "clifford_augmented_mps_runtime": camps_runtime.to_dict(),
                "cayley_tree_impurity_runtime": cayley_impurity_runtime.to_dict(),
                "certified_error_interference": error_interference.to_dict(),
                "real_backend_qualification": backend_qualification.to_dict(),
                "unified_quantum_error_budget": unified_quantum_error_budget.to_dict(),
                "lorentzian_metric_geometry": lorentzian.to_dict(),
                "coherent_boundary_family": boundary.to_dict(),
                "regularized_microscopic_measure": measure.to_dict(),
                "topology_transfer": asdict(topology),
                "topology_and_refinement_suite": refinement,
                "relational_observable": relational.to_dict(),
                "spectral_estimator": {
                    "cycle_1d": ds1.to_dict(),
                    "torus_2d": ds2.to_dict(),
                    "plateau_1d": plateau_1d,
                    "plateau_2d": plateau_2d,
                },
                "ponzano_regge": {
                    "orthogonality": orthogonality.to_dict(),
                    "equilateral_asymptotic": asymptotic.to_dict(),
                    "cross_backend": cross6j.to_dict(),
                },
                "tensor_svd_control": tensor_cert.to_dict()
                | {
                    "spin_labels_twice": list(spin_labels),
                    "fixture": "damped_SU2_recoupling_control_not_PhiQG_RG",
                },
                "frg_selected_polynomials": {
                    "R2": frg_r2.to_dict(),
                    "R5": frg_r5.to_dict(),
                    "critical_exponent_spread": frg_selected_order_spread,
                },
                "regge": {
                    "regular_geometry": regge.to_dict(),
                    "dimensional_scaling": regge_scaling.to_dict(),
                    "equations_of_motion": regge_equations.to_dict(),
                },
            },
            "target_evidence": {
                "eprl_single_vertex_coherent_family": eprl_single.to_dict(),
                "eprl_delta3_three_vertex_one_internal_face": eprl_three.to_dict(),
                "single_vertex_target_tensor_coarse_graining": target_tensor_single,
                "delta3_target_tensor_coarse_graining": target_tensor_delta3,
            },
            "external_differential_benchmarks": differential_benchmarks.to_dict(),
            "admitted_vertex_amplitude_cache": vertex_cache_evidence,
            "error_budget": error_budget.to_dict(),
            "control_gates": control_gates,
            "control_summary": {
                "passed": sum(bool(value) for value in control_gates.values()),
                "total": len(control_gates),
                "failed": control_failed,
            },
            "target_requirements": target_requirements,
            "target_summary": {
                "passed": target_passed,
                "partial": target_partial,
                "blocked": target_blocked,
                "failed": target_failed,
                "open": target_open,
            },
            "evidence_grade": evidence_grade,
            "verdict": verdict,
            "claim_boundary": (
                "The runtime binds the full 9,383-cell v3.0 law table to explicit proof levels and executes theorem-backed quantum-law certificates. It also executes exact bounded references, a certified 50-local-qubit structured MPS/trajectory sector, "
                "a bounded general-graph contraction-tree control, a bounded persistent adaptive TTN reference, a current Clifford-augmented MPS control with structured 200-qubit holdouts, a bounded interacting spinful SIAM Cayley-TTN control with exact finite-bath references and a structured 26-qubit statevector-free holdout, an intervention-complete process-tensor memory control, and a processor circuit/noise/readout/memory/toric-QEC control. "
                "The current environment qualifies the native C++17/OpenMP CPU backend only; it does not claim arbitrary exact 50-qubit evolution, qualified "
                "CUDA/multi-GPU/MPI performance, circuit-level fault tolerance, a quantum-gravity law, continuum theory, Standard Model derivation, or experimental truth. Successful emulation validates the implementation and declared assumptions; it is not by itself proof of a new law."
            ),
        }
        completed = result.pop("completed_utc")
        started_value = result.pop("started_utc")
        split = split_semantic_payload(result)
        semantic_result = split.semantic_payload
        semantic_result["semantic_digest_schema"] = "qpdtr-semantic-execution-v2"
        semantic_result["execution_digest"] = _digest(semantic_result)
        performance_telemetry = {
            "schema": "qpdtr-performance-telemetry-v1",
            "started_utc": started_value,
            "completed_utc": completed,
            "metrics": split.performance_metrics,
            "excluded_from_execution_digest": True,
        }
        final_result = semantic_result | {"performance_telemetry": performance_telemetry}
        (report_path / "EXECUTION_BUNDLE.json").write_text(
            json.dumps(final_result, indent=2, ensure_ascii=False, sort_keys=True, default=_json_default),
            encoding="utf-8",
        )
        (report_path / "LAW_TABLE_QUALIFICATION.json").write_text(
            json.dumps(
                semantic_result["control_evidence"]["physical_law_table_v3"],
                indent=2,
                ensure_ascii=False,
                sort_keys=True,
                default=_json_default,
            ),
            encoding="utf-8",
        )
        (report_path / "DIFFERENTIAL_BENCHMARK.json").write_text(
            json.dumps(
                semantic_result["external_differential_benchmarks"],
                indent=2,
                ensure_ascii=False,
                sort_keys=True,
                default=_json_default,
            ),
            encoding="utf-8",
        )
        self._write_plots(final_result, report_path)
        return final_result

    @staticmethod
    def _write_plots(result: dict[str, Any], report_path: Path) -> None:
        spectral = result["control_evidence"]["spectral_estimator"]
        plt.figure(figsize=(8, 5))
        plt.semilogx(
            spectral["cycle_1d"]["sigmas"],
            spectral["cycle_1d"]["spectral_dimensions"],
            label="1D cycle control",
        )
        plt.semilogx(
            spectral["torus_2d"]["sigmas"],
            spectral["torus_2d"]["spectral_dimensions"],
            label="2D torus control",
        )
        plt.xlabel("diffusion time sigma")
        plt.ylabel("spectral dimension")
        plt.title("Spectral-estimator ground-truth controls")
        plt.legend()
        plt.tight_layout()
        plt.savefig(report_path / "spectral_dimension_controls.png", dpi=170)
        plt.close()

        g = np.linspace(0.0, 4.0, 500)
        plt.figure(figsize=(8, 5))
        plt.plot(g, [beta_newton_r2(x) for x in g], label="selected O(R²) polynomial")
        plt.plot(g, [beta_newton_r5(x) for x in g], label="selected O(R⁵) polynomial")
        plt.axhline(0.0, linewidth=1)
        plt.xlabel("dimensionless Newton coupling g")
        plt.ylabel("beta_g")
        plt.title("Reproduced finite essential Newton-coupling polynomials")
        plt.legend()
        plt.tight_layout()
        plt.savefig(report_path / "frg_fixed_points.png", dpi=170)
        plt.close()

        boundary = result["control_evidence"]["coherent_boundary_family"]
        q = [entry["twice_spins"][0] for entry in boundary["configurations"]]
        probability = [entry["probability"] for entry in boundary["configurations"]]
        plt.figure(figsize=(8, 5))
        plt.bar(q, probability)
        plt.xlabel("twice spin q=2j")
        plt.ylabel("boundary-state probability")
        plt.title("Normalized coherent boundary scale family")
        plt.tight_layout()
        plt.savefig(report_path / "coherent_boundary_family.png", dpi=170)
        plt.close()

        matter = result["control_evidence"]["quantum_matter_emulator"]
        probabilities = matter["scalable_open_dynamics"]["mean_excitation_probability"]
        plt.figure(figsize=(9, 5))
        plt.bar(range(matter["qubit_count"]), probabilities)
        plt.xlabel("simplicial qubit vertex")
        plt.ylabel("trajectory-ensemble excitation probability")
        plt.title("Structured 50-qubit simplicial matter propagation")
        plt.tight_layout()
        plt.savefig(report_path / "quantum_matter_probabilities.png", dpi=170)
        plt.close()
