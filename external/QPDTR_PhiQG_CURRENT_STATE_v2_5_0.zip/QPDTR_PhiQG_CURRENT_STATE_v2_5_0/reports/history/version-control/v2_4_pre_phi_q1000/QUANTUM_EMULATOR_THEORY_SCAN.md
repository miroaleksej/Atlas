# Сканирование теорий квантового эмулятора — QPDTR/ΦQG v2.4.0

## Действующий owner

`qpdtr.domains.quantum_gravity.tempo.qualify_process_tensor_memory`

Временной process tensor и пространственная факторизация объединены в одну TT/MPS-структуру. Старого параллельного transfer-tensor алгоритма нет; прежние имена — только тонкие совместимые вызовы active owner.

## Пространственно-временной сертификат

- системных кубитов: **2**;
- временных слотов вмешательств: **2**;
- элементов точного тензора: **1,048,576**;
- физические ноги: `(16, 16, 16, 16, 4, 4)`;
- TT/MPS-ранги: `(1, 4, 16, 64, 16, 4, 1)`;
- максимальный bond: **64**;
- порядок: `TIME_MAJOR_SITE_FACTORED_TT_MPS`;
- ошибка сжатия: **2.444874e-15**;
- ошибка прогноза: **3.680593e-15**.

\[
\rho_S^{(n)}=\mathcal T_{n:0}[\mathcal A_{n-1},\ldots,\mathcal A_0].
\]

## Единый бюджет ошибки

\[
\epsilon_{\rm total}\le
\epsilon_{\rm temporal\,compression}+
\epsilon_{\rm temporal\,prediction}+
\epsilon_{\rm spacetime\,compression}+
\epsilon_{\rm spacetime\,prediction}.
\]

Наблюдаемая граница: **6.953177e-15**.  
Выделенный бюджет: **2.000000e-10**.  
Статус: `PASS_UNIFIED_SPATIAL_TEMPORAL_ERROR_BUDGET`.

## Digital twin

- backend: `ibmq_manila`;
- timestamp снимка: `2024-05-27T15:27:23-03:00`;
- Markov CPTP baseline: `PASS_REAL_CALIBRATION_SNAPSHOT_MARKOV_PROCESS_TENSOR_BASELINE`;
- non-Markov identification: `BLOCKED_MULTITIME_CALIBRATION_DATA_REQUIRED`.

Это публичный снимок свойств реального устройства, а не текущая live-калибровка. Он не содержит multitime intervention/outcome counts и covariance, поэтому аппаратная память не выводится из T1/T2 и gate errors.

## Causal-break control

- memory witness: **0.0441303890322**;
- Markov reset control: **0**.

## Граница

```text
NEW_PHYSICAL_THEORIES_CONFIRMED:       0
ACTIVE_OWNER_INTEGRATION:              PASS_BOUNDED_SPATIAL_TEMPORAL_PROCESS_TENSOR_TTN
REAL_DEVICE_DERIVED_SNAPSHOT:          USED
LIVE_DEVICE_CALIBRATION:               NOT_USED
NON_MARKOVIAN_HARDWARE_TWIN:           BLOCKED_MULTITIME_CALIBRATION_DATA_REQUIRED
ARBITRARY_MANY_QUBIT_CONTINUUM_BATH:   NOT_IMPLEMENTED
```
