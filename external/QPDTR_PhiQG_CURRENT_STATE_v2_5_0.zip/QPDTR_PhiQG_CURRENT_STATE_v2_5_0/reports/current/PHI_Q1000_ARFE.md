# PHI-Q1000-ARFE — активный сертификат

- owner: `PHI-Q1000-ARFE`
- status: `PASS_PHI_Q1000_ADAPTIVE_RESOURCE_FACTORIZED_EMULATOR`
- exact input qubits: **1000**
- retained causal qubits: **16**
- causal reduction: `PASS_EXACT_BACKWARD_CAUSAL_CONE`
- Pauli status: `PASS_PAULI_OBSERVABLE_PROPAGATION`
- Pauli dropped L1 bound: **0.0000000000000000e+00**
- graph-BP status: `PASS_GRAPH_TENSOR_BP`
- graph nodes: **1000**
- graph reference gap: **3.3306690738754696e-15**
- unified error ledger: `PASS_UNIFIED_SPATIAL_TEMPORAL_ERROR_BUDGET`

Generic 1000-qubit full-state, MAST и influence-functional graph-BP не являются активными путями.
